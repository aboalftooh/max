@echo off
setlocal
set APP_HOME=%~dp0
for /f "tokens=2 delims==" %%A in ('findstr /b "distributionUrl=" "%APP_HOME%gradle\wrapper\gradle-wrapper.properties"') do set DIST_URL=%%A
set DIST_URL=%DIST_URL:\:=:%
for %%F in (%DIST_URL%) do set DIST_FILE=%%~nxF
for /f "tokens=2 delims=-" %%V in ("%DIST_FILE%") do set VERSION=%%V
set BASE=%USERPROFILE%\.gradle\wrapper\dists\max-bootstrap\gradle-%VERSION%
set GRADLE_BIN=%BASE%\gradle-%VERSION%\bin\gradle.bat
set ZIP=%BASE%\gradle-%VERSION%-bin.zip
if not exist "%GRADLE_BIN%" (
  if not exist "%BASE%" mkdir "%BASE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%DIST_URL%' -OutFile '%ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%BASE%'"
)
call "%GRADLE_BIN%" -p "%APP_HOME%" %*
endlocal
