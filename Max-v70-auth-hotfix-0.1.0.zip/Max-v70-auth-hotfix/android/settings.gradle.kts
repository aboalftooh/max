pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MaxAndroid"

include(":app")
include(":core:common")
include(":core:model")
include(":core:designsystem")
include(":core:network")
include(":core:database")
include(":core:testing")
include(":feature:auth")
include(":feature:home")
include(":feature:request")
include(":feature:orders")
include(":feature:balance")
include(":feature:profile")
include(":feature:notifications")
include(":feature:invoices")
include(":feature:conversations")

include(":feature:settings")
