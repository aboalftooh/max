package com.maxnetwork.feature.auth.domain

import java.time.Instant

data class PasswordResetChallengeInfo(
    val expiresAt: Instant,
    val resendAvailableAt: Instant,
)

data class PasswordResetConfirmation(
    val resetCode: String,
    val newPassword: String,
)
