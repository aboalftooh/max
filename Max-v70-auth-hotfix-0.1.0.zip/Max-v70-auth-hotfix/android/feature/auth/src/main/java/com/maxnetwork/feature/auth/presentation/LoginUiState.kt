package com.maxnetwork.feature.auth.presentation

data class LoginUiState(
    val phone: String = "",
    val isLoading: Boolean = false,
    val error: LoginErrorKind? = null,
) {
    val canSubmit: Boolean
        get() = phone.isNotBlank() && !isLoading
}

enum class LoginErrorKind {
    RequiredPhone,
    InvalidPhone,
    Offline,
    TemporarilyLocked,
    SessionExpired,
    Generic,
}

sealed interface AuthUiEvent {
    data object Authenticated : AuthUiEvent
    data object RegistrationCodeAccepted : AuthUiEvent
    data object PhoneChallengeSent : AuthUiEvent
    data object OtpVerified : AuthUiEvent // compatibility only; active flow emits NewUserOtpVerified
    data object NewUserOtpVerified : AuthUiEvent
    data object PasswordResetCodeSent : AuthUiEvent
    data object PasswordResetCompleted : AuthUiEvent
    data object ContactSupportRequested : AuthUiEvent
}
