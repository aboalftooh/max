package com.maxnetwork.feature.auth.data

import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.SignOutReason
import java.time.Instant
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

internal class DefaultAuthSessionStore(
    private val storage: AuthTokenStorage,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val onAccessTokenChanged: (String?) -> Unit = {},
) : AuthSessionStore {
    private val mutableState = MutableStateFlow<AuthState>(AuthState.Initializing)
    private var inMemorySession: StoredAuthSession? = null

    override val state: StateFlow<AuthState> = mutableState.asStateFlow()

    override suspend fun restore(): StoredAuthSession? = withContext(ioDispatcher) {
        val restored = storage.read()
        inMemorySession = restored
        onAccessTokenChanged(restored?.accessToken)
        if (restored == null) {
            mutableState.value = AuthState.SignedOut()
        }
        restored
    }

    override suspend fun current(): StoredAuthSession? = inMemorySession ?: withContext(ioDispatcher) {
        storage.read().also {
            inMemorySession = it
            onAccessTokenChanged(it?.accessToken)
        }
    }

    override suspend fun save(session: StoredAuthSession) = withContext(ioDispatcher) {
        storage.write(session)
        inMemorySession = session
        onAccessTokenChanged(session.accessToken)
        mutableState.value = AuthState.Authenticated(session.expiresAt)
    }

    override suspend fun markAuthenticated(expiresAt: Instant) {
        mutableState.value = AuthState.Authenticated(expiresAt)
    }

    override suspend fun markRefreshing(previousExpiry: Instant?) {
        mutableState.value = AuthState.Refreshing(previousExpiry)
    }

    override suspend fun markUnavailable(retryable: Boolean) {
        mutableState.value = AuthState.TemporarilyUnavailable(retryable = retryable)
    }

    override suspend fun clear(reason: SignOutReason) = withContext(ioDispatcher) {
        storage.clear()
        inMemorySession = null
        onAccessTokenChanged(null)
        mutableState.value = AuthState.SignedOut(reason)
    }
}
