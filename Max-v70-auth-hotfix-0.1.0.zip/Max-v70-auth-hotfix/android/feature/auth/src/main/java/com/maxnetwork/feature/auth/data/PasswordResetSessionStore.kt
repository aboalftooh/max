package com.maxnetwork.feature.auth.data

import java.time.Instant
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal data class StoredPasswordResetSession(
    val phone: String,
    val expiresAt: Instant,
    val resendAvailableAt: Instant,
)

internal class PasswordResetSessionStore {
    private val mutex = Mutex()
    private var session: StoredPasswordResetSession? = null

    suspend fun replace(value: StoredPasswordResetSession) {
        mutex.withLock { session = value }
    }

    suspend fun current(): StoredPasswordResetSession? = mutex.withLock { session }

    suspend fun clear() {
        mutex.withLock { session = null }
    }
}
