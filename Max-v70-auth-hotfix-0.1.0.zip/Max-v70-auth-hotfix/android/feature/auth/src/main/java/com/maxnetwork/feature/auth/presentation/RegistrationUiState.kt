package com.maxnetwork.feature.auth.presentation

data class RegistrationCodeUiState(
    val code: String = "",
    val isLoading: Boolean = false,
    val error: RegistrationErrorKind? = null,
) {
    val canSubmit: Boolean
        get() = code.trim().length in 4..64 && !isLoading
}

data class ConfirmPhoneUiState(
    val phone: String = "",
    val isLoading: Boolean = false,
    val error: RegistrationErrorKind? = null,
) {
    val canSubmit: Boolean
        get() = phone.isNotBlank() && !isLoading
}

data class OtpUiState(
    val otp: String = "",
    val isLoading: Boolean = false,
    val isResending: Boolean = false,
    val resendSecondsRemaining: Int = 0,
    val remainingAttempts: Int = 5,
    val error: RegistrationErrorKind? = null,
) {
    val canSubmit: Boolean
        get() = otp.length == 6 && !isLoading && !isResending

    val canResend: Boolean
        get() = resendSecondsRemaining == 0 && !isLoading && !isResending
}

data class CreateAccountUiState(
    val name: String = "",
    val storeName: String = "",
    val password: String = "",
    val passwordConfirmation: String = "",
    val passwordVisible: Boolean = false,
    val isLoading: Boolean = false,
    val error: RegistrationErrorKind? = null,
) {
    val canSubmit: Boolean
        get() = name.isNotBlank() && !isLoading
}

enum class RegistrationErrorKind {
    RequiredField,
    InvalidCode,
    InvalidPhone,
    InvalidOtp,
    PasswordTooShort,
    PasswordMismatch,
    Offline,
    TemporarilyLocked,
    SessionExpired,
    Generic,
}
