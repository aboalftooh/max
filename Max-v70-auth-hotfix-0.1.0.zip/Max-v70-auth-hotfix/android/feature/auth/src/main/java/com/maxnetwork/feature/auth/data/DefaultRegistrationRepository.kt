package com.maxnetwork.feature.auth.data

import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.NewAccount
import com.maxnetwork.feature.auth.domain.PhoneAuthenticationResult
import com.maxnetwork.feature.auth.domain.PhoneChallengeInfo
import com.maxnetwork.feature.auth.domain.RegistrationCodeAcceptance
import com.maxnetwork.feature.auth.domain.RegistrationRepository
import com.maxnetwork.feature.auth.domain.VerifiedPhoneInfo

internal class DefaultRegistrationRepository(
    private val remote: AuthRemoteDataSource,
    private val registrationStore: RegistrationSessionStore,
    private val authSessionStore: AuthSessionStore,
) : RegistrationRepository {
    override suspend fun requestPhoneChallenge(phone: String): AuthResult<PhoneChallengeInfo> =
        requestChallenge(phone)

    override suspend fun resendPhoneChallenge(): AuthResult<PhoneChallengeInfo> {
        val current = registrationStore.current() as? StoredRegistrationSession.PhoneChallengeCreated
            ?: return AuthResult.Failure(AuthFailure.InvalidRequest)
        return requestChallenge(current.phone)
    }

    override suspend fun verifyPhoneOtp(otp: String): AuthResult<PhoneAuthenticationResult> {
        val current = registrationStore.current() as? StoredRegistrationSession.PhoneChallengeCreated
            ?: return AuthResult.Failure(AuthFailure.InvalidRequest)
        val verified = when (val result = remote.verifyPhoneChallenge(current.challengeId, otp)) {
            is RemoteAuthResult.Success -> result.value
            is RemoteAuthResult.Failure -> return AuthResult.Failure(result.toAuthFailure())
        }
        return when (val resolution = remote.resolveVerifiedPhone(verified.verificationToken)) {
            is RemoteAuthResult.Success -> when (val value = resolution.value) {
                is RemotePhoneAuthentication.ExistingUser -> {
                    val session = value.session.toStoredSession()
                    authSessionStore.save(session)
                    registrationStore.clear()
                    AuthResult.Success(
                        PhoneAuthenticationResult.ExistingUser(
                            AuthState.Authenticated(session.expiresAt),
                        ),
                    )
                }
                RemotePhoneAuthentication.NewUser -> {
                    registrationStore.replace(
                        StoredRegistrationSession.PhoneVerified(
                            phone = current.phone,
                            phoneVerificationToken = verified.verificationToken,
                            verificationExpiresAt = verified.expiresAt,
                            maskedPhone = verified.maskedPhone,
                        ),
                    )
                    AuthResult.Success(
                        PhoneAuthenticationResult.NewUser(
                            VerifiedPhoneInfo(verified.maskedPhone, verified.expiresAt),
                        ),
                    )
                }
            }
            is RemoteAuthResult.Failure -> AuthResult.Failure(resolution.toAuthFailure())
        }
    }

    override suspend fun validateRegistrationCode(code: String): AuthResult<RegistrationCodeAcceptance> {
        val verified = registrationStore.current() as? StoredRegistrationSession.PhoneVerified
            ?: return AuthResult.Failure(AuthFailure.InvalidRequest)
        return when (val result = remote.validateRegistrationCode(code)) {
            is RemoteAuthResult.Success -> {
                registrationStore.replace(
                    StoredRegistrationSession.ReadyToCreateAccount(
                        phone = verified.phone,
                        phoneVerificationToken = verified.phoneVerificationToken,
                        verificationExpiresAt = verified.verificationExpiresAt,
                        maskedPhone = verified.maskedPhone,
                        validationToken = result.value.validationToken,
                        registrationExpiresAt = result.value.expiresAt,
                    ),
                )
                AuthResult.Success(RegistrationCodeAcceptance(result.value.expiresAt))
            }
            is RemoteAuthResult.Failure -> AuthResult.Failure(result.toAuthFailure())
        }
    }

    override suspend fun createAccount(account: NewAccount): AuthResult<AuthState.Authenticated> {
        val current = registrationStore.current() as? StoredRegistrationSession.ReadyToCreateAccount
            ?: return AuthResult.Failure(AuthFailure.InvalidRequest)
        return when (
            val result = remote.createAccount(
                RemoteAccountCreation(
                    name = account.name,
                    phoneVerificationToken = current.phoneVerificationToken,
                    registrationValidationToken = current.validationToken,
                ),
            )
        ) {
            is RemoteAuthResult.Success -> {
                val session = result.value.toStoredSession()
                authSessionStore.save(session)
                registrationStore.clear()
                AuthResult.Success(AuthState.Authenticated(session.expiresAt))
            }
            is RemoteAuthResult.Failure -> AuthResult.Failure(result.toAuthFailure())
        }
    }

    override suspend fun clearRegistration() {
        registrationStore.clear()
    }

    private suspend fun requestChallenge(phone: String): AuthResult<PhoneChallengeInfo> =
        when (val result = remote.requestPhoneChallenge(phone)) {
            is RemoteAuthResult.Success -> {
                registrationStore.replace(
                    StoredRegistrationSession.PhoneChallengeCreated(
                        phone = phone,
                        challengeId = result.value.challengeId,
                        challengeExpiresAt = result.value.expiresAt,
                        resendAvailableAt = result.value.resendAvailableAt,
                        remainingAttempts = result.value.remainingAttempts,
                    ),
                )
                AuthResult.Success(
                    PhoneChallengeInfo(
                        expiresAt = result.value.expiresAt,
                        resendAvailableAt = result.value.resendAvailableAt,
                        remainingAttempts = result.value.remainingAttempts,
                    ),
                )
            }
            is RemoteAuthResult.Failure -> AuthResult.Failure(result.toAuthFailure())
        }
}

private fun RemoteSession.toStoredSession(): StoredAuthSession = StoredAuthSession(
    accessToken = accessToken,
    refreshToken = refreshToken,
    expiresAt = expiresAt,
)
