package com.maxnetwork.feature.auth.domain

/** Public feature capability; navigation and wiring remain in :app. */
object AuthFeature {
    const val ROUTE = "auth"
}
