package com.maxnetwork.feature.auth.domain

import java.time.Instant

data class RegistrationCodeAcceptance(
    val expiresAt: Instant,
)

data class PhoneChallengeInfo(
    val expiresAt: Instant,
    val resendAvailableAt: Instant,
    val remainingAttempts: Int,
)

data class VerifiedPhoneInfo(
    val maskedPhone: String,
    val expiresAt: Instant,
)

sealed interface PhoneAuthenticationResult {
    data class ExistingUser(val authenticated: AuthState.Authenticated) : PhoneAuthenticationResult
    data class NewUser(val verifiedPhone: VerifiedPhoneInfo) : PhoneAuthenticationResult
}

data class NewAccount(
    val name: String,
)
