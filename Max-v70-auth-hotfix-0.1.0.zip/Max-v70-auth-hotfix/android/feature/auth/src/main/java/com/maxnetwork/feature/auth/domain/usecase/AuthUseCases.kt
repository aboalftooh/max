package com.maxnetwork.feature.auth.domain.usecase

import com.maxnetwork.feature.auth.domain.AuthRepository
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.LoginRequest
import com.maxnetwork.feature.auth.domain.LogoutResult
import kotlinx.coroutines.flow.StateFlow

class ObserveAuthStateUseCase(
    private val repository: AuthRepository,
) {
    operator fun invoke(): StateFlow<AuthState> = repository.authState
}

class RestoreSessionUseCase(
    private val repository: AuthRepository,
) {
    suspend operator fun invoke(): AuthResult<AuthState> = repository.restoreSession()
}

class LoginUseCase(
    private val repository: AuthRepository,
) {
    suspend operator fun invoke(phone: String, password: String): AuthResult<AuthState.Authenticated> {
        if (phone.isBlank() || password.isBlank()) {
            return AuthResult.Failure(com.maxnetwork.feature.auth.domain.AuthFailure.InvalidRequest)
        }
        return repository.login(LoginRequest(phone = phone.trim(), password = password))
    }
}

class RefreshSessionUseCase(
    private val repository: AuthRepository,
) {
    suspend operator fun invoke(): AuthResult<AuthState.Authenticated> = repository.refreshSession()
}

class GetValidAccessTokenUseCase(
    private val repository: AuthRepository,
) {
    suspend operator fun invoke(): AuthResult<String> = repository.getValidAccessToken()
}

class LogoutUseCase(
    private val repository: AuthRepository,
) {
    suspend operator fun invoke(): AuthResult<LogoutResult> = repository.logout()
}
