package com.maxnetwork.feature.auth.domain

import java.time.Instant

/** Sanitized application-level authentication state. Tokens never leave the data layer. */
sealed interface AuthState {
    data object Initializing : AuthState

    data class SignedOut(
        val reason: SignOutReason = SignOutReason.None,
    ) : AuthState

    data class Authenticated(
        val expiresAt: Instant,
    ) : AuthState

    data class Refreshing(
        val previousExpiry: Instant?,
    ) : AuthState

    data class TemporarilyUnavailable(
        val retryable: Boolean,
    ) : AuthState
}

enum class SignOutReason {
    None,
    UserRequested,
    SessionExpired,
    StorageInvalid,
}

data class LoginRequest(
    val phone: String,
    val password: String,
)

sealed interface AuthResult<out T> {
    data class Success<T>(val value: T) : AuthResult<T>

    data class Failure(val reason: AuthFailure) : AuthResult<Nothing>
}

sealed interface AuthFailure {
    data object InvalidCredentials : AuthFailure
    data object NoSession : AuthFailure
    data object SessionExpired : AuthFailure
    data object NetworkUnavailable : AuthFailure
    data object RateLimited : AuthFailure
    data object InvalidRequest : AuthFailure
    data class Server(val retryable: Boolean) : AuthFailure
}

data class LogoutResult(
    val localSessionCleared: Boolean,
    val remoteRevocationCompleted: Boolean,
)
