package com.maxnetwork.feature.auth.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import com.maxnetwork.core.designsystem.component.MaxBrandMark
import com.maxnetwork.core.designsystem.component.MaxErrorMessage
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxTertiaryButton
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTextField
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.auth.R

data class RegistrationCodeScreenActions(
    val onCodeChanged: (String) -> Unit,
    val onSubmit: () -> Unit,
    val onContactMax: () -> Unit,
    val onBack: () -> Unit,
)

@Composable
fun RegistrationCodeScreen(
    state: RegistrationCodeUiState,
    actions: RegistrationCodeScreenActions,
    modifier: Modifier = Modifier,
) {
    val focusManager = LocalFocusManager.current
    val submit = {
        focusManager.clearFocus()
        actions.onSubmit()
    }

    MaxScaffold(
        modifier = modifier.testTag("registration_code_screen"),
        topBar = {
            MaxTopBar(
                title = stringResource(R.string.max_auth_registration_code_title),
                onBack = actions.onBack,
                backContentDescription = stringResource(R.string.max_auth_back),
            )
        },
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = MaxSpacing.lg, vertical = MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            MaxBrandMark()
            MaxText(
                text = stringResource(R.string.max_auth_registration_code_heading),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineMedium,
            )
            MaxText(
                text = stringResource(R.string.max_auth_registration_code_message),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            MaxTextField(
                value = state.code,
                onValueChange = actions.onCodeChanged,
                label = stringResource(R.string.max_auth_registration_code),
                enabled = !state.isLoading,
                isError = state.error == RegistrationErrorKind.RequiredField ||
                    state.error == RegistrationErrorKind.InvalidCode,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Ascii,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                testTag = "registration_code_input",
            )
            state.error?.let { error ->
                MaxErrorMessage(
                    message = error.registrationCodeMessage(),
                    modifier = Modifier.testTag("registration_code_error"),
                )
            }
            MaxPrimaryButton(
                text = stringResource(R.string.max_auth_next),
                onClick = submit,
                enabled = state.canSubmit,
                loading = state.isLoading,
                testTag = "registration_code_submit",
            )
            MaxTertiaryButton(
                text = stringResource(R.string.max_auth_contact_max),
                onClick = actions.onContactMax,
                modifier = Modifier.testTag("registration_contact_max"),
                enabled = !state.isLoading,
                testTag = "registration_contact_max",
            )
        }
    }
}

data class ConfirmPhoneScreenActions(
    val onPhoneChanged: (String) -> Unit,
    val onSubmit: () -> Unit,
    val onContactMax: () -> Unit,
    val onBack: () -> Unit,
)

@Composable
fun ConfirmPhoneScreen(
    state: ConfirmPhoneUiState,
    actions: ConfirmPhoneScreenActions,
    modifier: Modifier = Modifier,
) {
    val focusManager = LocalFocusManager.current
    val submit = {
        focusManager.clearFocus()
        actions.onSubmit()
    }

    MaxScaffold(
        modifier = modifier.testTag("confirm_phone_screen"),
        topBar = {
            MaxTopBar(
                title = stringResource(R.string.max_auth_confirm_phone_title),
                onBack = actions.onBack,
                backContentDescription = stringResource(R.string.max_auth_back),
            )
        },
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = MaxSpacing.lg, vertical = MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            MaxBrandMark()
            MaxText(
                text = stringResource(R.string.max_auth_confirm_phone_heading),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineMedium,
            )
            MaxText(
                text = stringResource(R.string.max_auth_confirm_phone_message),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            MaxTextField(
                value = state.phone,
                onValueChange = actions.onPhoneChanged,
                label = stringResource(R.string.max_auth_phone),
                enabled = !state.isLoading,
                isError = state.error == RegistrationErrorKind.RequiredField ||
                    state.error == RegistrationErrorKind.InvalidPhone,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                testTag = "registration_phone_input",
            )
            state.error?.let { error ->
                MaxErrorMessage(
                    message = error.phoneMessage(),
                    modifier = Modifier.testTag("registration_phone_error"),
                )
            }
            MaxPrimaryButton(
                text = stringResource(R.string.max_auth_next),
                onClick = submit,
                enabled = state.canSubmit,
                loading = state.isLoading,
                testTag = "registration_phone_submit",
            )
            MaxTertiaryButton(
                text = stringResource(R.string.max_auth_contact_max),
                onClick = actions.onContactMax,
                enabled = !state.isLoading,
                testTag = "phone_contact_max",
            )
        }
    }
}

@Composable
private fun RegistrationErrorKind.registrationCodeMessage(): String = when (this) {
    RegistrationErrorKind.RequiredField -> stringResource(R.string.max_auth_registration_code_required)
    RegistrationErrorKind.InvalidCode -> stringResource(R.string.max_auth_registration_code_invalid)
    RegistrationErrorKind.Offline -> stringResource(R.string.max_auth_offline)
    RegistrationErrorKind.TemporarilyLocked -> stringResource(R.string.max_auth_rate_limited)
    RegistrationErrorKind.SessionExpired -> stringResource(R.string.max_auth_registration_session_expired)
    RegistrationErrorKind.InvalidPhone,
    RegistrationErrorKind.InvalidOtp,
    RegistrationErrorKind.PasswordTooShort,
    RegistrationErrorKind.PasswordMismatch,
    RegistrationErrorKind.Generic -> stringResource(R.string.max_auth_generic_error)
}

@Composable
private fun RegistrationErrorKind.phoneMessage(): String = when (this) {
    RegistrationErrorKind.RequiredField -> stringResource(R.string.max_auth_phone_required)
    RegistrationErrorKind.InvalidPhone -> stringResource(R.string.max_auth_phone_invalid)
    RegistrationErrorKind.Offline -> stringResource(R.string.max_auth_offline)
    RegistrationErrorKind.TemporarilyLocked -> stringResource(R.string.max_auth_rate_limited)
    RegistrationErrorKind.SessionExpired -> stringResource(R.string.max_auth_registration_session_expired)
    RegistrationErrorKind.InvalidCode,
    RegistrationErrorKind.InvalidOtp,
    RegistrationErrorKind.PasswordTooShort,
    RegistrationErrorKind.PasswordMismatch,
    RegistrationErrorKind.Generic -> stringResource(R.string.max_auth_generic_error)
}
