package com.maxnetwork.feature.auth.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import com.maxnetwork.core.designsystem.component.MaxBrandMark
import com.maxnetwork.core.designsystem.component.MaxErrorMessage
import com.maxnetwork.core.designsystem.component.MaxOtpField
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxTertiaryButton
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.auth.R

data class OtpScreenActions(
    val onOtpChanged: (String) -> Unit,
    val onSubmit: () -> Unit,
    val onResend: () -> Unit,
    val onBack: () -> Unit,
)

@Composable
fun OtpScreen(
    state: OtpUiState,
    actions: OtpScreenActions,
    modifier: Modifier = Modifier,
) {
    val focusManager = LocalFocusManager.current
    val submit = {
        focusManager.clearFocus()
        actions.onSubmit()
    }
    val otpDescription = stringResource(R.string.max_auth_otp_accessibility)

    MaxScaffold(
        modifier = modifier.testTag("otp_screen"),
        topBar = {
            MaxTopBar(
                title = stringResource(R.string.max_auth_otp_title),
                onBack = actions.onBack,
                backContentDescription = stringResource(R.string.max_auth_back),
            )
        },
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = MaxSpacing.lg, vertical = MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            MaxBrandMark()
            MaxText(
                text = stringResource(R.string.max_auth_otp_heading),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineMedium,
            )
            MaxText(
                text = stringResource(R.string.max_auth_otp_message),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            MaxOtpField(
                value = state.otp,
                onValueChange = actions.onOtpChanged,
                enabled = !state.isLoading && !state.isResending,
                isError = state.error == RegistrationErrorKind.InvalidOtp ||
                    state.error == RegistrationErrorKind.RequiredField,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                modifier = Modifier.semantics { contentDescription = otpDescription },
                testTag = "otp_input",
            )
            MaxText(
                text = stringResource(R.string.max_auth_otp_attempts, state.remainingAttempts),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            state.error?.let { error ->
                MaxErrorMessage(
                    message = error.otpMessage(),
                    modifier = Modifier.testTag("otp_error"),
                )
            }
            MaxPrimaryButton(
                text = stringResource(R.string.max_auth_confirm),
                onClick = submit,
                enabled = state.canSubmit,
                loading = state.isLoading,
                testTag = "otp_submit",
            )
            MaxTertiaryButton(
                text = if (state.resendSecondsRemaining > 0) {
                    stringResource(
                        R.string.max_auth_resend_countdown,
                        state.resendSecondsRemaining,
                    )
                } else {
                    stringResource(R.string.max_auth_resend)
                },
                onClick = actions.onResend,
                enabled = state.canResend,
                testTag = "otp_resend",
            )
        }
    }
}

@Composable
private fun RegistrationErrorKind.otpMessage(): String = when (this) {
    RegistrationErrorKind.InvalidOtp,
    RegistrationErrorKind.RequiredField -> stringResource(R.string.max_auth_otp_invalid)

    RegistrationErrorKind.Offline -> stringResource(R.string.max_auth_offline)
    RegistrationErrorKind.TemporarilyLocked -> stringResource(R.string.max_auth_rate_limited)
    RegistrationErrorKind.SessionExpired -> stringResource(R.string.max_auth_registration_session_expired)
    else -> stringResource(R.string.max_auth_generic_error)
}
