package com.maxnetwork.feature.auth.data

import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.PasswordResetChallengeInfo
import com.maxnetwork.feature.auth.domain.PasswordResetConfirmation
import com.maxnetwork.feature.auth.domain.PasswordResetRepository
import com.maxnetwork.feature.auth.domain.SignOutReason

internal class DefaultPasswordResetRepository(
    private val remote: AuthRemoteDataSource,
    private val resetStore: PasswordResetSessionStore,
    private val authSessionStore: AuthSessionStore,
) : PasswordResetRepository {
    override suspend fun requestCode(phone: String): AuthResult<PasswordResetChallengeInfo> = request(phone)

    override suspend fun resendCode(): AuthResult<PasswordResetChallengeInfo> {
        val current = resetStore.current() ?: return AuthResult.Failure(AuthFailure.InvalidRequest)
        return request(current.phone)
    }

    override suspend fun resetPassword(
        confirmation: PasswordResetConfirmation,
    ): AuthResult<Unit> {
        val current = resetStore.current() ?: return AuthResult.Failure(AuthFailure.InvalidRequest)
        return when (
            val result = remote.resetPassword(
                phone = current.phone,
                resetCode = confirmation.resetCode,
                newPassword = confirmation.newPassword,
            )
        ) {
            is RemoteAuthResult.Success -> {
                resetStore.clear()
                authSessionStore.clear(SignOutReason.SessionExpired)
                AuthResult.Success(Unit)
            }

            is RemoteAuthResult.Failure -> AuthResult.Failure(result.toAuthFailure())
        }
    }

    override suspend fun clear() {
        resetStore.clear()
    }

    private suspend fun request(phone: String): AuthResult<PasswordResetChallengeInfo> =
        when (val result = remote.requestPasswordReset(phone)) {
            is RemoteAuthResult.Success -> {
                resetStore.replace(
                    StoredPasswordResetSession(
                        phone = phone,
                        expiresAt = result.value.expiresAt,
                        resendAvailableAt = result.value.resendAvailableAt,
                    ),
                )
                AuthResult.Success(
                    PasswordResetChallengeInfo(
                        expiresAt = result.value.expiresAt,
                        resendAvailableAt = result.value.resendAvailableAt,
                    ),
                )
            }

            is RemoteAuthResult.Failure -> AuthResult.Failure(result.toAuthFailure())
        }
}
