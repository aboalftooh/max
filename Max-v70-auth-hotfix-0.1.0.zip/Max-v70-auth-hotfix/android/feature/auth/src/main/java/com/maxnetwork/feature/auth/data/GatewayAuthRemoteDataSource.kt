package com.maxnetwork.feature.auth.data

import com.maxnetwork.core.network.AccountCreation
import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.LoginCredentials
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.PhoneAuthNextAction
import com.maxnetwork.core.network.PhoneAuthResolution
import com.maxnetwork.core.network.PhoneChallenge
import com.maxnetwork.core.network.RegistrationCodeValidation
import com.maxnetwork.core.network.ResetPasswordCommand
import com.maxnetwork.core.network.Session
import com.maxnetwork.core.network.VerifiedPhone

internal class GatewayAuthRemoteDataSource(
    private val gateway: MaxGateway,
) : AuthRemoteDataSource {
    override suspend fun validateRegistrationCode(code: String): RemoteAuthResult<RemoteRegistrationValidation> =
        gateway.validateRegistrationCode(code).toRemoteRegistrationValidation()

    override suspend fun requestPhoneChallenge(phone: String): RemoteAuthResult<RemotePhoneChallenge> =
        gateway.requestPhoneChallenge(phone).toRemotePhoneChallenge()

    override suspend fun verifyPhoneChallenge(
        challengeId: String,
        otp: String,
    ): RemoteAuthResult<RemoteVerifiedPhone> =
        gateway.verifyPhoneChallenge(challengeId, otp).toRemoteVerifiedPhone()

    override suspend fun resolveVerifiedPhone(verificationToken: String): RemoteAuthResult<RemotePhoneAuthentication> =
        gateway.resolveVerifiedPhone(verificationToken).toRemotePhoneAuthentication()

    override suspend fun createAccount(command: RemoteAccountCreation): RemoteAuthResult<RemoteSession> =
        gateway.createAccount(
            AccountCreation(
                name = command.name,
                phoneVerificationToken = command.phoneVerificationToken,
                registrationValidationToken = command.registrationValidationToken,
            ),
        ).toRemoteSession()

    override suspend fun requestPasswordReset(phone: String): RemoteAuthResult<RemotePhoneChallenge> =
        gateway.requestPasswordReset(phone).toRemotePhoneChallenge()

    override suspend fun resetPassword(
        phone: String,
        resetCode: String,
        newPassword: String,
    ): RemoteAuthResult<Unit> = gateway.resetPassword(
        ResetPasswordCommand(
            phone = phone,
            resetCode = resetCode,
            newPassword = newPassword,
        ),
    ).toRemoteUnit()

    override suspend fun login(phone: String, password: String): RemoteAuthResult<RemoteSession> =
        gateway.login(LoginCredentials(phone = phone, password = password)).toRemoteSession()

    override suspend fun refresh(refreshToken: String): RemoteAuthResult<RemoteSession> =
        gateway.refreshSession(refreshToken).toRemoteSession()

    override suspend fun logout(accessToken: String): RemoteAuthResult<Unit> =
        gateway.logout(accessToken).toRemoteUnit()
}

private fun GatewayResult<RegistrationCodeValidation>.toRemoteRegistrationValidation():
    RemoteAuthResult<RemoteRegistrationValidation> = when (this) {
    is GatewayResult.Success -> RemoteAuthResult.Success(
        RemoteRegistrationValidation(
            validationToken = value.validationToken,
            expiresAt = value.expiresAt,
        ),
    )

    is GatewayResult.Failure -> error.toRemoteFailure()
}

private fun GatewayResult<PhoneChallenge>.toRemotePhoneChallenge(): RemoteAuthResult<RemotePhoneChallenge> = when (this) {
    is GatewayResult.Success -> RemoteAuthResult.Success(
        RemotePhoneChallenge(
            challengeId = value.challengeId,
            expiresAt = value.expiresAt,
            resendAvailableAt = value.resendAvailableAt,
            remainingAttempts = value.remainingAttempts,
        ),
    )

    is GatewayResult.Failure -> error.toRemoteFailure()
}

private fun GatewayResult<VerifiedPhone>.toRemoteVerifiedPhone(): RemoteAuthResult<RemoteVerifiedPhone> = when (this) {
    is GatewayResult.Success -> RemoteAuthResult.Success(
        RemoteVerifiedPhone(
            verificationToken = value.verificationToken,
            maskedPhone = value.maskedPhone,
            expiresAt = value.expiresAt,
        ),
    )

    is GatewayResult.Failure -> error.toRemoteFailure()
}

private fun GatewayResult<PhoneAuthResolution>.toRemotePhoneAuthentication(): RemoteAuthResult<RemotePhoneAuthentication> = when (this) {
    is GatewayResult.Success -> when (value.nextAction) {
        PhoneAuthNextAction.Dashboard -> {
            val session = requireNotNull(value.session) { "Dashboard resolution requires session" }
            RemoteAuthResult.Success(
                RemotePhoneAuthentication.ExistingUser(
                    RemoteSession(session.accessToken, session.refreshToken, session.expiresAt),
                ),
            )
        }
        PhoneAuthNextAction.JoinCode -> RemoteAuthResult.Success(RemotePhoneAuthentication.NewUser)
    }
    is GatewayResult.Failure -> error.toRemoteFailure()
}

private fun GatewayResult<Session>.toRemoteSession(): RemoteAuthResult<RemoteSession> = when (this) {
    is GatewayResult.Success -> RemoteAuthResult.Success(
        RemoteSession(
            accessToken = value.accessToken,
            refreshToken = value.refreshToken,
            expiresAt = value.expiresAt,
        ),
    )

    is GatewayResult.Failure -> error.toRemoteFailure()
}

private fun GatewayResult<Unit>.toRemoteUnit(): RemoteAuthResult<Unit> = when (this) {
    is GatewayResult.Success -> RemoteAuthResult.Success(Unit)
    is GatewayResult.Failure -> error.toRemoteFailure()
}

private fun com.maxnetwork.core.network.ApiError.toRemoteFailure(): RemoteAuthResult.Failure {
    val kind = when (code) {
        ApiErrorCode.Unauthorized -> RemoteAuthFailure.Unauthorized
        ApiErrorCode.RateLimited -> RemoteAuthFailure.RateLimited
        ApiErrorCode.InvalidRequest,
        ApiErrorCode.Conflict -> RemoteAuthFailure.InvalidRequest

        ApiErrorCode.ServiceUnavailable -> if (traceId == "network-unavailable") {
            RemoteAuthFailure.Network
        } else {
            RemoteAuthFailure.Server
        }
        else -> RemoteAuthFailure.Server
    }
    return RemoteAuthResult.Failure(kind = kind, retryable = retryable)
}
