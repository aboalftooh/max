package com.maxnetwork.feature.auth.data

import com.maxnetwork.core.common.ClockProvider
import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthRepository
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.LoginRequest
import com.maxnetwork.feature.auth.domain.LogoutResult
import com.maxnetwork.feature.auth.domain.SignOutReason
import java.time.Duration
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal class DefaultAuthRepository(
    private val remote: AuthRemoteDataSource,
    private val sessionStore: AuthSessionStore,
    private val clock: ClockProvider,
) : AuthRepository {
    private val sessionMutex = Mutex()

    override val authState: StateFlow<AuthState> = sessionStore.state

    override suspend fun restoreSession(): AuthResult<AuthState> = sessionMutex.withLock {
        val restored = sessionStore.restore()
            ?: return AuthResult.Success(AuthState.SignedOut())
        if (restored.isUsable(clock)) {
            sessionStore.markAuthenticated(restored.expiresAt)
            return AuthResult.Success(AuthState.Authenticated(restored.expiresAt))
        }
        when (val refreshed = refreshLocked(restored)) {
            is AuthResult.Success -> AuthResult.Success(AuthState.Authenticated(refreshed.value.expiresAt))
            is AuthResult.Failure -> refreshed
        }
    }

    override suspend fun login(request: LoginRequest): AuthResult<AuthState.Authenticated> = sessionMutex.withLock {
        when (val result = remote.login(phone = request.phone, password = request.password)) {
            is RemoteAuthResult.Success -> {
                val session = result.value.toStoredSession()
                sessionStore.save(session)
                AuthResult.Success(AuthState.Authenticated(session.expiresAt))
            }
            is RemoteAuthResult.Failure -> {
                if (result.kind == RemoteAuthFailure.InvalidCredentials || result.kind == RemoteAuthFailure.Unauthorized) {
                    sessionStore.clear(SignOutReason.None)
                }
                AuthResult.Failure(result.toDomainFailure())
            }
        }
    }

    override suspend fun refreshSession(): AuthResult<AuthState.Authenticated> = sessionMutex.withLock {
        val current = sessionStore.current()
            ?: return AuthResult.Failure(AuthFailure.NoSession)
        when (val result = refreshLocked(current)) {
            is AuthResult.Success -> AuthResult.Success(AuthState.Authenticated(result.value.expiresAt))
            is AuthResult.Failure -> result
        }
    }

    override suspend fun getValidAccessToken(): AuthResult<String> = sessionMutex.withLock {
        val current = sessionStore.current()
            ?: return AuthResult.Failure(AuthFailure.NoSession)
        if (current.isUsable(clock)) {
            return AuthResult.Success(current.accessToken)
        }
        when (val refreshed = refreshLocked(current)) {
            is AuthResult.Success -> AuthResult.Success(refreshed.value.accessToken)
            is AuthResult.Failure -> refreshed
        }
    }

    override suspend fun logout(): AuthResult<LogoutResult> = sessionMutex.withLock {
        val accessToken = sessionStore.current()?.accessToken
        sessionStore.clear(SignOutReason.UserRequested)
        if (accessToken == null) {
            return AuthResult.Success(
                LogoutResult(
                    localSessionCleared = true,
                    remoteRevocationCompleted = true,
                ),
            )
        }
        val remoteRevoked = remote.logout(accessToken) is RemoteAuthResult.Success
        AuthResult.Success(
            LogoutResult(
                localSessionCleared = true,
                remoteRevocationCompleted = remoteRevoked,
            ),
        )
    }

    private suspend fun refreshLocked(current: StoredAuthSession): AuthResult<StoredAuthSession> {
        sessionStore.markRefreshing(current.expiresAt)
        return when (val result = remote.refresh(current.refreshToken)) {
            is RemoteAuthResult.Success -> {
                val refreshed = result.value.toStoredSession()
                sessionStore.save(refreshed)
                AuthResult.Success(refreshed)
            }
            is RemoteAuthResult.Failure -> {
                when (result.kind) {
                    RemoteAuthFailure.Unauthorized, RemoteAuthFailure.InvalidCredentials ->
                        sessionStore.clear(SignOutReason.SessionExpired)

                    else -> sessionStore.markUnavailable(retryable = result.retryable)
                }
                AuthResult.Failure(result.toDomainFailure())
            }
        }
    }

    private fun StoredAuthSession.isUsable(clock: ClockProvider): Boolean =
        expiresAt.isAfter(clock.now().plus(REFRESH_SKEW))

    private companion object {
        val REFRESH_SKEW: Duration = Duration.ofSeconds(30)
    }
}

private fun RemoteSession.toStoredSession(): StoredAuthSession = StoredAuthSession(
    accessToken = accessToken,
    refreshToken = refreshToken,
    expiresAt = expiresAt,
)

private fun RemoteAuthResult.Failure.toDomainFailure(): AuthFailure = when (kind) {
    RemoteAuthFailure.InvalidCredentials -> AuthFailure.InvalidCredentials
    RemoteAuthFailure.Unauthorized -> AuthFailure.SessionExpired
    RemoteAuthFailure.RateLimited -> AuthFailure.RateLimited
    RemoteAuthFailure.InvalidRequest -> AuthFailure.InvalidRequest
    RemoteAuthFailure.Network -> AuthFailure.NetworkUnavailable
    RemoteAuthFailure.Server -> AuthFailure.Server(retryable = retryable)
}
