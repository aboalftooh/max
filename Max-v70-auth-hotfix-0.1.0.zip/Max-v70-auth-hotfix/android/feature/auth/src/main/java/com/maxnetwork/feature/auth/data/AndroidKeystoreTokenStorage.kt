package com.maxnetwork.feature.auth.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.security.GeneralSecurityException
import java.security.KeyStore
import java.time.Instant
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

internal class AndroidKeystoreTokenStorage(
    context: Context,
) : AuthTokenStorage {
    private val appContext = context.applicationContext
    private val preferences = appContext.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
    private val lock = Any()

    override fun read(): StoredAuthSession? = synchronized(lock) {
        val encodedIv = preferences.getString(KEY_IV, null) ?: return@synchronized null
        val encodedCiphertext = preferences.getString(KEY_CIPHERTEXT, null) ?: return@synchronized null
        try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(
                Cipher.DECRYPT_MODE,
                getOrCreateKey(),
                GCMParameterSpec(GCM_TAG_LENGTH_BITS, Base64.decode(encodedIv, Base64.NO_WRAP)),
            )
            cipher.updateAAD(associatedData())
            decodeSession(cipher.doFinal(Base64.decode(encodedCiphertext, Base64.NO_WRAP)))
        } catch (error: GeneralSecurityException) {
            clearBestEffort()
            deleteKeyBestEffort()
            null
        } catch (error: IllegalArgumentException) {
            clearBestEffort()
            null
        } catch (error: java.io.IOException) {
            clearBestEffort()
            null
        }
    }

    override fun write(session: StoredAuthSession) = synchronized(lock) {
        try {
            encryptAndPersist(session)
        } catch (error: GeneralSecurityException) {
            deleteKeyBestEffort()
            encryptAndPersist(session)
        }
    }

    override fun clear() = synchronized(lock) {
        check(preferences.edit().clear().commit()) {
            "Unable to clear encrypted authentication session"
        }
    }

    private fun encryptAndPersist(session: StoredAuthSession) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        cipher.updateAAD(associatedData())
        val ciphertext = cipher.doFinal(encodeSession(session))
        check(
            preferences.edit()
                .putInt(KEY_VERSION, STORAGE_VERSION)
                .putString(KEY_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
                .putString(KEY_CIPHERTEXT, Base64.encodeToString(ciphertext, Base64.NO_WRAP))
                .commit(),
        ) { "Unable to persist encrypted authentication session" }
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        keyGenerator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return keyGenerator.generateKey()
    }

    private fun associatedData(): ByteArray =
        "${appContext.packageName}:auth-session:$STORAGE_VERSION".toByteArray(Charsets.UTF_8)

    private fun clearBestEffort() {
        preferences.edit().clear().commit()
    }

    private fun deleteKeyBestEffort() {
        runCatching {
            KeyStore.getInstance(KEYSTORE_PROVIDER).apply {
                load(null)
                if (containsAlias(KEY_ALIAS)) deleteEntry(KEY_ALIAS)
            }
        }
    }

    private fun encodeSession(session: StoredAuthSession): ByteArray {
        val output = ByteArrayOutputStream()
        DataOutputStream(output).use { data ->
            data.writeInt(STORAGE_VERSION)
            data.writeUTF(session.accessToken)
            data.writeUTF(session.refreshToken)
            data.writeLong(session.expiresAt.epochSecond)
        }
        return output.toByteArray()
    }

    private fun decodeSession(bytes: ByteArray): StoredAuthSession =
        DataInputStream(ByteArrayInputStream(bytes)).use { data ->
            require(data.readInt() == STORAGE_VERSION) { "Unsupported encrypted session version" }
            StoredAuthSession(
                accessToken = data.readUTF(),
                refreshToken = data.readUTF(),
                expiresAt = Instant.ofEpochSecond(data.readLong()),
            )
        }

    companion object {
        internal const val PREFERENCES_NAME = "max_auth_secure_v1"
        private const val KEY_ALIAS = "max_auth_session_key_v1"
        private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_LENGTH_BITS = 128
        private const val STORAGE_VERSION = 1
        private const val KEY_VERSION = "version"
        private const val KEY_IV = "iv"
        private const val KEY_CIPHERTEXT = "ciphertext"
    }
}
