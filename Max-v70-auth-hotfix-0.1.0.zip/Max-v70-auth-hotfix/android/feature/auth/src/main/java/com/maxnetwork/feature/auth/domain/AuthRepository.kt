package com.maxnetwork.feature.auth.domain

import kotlinx.coroutines.flow.StateFlow

/** Owns the only authentication session state exposed to the application. */
interface AuthRepository {
    val authState: StateFlow<AuthState>

    suspend fun restoreSession(): AuthResult<AuthState>

    suspend fun login(request: LoginRequest): AuthResult<AuthState.Authenticated>

    suspend fun refreshSession(): AuthResult<AuthState.Authenticated>

    suspend fun getValidAccessToken(): AuthResult<String>

    suspend fun logout(): AuthResult<LogoutResult>
}
