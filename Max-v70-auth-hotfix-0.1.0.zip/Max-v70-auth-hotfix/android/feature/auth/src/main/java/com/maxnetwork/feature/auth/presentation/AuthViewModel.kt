package com.maxnetwork.feature.auth.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.PhoneChallengeInfo
import com.maxnetwork.feature.auth.domain.PasswordResetChallengeInfo
import com.maxnetwork.feature.auth.domain.PhoneAuthenticationResult
import com.maxnetwork.feature.auth.domain.usecase.ClearRegistrationUseCase
import com.maxnetwork.feature.auth.domain.usecase.ClearPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.ConfirmPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.CreateAccountUseCase
import com.maxnetwork.feature.auth.domain.usecase.LoginUseCase
import com.maxnetwork.feature.auth.domain.usecase.LogoutUseCase
import com.maxnetwork.feature.auth.domain.usecase.ObserveAuthStateUseCase
import com.maxnetwork.feature.auth.domain.usecase.RequestPhoneChallengeUseCase
import com.maxnetwork.feature.auth.domain.usecase.RequestPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.ResendPhoneChallengeUseCase
import com.maxnetwork.feature.auth.domain.usecase.ResendPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.RestoreSessionUseCase
import com.maxnetwork.feature.auth.domain.usecase.ValidateRegistrationCodeUseCase
import com.maxnetwork.feature.auth.domain.usecase.VerifyPhoneOtpUseCase
import java.time.Duration
import java.time.Instant
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(
    observeAuthState: ObserveAuthStateUseCase,
    private val restoreSessionUseCase: RestoreSessionUseCase,
    private val loginUseCase: LoginUseCase,
    private val logoutUseCase: LogoutUseCase,
    private val validateRegistrationCodeUseCase: ValidateRegistrationCodeUseCase,
    private val requestPhoneChallengeUseCase: RequestPhoneChallengeUseCase,
    private val resendPhoneChallengeUseCase: ResendPhoneChallengeUseCase,
    private val verifyPhoneOtpUseCase: VerifyPhoneOtpUseCase,
    private val createAccountUseCase: CreateAccountUseCase,
    private val clearRegistrationUseCase: ClearRegistrationUseCase,
    private val requestPasswordResetUseCase: RequestPasswordResetUseCase,
    private val resendPasswordResetUseCase: ResendPasswordResetUseCase,
    private val confirmPasswordResetUseCase: ConfirmPasswordResetUseCase,
    private val clearPasswordResetUseCase: ClearPasswordResetUseCase,
    private val now: () -> Instant = Instant::now,
) : ViewModel() {
    val authState: StateFlow<AuthState> = observeAuthState()

    private val _loginUiState = MutableStateFlow(LoginUiState())
    val loginUiState: StateFlow<LoginUiState> = _loginUiState.asStateFlow()

    private val _registrationCodeUiState = MutableStateFlow(RegistrationCodeUiState())
    val registrationCodeUiState: StateFlow<RegistrationCodeUiState> = _registrationCodeUiState.asStateFlow()

    private val _confirmPhoneUiState = MutableStateFlow(ConfirmPhoneUiState())
    val confirmPhoneUiState: StateFlow<ConfirmPhoneUiState> = _confirmPhoneUiState.asStateFlow()

    private val _otpUiState = MutableStateFlow(OtpUiState())
    val otpUiState: StateFlow<OtpUiState> = _otpUiState.asStateFlow()

    private val _createAccountUiState = MutableStateFlow(CreateAccountUiState())
    val createAccountUiState: StateFlow<CreateAccountUiState> = _createAccountUiState.asStateFlow()

    private val _forgotPasswordUiState = MutableStateFlow(ForgotPasswordUiState())
    val forgotPasswordUiState: StateFlow<ForgotPasswordUiState> = _forgotPasswordUiState.asStateFlow()

    private val _resetPasswordUiState = MutableStateFlow(ResetPasswordUiState())
    val resetPasswordUiState: StateFlow<ResetPasswordUiState> = _resetPasswordUiState.asStateFlow()

    private val _events = MutableSharedFlow<AuthUiEvent>(extraBufferCapacity = 2)
    val events: SharedFlow<AuthUiEvent> = _events.asSharedFlow()

    private var resendTimerJob: Job? = null
    private var passwordResetTimerJob: Job? = null

    init {
        viewModelScope.launch {
            restoreSessionUseCase()
        }
    }

    fun onPhoneChanged(value: String) {
        updateLoginState { state -> state.copy(phone = value, error = null) }
    }

    fun submitLogin() {
        val snapshot = _loginUiState.value
        if (snapshot.isLoading) return
        if (snapshot.phone.isBlank()) {
            updateLoginState { state -> state.copy(error = LoginErrorKind.RequiredPhone) }
            return
        }
        updateLoginState { state -> state.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            when (val result = requestPhoneChallengeUseCase(snapshot.phone)) {
                is AuthResult.Success -> {
                    updateLoginState { state -> state.copy(isLoading = false, error = null) }
                    applyChallenge(result.value)
                    _events.emit(AuthUiEvent.PhoneChallengeSent)
                }
                is AuthResult.Failure -> {
                    updateLoginState { state ->
                        state.copy(isLoading = false, error = result.reason.toLoginErrorKind())
                    }
                }
            }
        }
    }

    fun onRegistrationCodeChanged(value: String) {
        _registrationCodeUiState.value = _registrationCodeUiState.value.copy(code = value, error = null)
    }

    fun submitRegistrationCode() {
        val snapshot = _registrationCodeUiState.value
        if (snapshot.isLoading) return
        if (snapshot.code.isBlank()) {
            _registrationCodeUiState.value = snapshot.copy(error = RegistrationErrorKind.RequiredField)
            return
        }
        _registrationCodeUiState.value = snapshot.copy(isLoading = true, error = null)
        viewModelScope.launch {
            when (val result = validateRegistrationCodeUseCase(snapshot.code)) {
                is AuthResult.Success -> {
                    _registrationCodeUiState.value = _registrationCodeUiState.value.copy(
                        isLoading = false,
                        error = null,
                    )
                    _events.emit(AuthUiEvent.RegistrationCodeAccepted)
                }

                is AuthResult.Failure -> {
                    _registrationCodeUiState.value = _registrationCodeUiState.value.copy(
                        isLoading = false,
                        error = result.reason.toRegistrationCodeError(),
                    )
                }
            }
        }
    }

    fun onRegistrationPhoneChanged(value: String) {
        _confirmPhoneUiState.value = _confirmPhoneUiState.value.copy(phone = value, error = null)
    }

    fun submitRegistrationPhone() {
        val snapshot = _confirmPhoneUiState.value
        if (snapshot.isLoading) return
        if (snapshot.phone.isBlank()) {
            _confirmPhoneUiState.value = snapshot.copy(error = RegistrationErrorKind.RequiredField)
            return
        }
        _confirmPhoneUiState.value = snapshot.copy(isLoading = true, error = null)
        viewModelScope.launch {
            when (val result = requestPhoneChallengeUseCase(snapshot.phone)) {
                is AuthResult.Success -> {
                    _confirmPhoneUiState.value = _confirmPhoneUiState.value.copy(
                        isLoading = false,
                        error = null,
                    )
                    applyChallenge(result.value)
                    _events.emit(AuthUiEvent.PhoneChallengeSent)
                }

                is AuthResult.Failure -> {
                    _confirmPhoneUiState.value = _confirmPhoneUiState.value.copy(
                        isLoading = false,
                        error = result.reason.toPhoneError(),
                    )
                }
            }
        }
    }

    fun onOtpChanged(value: String) {
        val normalized = value.filter(Char::isDigit).take(OTP_LENGTH)
        _otpUiState.value = _otpUiState.value.copy(otp = normalized, error = null)
    }

    fun submitOtp() {
        val snapshot = _otpUiState.value
        if (snapshot.isLoading || snapshot.isResending) return
        if (snapshot.otp.length != OTP_LENGTH) {
            _otpUiState.value = snapshot.copy(error = RegistrationErrorKind.InvalidOtp)
            return
        }
        _otpUiState.value = snapshot.copy(isLoading = true, error = null)
        viewModelScope.launch {
            when (val result = verifyPhoneOtpUseCase(snapshot.otp)) {
                is AuthResult.Success -> {
                    resendTimerJob?.cancel()
                    _otpUiState.value = _otpUiState.value.copy(
                        otp = "",
                        isLoading = false,
                        error = null,
                    )
                    when (result.value) {
                        is PhoneAuthenticationResult.ExistingUser -> _events.emit(AuthUiEvent.Authenticated)
                        is PhoneAuthenticationResult.NewUser -> _events.emit(AuthUiEvent.NewUserOtpVerified)
                    }
                }

                is AuthResult.Failure -> {
                    _otpUiState.value = _otpUiState.value.copy(
                        isLoading = false,
                        error = result.reason.toOtpError(),
                    )
                }
            }
        }
    }

    fun resendOtp() {
        val snapshot = _otpUiState.value
        if (!snapshot.canResend) return
        _otpUiState.value = snapshot.copy(isResending = true, error = null)
        viewModelScope.launch {
            when (val result = resendPhoneChallengeUseCase()) {
                is AuthResult.Success -> {
                    _otpUiState.value = _otpUiState.value.copy(
                        otp = "",
                        isResending = false,
                        error = null,
                    )
                    applyChallenge(result.value)
                }

                is AuthResult.Failure -> {
                    _otpUiState.value = _otpUiState.value.copy(
                        isResending = false,
                        error = result.reason.toOtpError(),
                    )
                }
            }
        }
    }

    fun onAccountNameChanged(value: String) {
        _createAccountUiState.value = _createAccountUiState.value.copy(name = value, error = null)
    }

    fun onStoreNameChanged(value: String) {
        _createAccountUiState.value = _createAccountUiState.value.copy(storeName = value, error = null)
    }

    fun onAccountPasswordChanged(value: String) {
        _createAccountUiState.value = _createAccountUiState.value.copy(password = value, error = null)
    }

    fun onAccountPasswordConfirmationChanged(value: String) {
        _createAccountUiState.value = _createAccountUiState.value.copy(
            passwordConfirmation = value,
            error = null,
        )
    }

    fun toggleAccountPasswordVisibility() {
        _createAccountUiState.value = _createAccountUiState.value.copy(
            passwordVisible = !_createAccountUiState.value.passwordVisible,
        )
    }

    fun submitCreateAccount() {
        val snapshot = _createAccountUiState.value
        if (snapshot.isLoading) return
        if (snapshot.name.isBlank()) {
            _createAccountUiState.value = snapshot.copy(error = RegistrationErrorKind.RequiredField)
            return
        }
        _createAccountUiState.value = snapshot.copy(isLoading = true, error = null)
        viewModelScope.launch {
            when (val result = createAccountUseCase(name = snapshot.name)) {
                is AuthResult.Success -> {
                    _createAccountUiState.value = CreateAccountUiState()
                    _events.emit(AuthUiEvent.Authenticated)
                }
                is AuthResult.Failure -> {
                    _createAccountUiState.value = _createAccountUiState.value.copy(
                        isLoading = false,
                        error = result.reason.toAccountError(),
                    )
                }
            }
        }
    }

    fun onForgotPasswordPhoneChanged(value: String) {
        _forgotPasswordUiState.value = _forgotPasswordUiState.value.copy(phone = value, error = null)
    }

    fun submitPasswordResetRequest() {
        val snapshot = _forgotPasswordUiState.value
        if (snapshot.isLoading) return
        if (snapshot.phone.isBlank()) {
            _forgotPasswordUiState.value = snapshot.copy(error = PasswordResetErrorKind.RequiredField)
            return
        }
        _forgotPasswordUiState.value = snapshot.copy(isLoading = true, error = null)
        viewModelScope.launch {
            when (val result = requestPasswordResetUseCase(snapshot.phone)) {
                is AuthResult.Success -> {
                    _forgotPasswordUiState.value = _forgotPasswordUiState.value.copy(
                        isLoading = false,
                        error = null,
                    )
                    applyPasswordResetChallenge(result.value)
                    _events.emit(AuthUiEvent.PasswordResetCodeSent)
                }

                is AuthResult.Failure -> {
                    _forgotPasswordUiState.value = _forgotPasswordUiState.value.copy(
                        isLoading = false,
                        error = result.reason.toPasswordResetRequestError(),
                    )
                }
            }
        }
    }

    fun onResetCodeChanged(value: String) {
        _resetPasswordUiState.value = _resetPasswordUiState.value.copy(
            resetCode = value.filter(Char::isDigit).take(RESET_CODE_MAX_LENGTH),
            error = null,
        )
    }

    fun onResetNewPasswordChanged(value: String) {
        _resetPasswordUiState.value = _resetPasswordUiState.value.copy(newPassword = value, error = null)
    }

    fun onResetPasswordConfirmationChanged(value: String) {
        _resetPasswordUiState.value = _resetPasswordUiState.value.copy(confirmation = value, error = null)
    }

    fun toggleResetPasswordVisibility() {
        _resetPasswordUiState.value = _resetPasswordUiState.value.copy(
            passwordVisible = !_resetPasswordUiState.value.passwordVisible,
        )
    }

    fun resendPasswordResetCode() {
        val snapshot = _resetPasswordUiState.value
        if (!snapshot.canResend) return
        _resetPasswordUiState.value = snapshot.copy(isResending = true, error = null)
        viewModelScope.launch {
            when (val result = resendPasswordResetUseCase()) {
                is AuthResult.Success -> {
                    _resetPasswordUiState.value = _resetPasswordUiState.value.copy(
                        resetCode = "",
                        isResending = false,
                        error = null,
                    )
                    applyPasswordResetChallenge(result.value)
                }

                is AuthResult.Failure -> {
                    _resetPasswordUiState.value = _resetPasswordUiState.value.copy(
                        isResending = false,
                        error = result.reason.toPasswordResetConfirmError(),
                    )
                }
            }
        }
    }

    fun submitPasswordReset() {
        val snapshot = _resetPasswordUiState.value
        if (snapshot.isLoading || snapshot.isResending) return
        val localError = when {
            snapshot.resetCode.length !in 4..RESET_CODE_MAX_LENGTH -> PasswordResetErrorKind.InvalidCode
            snapshot.newPassword.length !in 6..128 -> PasswordResetErrorKind.PasswordTooShort
            snapshot.newPassword != snapshot.confirmation -> PasswordResetErrorKind.PasswordMismatch
            else -> null
        }
        if (localError != null) {
            _resetPasswordUiState.value = snapshot.copy(error = localError)
            return
        }
        _resetPasswordUiState.value = snapshot.copy(isLoading = true, error = null)
        viewModelScope.launch {
            when (
                val result = confirmPasswordResetUseCase(
                    resetCode = snapshot.resetCode,
                    newPassword = snapshot.newPassword,
                    confirmation = snapshot.confirmation,
                )
            ) {
                is AuthResult.Success -> {
                    passwordResetTimerJob?.cancel()
                    _forgotPasswordUiState.value = ForgotPasswordUiState()
                    _resetPasswordUiState.value = ResetPasswordUiState()
                    _events.emit(AuthUiEvent.PasswordResetCompleted)
                }

                is AuthResult.Failure -> {
                    _resetPasswordUiState.value = _resetPasswordUiState.value.copy(
                        isLoading = false,
                        error = result.reason.toPasswordResetConfirmError(),
                    )
                }
            }
        }
    }

    fun clearPasswordReset() {
        passwordResetTimerJob?.cancel()
        _forgotPasswordUiState.value = ForgotPasswordUiState()
        _resetPasswordUiState.value = ResetPasswordUiState()
        viewModelScope.launch { clearPasswordResetUseCase() }
    }

    fun clearRegistration() {
        resendTimerJob?.cancel()
        _registrationCodeUiState.value = RegistrationCodeUiState()
        _confirmPhoneUiState.value = ConfirmPhoneUiState()
        _otpUiState.value = OtpUiState()
        _createAccountUiState.value = CreateAccountUiState()
        viewModelScope.launch { clearRegistrationUseCase() }
    }

    fun requestContactSupport() {
        _events.tryEmit(AuthUiEvent.ContactSupportRequested)
    }

    fun clearSensitiveUiState() {
        resendTimerJob?.cancel()
        passwordResetTimerJob?.cancel()
        _loginUiState.value = LoginUiState()
        _registrationCodeUiState.value = RegistrationCodeUiState()
        _confirmPhoneUiState.value = ConfirmPhoneUiState()
        _otpUiState.value = OtpUiState()
        _createAccountUiState.value = CreateAccountUiState()
        _forgotPasswordUiState.value = ForgotPasswordUiState()
        _resetPasswordUiState.value = ResetPasswordUiState()
    }

    fun logout() {
        viewModelScope.launch { logoutUseCase() }
    }

    private fun applyChallenge(challenge: PhoneChallengeInfo) {
        val seconds = Duration.between(now(), challenge.resendAvailableAt)
            .seconds
            .coerceAtLeast(0)
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()
        _otpUiState.value = _otpUiState.value.copy(
            resendSecondsRemaining = seconds,
            remainingAttempts = challenge.remainingAttempts,
        )
        resendTimerJob?.cancel()
        if (seconds == 0) return
        resendTimerJob = viewModelScope.launch {
            while (_otpUiState.value.resendSecondsRemaining > 0) {
                delay(ONE_SECOND_MILLIS)
                val current = _otpUiState.value
                _otpUiState.value = current.copy(
                    resendSecondsRemaining = (current.resendSecondsRemaining - 1).coerceAtLeast(0),
                )
            }
        }
    }

    private fun applyPasswordResetChallenge(challenge: PasswordResetChallengeInfo) {
        val seconds = Duration.between(now(), challenge.resendAvailableAt)
            .seconds
            .coerceAtLeast(0)
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()
        _resetPasswordUiState.value = _resetPasswordUiState.value.copy(
            resendSecondsRemaining = seconds,
        )
        passwordResetTimerJob?.cancel()
        if (seconds == 0) return
        passwordResetTimerJob = viewModelScope.launch {
            while (_resetPasswordUiState.value.resendSecondsRemaining > 0) {
                delay(ONE_SECOND_MILLIS)
                val current = _resetPasswordUiState.value
                _resetPasswordUiState.value = current.copy(
                    resendSecondsRemaining = (current.resendSecondsRemaining - 1).coerceAtLeast(0),
                )
            }
        }
    }

    private inline fun updateLoginState(transform: (LoginUiState) -> LoginUiState) {
        _loginUiState.value = transform(_loginUiState.value)
    }

    private companion object {
        const val OTP_LENGTH = 6
        const val RESET_CODE_MAX_LENGTH = 12
        const val ONE_SECOND_MILLIS = 1_000L
    }
}

private fun AuthFailure.toLoginErrorKind(): LoginErrorKind = when (this) {
    AuthFailure.InvalidCredentials,
    AuthFailure.InvalidRequest -> LoginErrorKind.InvalidPhone
    AuthFailure.NetworkUnavailable -> LoginErrorKind.Offline
    AuthFailure.RateLimited -> LoginErrorKind.TemporarilyLocked
    AuthFailure.NoSession,
    AuthFailure.SessionExpired -> LoginErrorKind.SessionExpired

    is AuthFailure.Server -> LoginErrorKind.Generic
}

private fun AuthFailure.toRegistrationCodeError(): RegistrationErrorKind = when (this) {
    AuthFailure.InvalidRequest,
    AuthFailure.InvalidCredentials -> RegistrationErrorKind.InvalidCode

    AuthFailure.NetworkUnavailable -> RegistrationErrorKind.Offline
    AuthFailure.RateLimited -> RegistrationErrorKind.TemporarilyLocked
    AuthFailure.NoSession,
    AuthFailure.SessionExpired -> RegistrationErrorKind.SessionExpired

    is AuthFailure.Server -> RegistrationErrorKind.Generic
}

private fun AuthFailure.toPhoneError(): RegistrationErrorKind = when (this) {
    AuthFailure.InvalidRequest,
    AuthFailure.InvalidCredentials -> RegistrationErrorKind.InvalidPhone

    AuthFailure.NetworkUnavailable -> RegistrationErrorKind.Offline
    AuthFailure.RateLimited -> RegistrationErrorKind.TemporarilyLocked
    AuthFailure.NoSession,
    AuthFailure.SessionExpired -> RegistrationErrorKind.SessionExpired

    is AuthFailure.Server -> RegistrationErrorKind.Generic
}

private fun AuthFailure.toOtpError(): RegistrationErrorKind = when (this) {
    AuthFailure.InvalidRequest,
    AuthFailure.InvalidCredentials -> RegistrationErrorKind.InvalidOtp

    AuthFailure.NetworkUnavailable -> RegistrationErrorKind.Offline
    AuthFailure.RateLimited -> RegistrationErrorKind.TemporarilyLocked
    AuthFailure.NoSession,
    AuthFailure.SessionExpired -> RegistrationErrorKind.SessionExpired

    is AuthFailure.Server -> RegistrationErrorKind.Generic
}

private fun AuthFailure.toAccountError(): RegistrationErrorKind = when (this) {
    AuthFailure.InvalidRequest,
    AuthFailure.InvalidCredentials -> RegistrationErrorKind.Generic

    AuthFailure.NetworkUnavailable -> RegistrationErrorKind.Offline
    AuthFailure.RateLimited -> RegistrationErrorKind.TemporarilyLocked
    AuthFailure.NoSession,
    AuthFailure.SessionExpired -> RegistrationErrorKind.SessionExpired

    is AuthFailure.Server -> RegistrationErrorKind.Generic
}

private fun AuthFailure.toPasswordResetRequestError(): PasswordResetErrorKind = when (this) {
    AuthFailure.InvalidRequest -> PasswordResetErrorKind.InvalidPhone
    AuthFailure.NetworkUnavailable -> PasswordResetErrorKind.Offline
    AuthFailure.RateLimited -> PasswordResetErrorKind.TemporarilyLocked
    else -> PasswordResetErrorKind.Generic
}

private fun AuthFailure.toPasswordResetConfirmError(): PasswordResetErrorKind = when (this) {
    AuthFailure.InvalidRequest,
    AuthFailure.InvalidCredentials -> PasswordResetErrorKind.InvalidCode
    AuthFailure.NetworkUnavailable -> PasswordResetErrorKind.Offline
    AuthFailure.RateLimited -> PasswordResetErrorKind.TemporarilyLocked
    else -> PasswordResetErrorKind.Generic
}
