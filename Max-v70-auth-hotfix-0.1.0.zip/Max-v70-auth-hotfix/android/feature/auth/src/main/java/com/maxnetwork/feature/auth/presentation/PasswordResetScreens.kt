package com.maxnetwork.feature.auth.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.maxnetwork.core.designsystem.component.MaxBrandMark
import com.maxnetwork.core.designsystem.component.MaxErrorMessage
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxTertiaryButton
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTextField
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.auth.R

data class ForgotPasswordScreenActions(
    val onPhoneChanged: (String) -> Unit,
    val onSubmit: () -> Unit,
    val onBack: () -> Unit,
)

@Composable
fun ForgotPasswordScreen(
    state: ForgotPasswordUiState,
    actions: ForgotPasswordScreenActions,
    modifier: Modifier = Modifier,
) {
    val focusManager = LocalFocusManager.current
    val submit = {
        focusManager.clearFocus()
        actions.onSubmit()
    }
    MaxScaffold(
        modifier = modifier.testTag("forgot_password_screen"),
        topBar = {
            MaxTopBar(
                title = stringResource(R.string.max_auth_forgot_password_title),
                onBack = actions.onBack,
                backContentDescription = stringResource(R.string.max_auth_back),
            )
        },
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = MaxSpacing.lg, vertical = MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            MaxBrandMark()
            MaxText(
                text = stringResource(R.string.max_auth_forgot_password_heading),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineMedium,
            )
            MaxText(
                text = stringResource(R.string.max_auth_forgot_password_message),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            MaxTextField(
                value = state.phone,
                onValueChange = actions.onPhoneChanged,
                label = stringResource(R.string.max_auth_phone),
                enabled = !state.isLoading,
                isError = state.error == PasswordResetErrorKind.RequiredField ||
                    state.error == PasswordResetErrorKind.InvalidPhone,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                testTag = "forgot_password_phone",
            )
            state.error?.let {
                MaxErrorMessage(
                    message = it.requestMessage(),
                    modifier = Modifier.testTag("forgot_password_error"),
                )
            }
            MaxPrimaryButton(
                text = stringResource(R.string.max_auth_send_reset_code),
                onClick = submit,
                enabled = state.canSubmit,
                loading = state.isLoading,
                testTag = "forgot_password_submit",
            )
        }
    }
}

data class ResetPasswordScreenActions(
    val onCodeChanged: (String) -> Unit,
    val onNewPasswordChanged: (String) -> Unit,
    val onConfirmationChanged: (String) -> Unit,
    val onTogglePasswordVisibility: () -> Unit,
    val onSubmit: () -> Unit,
    val onResend: () -> Unit,
    val onBack: () -> Unit,
)

@Composable
fun ResetPasswordScreen(
    state: ResetPasswordUiState,
    actions: ResetPasswordScreenActions,
    modifier: Modifier = Modifier,
) {
    val newPasswordFocus = FocusRequester()
    val confirmationFocus = FocusRequester()
    val focusManager = LocalFocusManager.current
    val submit = {
        focusManager.clearFocus()
        actions.onSubmit()
    }
    MaxScaffold(
        modifier = modifier.testTag("reset_password_screen"),
        topBar = {
            MaxTopBar(
                title = stringResource(R.string.max_auth_reset_password_title),
                onBack = actions.onBack,
                backContentDescription = stringResource(R.string.max_auth_back),
            )
        },
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = MaxSpacing.lg, vertical = MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            MaxBrandMark()
            MaxText(
                text = stringResource(R.string.max_auth_reset_password_heading),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineMedium,
            )
            MaxText(
                text = stringResource(R.string.max_auth_reset_generic_message),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            MaxTextField(
                value = state.resetCode,
                onValueChange = actions.onCodeChanged,
                label = stringResource(R.string.max_auth_reset_code),
                enabled = !state.isLoading,
                isError = state.error == PasswordResetErrorKind.RequiredField ||
                    state.error == PasswordResetErrorKind.InvalidCode,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Next,
                ),
                keyboardActions = KeyboardActions(onNext = { newPasswordFocus.requestFocus() }),
                testTag = "reset_password_code",
            )
            MaxTextField(
                value = state.newPassword,
                onValueChange = actions.onNewPasswordChanged,
                label = stringResource(R.string.max_auth_new_password),
                modifier = Modifier.focusRequester(newPasswordFocus),
                enabled = !state.isLoading,
                isError = state.error == PasswordResetErrorKind.PasswordTooShort ||
                    state.error == PasswordResetErrorKind.PasswordMismatch,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next,
                ),
                keyboardActions = KeyboardActions(onNext = { confirmationFocus.requestFocus() }),
                visualTransformation = if (state.passwordVisible) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                trailingIcon = {
                    MaxTertiaryButton(
                        text = if (state.passwordVisible) {
                            stringResource(R.string.max_auth_hide_password)
                        } else {
                            stringResource(R.string.max_auth_show_password)
                        },
                        onClick = actions.onTogglePasswordVisibility,
                        testTag = "reset_password_visibility",
                    )
                },
                testTag = "reset_password_new",
            )
            MaxTextField(
                value = state.confirmation,
                onValueChange = actions.onConfirmationChanged,
                label = stringResource(R.string.max_auth_password_confirmation),
                modifier = Modifier.focusRequester(confirmationFocus),
                enabled = !state.isLoading,
                isError = state.error == PasswordResetErrorKind.PasswordMismatch,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                visualTransformation = if (state.passwordVisible) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                testTag = "reset_password_confirmation",
            )
            state.error?.let {
                MaxErrorMessage(
                    message = it.confirmMessage(),
                    modifier = Modifier.testTag("reset_password_error"),
                )
            }
            MaxPrimaryButton(
                text = stringResource(R.string.max_auth_save_password),
                onClick = submit,
                enabled = state.canSubmit,
                loading = state.isLoading,
                testTag = "reset_password_submit",
            )
            MaxTertiaryButton(
                text = if (state.resendSecondsRemaining > 0) {
                    stringResource(R.string.max_auth_resend_countdown, state.resendSecondsRemaining)
                } else {
                    stringResource(R.string.max_auth_resend)
                },
                onClick = actions.onResend,
                enabled = state.canResend,
                modifier = Modifier.align(Alignment.CenterHorizontally),
                testTag = "reset_password_resend",
            )
        }
    }
}

@Composable
private fun PasswordResetErrorKind.requestMessage(): String = when (this) {
    PasswordResetErrorKind.RequiredField,
    PasswordResetErrorKind.InvalidPhone -> stringResource(R.string.max_auth_phone_invalid)
    PasswordResetErrorKind.Offline -> stringResource(R.string.max_auth_offline)
    PasswordResetErrorKind.TemporarilyLocked -> stringResource(R.string.max_auth_rate_limited)
    else -> stringResource(R.string.max_auth_reset_request_failed)
}

@Composable
private fun PasswordResetErrorKind.confirmMessage(): String = when (this) {
    PasswordResetErrorKind.RequiredField -> stringResource(R.string.max_auth_account_required)
    PasswordResetErrorKind.InvalidCode -> stringResource(R.string.max_auth_reset_code_invalid)
    PasswordResetErrorKind.PasswordTooShort -> stringResource(R.string.max_auth_password_short)
    PasswordResetErrorKind.PasswordMismatch -> stringResource(R.string.max_auth_password_mismatch)
    PasswordResetErrorKind.Offline -> stringResource(R.string.max_auth_offline)
    PasswordResetErrorKind.TemporarilyLocked -> stringResource(R.string.max_auth_rate_limited)
    else -> stringResource(R.string.max_auth_reset_failed)
}
