package com.maxnetwork.feature.auth.data

import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.SignOutReason
import java.time.Instant
import kotlinx.coroutines.flow.StateFlow

internal data class StoredAuthSession(
    val accessToken: String,
    val refreshToken: String,
    val expiresAt: Instant,
)

internal interface AuthTokenStorage {
    fun read(): StoredAuthSession?

    fun write(session: StoredAuthSession)

    fun clear()
}

/** Owns persisted credentials and publishes only a token-free application state. */
internal interface AuthSessionStore {
    val state: StateFlow<AuthState>

    suspend fun restore(): StoredAuthSession?

    suspend fun current(): StoredAuthSession?

    suspend fun save(session: StoredAuthSession)

    suspend fun markAuthenticated(expiresAt: Instant)

    suspend fun markRefreshing(previousExpiry: Instant?)

    suspend fun markUnavailable(retryable: Boolean)

    suspend fun clear(reason: SignOutReason)
}
