package com.maxnetwork.feature.auth.presentation

data class ForgotPasswordUiState(
    val phone: String = "",
    val isLoading: Boolean = false,
    val error: PasswordResetErrorKind? = null,
) {
    val canSubmit: Boolean
        get() = phone.isNotBlank() && !isLoading
}

data class ResetPasswordUiState(
    val resetCode: String = "",
    val newPassword: String = "",
    val confirmation: String = "",
    val passwordVisible: Boolean = false,
    val isLoading: Boolean = false,
    val isResending: Boolean = false,
    val resendSecondsRemaining: Int = 0,
    val error: PasswordResetErrorKind? = null,
) {
    val canSubmit: Boolean
        get() = resetCode.length in 4..12 && newPassword.isNotBlank() && confirmation.isNotBlank() &&
            !isLoading && !isResending

    val canResend: Boolean
        get() = resendSecondsRemaining == 0 && !isLoading && !isResending
}

enum class PasswordResetErrorKind {
    RequiredField,
    InvalidPhone,
    InvalidCode,
    PasswordTooShort,
    PasswordMismatch,
    Offline,
    TemporarilyLocked,
    Generic,
}
