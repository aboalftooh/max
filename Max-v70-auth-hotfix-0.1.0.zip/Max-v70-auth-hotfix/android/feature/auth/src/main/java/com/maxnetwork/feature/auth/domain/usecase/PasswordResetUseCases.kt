package com.maxnetwork.feature.auth.domain.usecase

import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.PasswordResetChallengeInfo
import com.maxnetwork.feature.auth.domain.PasswordResetConfirmation
import com.maxnetwork.feature.auth.domain.PasswordResetRepository

class RequestPasswordResetUseCase(
    private val repository: PasswordResetRepository,
) {
    suspend operator fun invoke(phone: String): AuthResult<PasswordResetChallengeInfo> {
        val normalized = phone.trim()
        if (!PHONE_PATTERN.matches(normalized)) return AuthResult.Failure(AuthFailure.InvalidRequest)
        return repository.requestCode(normalized)
    }

    private companion object {
        val PHONE_PATTERN = Regex("^\\+[1-9][0-9]{7,14}$")
    }
}

class ResendPasswordResetUseCase(
    private val repository: PasswordResetRepository,
) {
    suspend operator fun invoke(): AuthResult<PasswordResetChallengeInfo> = repository.resendCode()
}

class ConfirmPasswordResetUseCase(
    private val repository: PasswordResetRepository,
) {
    suspend operator fun invoke(
        resetCode: String,
        newPassword: String,
        confirmation: String,
    ): AuthResult<Unit> {
        val normalizedCode = resetCode.trim()
        if (normalizedCode.length !in 4..12 || !normalizedCode.all(Char::isDigit)) {
            return AuthResult.Failure(AuthFailure.InvalidRequest)
        }
        if (newPassword.length !in 6..128 || newPassword != confirmation) {
            return AuthResult.Failure(AuthFailure.InvalidRequest)
        }
        return repository.resetPassword(
            PasswordResetConfirmation(
                resetCode = normalizedCode,
                newPassword = newPassword,
            ),
        )
    }
}

class ClearPasswordResetUseCase(
    private val repository: PasswordResetRepository,
) {
    suspend operator fun invoke() = repository.clear()
}
