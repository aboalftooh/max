package com.maxnetwork.feature.auth.domain

interface RegistrationRepository {
    suspend fun requestPhoneChallenge(phone: String): AuthResult<PhoneChallengeInfo>

    suspend fun resendPhoneChallenge(): AuthResult<PhoneChallengeInfo>

    suspend fun verifyPhoneOtp(otp: String): AuthResult<PhoneAuthenticationResult>

    suspend fun validateRegistrationCode(code: String): AuthResult<RegistrationCodeAcceptance>

    suspend fun createAccount(account: NewAccount): AuthResult<AuthState.Authenticated>

    suspend fun clearRegistration()
}
