package com.maxnetwork.feature.auth.data

import java.time.Instant
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal sealed interface StoredRegistrationSession {
    data object Empty : StoredRegistrationSession

    data class PhoneChallengeCreated(
        val phone: String,
        val challengeId: String,
        val challengeExpiresAt: Instant,
        val resendAvailableAt: Instant,
        val remainingAttempts: Int,
    ) : StoredRegistrationSession

    data class PhoneVerified(
        val phone: String,
        val phoneVerificationToken: String,
        val verificationExpiresAt: Instant,
        val maskedPhone: String,
    ) : StoredRegistrationSession

    data class ReadyToCreateAccount(
        val phone: String,
        val phoneVerificationToken: String,
        val verificationExpiresAt: Instant,
        val maskedPhone: String,
        val validationToken: String,
        val registrationExpiresAt: Instant,
    ) : StoredRegistrationSession
}

internal class RegistrationSessionStore {
    private val mutex = Mutex()
    private var session: StoredRegistrationSession = StoredRegistrationSession.Empty

    suspend fun replace(value: StoredRegistrationSession) {
        mutex.withLock { session = value }
    }

    suspend fun current(): StoredRegistrationSession = mutex.withLock { session }

    suspend fun clear() = replace(StoredRegistrationSession.Empty)
}
