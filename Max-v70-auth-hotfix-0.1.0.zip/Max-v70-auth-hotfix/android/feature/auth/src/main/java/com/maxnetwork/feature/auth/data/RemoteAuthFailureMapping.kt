package com.maxnetwork.feature.auth.data

import com.maxnetwork.feature.auth.domain.AuthFailure

internal fun RemoteAuthResult.Failure.toAuthFailure(): AuthFailure = when (kind) {
    RemoteAuthFailure.RateLimited -> AuthFailure.RateLimited
    RemoteAuthFailure.Network -> AuthFailure.NetworkUnavailable
    RemoteAuthFailure.Unauthorized -> AuthFailure.SessionExpired
    RemoteAuthFailure.InvalidCredentials,
    RemoteAuthFailure.InvalidRequest -> AuthFailure.InvalidRequest
    RemoteAuthFailure.Server -> AuthFailure.Server(retryable = retryable)
}
