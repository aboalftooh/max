package com.maxnetwork.feature.auth.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import com.maxnetwork.core.designsystem.component.MaxBrandMark
import com.maxnetwork.core.designsystem.component.MaxErrorMessage
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTextField
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.auth.R

data class CreateAccountScreenActions(
    val onNameChanged: (String) -> Unit,
    val onStoreNameChanged: (String) -> Unit = {},
    val onPasswordChanged: (String) -> Unit = {},
    val onPasswordConfirmationChanged: (String) -> Unit = {},
    val onTogglePasswordVisibility: () -> Unit = {},
    val onSubmit: () -> Unit,
    val onBack: () -> Unit,
)

@Composable
fun CreateAccountScreen(
    state: CreateAccountUiState,
    actions: CreateAccountScreenActions,
    modifier: Modifier = Modifier,
) {
    val focusManager = LocalFocusManager.current
    val submit = { focusManager.clearFocus(); actions.onSubmit() }
    MaxScaffold(
        modifier = modifier.testTag("create_account_screen"),
        topBar = {
            MaxTopBar(
                title = "بيانات التسجيل",
                onBack = actions.onBack,
                backContentDescription = stringResource(R.string.max_auth_back),
            )
        },
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = MaxSpacing.lg, vertical = MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            MaxBrandMark()
            MaxText(
                text = "أكمل بياناتك",
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineMedium,
            )
            MaxText(
                text = "تم التحقق من رقمك وكود الانضمام. أدخل الاسم لإكمال الربط.",
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            MaxTextField(
                value = state.name,
                onValueChange = actions.onNameChanged,
                label = stringResource(R.string.max_auth_name),
                enabled = !state.isLoading,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                testTag = "create_account_name",
            )
            state.error?.let { error ->
                MaxErrorMessage(
                    message = error.accountMessage(),
                    modifier = Modifier.testTag("create_account_error"),
                )
            }
            MaxPrimaryButton(
                text = "إكمال التسجيل",
                onClick = submit,
                enabled = state.canSubmit,
                loading = state.isLoading,
                testTag = "create_account_submit",
            )
        }
    }
}

@Composable
private fun RegistrationErrorKind.accountMessage(): String = when (this) {
    RegistrationErrorKind.RequiredField -> stringResource(R.string.max_auth_account_required)
    RegistrationErrorKind.Offline -> stringResource(R.string.max_auth_offline)
    RegistrationErrorKind.TemporarilyLocked -> stringResource(R.string.max_auth_rate_limited)
    RegistrationErrorKind.SessionExpired -> stringResource(R.string.max_auth_registration_session_expired)
    else -> stringResource(R.string.max_auth_account_failed)
}
