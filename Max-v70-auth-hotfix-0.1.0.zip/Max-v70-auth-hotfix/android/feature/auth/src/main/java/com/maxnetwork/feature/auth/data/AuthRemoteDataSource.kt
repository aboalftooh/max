package com.maxnetwork.feature.auth.data

import java.time.Instant

internal interface AuthRemoteDataSource {
    suspend fun validateRegistrationCode(code: String): RemoteAuthResult<RemoteRegistrationValidation>
    suspend fun requestPhoneChallenge(phone: String): RemoteAuthResult<RemotePhoneChallenge>
    suspend fun verifyPhoneChallenge(challengeId: String, otp: String): RemoteAuthResult<RemoteVerifiedPhone>
    suspend fun resolveVerifiedPhone(verificationToken: String): RemoteAuthResult<RemotePhoneAuthentication>
    suspend fun createAccount(command: RemoteAccountCreation): RemoteAuthResult<RemoteSession>
    suspend fun requestPasswordReset(phone: String): RemoteAuthResult<RemotePhoneChallenge>
    suspend fun resetPassword(phone: String, resetCode: String, newPassword: String): RemoteAuthResult<Unit>
    suspend fun login(phone: String, password: String): RemoteAuthResult<RemoteSession>
    suspend fun refresh(refreshToken: String): RemoteAuthResult<RemoteSession>
    suspend fun logout(accessToken: String): RemoteAuthResult<Unit>
}

internal data class RemoteRegistrationValidation(val validationToken: String, val expiresAt: Instant)
internal data class RemotePhoneChallenge(
    val challengeId: String,
    val expiresAt: Instant,
    val resendAvailableAt: Instant,
    val remainingAttempts: Int,
)
internal data class RemoteVerifiedPhone(
    val verificationToken: String,
    val maskedPhone: String,
    val expiresAt: Instant,
)
internal sealed interface RemotePhoneAuthentication {
    data class ExistingUser(val session: RemoteSession) : RemotePhoneAuthentication
    data object NewUser : RemotePhoneAuthentication
}
internal data class RemoteAccountCreation(
    val name: String,
    val phoneVerificationToken: String,
    val registrationValidationToken: String,
)
internal data class RemoteSession(val accessToken: String, val refreshToken: String, val expiresAt: Instant)

internal sealed interface RemoteAuthResult<out T> {
    data class Success<T>(val value: T) : RemoteAuthResult<T>
    data class Failure(val kind: RemoteAuthFailure, val retryable: Boolean) : RemoteAuthResult<Nothing>
}

internal enum class RemoteAuthFailure {
    InvalidCredentials,
    Unauthorized,
    RateLimited,
    InvalidRequest,
    Network,
    Server,
}
