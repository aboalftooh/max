package com.maxnetwork.feature.auth.domain

interface PasswordResetRepository {
    suspend fun requestCode(phone: String): AuthResult<PasswordResetChallengeInfo>

    suspend fun resendCode(): AuthResult<PasswordResetChallengeInfo>

    suspend fun resetPassword(confirmation: PasswordResetConfirmation): AuthResult<Unit>

    suspend fun clear()
}
