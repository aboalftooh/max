package com.maxnetwork.feature.auth.domain.usecase

import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.NewAccount
import com.maxnetwork.feature.auth.domain.PhoneChallengeInfo
import com.maxnetwork.feature.auth.domain.RegistrationCodeAcceptance
import com.maxnetwork.feature.auth.domain.RegistrationRepository
import com.maxnetwork.feature.auth.domain.PhoneAuthenticationResult

class ValidateRegistrationCodeUseCase(
    private val repository: RegistrationRepository,
) {
    suspend operator fun invoke(code: String): AuthResult<RegistrationCodeAcceptance> {
        val normalized = code.trim()
        if (normalized.length !in 4..64) {
            return AuthResult.Failure(AuthFailure.InvalidRequest)
        }
        return repository.validateRegistrationCode(normalized)
    }
}

class RequestPhoneChallengeUseCase(
    private val repository: RegistrationRepository,
) {
    suspend operator fun invoke(phone: String): AuthResult<PhoneChallengeInfo> {
        val normalized = normalizePhoneForMax(phone)
            ?: return AuthResult.Failure(AuthFailure.InvalidRequest)
        return repository.requestPhoneChallenge(normalized)
    }
}

internal fun normalizePhoneForMax(raw: String): String? {
    val ascii = buildString {
        raw.trim().forEach { ch ->
            when (ch) {
                in '0'..'9' -> append(ch)
                in '\u0660'..'\u0669' -> append('0' + (ch.code - '\u0660'.code))
                in '\u06F0'..'\u06F9' -> append('0' + (ch.code - '\u06F0'.code))
                '+', ' ', '-', '(', ')' -> if (ch == '+') append(ch)
            }
        }
    }
    val normalized = when {
        ascii.startsWith("+249") -> ascii
        ascii.startsWith("00249") -> "+${ascii.drop(2)}"
        ascii.startsWith("249") -> "+$ascii"
        ascii.startsWith("0") && ascii.length == 10 -> "+249${ascii.drop(1)}"
        ascii.length == 9 && ascii.all(Char::isDigit) -> "+249$ascii"
        ascii.startsWith("+") -> ascii
        else -> return null
    }
    return normalized.takeIf { Regex("^\\+[1-9][0-9]{7,14}$").matches(it) }
}

class ResendPhoneChallengeUseCase(
    private val repository: RegistrationRepository,
) {
    suspend operator fun invoke(): AuthResult<PhoneChallengeInfo> = repository.resendPhoneChallenge()
}

class VerifyPhoneOtpUseCase(
    private val repository: RegistrationRepository,
) {
    suspend operator fun invoke(otp: String): AuthResult<PhoneAuthenticationResult> {
        if (otp.length != OTP_LENGTH || !otp.all(Char::isDigit)) {
            return AuthResult.Failure(AuthFailure.InvalidRequest)
        }
        return repository.verifyPhoneOtp(otp)
    }

    private companion object {
        const val OTP_LENGTH = 6
    }
}

class CreateAccountUseCase(
    private val repository: RegistrationRepository,
) {
    suspend operator fun invoke(name: String): AuthResult<AuthState.Authenticated> {
        val normalizedName = name.trim()
        if (normalizedName.length !in 2..100) {
            return AuthResult.Failure(AuthFailure.InvalidRequest)
        }
        return repository.createAccount(NewAccount(name = normalizedName))
    }
}

class ClearRegistrationUseCase(
    private val repository: RegistrationRepository,
) {
    suspend operator fun invoke() = repository.clearRegistration()
}
