package com.maxnetwork.feature.auth

import android.content.Context
import com.maxnetwork.core.common.ClockProvider
import com.maxnetwork.core.common.SystemClockProvider
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.auth.data.AndroidKeystoreTokenStorage
import com.maxnetwork.feature.auth.data.DefaultAuthRepository
import com.maxnetwork.feature.auth.data.DefaultAuthSessionStore
import com.maxnetwork.feature.auth.data.DefaultRegistrationRepository
import com.maxnetwork.feature.auth.data.DefaultPasswordResetRepository
import com.maxnetwork.feature.auth.data.GatewayAuthRemoteDataSource
import com.maxnetwork.feature.auth.data.RegistrationSessionStore
import com.maxnetwork.feature.auth.data.PasswordResetSessionStore
import com.maxnetwork.feature.auth.domain.AuthRepository
import com.maxnetwork.feature.auth.domain.RegistrationRepository
import com.maxnetwork.feature.auth.domain.PasswordResetRepository
import com.maxnetwork.feature.auth.domain.usecase.ClearRegistrationUseCase
import com.maxnetwork.feature.auth.domain.usecase.ClearPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.ConfirmPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.CreateAccountUseCase
import com.maxnetwork.feature.auth.domain.usecase.GetValidAccessTokenUseCase
import com.maxnetwork.feature.auth.domain.usecase.LoginUseCase
import com.maxnetwork.feature.auth.domain.usecase.LogoutUseCase
import com.maxnetwork.feature.auth.domain.usecase.ObserveAuthStateUseCase
import com.maxnetwork.feature.auth.domain.usecase.RefreshSessionUseCase
import com.maxnetwork.feature.auth.domain.usecase.RequestPhoneChallengeUseCase
import com.maxnetwork.feature.auth.domain.usecase.RequestPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.ResendPhoneChallengeUseCase
import com.maxnetwork.feature.auth.domain.usecase.ResendPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.RestoreSessionUseCase
import com.maxnetwork.feature.auth.domain.usecase.ValidateRegistrationCodeUseCase
import com.maxnetwork.feature.auth.domain.usecase.VerifyPhoneOtpUseCase

data class AuthUseCases(
    val observeState: ObserveAuthStateUseCase,
    val restoreSession: RestoreSessionUseCase,
    val login: LoginUseCase,
    val refreshSession: RefreshSessionUseCase,
    val getValidAccessToken: GetValidAccessTokenUseCase,
    val logout: LogoutUseCase,
    val validateRegistrationCode: ValidateRegistrationCodeUseCase,
    val requestPhoneChallenge: RequestPhoneChallengeUseCase,
    val resendPhoneChallenge: ResendPhoneChallengeUseCase,
    val verifyPhoneOtp: VerifyPhoneOtpUseCase,
    val createAccount: CreateAccountUseCase,
    val clearRegistration: ClearRegistrationUseCase,
    val requestPasswordReset: RequestPasswordResetUseCase,
    val resendPasswordReset: ResendPasswordResetUseCase,
    val confirmPasswordReset: ConfirmPasswordResetUseCase,
    val clearPasswordReset: ClearPasswordResetUseCase,
)

data class AuthFeatureDependencies(
    val repository: AuthRepository,
    val registrationRepository: RegistrationRepository,
    val passwordResetRepository: PasswordResetRepository,
    val useCases: AuthUseCases,
)

object AuthFeatureFactory {
    fun create(
        context: Context,
        gateway: MaxGateway,
        clock: ClockProvider = SystemClockProvider,
        onAccessTokenChanged: (String?) -> Unit = {},
    ): AuthFeatureDependencies {
        val remote = GatewayAuthRemoteDataSource(gateway)
        val authSessionStore = DefaultAuthSessionStore(
            storage = AndroidKeystoreTokenStorage(context),
            onAccessTokenChanged = onAccessTokenChanged,
        )
        val repository = DefaultAuthRepository(
            remote = remote,
            sessionStore = authSessionStore,
            clock = clock,
        )
        val passwordResetRepository = DefaultPasswordResetRepository(
            remote = remote,
            resetStore = PasswordResetSessionStore(),
            authSessionStore = authSessionStore,
        )
        val registrationRepository = DefaultRegistrationRepository(
            remote = remote,
            registrationStore = RegistrationSessionStore(),
            authSessionStore = authSessionStore,
        )
        return AuthFeatureDependencies(
            repository = repository,
            registrationRepository = registrationRepository,
            passwordResetRepository = passwordResetRepository,
            useCases = AuthUseCases(
                observeState = ObserveAuthStateUseCase(repository),
                restoreSession = RestoreSessionUseCase(repository),
                login = LoginUseCase(repository),
                refreshSession = RefreshSessionUseCase(repository),
                getValidAccessToken = GetValidAccessTokenUseCase(repository),
                logout = LogoutUseCase(repository),
                validateRegistrationCode = ValidateRegistrationCodeUseCase(registrationRepository),
                requestPhoneChallenge = RequestPhoneChallengeUseCase(registrationRepository),
                resendPhoneChallenge = ResendPhoneChallengeUseCase(registrationRepository),
                verifyPhoneOtp = VerifyPhoneOtpUseCase(registrationRepository),
                createAccount = CreateAccountUseCase(registrationRepository),
                clearRegistration = ClearRegistrationUseCase(registrationRepository),
                requestPasswordReset = RequestPasswordResetUseCase(passwordResetRepository),
                resendPasswordReset = ResendPasswordResetUseCase(passwordResetRepository),
                confirmPasswordReset = ConfirmPasswordResetUseCase(passwordResetRepository),
                clearPasswordReset = ClearPasswordResetUseCase(passwordResetRepository),
            ),
        )
    }
}
