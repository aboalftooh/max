package com.maxnetwork.feature.auth.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import com.maxnetwork.core.designsystem.component.MaxBrandMark
import com.maxnetwork.core.designsystem.component.MaxErrorMessage
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTextField
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.auth.R

data class LoginScreenActions(
    val onPhoneChanged: (String) -> Unit,
    val onSubmit: () -> Unit,
)

@Composable
fun LoginScreen(
    state: LoginUiState,
    actions: LoginScreenActions,
    modifier: Modifier = Modifier,
) {
    val focusManager = LocalFocusManager.current
    val submit = {
        focusManager.clearFocus()
        actions.onSubmit()
    }
    MaxScaffold(
        modifier = modifier.testTag("login_screen"),
        topBar = {
            MaxTopBar(
                title = stringResource(R.string.max_auth_login),
                leadingContent = {
                    MaxBrandMark(
                        size = MaxSizes.iconContainer,
                        contentDescription = stringResource(R.string.max_auth_app_name),
                    )
                },
            )
        },
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = MaxSpacing.lg, vertical = MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            MaxBrandMark()
            MaxText(
                text = stringResource(R.string.max_auth_login_title),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineMedium,
            )
            MaxText(
                text = stringResource(R.string.max_auth_login_message),
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            MaxTextField(
                value = state.phone,
                onValueChange = actions.onPhoneChanged,
                label = stringResource(R.string.max_auth_phone),
                enabled = !state.isLoading,
                isError = state.error == LoginErrorKind.RequiredPhone || state.error == LoginErrorKind.InvalidPhone,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                testTag = "login_phone",
            )
            state.error?.let {
                MaxErrorMessage(
                    message = it.message(),
                    modifier = Modifier.testTag("login_error"),
                )
            }
            MaxPrimaryButton(
                text = stringResource(R.string.max_auth_send_otp),
                onClick = submit,
                enabled = state.canSubmit,
                loading = state.isLoading,
                testTag = "login_submit",
            )
        }
    }
}

@Composable
private fun LoginErrorKind.message(): String = when (this) {
    LoginErrorKind.RequiredPhone -> stringResource(R.string.max_auth_phone_required)
    LoginErrorKind.InvalidPhone -> stringResource(R.string.max_auth_phone_invalid)
    LoginErrorKind.Offline -> stringResource(R.string.max_auth_offline)
    LoginErrorKind.TemporarilyLocked -> stringResource(R.string.max_auth_rate_limited)
    LoginErrorKind.SessionExpired -> stringResource(R.string.max_auth_session_expired)
    LoginErrorKind.Generic -> stringResource(R.string.max_auth_generic_error)
}
