package com.maxnetwork.feature.auth.data

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import java.time.Instant
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class AndroidKeystoreTokenStorageTest {
    private lateinit var context: Context
    private lateinit var storage: AndroidKeystoreTokenStorage

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences(AndroidKeystoreTokenStorage.PREFERENCES_NAME, Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()
        storage = AndroidKeystoreTokenStorage(context)
    }

    @After
    fun tearDown() {
        storage.clear()
    }

    @Test
    fun encryptedSessionSurvivesStoreRecreation() {
        val expected = StoredAuthSession(
            accessToken = "access-fixture",
            refreshToken = "refresh-fixture",
            expiresAt = Instant.parse("2026-07-28T13:00:00Z"),
        )

        storage.write(expected)
        val restored = AndroidKeystoreTokenStorage(context).read()

        assertEquals(expected, restored)
    }

    @Test
    fun preferencesNeverContainPlaintextTokens() {
        storage.write(
            StoredAuthSession(
                accessToken = "plain-access",
                refreshToken = "plain-refresh",
                expiresAt = Instant.parse("2026-07-28T13:00:00Z"),
            ),
        )

        val values = context
            .getSharedPreferences(AndroidKeystoreTokenStorage.PREFERENCES_NAME, Context.MODE_PRIVATE)
            .all
        val persistedText = values.values.joinToString(separator = "|")

        assertNotNull(storage.read())
        assertFalse(persistedText.contains("plain-access"))
        assertFalse(persistedText.contains("plain-refresh"))
    }
}
