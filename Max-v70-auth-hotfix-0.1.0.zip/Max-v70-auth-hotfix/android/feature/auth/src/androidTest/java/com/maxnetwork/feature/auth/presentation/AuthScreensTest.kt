package com.maxnetwork.feature.auth.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performImeAction
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.unit.Density
import com.maxnetwork.core.designsystem.theme.MaxTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class AuthScreensTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun loginErrorKeepsEnteredPhoneAndExplainsFailure() {
        val state = LoginUiState(
            phone = "0912000000",
            error = LoginErrorKind.InvalidPhone,
        )
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                LoginScreen(
                    state = state,
                    actions = loginActions(),
                )
            }
        }

        composeRule.onNodeWithTag("login_phone").assertTextContains("0912000000")
        composeRule.onNodeWithText("أدخل رقم هاتف صحيحًا.").assertIsDisplayed()
        composeRule.onNodeWithTag("login_submit").assertIsEnabled()
    }

    @Test
    fun phoneDoneActionSubmits() {
        var state by mutableStateOf(LoginUiState())
        var submitted = false
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                LoginScreen(
                    state = state,
                    actions = loginActions(
                        onPhoneChanged = { state = state.copy(phone = it, error = null) },
                        onSubmit = { submitted = true },
                    ),
                )
            }
        }

        composeRule.onNodeWithTag("login_phone").performTextInput("0912000000")
        composeRule.onNodeWithTag("login_phone").performImeAction()
        composeRule.runOnIdle { assertTrue(submitted) }
    }

    @Test
    fun loadingDisablesPhoneAndSubmit() {
        val state = LoginUiState(
            phone = "0912000000",
            isLoading = true,
        )
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                LoginScreen(
                    state = state,
                    actions = loginActions(),
                )
            }
        }

        composeRule.onNodeWithTag("login_phone").assertIsNotEnabled()
        composeRule.onNodeWithTag("login_submit").assertIsNotEnabled()
    }

    @Test
    fun forgotPasswordUsesInlineErrorAndLoadingInsidePrimaryAction() {
        val state = ForgotPasswordUiState(
            phone = "bad",
            isLoading = true,
            error = PasswordResetErrorKind.InvalidPhone,
        )
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                ForgotPasswordScreen(
                    state = state,
                    actions = forgotPasswordActions(),
                )
            }
        }

        composeRule.onNodeWithTag("forgot_password_phone").assertIsNotEnabled()
        composeRule.onNodeWithTag("forgot_password_error").assertIsDisplayed()
        composeRule.onNodeWithTag("forgot_password_submit").assertIsNotEnabled()
    }

    @Test
    fun resetPasswordVisibilityAndResendCallbacksRemainOperable() {
        var state by mutableStateOf(
            ResetPasswordUiState(
                resetCode = "123456",
                newPassword = "secret-password",
                confirmation = "secret-password",
            ),
        )
        var resendClicked = false
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                ResetPasswordScreen(
                    state = state,
                    actions = resetPasswordActions(
                        onTogglePasswordVisibility = {
                            state = state.copy(passwordVisible = !state.passwordVisible)
                        },
                        onResend = { resendClicked = true },
                    ),
                )
            }
        }

        composeRule.onNodeWithTag("reset_password_visibility").performScrollTo().performClick()
        composeRule.onNodeWithText("إخفاء").assertIsDisplayed()
        composeRule.onNodeWithTag("reset_password_resend").performScrollTo().performClick()
        composeRule.runOnIdle { assertTrue(resendClicked) }
    }

    @Test
    fun loginRemainsScrollableAtFontScaleTwo() {
        composeRule.setContent {
            FontScaleTwo {
                MaxTheme(motionEnabled = false) {
                    LoginScreen(
                        state = LoginUiState(phone = "0912000000"),
                        actions = loginActions(),
                    )
                }
            }
        }

        composeRule.onNodeWithTag("login_submit").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun forgotPasswordRemainsScrollableAtFontScaleTwo() {
        composeRule.setContent {
            FontScaleTwo {
                MaxTheme(motionEnabled = false) {
                    ForgotPasswordScreen(
                        state = ForgotPasswordUiState(phone = "0912000000"),
                        actions = forgotPasswordActions(),
                    )
                }
            }
        }

        composeRule.onNodeWithTag("forgot_password_submit").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun resetPasswordRemainsScrollableAtFontScaleTwo() {
        composeRule.setContent {
            FontScaleTwo {
                MaxTheme(motionEnabled = false) {
                    ResetPasswordScreen(
                        state = ResetPasswordUiState(
                            resetCode = "123456",
                            newPassword = "secret-password",
                            confirmation = "secret-password",
                        ),
                        actions = resetPasswordActions(),
                    )
                }
            }
        }

        composeRule.onNodeWithTag("reset_password_resend").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun registrationCodeImeActionStillSubmits() {
        var state by mutableStateOf(RegistrationCodeUiState())
        var submitted = false
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                RegistrationCodeScreen(
                    state = state,
                    actions = registrationCodeActions(
                        onCodeChanged = { state = state.copy(code = it, error = null) },
                        onSubmit = { submitted = true },
                    ),
                )
            }
        }

        composeRule.onNodeWithTag("registration_code_input").performTextInput("ABCD1234")
        composeRule.onNodeWithTag("registration_code_input").performImeAction()
        composeRule.runOnIdle { assertTrue(submitted) }
    }

    @Test
    fun confirmPhoneLoadingDisablesFieldAndContactAction() {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                ConfirmPhoneScreen(
                    state = ConfirmPhoneUiState(phone = "0912000000", isLoading = true),
                    actions = confirmPhoneActions(),
                )
            }
        }

        composeRule.onNodeWithTag("registration_phone_input").assertIsNotEnabled()
        composeRule.onNodeWithTag("registration_phone_submit").assertIsNotEnabled()
        composeRule.onNodeWithTag("phone_contact_max").assertIsNotEnabled()
    }

    @Test
    fun otpPasteDoneAndResendBehaviorRemainOperable() {
        var state by mutableStateOf(OtpUiState())
        var submitted = false
        var resent = false
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                OtpScreen(
                    state = state,
                    actions = otpActions(
                        onOtpChanged = { state = state.copy(otp = it, error = null) },
                        onSubmit = { submitted = true },
                        onResend = { resent = true },
                    ),
                )
            }
        }

        composeRule.onNodeWithTag("otp_input").performTextInput("123456")
        composeRule.onNodeWithTag("otp_input").performImeAction()
        composeRule.onNodeWithTag("otp_resend").performClick()
        composeRule.runOnIdle {
            assertTrue(state.otp == "123456")
            assertTrue(submitted)
            assertTrue(resent)
        }
    }

    @Test
    fun createAccountVisibilityAndDoneActionRemainOperable() {
        var state by mutableStateOf(
            CreateAccountUiState(
                name = "متجر",
                storeName = "اسم المحل",
                password = "secret-password",
                passwordConfirmation = "secret-password",
            ),
        )
        var submitted = false
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                CreateAccountScreen(
                    state = state,
                    actions = createAccountActions(
                        onTogglePasswordVisibility = {
                            state = state.copy(passwordVisible = !state.passwordVisible)
                        },
                        onSubmit = { submitted = true },
                    ),
                )
            }
        }

        composeRule.onNodeWithTag("create_account_password_visibility").performScrollTo().performClick()
        composeRule.onNodeWithText("إخفاء").assertIsDisplayed()
        composeRule.onNodeWithTag("create_account_password_confirmation").performScrollTo().performImeAction()
        composeRule.runOnIdle { assertTrue(submitted) }
    }

    @Test
    fun registrationCodeRemainsScrollableAtFontScaleTwo() {
        composeRule.setContent {
            FontScaleTwo {
                MaxTheme(motionEnabled = false) {
                    RegistrationCodeScreen(
                        state = RegistrationCodeUiState(code = "ABCD1234"),
                        actions = registrationCodeActions(),
                    )
                }
            }
        }

        composeRule.onNodeWithTag("registration_contact_max").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun confirmPhoneRemainsScrollableAtFontScaleTwo() {
        composeRule.setContent {
            FontScaleTwo {
                MaxTheme(motionEnabled = false) {
                    ConfirmPhoneScreen(
                        state = ConfirmPhoneUiState(phone = "0912000000"),
                        actions = confirmPhoneActions(),
                    )
                }
            }
        }

        composeRule.onNodeWithTag("phone_contact_max").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun otpRemainsScrollableAtFontScaleTwo() {
        composeRule.setContent {
            FontScaleTwo {
                MaxTheme(motionEnabled = false) {
                    OtpScreen(
                        state = OtpUiState(otp = "123456"),
                        actions = otpActions(),
                    )
                }
            }
        }

        composeRule.onNodeWithTag("otp_resend").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun createAccountRemainsScrollableAtFontScaleTwo() {
        composeRule.setContent {
            FontScaleTwo {
                MaxTheme(motionEnabled = false) {
                    CreateAccountScreen(
                        state = CreateAccountUiState(
                            name = "متجر",
                            storeName = "اسم المحل",
                            password = "secret-password",
                            passwordConfirmation = "secret-password",
                        ),
                        actions = createAccountActions(),
                    )
                }
            }
        }

        composeRule.onNodeWithTag("create_account_submit").performScrollTo().assertIsDisplayed()
    }

    private fun loginActions(
        onPhoneChanged: (String) -> Unit = {},
        onSubmit: () -> Unit = {},
    ) = LoginScreenActions(
        onPhoneChanged = onPhoneChanged,
        onSubmit = onSubmit,
    )

    private fun registrationCodeActions(
        onCodeChanged: (String) -> Unit = {},
        onSubmit: () -> Unit = {},
        onContactMax: () -> Unit = {},
    ) = RegistrationCodeScreenActions(
        onCodeChanged = onCodeChanged,
        onSubmit = onSubmit,
        onContactMax = onContactMax,
        onBack = {},
    )

    private fun confirmPhoneActions() = ConfirmPhoneScreenActions(
        onPhoneChanged = {},
        onSubmit = {},
        onContactMax = {},
        onBack = {},
    )

    private fun otpActions(
        onOtpChanged: (String) -> Unit = {},
        onSubmit: () -> Unit = {},
        onResend: () -> Unit = {},
    ) = OtpScreenActions(
        onOtpChanged = onOtpChanged,
        onSubmit = onSubmit,
        onResend = onResend,
        onBack = {},
    )

    private fun createAccountActions(
        onTogglePasswordVisibility: () -> Unit = {},
        onSubmit: () -> Unit = {},
    ) = CreateAccountScreenActions(
        onNameChanged = {},
        onStoreNameChanged = {},
        onPasswordChanged = {},
        onPasswordConfirmationChanged = {},
        onTogglePasswordVisibility = onTogglePasswordVisibility,
        onSubmit = onSubmit,
        onBack = {},
    )

    private fun forgotPasswordActions() = ForgotPasswordScreenActions(
        onPhoneChanged = {},
        onSubmit = {},
        onBack = {},
    )

    private fun resetPasswordActions(
        onTogglePasswordVisibility: () -> Unit = {},
        onResend: () -> Unit = {},
    ) = ResetPasswordScreenActions(
        onCodeChanged = {},
        onNewPasswordChanged = {},
        onConfirmationChanged = {},
        onTogglePasswordVisibility = onTogglePasswordVisibility,
        onSubmit = {},
        onResend = onResend,
        onBack = {},
    )
}

@Composable
private fun FontScaleTwo(content: @Composable () -> Unit) {
    val currentDensity = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(
            density = currentDensity.density,
            fontScale = 2f,
        ),
        content = content,
    )
}
