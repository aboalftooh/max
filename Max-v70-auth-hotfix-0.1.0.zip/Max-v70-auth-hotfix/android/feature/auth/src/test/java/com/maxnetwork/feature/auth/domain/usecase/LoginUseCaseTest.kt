package com.maxnetwork.feature.auth.domain.usecase

import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthRepository
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.LoginRequest
import com.maxnetwork.feature.auth.domain.NewAccount
import com.maxnetwork.feature.auth.domain.PasswordResetChallengeInfo
import com.maxnetwork.feature.auth.domain.PasswordResetConfirmation
import com.maxnetwork.feature.auth.domain.PasswordResetRepository
import com.maxnetwork.feature.auth.domain.PhoneChallengeInfo
import com.maxnetwork.feature.auth.domain.RegistrationCodeAcceptance
import com.maxnetwork.feature.auth.domain.RegistrationRepository
import com.maxnetwork.feature.auth.domain.PhoneAuthenticationResult
import com.maxnetwork.feature.auth.domain.VerifiedPhoneInfo
import com.maxnetwork.feature.auth.domain.LogoutResult
import java.time.Instant
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

class LoginUseCaseTest {
    @Test
    fun `blank fields are rejected before repository call`() = runTest {
        val repository = RecordingRepository()
        val useCase = LoginUseCase(repository)

        val result = useCase(phone = " ", password = "")

        assertEquals(AuthResult.Failure(AuthFailure.InvalidRequest), result)
        assertEquals(0, repository.loginCalls)
    }

    @Test
    fun `phone is trimmed before repository call`() = runTest {
        val repository = RecordingRepository()
        val useCase = LoginUseCase(repository)

        useCase(phone = "  +249900000000  ", password = "password")

        assertEquals("+249900000000", repository.lastLogin?.phone)
        assertEquals(1, repository.loginCalls)
    }

    @Test
    fun `sudan local phone is normalized before otp request`() = runTest {
        val repository = RecordingRegistrationRepository()
        val useCase = RequestPhoneChallengeUseCase(repository)

        useCase("0909212287")

        assertEquals("+249909212287", repository.requestedPhone)
    }

    @Test
    fun `new account requires only a valid display name`() = runTest {
        val repository = RecordingRegistrationRepository()
        val useCase = CreateAccountUseCase(repository)

        assertEquals(AuthResult.Failure(AuthFailure.InvalidRequest), useCase(" "))
        assertEquals(0, repository.createCalls)

        assertEquals(true, useCase("محمد") is AuthResult.Success)
        assertEquals(1, repository.createCalls)
    }

    @Test
    fun `password reset uses the same 6 to 128 length policy`() = runTest {
        val repository = RecordingPasswordResetRepository()
        val useCase = ConfirmPasswordResetUseCase(repository)

        assertEquals(
            AuthResult.Failure(AuthFailure.InvalidRequest),
            useCase(resetCode = "123456", newPassword = "12345", confirmation = "12345"),
        )
        assertEquals(0, repository.resetCalls)

        assertEquals(
            AuthResult.Success(Unit),
            useCase(resetCode = "123456", newPassword = "!!!!!!", confirmation = "!!!!!!"),
        )
        assertEquals(1, repository.resetCalls)
    }
}

private class RecordingRepository : AuthRepository {
    override val authState: StateFlow<AuthState> = MutableStateFlow(AuthState.SignedOut())
    var loginCalls = 0
    var lastLogin: LoginRequest? = null

    override suspend fun restoreSession(): AuthResult<AuthState> = AuthResult.Success(AuthState.SignedOut())

    override suspend fun login(request: LoginRequest): AuthResult<AuthState.Authenticated> {
        loginCalls += 1
        lastLogin = request
        return AuthResult.Failure(AuthFailure.InvalidCredentials)
    }

    override suspend fun refreshSession(): AuthResult<AuthState.Authenticated> =
        AuthResult.Failure(AuthFailure.NoSession)

    override suspend fun getValidAccessToken(): AuthResult<String> = AuthResult.Failure(AuthFailure.NoSession)

    override suspend fun logout(): AuthResult<LogoutResult> =
        AuthResult.Success(LogoutResult(localSessionCleared = true, remoteRevocationCompleted = true))
}

private class RecordingRegistrationRepository : RegistrationRepository {
    var createCalls = 0
    var requestedPhone: String? = null

    override suspend fun validateRegistrationCode(code: String): AuthResult<RegistrationCodeAcceptance> =
        AuthResult.Failure(AuthFailure.InvalidRequest)

    override suspend fun requestPhoneChallenge(phone: String): AuthResult<PhoneChallengeInfo> {
        requestedPhone = phone
        return AuthResult.Failure(AuthFailure.InvalidRequest)
    }

    override suspend fun resendPhoneChallenge(): AuthResult<PhoneChallengeInfo> =
        AuthResult.Failure(AuthFailure.InvalidRequest)

    override suspend fun verifyPhoneOtp(otp: String): AuthResult<PhoneAuthenticationResult> =
        AuthResult.Failure(AuthFailure.InvalidRequest)

    override suspend fun createAccount(account: NewAccount): AuthResult<AuthState.Authenticated> {
        createCalls += 1
        return AuthResult.Success(AuthState.Authenticated(Instant.parse("2026-08-15T12:00:00Z")))
    }

    override suspend fun clearRegistration() = Unit
}

private class RecordingPasswordResetRepository : PasswordResetRepository {
    var resetCalls = 0

    override suspend fun requestCode(phone: String): AuthResult<PasswordResetChallengeInfo> =
        AuthResult.Failure(AuthFailure.InvalidRequest)

    override suspend fun resendCode(): AuthResult<PasswordResetChallengeInfo> =
        AuthResult.Failure(AuthFailure.InvalidRequest)

    override suspend fun resetPassword(confirmation: PasswordResetConfirmation): AuthResult<Unit> {
        resetCalls += 1
        return AuthResult.Success(Unit)
    }

    override suspend fun clear() = Unit
}
