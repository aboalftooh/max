package com.maxnetwork.feature.auth.data

import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.PasswordResetConfirmation
import com.maxnetwork.feature.auth.domain.SignOutReason
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DefaultPasswordResetRepositoryTest {
    @Test
    fun `reset requires a prior generic challenge request`() = runTest {
        val remote = FakeAuthRemoteDataSource()
        val repository = DefaultPasswordResetRepository(
            remote,
            PasswordResetSessionStore(),
            FakeAuthSessionStore(),
        )

        val result = repository.resetPassword(
            PasswordResetConfirmation("246810", "new-password-12"),
        )

        assertEquals(AuthResult.Failure(AuthFailure.InvalidRequest), result)
        assertEquals(0, remote.passwordResetConfirmCalls)
    }

    @Test
    fun `request stores phone only in temporary reset session`() = runTest {
        val remote = FakeAuthRemoteDataSource()
        val store = PasswordResetSessionStore()
        val repository = DefaultPasswordResetRepository(remote, store, FakeAuthSessionStore())

        assertTrue(repository.requestCode("+249912000000") is AuthResult.Success)

        assertEquals("+249912000000", store.current()?.phone)
        assertEquals(1, remote.passwordResetRequestCalls)
    }

    @Test
    fun `successful reset clears temporary and active sessions`() = runTest {
        val remote = FakeAuthRemoteDataSource()
        val resetStore = PasswordResetSessionStore()
        val authStore = FakeAuthSessionStore()
        authStore.stored = FakeAuthRemoteDataSource.defaultSession().let {
            StoredAuthSession(it.accessToken, it.refreshToken, it.expiresAt)
        }
        val repository = DefaultPasswordResetRepository(remote, resetStore, authStore)
        repository.requestCode("+249912000000")

        val result = repository.resetPassword(
            PasswordResetConfirmation("246810", "new-password-12"),
        )

        assertEquals(AuthResult.Success(Unit), result)
        assertNull(resetStore.current())
        assertNull(authStore.stored)
        assertTrue(authStore.state.value is com.maxnetwork.feature.auth.domain.AuthState.SignedOut)
        assertEquals(SignOutReason.SessionExpired, (authStore.state.value as com.maxnetwork.feature.auth.domain.AuthState.SignedOut).reason)
    }

    @Test
    fun `used reset session cannot be replayed`() = runTest {
        val remote = FakeAuthRemoteDataSource()
        val repository = DefaultPasswordResetRepository(
            remote,
            PasswordResetSessionStore(),
            FakeAuthSessionStore(),
        )
        repository.requestCode("+249912000000")
        repository.resetPassword(PasswordResetConfirmation("246810", "new-password-12"))

        val second = repository.resetPassword(PasswordResetConfirmation("246810", "new-password-12"))

        assertEquals(AuthResult.Failure(AuthFailure.InvalidRequest), second)
        assertEquals(1, remote.passwordResetConfirmCalls)
    }
}
