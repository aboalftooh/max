package com.maxnetwork.feature.auth.data

import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.SignOutReason
import java.time.Instant
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow

internal class FakeTokenStorage(
    initial: StoredAuthSession? = null,
) : AuthTokenStorage {
    var value: StoredAuthSession? = initial
    var writes: Int = 0
    var clears: Int = 0

    override fun read(): StoredAuthSession? = value

    override fun write(session: StoredAuthSession) {
        value = session
        writes += 1
    }

    override fun clear() {
        value = null
        clears += 1
    }
}

internal class FakeAuthSessionStore : AuthSessionStore {
    override val state = MutableStateFlow<AuthState>(AuthState.SignedOut())
    var stored: StoredAuthSession? = null
    var saves: Int = 0

    override suspend fun restore(): StoredAuthSession? = stored
    override suspend fun current(): StoredAuthSession? = stored
    override suspend fun save(session: StoredAuthSession) {
        stored = session
        saves += 1
        state.value = AuthState.Authenticated(session.expiresAt)
    }

    override suspend fun markAuthenticated(expiresAt: Instant) {
        state.value = AuthState.Authenticated(expiresAt)
    }

    override suspend fun markRefreshing(previousExpiry: Instant?) {
        state.value = AuthState.Refreshing(previousExpiry)
    }

    override suspend fun markUnavailable(retryable: Boolean) {
        state.value = AuthState.TemporarilyUnavailable(retryable)
    }

    override suspend fun clear(reason: SignOutReason) {
        stored = null
        state.value = AuthState.SignedOut(reason)
    }
}

internal class FakeAuthRemoteDataSource : AuthRemoteDataSource {
    var registrationResult: RemoteAuthResult<RemoteRegistrationValidation> = RemoteAuthResult.Success(
        RemoteRegistrationValidation(
            validationToken = "registration-token",
            expiresAt = Instant.parse("2026-07-28T12:15:00Z"),
        ),
    )
    var phoneChallengeResult: RemoteAuthResult<RemotePhoneChallenge> = RemoteAuthResult.Success(
        RemotePhoneChallenge(
            challengeId = "challenge-id",
            expiresAt = Instant.parse("2026-07-28T12:05:00Z"),
            resendAvailableAt = Instant.parse("2026-07-28T12:01:00Z"),
            remainingAttempts = 5,
        ),
    )
    var verifyPhoneResult: RemoteAuthResult<RemoteVerifiedPhone> = RemoteAuthResult.Success(
        RemoteVerifiedPhone(
            verificationToken = "phone-proof",
            maskedPhone = "+249***0000",
            expiresAt = Instant.parse("2026-07-28T12:15:00Z"),
        ),
    )
    var resolvePhoneResult: RemoteAuthResult<RemotePhoneAuthentication> =
        RemoteAuthResult.Success(RemotePhoneAuthentication.NewUser)
    var createAccountResult: RemoteAuthResult<RemoteSession> = RemoteAuthResult.Success(defaultSession())
    var passwordResetRequestResult: RemoteAuthResult<RemotePhoneChallenge> = phoneChallengeResult
    var passwordResetConfirmResult: RemoteAuthResult<Unit> = RemoteAuthResult.Success(Unit)
    var loginResult: RemoteAuthResult<RemoteSession> = RemoteAuthResult.Success(defaultSession())
    var refreshResult: RemoteAuthResult<RemoteSession> = RemoteAuthResult.Success(defaultSession())
    var logoutResult: RemoteAuthResult<Unit> = RemoteAuthResult.Success(Unit)
    var refreshDelayMillis: Long = 0
    var registrationCalls: Int = 0
    var phoneChallengeCalls: Int = 0
    var verifyPhoneCalls: Int = 0
    var resolvePhoneCalls: Int = 0
    var createAccountCalls: Int = 0
    var passwordResetRequestCalls: Int = 0
    var passwordResetConfirmCalls: Int = 0
    var loginCalls: Int = 0
    var refreshCalls: Int = 0
    var logoutCalls: Int = 0

    override suspend fun validateRegistrationCode(code: String): RemoteAuthResult<RemoteRegistrationValidation> {
        registrationCalls += 1
        return registrationResult
    }

    override suspend fun requestPhoneChallenge(phone: String): RemoteAuthResult<RemotePhoneChallenge> {
        phoneChallengeCalls += 1
        return phoneChallengeResult
    }

    override suspend fun verifyPhoneChallenge(
        challengeId: String,
        otp: String,
    ): RemoteAuthResult<RemoteVerifiedPhone> {
        verifyPhoneCalls += 1
        return verifyPhoneResult
    }

    override suspend fun resolveVerifiedPhone(verificationToken: String): RemoteAuthResult<RemotePhoneAuthentication> {
        resolvePhoneCalls += 1
        return resolvePhoneResult
    }

    override suspend fun createAccount(command: RemoteAccountCreation): RemoteAuthResult<RemoteSession> {
        createAccountCalls += 1
        return createAccountResult
    }

    override suspend fun requestPasswordReset(phone: String): RemoteAuthResult<RemotePhoneChallenge> {
        passwordResetRequestCalls += 1
        return passwordResetRequestResult
    }

    override suspend fun resetPassword(
        phone: String,
        resetCode: String,
        newPassword: String,
    ): RemoteAuthResult<Unit> {
        passwordResetConfirmCalls += 1
        return passwordResetConfirmResult
    }

    override suspend fun login(phone: String, password: String): RemoteAuthResult<RemoteSession> {
        loginCalls += 1
        return loginResult
    }

    override suspend fun refresh(refreshToken: String): RemoteAuthResult<RemoteSession> {
        refreshCalls += 1
        if (refreshDelayMillis > 0) delay(refreshDelayMillis)
        return refreshResult
    }

    override suspend fun logout(accessToken: String): RemoteAuthResult<Unit> {
        logoutCalls += 1
        return logoutResult
    }

    companion object {
        fun defaultSession(
            accessToken: String = "new-access-token",
            refreshToken: String = "new-refresh-token",
            expiresAt: Instant = Instant.parse("2026-07-28T13:00:00Z"),
        ) = RemoteSession(
            accessToken = accessToken,
            refreshToken = refreshToken,
            expiresAt = expiresAt,
        )
    }
}
