package com.maxnetwork.feature.auth.data

import com.maxnetwork.core.common.ClockProvider
import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.LoginRequest
import com.maxnetwork.feature.auth.domain.SignOutReason
import java.time.Instant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DefaultAuthRepositoryTest {
    private val now = Instant.parse("2026-07-28T12:00:00Z")
    private val clock = ClockProvider { now }

    @Test
    fun `restore keeps an unexpired encrypted session without refresh`() = runTest {
        val fixture = fixture(
            stored = storedSession(expiresAt = now.plusSeconds(600)),
        )

        val result = fixture.repository.restoreSession()

        assertTrue(result is AuthResult.Success)
        assertEquals(0, fixture.remote.refreshCalls)
        assertEquals(AuthState.Authenticated(now.plusSeconds(600)), fixture.repository.authState.value)
    }

    @Test
    fun `restore refreshes an expired session and persists rotated tokens`() = runTest {
        val fixture = fixture(
            stored = storedSession(expiresAt = now.minusSeconds(1)),
        )

        val result = fixture.repository.restoreSession()

        assertTrue(result is AuthResult.Success)
        assertEquals(1, fixture.remote.refreshCalls)
        assertEquals("new-access-token", fixture.storage.value?.accessToken)
        assertEquals("new-refresh-token", fixture.storage.value?.refreshToken)
    }

    @Test
    fun `network failure preserves encrypted refresh token and exposes retryable state`() = runTest {
        val fixture = fixture(stored = storedSession(expiresAt = now.minusSeconds(1)))
        fixture.remote.refreshResult = RemoteAuthResult.Failure(
            kind = RemoteAuthFailure.Network,
            retryable = true,
        )

        val result = fixture.repository.restoreSession()

        assertEquals(AuthResult.Failure(AuthFailure.NetworkUnavailable), result)
        assertEquals("stored-refresh-token", fixture.storage.value?.refreshToken)
        assertEquals(AuthState.TemporarilyUnavailable(retryable = true), fixture.repository.authState.value)
    }

    @Test
    fun `unauthorized refresh clears session and marks expiry`() = runTest {
        val fixture = fixture(stored = storedSession(expiresAt = now.minusSeconds(1)))
        fixture.remote.refreshResult = RemoteAuthResult.Failure(
            kind = RemoteAuthFailure.Unauthorized,
            retryable = false,
        )

        val result = fixture.repository.restoreSession()

        assertEquals(AuthResult.Failure(AuthFailure.SessionExpired), result)
        assertEquals(null, fixture.storage.value)
        assertEquals(AuthState.SignedOut(SignOutReason.SessionExpired), fixture.repository.authState.value)
    }

    @Test
    fun `concurrent token requests perform only one refresh`() = runTest {
        val dispatcher = StandardTestDispatcher(testScheduler)
        val fixture = fixture(
            stored = storedSession(expiresAt = now.minusSeconds(1)),
        )
        fixture.remote.refreshDelayMillis = 100
        fixture.store.restore()
        fixture.remote.refreshCalls = 0

        val results = List(16) {
            async(dispatcher) { fixture.repository.getValidAccessToken() }
        }
        testScheduler.advanceUntilIdle()

        assertTrue(results.awaitAll().all { it == AuthResult.Success("new-access-token") })
        assertEquals(1, fixture.remote.refreshCalls)
    }

    @Test
    fun `logout clears locally even when remote revocation fails`() = runTest {
        val fixture = fixture(stored = storedSession(expiresAt = now.plusSeconds(600)))
        fixture.repository.restoreSession()
        fixture.remote.logoutResult = RemoteAuthResult.Failure(
            kind = RemoteAuthFailure.Network,
            retryable = true,
        )

        val result = fixture.repository.logout()

        assertTrue(result is AuthResult.Success)
        val value = (result as AuthResult.Success).value
        assertTrue(value.localSessionCleared)
        assertEquals(false, value.remoteRevocationCompleted)
        assertEquals(null, fixture.storage.value)
        assertEquals(AuthState.SignedOut(SignOutReason.UserRequested), fixture.repository.authState.value)
    }

    @Test
    fun `invalid credentials never create a local session`() = runTest {
        val fixture = fixture(stored = null)
        fixture.remote.loginResult = RemoteAuthResult.Failure(
            kind = RemoteAuthFailure.InvalidCredentials,
            retryable = false,
        )

        val result = fixture.repository.login(LoginRequest(phone = "+249900000000", password = "wrong"))

        assertEquals(AuthResult.Failure(AuthFailure.InvalidCredentials), result)
        assertEquals(null, fixture.storage.value)
        assertEquals(AuthState.SignedOut(), fixture.repository.authState.value)
    }

    private fun fixture(
        stored: StoredAuthSession?,
        dispatcher: kotlinx.coroutines.CoroutineDispatcher = Dispatchers.Unconfined,
    ): Fixture {
        val storage = FakeTokenStorage(stored)
        val store = DefaultAuthSessionStore(storage = storage, ioDispatcher = dispatcher)
        val remote = FakeAuthRemoteDataSource()
        return Fixture(
            storage = storage,
            store = store,
            remote = remote,
            repository = DefaultAuthRepository(remote = remote, sessionStore = store, clock = clock),
        )
    }

    private fun storedSession(expiresAt: Instant) = StoredAuthSession(
        accessToken = "stored-access-token",
        refreshToken = "stored-refresh-token",
        expiresAt = expiresAt,
    )

    private data class Fixture(
        val storage: FakeTokenStorage,
        val store: DefaultAuthSessionStore,
        val remote: FakeAuthRemoteDataSource,
        val repository: DefaultAuthRepository,
    )
}
