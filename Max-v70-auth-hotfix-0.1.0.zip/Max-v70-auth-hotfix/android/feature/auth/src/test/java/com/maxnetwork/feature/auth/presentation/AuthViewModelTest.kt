package com.maxnetwork.feature.auth.presentation

import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthRepository
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.LoginRequest
import com.maxnetwork.feature.auth.domain.LogoutResult
import com.maxnetwork.feature.auth.domain.NewAccount
import com.maxnetwork.feature.auth.domain.PasswordResetChallengeInfo
import com.maxnetwork.feature.auth.domain.PasswordResetConfirmation
import com.maxnetwork.feature.auth.domain.PasswordResetRepository
import com.maxnetwork.feature.auth.domain.PhoneAuthenticationResult
import com.maxnetwork.feature.auth.domain.PhoneChallengeInfo
import com.maxnetwork.feature.auth.domain.RegistrationCodeAcceptance
import com.maxnetwork.feature.auth.domain.RegistrationRepository
import com.maxnetwork.feature.auth.domain.VerifiedPhoneInfo
import com.maxnetwork.feature.auth.domain.usecase.ClearPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.ClearRegistrationUseCase
import com.maxnetwork.feature.auth.domain.usecase.ConfirmPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.CreateAccountUseCase
import com.maxnetwork.feature.auth.domain.usecase.LoginUseCase
import com.maxnetwork.feature.auth.domain.usecase.LogoutUseCase
import com.maxnetwork.feature.auth.domain.usecase.ObserveAuthStateUseCase
import com.maxnetwork.feature.auth.domain.usecase.RequestPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.RequestPhoneChallengeUseCase
import com.maxnetwork.feature.auth.domain.usecase.ResendPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.ResendPhoneChallengeUseCase
import com.maxnetwork.feature.auth.domain.usecase.RestoreSessionUseCase
import com.maxnetwork.feature.auth.domain.usecase.ValidateRegistrationCodeUseCase
import com.maxnetwork.feature.auth.domain.usecase.VerifyPhoneOtpUseCase
import java.time.Instant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AuthViewModelTest {
    private val dispatcher: TestDispatcher = StandardTestDispatcher()

    @Before fun setUp() = Dispatchers.setMain(dispatcher)
    @After fun tearDown() = Dispatchers.resetMain()

    @Test
    fun `phone is the only required login field and opens otp`() = runTest(dispatcher) {
        val registration = FakeRegistrationRepository()
        val viewModel = createViewModel(FakeAuthRepository(), registration)
        val event = async { viewModel.events.first() }

        viewModel.onPhoneChanged("+249912000000")
        viewModel.submitLogin()
        advanceUntilIdle()

        assertEquals(AuthUiEvent.PhoneChallengeSent, event.await())
        assertEquals(1, registration.phoneCalls)
    }

    @Test
    fun `new phone otp advances to join code`() = runTest(dispatcher) {
        val registration = FakeRegistrationRepository(
            verifyResult = AuthResult.Success(
                PhoneAuthenticationResult.NewUser(
                    VerifiedPhoneInfo("+249***0000", Instant.parse("2026-08-29T10:00:00Z")),
                ),
            ),
        )
        val viewModel = createViewModel(FakeAuthRepository(), registration)
        viewModel.onPhoneChanged("+249912000000")
        viewModel.submitLogin()
        advanceUntilIdle()
        val event = async { viewModel.events.first() }
        viewModel.onOtpChanged("123456")
        viewModel.submitOtp()
        advanceUntilIdle()

        assertEquals(AuthUiEvent.NewUserOtpVerified, event.await())
    }

    @Test
    fun `existing phone otp goes directly to dashboard`() = runTest(dispatcher) {
        val registration = FakeRegistrationRepository(
            verifyResult = AuthResult.Success(
                PhoneAuthenticationResult.ExistingUser(
                    AuthState.Authenticated(Instant.parse("2026-08-29T10:00:00Z")),
                ),
            ),
        )
        val viewModel = createViewModel(FakeAuthRepository(), registration)
        viewModel.onPhoneChanged("+249912000000")
        viewModel.submitLogin()
        advanceUntilIdle()
        val event = async { viewModel.events.first() }
        viewModel.onOtpChanged("123456")
        viewModel.submitOtp()
        advanceUntilIdle()

        assertEquals(AuthUiEvent.Authenticated, event.await())
    }

    @Test
    fun `new user completes join code then registration data`() = runTest(dispatcher) {
        val registration = FakeRegistrationRepository()
        val viewModel = createViewModel(FakeAuthRepository(), registration)
        val codeEvent = async { viewModel.events.first() }

        viewModel.onRegistrationCodeChanged("12345678")
        viewModel.submitRegistrationCode()
        advanceUntilIdle()
        assertEquals(AuthUiEvent.RegistrationCodeAccepted, codeEvent.await())

        val authEvent = async { viewModel.events.first() }
        viewModel.onAccountNameChanged("محمد أحمد")
        viewModel.submitCreateAccount()
        advanceUntilIdle()
        assertEquals(AuthUiEvent.Authenticated, authEvent.await())
        assertEquals(1, registration.createCalls)
        assertEquals("محمد أحمد", registration.lastAccount?.name)
    }

    private fun createViewModel(
        auth: AuthRepository,
        registration: RegistrationRepository,
    ) = AuthViewModel(
        observeAuthState = ObserveAuthStateUseCase(auth),
        restoreSessionUseCase = RestoreSessionUseCase(auth),
        loginUseCase = LoginUseCase(auth),
        logoutUseCase = LogoutUseCase(auth),
        validateRegistrationCodeUseCase = ValidateRegistrationCodeUseCase(registration),
        requestPhoneChallengeUseCase = RequestPhoneChallengeUseCase(registration),
        resendPhoneChallengeUseCase = ResendPhoneChallengeUseCase(registration),
        verifyPhoneOtpUseCase = VerifyPhoneOtpUseCase(registration),
        createAccountUseCase = CreateAccountUseCase(registration),
        clearRegistrationUseCase = ClearRegistrationUseCase(registration),
        requestPasswordResetUseCase = RequestPasswordResetUseCase(FakePasswordResetRepository()),
        resendPasswordResetUseCase = ResendPasswordResetUseCase(FakePasswordResetRepository()),
        confirmPasswordResetUseCase = ConfirmPasswordResetUseCase(FakePasswordResetRepository()),
        clearPasswordResetUseCase = ClearPasswordResetUseCase(FakePasswordResetRepository()),
    )
}

private class FakeAuthRepository : AuthRepository {
    private val state = MutableStateFlow<AuthState>(AuthState.SignedOut())
    override val authState = state
    override suspend fun restoreSession(): AuthResult<AuthState> = AuthResult.Success(state.value)
    override suspend fun login(request: LoginRequest): AuthResult<AuthState.Authenticated> = AuthResult.Failure(AuthFailure.InvalidCredentials)
    override suspend fun refreshSession(): AuthResult<AuthState.Authenticated> = AuthResult.Failure(AuthFailure.NoSession)
    override suspend fun getValidAccessToken(): AuthResult<String> = AuthResult.Failure(AuthFailure.NoSession)
    override suspend fun logout(): AuthResult<LogoutResult> = AuthResult.Success(LogoutResult(true, true))
}

private class FakeRegistrationRepository(
    private val verifyResult: AuthResult<PhoneAuthenticationResult> = AuthResult.Success(
        PhoneAuthenticationResult.NewUser(
            VerifiedPhoneInfo("+249***0000", Instant.parse("2026-08-29T10:00:00Z")),
        ),
    ),
) : RegistrationRepository {
    var phoneCalls = 0
    var createCalls = 0
    var lastAccount: NewAccount? = null

    override suspend fun requestPhoneChallenge(phone: String): AuthResult<PhoneChallengeInfo> {
        phoneCalls += 1
        return AuthResult.Success(
            PhoneChallengeInfo(
                Instant.parse("2026-08-29T09:05:00Z"),
                Instant.parse("2026-08-29T09:01:00Z"),
                5,
            ),
        )
    }
    override suspend fun resendPhoneChallenge(): AuthResult<PhoneChallengeInfo> = requestPhoneChallenge("+249912000000")
    override suspend fun verifyPhoneOtp(otp: String): AuthResult<PhoneAuthenticationResult> = verifyResult
    override suspend fun validateRegistrationCode(code: String): AuthResult<RegistrationCodeAcceptance> =
        AuthResult.Success(RegistrationCodeAcceptance(Instant.parse("2026-08-29T10:00:00Z")))
    override suspend fun createAccount(account: NewAccount): AuthResult<AuthState.Authenticated> {
        createCalls += 1
        lastAccount = account
        return AuthResult.Success(AuthState.Authenticated(Instant.parse("2026-08-29T10:00:00Z")))
    }
    override suspend fun clearRegistration() = Unit
}

private class FakePasswordResetRepository : PasswordResetRepository {
    override suspend fun requestCode(phone: String): AuthResult<PasswordResetChallengeInfo> =
        AuthResult.Success(PasswordResetChallengeInfo(Instant.parse("2026-08-29T09:05:00Z"), Instant.parse("2026-08-29T09:01:00Z")))
    override suspend fun resendCode(): AuthResult<PasswordResetChallengeInfo> = requestCode("+249912000000")
    override suspend fun resetPassword(confirmation: PasswordResetConfirmation): AuthResult<Unit> = AuthResult.Success(Unit)
    override suspend fun clear() = Unit
}
