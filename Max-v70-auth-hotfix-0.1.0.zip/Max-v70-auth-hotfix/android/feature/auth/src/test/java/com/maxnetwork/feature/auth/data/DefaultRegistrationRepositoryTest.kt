package com.maxnetwork.feature.auth.data

import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.PhoneAuthenticationResult
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DefaultRegistrationRepositoryTest {
    @Test
    fun `phone challenge is the first registration step`() = runTest {
        val remote = FakeAuthRemoteDataSource()
        val repository = DefaultRegistrationRepository(remote, RegistrationSessionStore(), FakeAuthSessionStore())

        val result = repository.requestPhoneChallenge("+249912000000")

        assertTrue(result is AuthResult.Success)
        assertEquals(1, remote.phoneChallengeCalls)
    }

    @Test
    fun `new verified phone advances to join code then account creation`() = runTest {
        val remote = FakeAuthRemoteDataSource()
        val store = RegistrationSessionStore()
        val repository = DefaultRegistrationRepository(remote, store, FakeAuthSessionStore())

        assertTrue(repository.requestPhoneChallenge("+249912000000") is AuthResult.Success)
        val verified = repository.verifyPhoneOtp("123456")
        assertTrue(verified is AuthResult.Success && verified.value is PhoneAuthenticationResult.NewUser)
        assertTrue(store.current() is StoredRegistrationSession.PhoneVerified)

        assertTrue(repository.validateRegistrationCode("MAX-STORE-001") is AuthResult.Success)
        val ready = store.current() as StoredRegistrationSession.ReadyToCreateAccount
        assertEquals("+249912000000", ready.phone)
        assertEquals("phone-proof", ready.phoneVerificationToken)
        assertEquals("registration-token", ready.validationToken)
    }

    @Test
    fun `existing verified phone creates session without join code`() = runTest {
        val remote = FakeAuthRemoteDataSource().apply {
            resolvePhoneResult = RemoteAuthResult.Success(
                RemotePhoneAuthentication.ExistingUser(FakeAuthRemoteDataSource.defaultSession()),
            )
        }
        val authStore = FakeAuthSessionStore()
        val registrationStore = RegistrationSessionStore()
        val repository = DefaultRegistrationRepository(remote, registrationStore, authStore)

        repository.requestPhoneChallenge("+249912000000")
        val verified = repository.verifyPhoneOtp("123456")

        assertTrue(verified is AuthResult.Success && verified.value is PhoneAuthenticationResult.ExistingUser)
        assertEquals(1, authStore.saves)
        assertTrue(registrationStore.current() is StoredRegistrationSession.Empty)
        assertEquals(0, remote.registrationCalls)
    }
}
