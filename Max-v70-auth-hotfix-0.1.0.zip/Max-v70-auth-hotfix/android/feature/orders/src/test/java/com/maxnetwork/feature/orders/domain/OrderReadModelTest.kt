package com.maxnetwork.feature.orders.domain

import java.time.Instant
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OrderReadModelTest {
    @Test
    fun `page is deterministic newest first and direction filtered`() = runTest {
        val old = order("old", OrderDirection.Incoming, "2026-07-27T10:00:00Z")
        val newest = order("new", OrderDirection.Incoming, "2026-07-28T10:00:00Z")
        val foreignDirection = order("out", OrderDirection.Outgoing, "2026-07-29T10:00:00Z")
        val repository = object : OrderReadRepository {
            override suspend fun getOrders(query: OrderQuery) = OrderReadResult.Success(
                OrderPage(listOf(old, foreignDirection, newest, newest), null),
            )
            override suspend fun getOrder(id: OrderId) = OrderReadResult.Success(newest)
        }

        val result = LoadOrdersPageUseCase(repository)(OrderQuery(OrderDirection.Incoming))

        assertEquals(listOf("new", "old"), (result as OrderReadResult.Success).value.items.map { it.id.value })
    }

    @Test(expected = IllegalArgumentException::class)
    fun `unavailable order cannot carry invoice reference`() {
        order("missing", OrderDirection.Incoming, "2026-07-28T10:00:00Z", OrderVisualStatus.Unavailable, "invoice")
    }

    @Test
    fun `unavailable order has no financial object`() {
        val value = order("missing", OrderDirection.Incoming, "2026-07-28T10:00:00Z", OrderVisualStatus.Unavailable)
        assertNull(value.invoiceReference)
        assertEquals(setOf("id", "direction", "source", "content", "status", "occurredAt", "invoiceReference"),
            OrderReadModel::class.java.declaredFields.map { it.name }.filterNot { it.startsWith("$") }.toSet())
    }

    private fun order(
        id: String,
        direction: OrderDirection,
        time: String,
        status: OrderVisualStatus = OrderVisualStatus.NeedsReply,
        invoice: String? = null,
    ) = OrderReadModel(
        OrderId(id), direction, OrderSource.App, OrderContent(id, null, null), status,
        Instant.parse(time), invoice?.let(::InvoiceReference),
    )
}
