package com.maxnetwork.feature.orders.domain

import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OutgoingTimelineMergerTest {
    @Test
    fun `offline pending is replaced by synchronized remote order`() {
        val pending = PendingOutgoingOrder(
            clientRequestId = "client-1",
            serverRequestId = null,
            contentPreview = "فلتر هواء",
            createdAt = Instant.parse("2026-07-28T10:00:00Z"),
            synchronization = OrderSynchronization.WaitingForNetwork,
        )
        val first = OutgoingTimelineMerger.merge(emptyList(), pending)
        assertTrue(first.single() is OutgoingTimelineItem.Pending)

        val accepted = pending.copy(
            serverRequestId = "server-1",
            synchronization = OrderSynchronization.AcceptedWaitingForReadModel,
        )
        val remote = order("server-1")
        val afterSync = OutgoingTimelineMerger.merge(listOf(remote), accepted)

        assertEquals(1, afterSync.size)
        assertTrue(afterSync.single() is OutgoingTimelineItem.Synchronized)
    }

    private fun order(id: String) = OrderReadModel(
        OrderId(id), OrderDirection.Outgoing, OrderSource.App, OrderContent("فلتر هواء", null, null),
        OrderVisualStatus.NeedsReply, Instant.parse("2026-07-28T10:01:00Z"), null,
    )
}
