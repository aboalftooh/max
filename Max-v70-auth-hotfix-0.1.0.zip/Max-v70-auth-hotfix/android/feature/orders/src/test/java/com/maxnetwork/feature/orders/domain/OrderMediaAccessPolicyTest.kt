package com.maxnetwork.feature.orders.domain

import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Test

class OrderMediaAccessPolicyTest {
    private val now = Instant.parse("2026-07-28T18:00:00Z")

    @Test
    fun `expired links require refresh`() {
        val media = OrderMedia("https://media.max.test/private", now, "image/jpeg")
        assertEquals(OrderMediaAvailability.Expired, OrderMediaAccessPolicy.evaluate(media, OrderMediaKind.Image, now))
    }

    @Test
    fun `wrong content type is not rendered`() {
        val media = OrderMedia("https://media.max.test/private", now.plusSeconds(60), "audio/mp4")
        assertEquals(OrderMediaAvailability.Unsupported, OrderMediaAccessPolicy.evaluate(media, OrderMediaKind.Image, now))
    }
}
