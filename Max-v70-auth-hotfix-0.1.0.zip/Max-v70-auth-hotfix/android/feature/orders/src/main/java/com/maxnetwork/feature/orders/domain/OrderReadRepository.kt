package com.maxnetwork.feature.orders.domain

interface OrderReadRepository {
    suspend fun getOrders(query: OrderQuery): OrderReadResult<OrderPage>
    suspend fun getOrder(id: OrderId): OrderReadResult<OrderReadModel>
}
