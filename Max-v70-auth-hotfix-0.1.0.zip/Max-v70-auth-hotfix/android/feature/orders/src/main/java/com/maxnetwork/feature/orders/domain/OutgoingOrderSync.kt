package com.maxnetwork.feature.orders.domain

import java.time.Instant

enum class OrderSynchronization {
    WaitingForNetwork,
    Uploading,
    Submitting,
    RetryableFailure,
    PermanentFailure,
    AcceptedWaitingForReadModel,
}

data class PendingOutgoingOrder(
    val clientRequestId: String,
    val serverRequestId: String?,
    val contentPreview: String,
    val createdAt: Instant,
    val synchronization: OrderSynchronization,
) {
    init {
        require(clientRequestId.isNotBlank())
        require(contentPreview.isNotBlank())
        require(
            synchronization != OrderSynchronization.AcceptedWaitingForReadModel || serverRequestId != null,
        )
    }
}

sealed interface OutgoingTimelineItem {
    data class Synchronized(val order: OrderReadModel) : OutgoingTimelineItem
    data class Pending(val submission: PendingOutgoingOrder) : OutgoingTimelineItem
}

object OutgoingTimelineMerger {
    fun merge(
        remoteOrders: List<OrderReadModel>,
        pending: PendingOutgoingOrder?,
    ): List<OutgoingTimelineItem> {
        val outgoing = remoteOrders
            .filter { it.direction == OrderDirection.Outgoing }
            .sortedWith(compareByDescending<OrderReadModel> { it.occurredAt }.thenByDescending { it.id.value })
        val serverId = pending?.serverRequestId
        val remoteContainsPending = serverId != null && outgoing.any { it.id.value == serverId }
        return buildList {
            if (pending != null && !remoteContainsPending) add(OutgoingTimelineItem.Pending(pending))
            addAll(outgoing.map(OutgoingTimelineItem::Synchronized))
        }
    }
}
