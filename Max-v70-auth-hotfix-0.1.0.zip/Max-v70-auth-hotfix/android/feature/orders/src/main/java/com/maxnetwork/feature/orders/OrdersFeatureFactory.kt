package com.maxnetwork.feature.orders

import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.orders.data.NetworkOrderReadRepository
import com.maxnetwork.feature.orders.domain.LoadOrderUseCase
import com.maxnetwork.feature.orders.domain.LoadOrdersPageUseCase

data class OrdersUseCases(
    val loadPage: LoadOrdersPageUseCase,
    val loadOrder: LoadOrderUseCase,
)

data class OrdersFeatureDependencies(
    val useCases: OrdersUseCases,
)

object OrdersFeatureFactory {
    fun create(gateway: MaxGateway): OrdersFeatureDependencies {
        val repository = NetworkOrderReadRepository(gateway)
        return OrdersFeatureDependencies(
            useCases = OrdersUseCases(
                loadPage = LoadOrdersPageUseCase(repository),
                loadOrder = LoadOrderUseCase(repository),
            ),
        )
    }
}
