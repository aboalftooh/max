package com.maxnetwork.feature.orders.domain

object OrdersFeature {
    const val ROUTE_INCOMING = "orders/incoming"
    const val ROUTE_OUTGOING = "orders/outgoing"
}
