package com.maxnetwork.feature.orders.domain

import java.time.Instant

@JvmInline
value class OrderId(val value: String) {
    init { require(value.isNotBlank()) }
}

enum class OrderDirection { Incoming, Outgoing }

enum class OrderSource { App, Verto, MaxTeam }

enum class OrderVisualStatus { NeedsReply, Provided, Unavailable }

@JvmInline
value class InvoiceReference(val value: String) {
    init { require(value.isNotBlank()) }
}

data class OrderMedia(
    val url: String,
    val expiresAt: Instant,
    val contentType: String,
) {
    init {
        require(url.startsWith("https://"))
        require(contentType.isNotBlank())
    }
}

data class OrderContent(
    val text: String?,
    val image: OrderMedia?,
    val audio: OrderMedia?,
) {
    init {
        require(!text.isNullOrBlank() || image != null || audio != null) {
            "An order must contain text, image, or audio"
        }
    }

    val preview: String
        get() = text?.trim()?.takeIf(String::isNotEmpty)
            ?: when {
                image != null && audio != null -> "صورة ورسالة صوتية"
                image != null -> "صورة مرفقة"
                else -> "رسالة صوتية"
            }
}

data class OrderReadModel(
    val id: OrderId,
    val direction: OrderDirection,
    val source: OrderSource,
    val content: OrderContent,
    val status: OrderVisualStatus,
    val occurredAt: Instant,
    val invoiceReference: InvoiceReference?,
) {
    init {
        require(status != OrderVisualStatus.Unavailable || invoiceReference == null) {
            "Unavailable orders cannot reference an executed invoice"
        }
    }
}

@JvmInline
value class OrderCursor(val value: String) {
    init { require(value.isNotBlank()) }
}

data class OrderQuery(
    val direction: OrderDirection,
    val cursor: OrderCursor? = null,
    val limit: Int = 20,
) {
    init { require(limit in 1..50) }
}

data class OrderPage(
    val items: List<OrderReadModel>,
    val nextCursor: OrderCursor?,
)

sealed interface OrderReadFailure {
    data object Offline : OrderReadFailure
    data object Unauthorized : OrderReadFailure
    data object NotFound : OrderReadFailure
    data class Unavailable(val retryable: Boolean) : OrderReadFailure
}

sealed interface OrderReadResult<out T> {
    data class Success<T>(val value: T) : OrderReadResult<T>
    data class Failure(val reason: OrderReadFailure) : OrderReadResult<Nothing>
}
