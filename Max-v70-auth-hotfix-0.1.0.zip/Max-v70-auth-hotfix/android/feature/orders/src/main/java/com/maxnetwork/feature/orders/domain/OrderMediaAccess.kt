package com.maxnetwork.feature.orders.domain

import java.time.Duration
import java.time.Instant

enum class OrderMediaKind {
    Image,
    Audio,
}

sealed interface OrderMediaAvailability {
    data object Available : OrderMediaAvailability
    data object Expired : OrderMediaAvailability
    data object Unsupported : OrderMediaAvailability
}

object OrderMediaAccessPolicy {
    private val refreshLeeway: Duration = Duration.ofSeconds(15)

    fun evaluate(
        media: OrderMedia,
        kind: OrderMediaKind,
        now: Instant,
    ): OrderMediaAvailability {
        if (!media.expiresAt.isAfter(now.plus(refreshLeeway))) return OrderMediaAvailability.Expired
        val expectedPrefix = when (kind) {
            OrderMediaKind.Image -> "image/"
            OrderMediaKind.Audio -> "audio/"
        }
        return if (media.contentType.lowercase().startsWith(expectedPrefix)) {
            OrderMediaAvailability.Available
        } else {
            OrderMediaAvailability.Unsupported
        }
    }
}
