package com.maxnetwork.feature.orders.data

import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.OrderDirection as NetworkDirection
import com.maxnetwork.core.network.OrderSource as NetworkSource
import com.maxnetwork.core.network.OrderStatus as NetworkStatus
import com.maxnetwork.core.network.OrderSummary
import com.maxnetwork.feature.orders.domain.InvoiceReference
import com.maxnetwork.feature.orders.domain.OrderContent
import com.maxnetwork.feature.orders.domain.OrderCursor
import com.maxnetwork.feature.orders.domain.OrderDirection
import com.maxnetwork.feature.orders.domain.OrderId
import com.maxnetwork.feature.orders.domain.OrderMedia
import com.maxnetwork.feature.orders.domain.OrderPage
import com.maxnetwork.feature.orders.domain.OrderQuery
import com.maxnetwork.feature.orders.domain.OrderReadFailure
import com.maxnetwork.feature.orders.domain.OrderReadModel
import com.maxnetwork.feature.orders.domain.OrderReadRepository
import com.maxnetwork.feature.orders.domain.OrderReadResult
import com.maxnetwork.feature.orders.domain.OrderSource
import com.maxnetwork.feature.orders.domain.OrderVisualStatus

class NetworkOrderReadRepository(
    private val gateway: MaxGateway,
) : OrderReadRepository {
    override suspend fun getOrders(query: OrderQuery): OrderReadResult<OrderPage> = when (
        val result = gateway.getOrders(
            direction = query.direction.toNetwork(),
            cursor = query.cursor?.value,
            limit = query.limit,
        )
    ) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> OrderReadResult.Success(
            OrderPage(
                items = result.value.items.map(OrderSummary::toDomain),
                nextCursor = result.value.nextCursor?.let(::OrderCursor),
            ),
        )
    }

    override suspend fun getOrder(id: OrderId): OrderReadResult<OrderReadModel> = when (val result = gateway.getOrder(id.value)) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> OrderReadResult.Success(result.value.toDomain())
    }
}

private fun OrderDirection.toNetwork(): NetworkDirection = when (this) {
    OrderDirection.Incoming -> NetworkDirection.Incoming
    OrderDirection.Outgoing -> NetworkDirection.Outgoing
}

private fun OrderSummary.toDomain() = OrderReadModel(
    id = OrderId(id),
    direction = when (direction) {
        NetworkDirection.Incoming -> OrderDirection.Incoming
        NetworkDirection.Outgoing -> OrderDirection.Outgoing
    },
    source = when (source) {
        NetworkSource.App -> OrderSource.App
        NetworkSource.Verto -> OrderSource.Verto
        NetworkSource.MaxTeam -> OrderSource.MaxTeam
    },
    content = OrderContent(
        text = content.text,
        image = content.image?.let { OrderMedia(it.url, it.expiresAt, it.contentType) },
        audio = content.audio?.let { OrderMedia(it.url, it.expiresAt, it.contentType) },
    ),
    status = when (status) {
        NetworkStatus.NeedsReply -> OrderVisualStatus.NeedsReply
        NetworkStatus.Provided -> OrderVisualStatus.Provided
        NetworkStatus.Unavailable -> OrderVisualStatus.Unavailable
    },
    occurredAt = occurredAt,
    invoiceReference = invoiceReference?.let(::InvoiceReference),
)

private fun GatewayResult.Failure.toDomainFailure(): OrderReadResult.Failure = OrderReadResult.Failure(
    when (error.code) {
        ApiErrorCode.Unauthorized -> OrderReadFailure.Unauthorized
        ApiErrorCode.NotFound -> OrderReadFailure.NotFound
        ApiErrorCode.ServiceUnavailable -> if (error.traceId == "network-unavailable") {
            OrderReadFailure.Offline
        } else {
            OrderReadFailure.Unavailable(error.retryable)
        }
        else -> OrderReadFailure.Unavailable(error.retryable)
    },
)
