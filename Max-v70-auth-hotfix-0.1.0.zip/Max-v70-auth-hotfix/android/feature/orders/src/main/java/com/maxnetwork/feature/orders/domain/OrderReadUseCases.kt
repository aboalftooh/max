package com.maxnetwork.feature.orders.domain

class LoadOrdersPageUseCase(
    private val repository: OrderReadRepository,
) {
    suspend operator fun invoke(query: OrderQuery): OrderReadResult<OrderPage> = when (val result = repository.getOrders(query)) {
        is OrderReadResult.Failure -> result
        is OrderReadResult.Success -> {
            val normalized = result.value.items
                .asSequence()
                .filter { it.direction == query.direction }
                .distinctBy { it.id }
                .sortedWith(compareByDescending<OrderReadModel> { it.occurredAt }.thenByDescending { it.id.value })
                .toList()
            OrderReadResult.Success(result.value.copy(items = normalized))
        }
    }
}

class LoadOrderUseCase(
    private val repository: OrderReadRepository,
) {
    suspend operator fun invoke(id: OrderId): OrderReadResult<OrderReadModel> = repository.getOrder(id)
}
