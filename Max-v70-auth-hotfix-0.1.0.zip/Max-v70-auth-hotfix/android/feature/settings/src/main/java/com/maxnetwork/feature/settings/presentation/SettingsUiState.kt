package com.maxnetwork.feature.settings.presentation

data class SettingsUiState(
    val appLockEnabled: Boolean = false,
    val appLockAvailable: Boolean = true,
    val appLockBusy: Boolean = false,
    val appLockUnavailableMessage: String? = null,
)
