package com.maxnetwork.feature.settings.presentation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.maxnetwork.core.designsystem.component.MaxDialog
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxSectionHeader
import com.maxnetwork.core.designsystem.component.MaxSwitch
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.pattern.MaxSettingsPattern

@Suppress("LongParameterList")
data class SettingsActions(
    val onBack: () -> Unit,
    val onProfile: () -> Unit,
    val onAppLockChanged: (Boolean) -> Unit,
    val onPrivacy: () -> Unit,
    val onSupport: () -> Unit,
    val onLogout: () -> Unit,
)

@Composable
fun SettingsScreen(
    state: SettingsUiState,
    actions: SettingsActions,
    modifier: Modifier = Modifier,
) {
    var showAbout by remember { mutableStateOf(false) }

    MaxScaffold(
        modifier = modifier.testTag("settings_screen"),
        topBar = { MaxTopBar(title = "الإعدادات", onBack = actions.onBack) },
    ) { contentPadding ->
        SettingsContent(
            state = state,
            actions = actions,
            contentPadding = contentPadding,
            onAbout = { showAbout = true },
        )
    }

    if (showAbout) {
        MaxDialog(
            title = "حول max",
            onDismissRequest = { showAbout = false },
            confirmText = "موافق",
            onConfirm = { showAbout = false },
            modifier = Modifier.testTag("settings_about_dialog"),
        ) {
            MaxText("max يساعدك على متابعة الطلبات والفواتير والرصيد بصورة واضحة ومباشرة.")
        }
    }
}

@Composable
private fun SettingsContent(
    state: SettingsUiState,
    actions: SettingsActions,
    contentPadding: PaddingValues,
    onAbout: () -> Unit,
) {
    MaxSettingsPattern(modifier = Modifier.padding(contentPadding)) {
        MaxSectionHeader("الحساب")
        MaxListContainer {
            MaxListRow(
                title = "الملف الشخصي",
                supportingText = "بيانات الحساب وتغيير كلمة المرور",
                modifier = Modifier.testTag("settings_profile"),
                onClick = actions.onProfile,
            )
            MaxDivider()
            AppLockRow(state, actions.onAppLockChanged)
            MaxDivider()
            MaxListRow(
                title = "الخصوصية",
                supportingText = "سياسة الخصوصية",
                modifier = Modifier.testTag("settings_privacy"),
                onClick = actions.onPrivacy,
            )
        }

        MaxSectionHeader("المساعدة")
        MaxListContainer {
            MaxListRow(
                title = "الدعم",
                supportingText = "التواصل مع max",
                modifier = Modifier.testTag("settings_support"),
                onClick = actions.onSupport,
            )
            MaxDivider()
            MaxListRow(
                title = "حول التطبيق",
                supportingText = "معلومات max",
                modifier = Modifier.testTag("settings_about"),
                onClick = onAbout,
            )
        }

        MaxSectionHeader("الجلسة")
        MaxListContainer {
            MaxListRow(
                title = "تسجيل الخروج",
                supportingText = "إنهاء الجلسة على هذا الجهاز",
                modifier = Modifier.testTag("settings_logout"),
                onClick = actions.onLogout,
            )
        }
    }
}

@Composable
private fun AppLockRow(
    state: SettingsUiState,
    onChanged: (Boolean) -> Unit,
) {
    val supporting = when {
        !state.appLockAvailable -> state.appLockUnavailableMessage ?: "يتطلب قفل شاشة آمنًا على الجهاز"
        state.appLockBusy -> "جارٍ التحقق من هوية الجهاز"
        state.appLockEnabled -> "مفعّل — يُقفل بعد 120 ثانية في الخلفية"
        else -> "غير مفعّل"
    }
    MaxListRow(
        title = "قفل التطبيق",
        supportingText = supporting,
        modifier = Modifier.testTag("settings_app_lock"),
        trailingContent = {
            MaxSwitch(
                checked = state.appLockEnabled,
                onCheckedChange = onChanged,
                enabled = state.appLockAvailable && !state.appLockBusy,
                testTag = "settings_app_lock_switch",
            )
        },
    )
}
