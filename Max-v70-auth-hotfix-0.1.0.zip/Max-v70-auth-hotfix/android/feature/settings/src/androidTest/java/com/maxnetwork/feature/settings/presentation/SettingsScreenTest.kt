package com.maxnetwork.feature.settings.presentation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.maxnetwork.core.designsystem.theme.MaxTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class SettingsScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun aboutDialogUsesReachableSettingsAction() {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                SettingsScreen(
                    state = SettingsUiState(),
                    actions = actions(),
                )
            }
        }

        composeRule.onNodeWithTag("settings_about").performClick()
        composeRule.onNodeWithTag("settings_about_dialog").assertIsDisplayed()
        composeRule.onNodeWithText("حول max").assertIsDisplayed()
    }

    @Test
    fun appLockSwitchPreservesCallbackAndState() {
        var requested = false
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                SettingsScreen(
                    state = SettingsUiState(appLockEnabled = false),
                    actions = actions(onAppLockChanged = { requested = it }),
                )
            }
        }

        composeRule.onNodeWithTag("settings_app_lock_switch").assertIsOff().performClick()
        composeRule.runOnIdle { assertTrue(requested) }
    }

    @Test
    fun rtlFontScaleTwoRemainsScrollableOnSmallHeight() {
        composeRule.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(
                LocalLayoutDirection provides LayoutDirection.Rtl,
                LocalDensity provides Density(density.density, fontScale = 2f),
            ) {
                MaxTheme(motionEnabled = false) {
                    Box(modifier = Modifier.height(320.dp)) {
                        SettingsScreen(
                            state = SettingsUiState(),
                            actions = actions(),
                        )
                    }
                }
            }
        }

        composeRule.onNodeWithTag("settings_logout").performScrollTo().assertIsDisplayed()
    }

    private fun actions(onAppLockChanged: (Boolean) -> Unit = {}) = SettingsActions(
        onBack = {},
        onProfile = {},
        onAppLockChanged = onAppLockChanged,
        onPrivacy = {},
        onSupport = {},
        onLogout = {},
    )
}
