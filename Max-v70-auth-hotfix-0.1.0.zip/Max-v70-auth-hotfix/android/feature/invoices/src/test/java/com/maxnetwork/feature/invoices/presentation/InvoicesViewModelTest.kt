package com.maxnetwork.feature.invoices.presentation

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.feature.invoices.domain.InvoiceDetails
import com.maxnetwork.feature.invoices.domain.InvoiceId
import com.maxnetwork.feature.invoices.domain.InvoiceKind
import com.maxnetwork.feature.invoices.domain.InvoicePage
import com.maxnetwork.feature.invoices.domain.InvoiceQuery
import com.maxnetwork.feature.invoices.domain.InvoiceReadFailure
import com.maxnetwork.feature.invoices.domain.InvoiceReadResult
import com.maxnetwork.feature.invoices.domain.InvoiceRepository
import com.maxnetwork.feature.invoices.domain.InvoiceSummary
import com.maxnetwork.feature.invoices.domain.LoadInvoiceDetailsUseCase
import com.maxnetwork.feature.invoices.domain.LoadInvoicesPageUseCase
import java.time.Instant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class InvoicesViewModelTest {
    private val dispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `search is submitted asynchronously and replaces list`() = runTest(dispatcher) {
        val repository = RecordingRepository()
        val viewModel = viewModel(repository)

        viewModel.onSearchTextChanged("90915")
        viewModel.submitSearch()

        assertTrue(viewModel.state.value.initialLoading)
        advanceUntilIdle()

        assertEquals("90915", repository.lastQuery?.normalizedSearch)
        assertEquals(listOf("INV-1001"), viewModel.state.value.items.map { it.invoiceNumber })
        assertFalse(viewModel.state.value.initialLoading)
    }

    @Test
    fun `details expose full invoice state`() = runTest(dispatcher) {
        val repository = RecordingRepository()
        val viewModel = viewModel(repository)

        viewModel.loadDetails(InvoiceId("invoice-1"))
        assertTrue(viewModel.state.value.detailsLoading)
        advanceUntilIdle()

        assertEquals("INV-1001", viewModel.state.value.selectedDetails?.summary?.invoiceNumber)
        assertFalse(viewModel.state.value.detailsLoading)
    }

    @Test
    fun `list error produces error state without content`() = runTest(dispatcher) {
        val repository = RecordingRepository(listFailure = InvoiceReadFailure.Offline)
        val viewModel = viewModel(repository)

        viewModel.start()
        advanceUntilIdle()

        assertTrue(viewModel.state.value.items.isEmpty())
        assertTrue(viewModel.state.value.offline)
        assertTrue(viewModel.state.value.errorMessage?.isNotBlank() == true)
    }

    private fun viewModel(repository: InvoiceRepository) = InvoicesViewModel(
        loadPage = LoadInvoicesPageUseCase(repository),
        loadInvoiceDetails = LoadInvoiceDetailsUseCase(repository),
    )

    private class RecordingRepository(
        private val listFailure: InvoiceReadFailure? = null,
    ) : InvoiceRepository {
        var lastQuery: InvoiceQuery? = null

        override suspend fun getInvoices(query: InvoiceQuery): InvoiceReadResult<InvoicePage> {
            lastQuery = query
            listFailure?.let { return InvoiceReadResult.Failure(it) }
            return InvoiceReadResult.Success(InvoicePage(listOf(SUMMARY), null))
        }

        override suspend fun getInvoice(id: InvoiceId): InvoiceReadResult<InvoiceDetails> =
            InvoiceReadResult.Success(InvoiceDetails(SUMMARY.copy(id = id), emptyList()))
    }

    private companion object {
        val SUMMARY = InvoiceSummary(
            id = InvoiceId("invoice-1"),
            invoiceNumber = "INV-1001",
            kind = InvoiceKind.Sale,
            total = Money(100_000, CurrencyCode.SDG),
            occurredAt = Instant.parse("2026-08-15T10:00:00Z"),
        )
    }
}
