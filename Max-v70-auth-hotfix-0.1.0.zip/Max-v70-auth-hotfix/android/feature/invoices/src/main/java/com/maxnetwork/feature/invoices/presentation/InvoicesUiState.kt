package com.maxnetwork.feature.invoices.presentation

import com.maxnetwork.feature.invoices.domain.InvoiceCursor
import com.maxnetwork.feature.invoices.domain.InvoiceDetails
import com.maxnetwork.feature.invoices.domain.InvoicePage
import com.maxnetwork.feature.invoices.domain.InvoiceReadFailure
import com.maxnetwork.feature.invoices.domain.InvoiceSummary

data class InvoicesUiState(
    val searchText: String = "",
    val activeSearch: String = "",
    val items: List<InvoiceSummary> = emptyList(),
    val nextCursor: InvoiceCursor? = null,
    val initialLoading: Boolean = false,
    val loadingMore: Boolean = false,
    val offline: Boolean = false,
    val errorMessage: String? = null,
    val selectedDetails: InvoiceDetails? = null,
    val detailsLoading: Boolean = false,
    val detailsErrorMessage: String? = null,
) {
    val canLoadMore: Boolean get() = nextCursor != null && !initialLoading && !loadingMore && errorMessage == null
    val hasListContent: Boolean get() = items.isNotEmpty()
}

class InvoicesStateReducer {
    var state: InvoicesUiState = InvoicesUiState()
        private set

    fun searchChanged(value: String) {
        state = state.copy(searchText = value.take(120))
    }

    fun refreshing(search: String) {
        state = state.copy(
            activeSearch = search,
            initialLoading = true,
            loadingMore = false,
            errorMessage = null,
        )
    }

    fun loadingMore() {
        if (state.canLoadMore) state = state.copy(loadingMore = true, errorMessage = null)
    }

    fun pageLoaded(page: InvoicePage, append: Boolean) {
        val merged = if (append) state.items + page.items else page.items
        state = state.copy(
            items = merged.distinctBy { it.id },
            nextCursor = page.nextCursor,
            initialLoading = false,
            loadingMore = false,
            offline = false,
            errorMessage = null,
        )
    }

    fun failed(failure: InvoiceReadFailure) {
        state = state.copy(
            initialLoading = false,
            loadingMore = false,
            offline = failure == InvoiceReadFailure.Offline,
            errorMessage = failure.listMessage(),
        )
    }

    fun detailsLoading() {
        state = state.copy(selectedDetails = null, detailsLoading = true, detailsErrorMessage = null)
    }

    fun detailsLoaded(details: InvoiceDetails) {
        state = state.copy(selectedDetails = details, detailsLoading = false, detailsErrorMessage = null, offline = false)
    }

    fun detailsFailed(failure: InvoiceReadFailure) {
        state = state.copy(
            selectedDetails = null,
            detailsLoading = false,
            detailsErrorMessage = failure.detailsMessage(),
            offline = state.offline || failure == InvoiceReadFailure.Offline,
        )
    }

    fun clearDetails() {
        state = state.copy(selectedDetails = null, detailsLoading = false, detailsErrorMessage = null)
    }

    fun clear() {
        state = InvoicesUiState()
    }
}

private fun InvoiceReadFailure.listMessage(): String = when (this) {
    InvoiceReadFailure.Offline -> "لا يوجد اتصال بالإنترنت. حاول مجددًا."
    InvoiceReadFailure.Unauthorized -> "انتهت الجلسة. سجّل الدخول من جديد."
    InvoiceReadFailure.InvalidQuery -> "عبارة البحث غير صالحة."
    InvoiceReadFailure.NotFound -> "لا توجد فواتير مطابقة."
    is InvoiceReadFailure.Unavailable -> "تعذر تحميل الفواتير حاليًا."
}

private fun InvoiceReadFailure.detailsMessage(): String = when (this) {
    InvoiceReadFailure.Offline -> "لا يوجد اتصال بالإنترنت. حاول مجددًا."
    InvoiceReadFailure.Unauthorized -> "انتهت الجلسة. سجّل الدخول من جديد."
    InvoiceReadFailure.NotFound -> "الفاتورة غير موجودة."
    InvoiceReadFailure.InvalidQuery -> "معرّف الفاتورة غير صالح."
    is InvoiceReadFailure.Unavailable -> "تعذر تحميل تفاصيل الفاتورة حاليًا."
}
