package com.maxnetwork.feature.invoices.data

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.InvoiceDetails as NetworkInvoiceDetails
import com.maxnetwork.core.network.InvoiceItem as NetworkInvoiceItem
import com.maxnetwork.core.network.InvoiceSummary as NetworkInvoiceSummary
import com.maxnetwork.core.network.InvoiceType as NetworkInvoiceType
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.MoneyAmount
import com.maxnetwork.feature.invoices.domain.InvoiceCursor
import com.maxnetwork.feature.invoices.domain.InvoiceDetails
import com.maxnetwork.feature.invoices.domain.InvoiceId
import com.maxnetwork.feature.invoices.domain.InvoiceItem
import com.maxnetwork.feature.invoices.domain.InvoiceKind
import com.maxnetwork.feature.invoices.domain.InvoicePage
import com.maxnetwork.feature.invoices.domain.InvoiceQuery
import com.maxnetwork.feature.invoices.domain.InvoiceReadFailure
import com.maxnetwork.feature.invoices.domain.InvoiceReadResult
import com.maxnetwork.feature.invoices.domain.InvoiceRepository
import com.maxnetwork.feature.invoices.domain.InvoiceSummary

class NetworkInvoiceRepository(
    private val gateway: MaxGateway,
) : InvoiceRepository {
    override suspend fun getInvoices(query: InvoiceQuery): InvoiceReadResult<InvoicePage> = when (
        val result = gateway.getInvoices(
            query = query.normalizedSearch.takeIf(String::isNotEmpty),
            cursor = query.cursor?.value,
            limit = query.limit,
        )
    ) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> InvoiceReadResult.Success(
            InvoicePage(
                items = result.value.items.map(NetworkInvoiceSummary::toDomain),
                nextCursor = result.value.nextCursor?.let(::InvoiceCursor),
            ),
        )
    }

    override suspend fun getInvoice(id: InvoiceId): InvoiceReadResult<InvoiceDetails> = when (
        val result = gateway.getInvoice(id.value)
    ) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> InvoiceReadResult.Success(result.value.toDomain())
    }
}

private fun NetworkInvoiceSummary.toDomain() = InvoiceSummary(
    id = InvoiceId(id),
    invoiceNumber = invoiceNumber,
    kind = type.toDomain(),
    total = total.toDomainMoney(),
    occurredAt = occurredAt,
)

private fun NetworkInvoiceDetails.toDomain() = InvoiceDetails(
    summary = InvoiceSummary(
        id = InvoiceId(id),
        invoiceNumber = invoiceNumber,
        kind = type.toDomain(),
        total = total.toDomainMoney(),
        occurredAt = occurredAt,
    ),
    items = items.map(NetworkInvoiceItem::toDomain),
)

private fun NetworkInvoiceItem.toDomain() = InvoiceItem(
    name = name,
    partNumber = partNumber,
    quantity = quantity,
    unitAmount = unitAmount?.toDomainMoney(),
    lineTotal = lineTotal?.toDomainMoney(),
)

private fun NetworkInvoiceType.toDomain() = when (this) {
    NetworkInvoiceType.Sale -> InvoiceKind.Sale
    NetworkInvoiceType.Purchase -> InvoiceKind.Purchase
}

private fun MoneyAmount.toDomainMoney(): Money {
    require(currency == "SDG") { "Max V1 supports SDG only" }
    return Money(minorUnits, CurrencyCode.SDG)
}

private fun GatewayResult.Failure.toDomainFailure(): InvoiceReadResult.Failure = InvoiceReadResult.Failure(
    when (error.code) {
        ApiErrorCode.Unauthorized -> InvoiceReadFailure.Unauthorized
        ApiErrorCode.NotFound -> InvoiceReadFailure.NotFound
        ApiErrorCode.InvalidRequest -> InvoiceReadFailure.InvalidQuery
        ApiErrorCode.ServiceUnavailable -> if (error.traceId == "network-unavailable") {
            InvoiceReadFailure.Offline
        } else {
            InvoiceReadFailure.Unavailable(error.retryable)
        }
        else -> InvoiceReadFailure.Unavailable(error.retryable)
    },
)
