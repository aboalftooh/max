package com.maxnetwork.feature.invoices.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxEmptyState
import com.maxnetwork.core.designsystem.component.MaxErrorState
import com.maxnetwork.core.designsystem.component.MaxHeroContainer
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxLoadingState
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxSectionHeader
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxScreenInsets
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.invoices.domain.InvoiceDetails
import com.maxnetwork.feature.invoices.domain.InvoiceItem
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun InvoiceDetailsScreen(
    state: InvoicesUiState,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    MaxScaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("invoice_details_screen"),
        topBar = { MaxTopBar(title = "تفاصيل الفاتورة", onBack = onBack) },
    ) { contentPadding ->
        when {
            state.detailsLoading -> MaxLoadingState(
                title = "جارٍ تحميل الفاتورة",
                message = "ستظهر التفاصيل فور اكتمال التحميل",
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("invoice_details_loading"),
            )

            state.detailsErrorMessage != null -> MaxErrorState(
                title = "تعذر تحميل الفاتورة",
                message = state.detailsErrorMessage,
                actionText = "إعادة المحاولة",
                onAction = onRetry,
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("invoice_details_error"),
            )

            state.selectedDetails != null -> DetailsContent(
                details = state.selectedDetails,
                contentPadding = contentPadding,
            )

            else -> MaxEmptyState(
                title = "الفاتورة غير محملة",
                message = "ارجع إلى قائمة الفواتير واختر فاتورة.",
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("invoice_details_empty"),
            )
        }
    }
}

@Composable
private fun DetailsContent(
    details: InvoiceDetails,
    contentPadding: PaddingValues,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("invoice_details_content"),
        contentPadding = PaddingValues(
            start = MaxScreenInsets.compactHorizontal,
            end = MaxScreenInsets.compactHorizontal,
            top = contentPadding.calculateTopPadding() + MaxSpacing.sm,
            bottom = contentPadding.calculateBottomPadding() + MaxSpacing.md,
        ),
        verticalArrangement = Arrangement.spacedBy(MaxSpacing.sectionGap),
    ) {
        item(key = "invoice_summary") {
            InvoiceSummaryHeader(details = details)
        }

        item(key = "invoice_facts") {
            InvoiceFacts(details = details)
        }

        if (details.items.isNotEmpty()) {
            item(key = "invoice_items") {
                InvoiceItems(items = details.items)
            }
        }

        item(key = "invoice_totals") {
            InvoiceTotals(details = details)
        }
    }
}

@Composable
private fun InvoiceSummaryHeader(details: InvoiceDetails) {
    MaxHeroContainer(
        modifier = Modifier.testTag("invoice_summary_header"),
        contentPadding = PaddingValues(MaxSpacing.lg),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
        ) {
            MaxText(
                text = "فاتورة ${details.summary.kind.displayName()}",
                style = MaterialTheme.typography.labelLarge,
            )
            MaxText(
                text = details.summary.invoiceNumber,
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.testTag("invoice_details_number"),
            )
            MaxText(
                text = details.summary.total.toSdgText(),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.testTag("invoice_details_total_header"),
            )
        }
    }
}

@Composable
private fun InvoiceFacts(details: InvoiceDetails) {
    Column(verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm)) {
        MaxSectionHeader(title = "بيانات الفاتورة")
        MaxListContainer(modifier = Modifier.testTag("invoice_facts_group")) {
            MaxListRow(
                title = "نوع الفاتورة",
                supportingText = details.summary.kind.displayName(),
            )
            MaxDivider()
            MaxListRow(
                title = "التاريخ والوقت",
                supportingText = DETAILS_TIME.format(details.summary.occurredAt),
            )
        }
    }
}

@Composable
private fun InvoiceItems(items: List<InvoiceItem>) {
    Column(verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm)) {
        MaxSectionHeader(title = "الأصناف (${items.size})")
        MaxListContainer(modifier = Modifier.testTag("invoice_items_group")) {
            items.forEachIndexed { index, item ->
                MaxListRow(
                    title = item.name,
                    supportingText = item.supportingDetails(),
                    modifier = Modifier.testTag("invoice_item_$index"),
                )
                if (index < items.lastIndex) MaxDivider()
            }
        }
    }
}

@Composable
private fun InvoiceTotals(details: InvoiceDetails) {
    Column(verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm)) {
        MaxSectionHeader(title = "الإجمالي")
        MaxListContainer(modifier = Modifier.testTag("invoice_totals_group")) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(MaxSpacing.lg),
                verticalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
            ) {
                MaxText(
                    text = "إجمالي الفاتورة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                MaxText(
                    text = details.summary.total.toSdgText(),
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.testTag("invoice_details_total"),
                )
            }
        }
    }
}

private fun InvoiceItem.supportingDetails(): String = buildList {
    partNumber?.let { add("رقم القطعة: $it") }
    add("الكمية: $quantity")
    unitAmount?.let { add("سعر الوحدة: ${it.toSdgText()}") }
    lineTotal?.let { add("إجمالي الصنف: ${it.toSdgText()}") }
}.joinToString("\n")

private val DETAILS_TIME: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd • HH:mm")
    .withZone(ZoneId.systemDefault())
