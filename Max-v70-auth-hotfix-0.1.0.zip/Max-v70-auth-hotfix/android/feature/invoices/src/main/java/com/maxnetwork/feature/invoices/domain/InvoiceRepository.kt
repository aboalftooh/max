package com.maxnetwork.feature.invoices.domain

interface InvoiceRepository {
    suspend fun getInvoices(query: InvoiceQuery): InvoiceReadResult<InvoicePage>
    suspend fun getInvoice(id: InvoiceId): InvoiceReadResult<InvoiceDetails>
}
