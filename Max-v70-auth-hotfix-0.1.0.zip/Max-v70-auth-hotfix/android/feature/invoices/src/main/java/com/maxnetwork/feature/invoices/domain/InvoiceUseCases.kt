package com.maxnetwork.feature.invoices.domain

class LoadInvoicesPageUseCase(
    private val repository: InvoiceRepository,
) {
    suspend operator fun invoke(query: InvoiceQuery): InvoiceReadResult<InvoicePage> = repository.getInvoices(query)
}

class LoadInvoiceDetailsUseCase(
    private val repository: InvoiceRepository,
) {
    suspend operator fun invoke(id: InvoiceId): InvoiceReadResult<InvoiceDetails> = repository.getInvoice(id)
}
