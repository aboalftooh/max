package com.maxnetwork.feature.invoices.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.maxnetwork.feature.invoices.domain.InvoiceId
import com.maxnetwork.feature.invoices.domain.InvoiceQuery
import com.maxnetwork.feature.invoices.domain.InvoiceReadResult
import com.maxnetwork.feature.invoices.domain.LoadInvoiceDetailsUseCase
import com.maxnetwork.feature.invoices.domain.LoadInvoicesPageUseCase
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class InvoicesViewModel(
    private val loadPage: LoadInvoicesPageUseCase,
    private val loadInvoiceDetails: LoadInvoiceDetailsUseCase,
) : ViewModel() {
    private val reducer = InvoicesStateReducer()
    private val mutableState = MutableStateFlow(reducer.state)
    private var listJob: Job? = null
    private var detailsJob: Job? = null

    val state: StateFlow<InvoicesUiState> = mutableState.asStateFlow()

    fun start() {
        if (reducer.state.items.isNotEmpty() || reducer.state.initialLoading) return
        refresh()
    }

    fun onSearchTextChanged(value: String) {
        reducer.searchChanged(value)
        publish()
    }

    fun submitSearch() {
        refresh(search = reducer.state.searchText.trim())
    }

    fun retry() {
        refresh(search = reducer.state.activeSearch)
    }

    fun loadMore() {
        val cursor = reducer.state.nextCursor ?: return
        if (!reducer.state.canLoadMore || listJob?.isActive == true) return
        reducer.loadingMore()
        publish()
        listJob = viewModelScope.launch {
            when (
                val result = loadPage(
                    InvoiceQuery(search = reducer.state.activeSearch, cursor = cursor),
                )
            ) {
                is InvoiceReadResult.Success -> reducer.pageLoaded(result.value, append = true)
                is InvoiceReadResult.Failure -> reducer.failed(result.reason)
            }
            publish()
        }
    }

    fun loadDetails(id: InvoiceId) {
        detailsJob?.cancel()
        reducer.detailsLoading()
        publish()
        detailsJob = viewModelScope.launch {
            when (val result = loadInvoiceDetails(id)) {
                is InvoiceReadResult.Success -> reducer.detailsLoaded(result.value)
                is InvoiceReadResult.Failure -> reducer.detailsFailed(result.reason)
            }
            publish()
        }
    }

    fun retryDetails(id: InvoiceId) {
        loadDetails(id)
    }

    fun clearDetails() {
        detailsJob?.cancel()
        detailsJob = null
        reducer.clearDetails()
        publish()
    }

    fun clear() {
        listJob?.cancel()
        detailsJob?.cancel()
        listJob = null
        detailsJob = null
        reducer.clear()
        publish()
    }

    private fun refresh(search: String = reducer.state.activeSearch) {
        listJob?.cancel()
        reducer.refreshing(search)
        publish()
        listJob = viewModelScope.launch {
            when (val result = loadPage(InvoiceQuery(search = search))) {
                is InvoiceReadResult.Success -> reducer.pageLoaded(result.value, append = false)
                is InvoiceReadResult.Failure -> reducer.failed(result.reason)
            }
            publish()
        }
    }

    private fun publish() {
        mutableState.value = reducer.state
    }
}
