package com.maxnetwork.feature.invoices.domain

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import java.time.Instant

@JvmInline
value class InvoiceId(val value: String) {
    init { require(value.isNotBlank()) }
}

enum class InvoiceKind {
    Sale,
    Purchase,
}

data class InvoiceSummary(
    val id: InvoiceId,
    val invoiceNumber: String,
    val kind: InvoiceKind,
    val total: Money,
    val occurredAt: Instant,
) {
    init {
        require(invoiceNumber.isNotBlank())
        require(total.currency == CurrencyCode.SDG)
        require(total.minorUnits > 0)
    }
}

data class InvoiceItem(
    val name: String,
    val partNumber: String?,
    val quantity: String,
    val unitAmount: Money?,
    val lineTotal: Money?,
) {
    init {
        require(name.isNotBlank())
        require(partNumber == null || partNumber.isNotBlank())
        require(QUANTITY.matches(quantity))
        require(unitAmount == null || unitAmount.currency == CurrencyCode.SDG)
        require(lineTotal == null || lineTotal.currency == CurrencyCode.SDG)
        require(unitAmount == null || unitAmount.minorUnits >= 0)
        require(lineTotal == null || lineTotal.minorUnits >= 0)
    }
}

data class InvoiceDetails(
    val summary: InvoiceSummary,
    val items: List<InvoiceItem>,
)

@JvmInline
value class InvoiceCursor(val value: String) {
    init { require(value.isNotBlank()) }
}

data class InvoiceQuery(
    val search: String = "",
    val cursor: InvoiceCursor? = null,
    val limit: Int = 20,
) {
    init {
        require(search.length <= 120)
        require(limit in 1..50)
    }

    val normalizedSearch: String get() = search.trim()
}

data class InvoicePage(
    val items: List<InvoiceSummary>,
    val nextCursor: InvoiceCursor?,
)

sealed interface InvoiceReadFailure {
    data object Offline : InvoiceReadFailure
    data object Unauthorized : InvoiceReadFailure
    data object NotFound : InvoiceReadFailure
    data object InvalidQuery : InvoiceReadFailure
    data class Unavailable(val retryable: Boolean) : InvoiceReadFailure
}

sealed interface InvoiceReadResult<out T> {
    data class Success<T>(val value: T) : InvoiceReadResult<T>
    data class Failure(val reason: InvoiceReadFailure) : InvoiceReadResult<Nothing>
}

private val QUANTITY = Regex("^-?(0|[1-9][0-9]*)(\\.[0-9]+)?$")
