package com.maxnetwork.feature.invoices

import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.invoices.data.NetworkInvoiceRepository
import com.maxnetwork.feature.invoices.domain.LoadInvoiceDetailsUseCase
import com.maxnetwork.feature.invoices.domain.LoadInvoicesPageUseCase

data class InvoicesUseCases(
    val loadPage: LoadInvoicesPageUseCase,
    val loadDetails: LoadInvoiceDetailsUseCase,
)

data class InvoicesFeatureDependencies(
    val useCases: InvoicesUseCases,
)

object InvoicesFeatureFactory {
    fun create(gateway: MaxGateway): InvoicesFeatureDependencies {
        val repository = NetworkInvoiceRepository(gateway)
        return InvoicesFeatureDependencies(
            useCases = InvoicesUseCases(
                loadPage = LoadInvoicesPageUseCase(repository),
                loadDetails = LoadInvoiceDetailsUseCase(repository),
            ),
        )
    }
}
