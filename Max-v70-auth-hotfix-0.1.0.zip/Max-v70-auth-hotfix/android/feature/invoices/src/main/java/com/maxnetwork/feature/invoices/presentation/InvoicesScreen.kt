package com.maxnetwork.feature.invoices.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.maxnetwork.core.designsystem.component.MaxBadge
import com.maxnetwork.core.designsystem.component.MaxBannerTone
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxEmptyState
import com.maxnetwork.core.designsystem.component.MaxErrorState
import com.maxnetwork.core.designsystem.component.MaxInlineBanner
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxLoadingState
import com.maxnetwork.core.designsystem.component.MaxOfflineState
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxSearchField
import com.maxnetwork.core.designsystem.component.MaxSecondaryButton
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxScreenInsets
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.invoices.domain.InvoiceId
import com.maxnetwork.feature.invoices.domain.InvoiceKind
import com.maxnetwork.feature.invoices.domain.InvoiceSummary
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.flow.distinctUntilChanged

@Composable
fun InvoicesScreen(
    state: InvoicesUiState,
    onSearchTextChanged: (String) -> Unit,
    onSearch: () -> Unit,
    onInvoiceClick: (InvoiceId) -> Unit,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    MaxScaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("invoices_screen"),
        topBar = { MaxTopBar(title = "الفواتير", onBack = onBack) },
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding),
        ) {
            InvoiceSearch(
                value = state.searchText,
                onValueChanged = onSearchTextChanged,
                onSearch = onSearch,
            )
            InvoiceResults(
                state = state,
                onInvoiceClick = onInvoiceClick,
                onRetry = onRetry,
                onLoadMore = onLoadMore,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
            )
        }
    }
}

@Composable
private fun InvoiceSearch(
    value: String,
    onValueChanged: (String) -> Unit,
    onSearch: () -> Unit,
) {
    MaxSearchField(
        value = value,
        onValueChange = onValueChanged,
        placeholder = "رقم الفاتورة، الصنف أو رقم القطعة",
        onClear = {
            onValueChanged("")
            onSearch()
        },
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        testTag = "invoice_search_field",
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = MaxScreenInsets.compactHorizontal,
                vertical = MaxSpacing.sm,
            ),
    )
}

@Composable
private fun InvoiceResults(
    state: InvoicesUiState,
    onInvoiceClick: (InvoiceId) -> Unit,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    modifier: Modifier = Modifier,
) {
    when {
        state.initialLoading && !state.hasListContent -> MaxLoadingState(
            title = "جارٍ تحميل الفواتير",
            message = "ستظهر الفواتير هنا فور اكتمال التحميل",
            modifier = modifier.testTag("invoices_loading"),
        )

        state.errorMessage != null && !state.hasListContent && state.offline -> MaxOfflineState(
            title = "لا يوجد اتصال",
            message = state.errorMessage,
            actionText = "إعادة المحاولة",
            onAction = onRetry,
            modifier = modifier.testTag("invoices_error"),
        )

        state.errorMessage != null && !state.hasListContent -> MaxErrorState(
            title = "تعذر تحميل الفواتير",
            message = state.errorMessage,
            actionText = "إعادة المحاولة",
            onAction = onRetry,
            modifier = modifier.testTag("invoices_error"),
        )

        state.items.isEmpty() -> MaxEmptyState(
            title = if (state.activeSearch.isBlank()) "لا توجد فواتير بعد" else "لا توجد نتائج",
            message = if (state.activeSearch.isBlank()) {
                "ستظهر الفواتير هنا عند توفرها."
            } else {
                "لا توجد فواتير مطابقة لعبارة البحث الحالية."
            },
            modifier = modifier.testTag("invoices_empty"),
        )

        else -> InvoiceList(
            state = state,
            onInvoiceClick = onInvoiceClick,
            onRetry = onRetry,
            onLoadMore = onLoadMore,
            modifier = modifier,
        )
    }
}

@Composable
private fun InvoiceList(
    state: InvoicesUiState,
    onInvoiceClick: (InvoiceId) -> Unit,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()
    LaunchedEffect(listState, state.canLoadMore, state.items.size) {
        snapshotFlow { !listState.canScrollForward }
            .distinctUntilChanged()
            .collect { reachedEnd -> if (reachedEnd && state.canLoadMore) onLoadMore() }
    }

    LazyColumn(
        modifier = modifier.testTag("invoice_list"),
        state = listState,
        contentPadding = PaddingValues(
            horizontal = MaxScreenInsets.compactHorizontal,
            vertical = MaxSpacing.sm,
        ),
        verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
    ) {
        if (state.errorMessage != null) {
            item(key = "invoice_stale_error") {
                Column(verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm)) {
                    MaxInlineBanner(
                        message = "تعذر تحديث الفواتير. المعروض هو آخر محتوى متاح. ${state.errorMessage}",
                        tone = MaxBannerTone.Error,
                        modifier = Modifier.testTag("invoices_inline_error"),
                    )
                    MaxSecondaryButton(
                        text = "إعادة المحاولة",
                        onClick = onRetry,
                        testTag = "invoices_inline_retry",
                    )
                }
            }
        } else if (state.initialLoading) {
            item(key = "invoice_refreshing") {
                MaxInlineBanner(
                    message = "جارٍ تحديث الفواتير…",
                    modifier = Modifier.testTag("invoices_refreshing"),
                )
            }
        }

        item(key = "invoice_list_container") {
            MaxListContainer {
                state.items.forEachIndexed { index, invoice ->
                    InvoiceRow(invoice = invoice, onClick = { onInvoiceClick(invoice.id) })
                    if (index < state.items.lastIndex) MaxDivider()
                }
            }
        }

        if (state.loadingMore) {
            item(key = "invoice_loading_more") {
                MaxInlineBanner(
                    message = "جارٍ تحميل المزيد من الفواتير…",
                    modifier = Modifier.testTag("invoice_loading_more"),
                )
            }
        }
    }
}

@Composable
private fun InvoiceRow(
    invoice: InvoiceSummary,
    onClick: () -> Unit,
) {
    MaxListRow(
        title = invoice.invoiceNumber,
        supportingText = INVOICE_TIME.format(invoice.occurredAt),
        modifier = Modifier.testTag("invoice_${invoice.id.value}"),
        trailingContent = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(MaxSpacing.xxs),
            ) {
                MaxText(
                    text = invoice.total.toSdgText(),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.testTag("invoice_amount_${invoice.id.value}"),
                )
                MaxBadge(
                    text = invoice.kind.displayName(),
                    modifier = Modifier.testTag("invoice_kind_${invoice.id.value}"),
                )
            }
        },
        onClick = onClick,
    )
}

internal fun InvoiceKind.displayName(): String = if (this == InvoiceKind.Sale) "مبيعات" else "مشتريات"

internal fun com.maxnetwork.core.model.Money.toSdgText(): String = "%,d ج.س".format(minorUnits)

private val INVOICE_TIME: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd • HH:mm")
    .withZone(ZoneId.systemDefault())
