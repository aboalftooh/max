package com.maxnetwork.feature.invoices.presentation

import androidx.compose.runtime.Composable
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.feature.invoices.domain.InvoiceDetails
import com.maxnetwork.feature.invoices.domain.InvoiceId
import com.maxnetwork.feature.invoices.domain.InvoiceItem
import com.maxnetwork.feature.invoices.domain.InvoiceKind
import com.maxnetwork.feature.invoices.domain.InvoiceSummary
import java.time.Instant

@MaxComponentPreviews
@Composable
private fun InvoicesScreenPreview() {
    MaxTheme(motionEnabled = false) {
        InvoicesScreen(
            state = InvoicesUiState(
                items = listOf(
                    invoiceSummary("invoice-1", "INV-1001", InvoiceKind.Sale, 250_000),
                    invoiceSummary("invoice-2", "INV-1002", InvoiceKind.Purchase, 480_000),
                ),
            ),
            onSearchTextChanged = {},
            onSearch = {},
            onInvoiceClick = {},
            onRetry = {},
            onLoadMore = {},
            onBack = {},
        )
    }
}

@MaxComponentPreviews
@Composable
private fun InvoicesEmptyPreview() {
    MaxTheme(motionEnabled = false) {
        InvoicesScreen(
            state = InvoicesUiState(),
            onSearchTextChanged = {},
            onSearch = {},
            onInvoiceClick = {},
            onRetry = {},
            onLoadMore = {},
            onBack = {},
        )
    }
}

@MaxComponentPreviews
@Composable
private fun InvoiceDetailsPreview() {
    MaxTheme(motionEnabled = false) {
        InvoiceDetailsScreen(
            state = InvoicesUiState(
                selectedDetails = InvoiceDetails(
                    summary = invoiceSummary("invoice-1", "INV-1001", InvoiceKind.Sale, 250_000),
                    items = listOf(
                        InvoiceItem(
                            name = "مساعد أمامي كورولا",
                            partNumber = "48510-09A70",
                            quantity = "2",
                            unitAmount = Money(100_000, CurrencyCode.SDG),
                            lineTotal = Money(200_000, CurrencyCode.SDG),
                        ),
                        InvoiceItem(
                            name = "جلدة ميزان",
                            partNumber = null,
                            quantity = "1",
                            unitAmount = Money(50_000, CurrencyCode.SDG),
                            lineTotal = Money(50_000, CurrencyCode.SDG),
                        ),
                    ),
                ),
            ),
            onBack = {},
            onRetry = {},
        )
    }
}

private fun invoiceSummary(
    id: String,
    number: String,
    kind: InvoiceKind,
    total: Long,
): InvoiceSummary = InvoiceSummary(
    id = InvoiceId(id),
    invoiceNumber = number,
    kind = kind,
    total = Money(total, CurrencyCode.SDG),
    occurredAt = Instant.parse("2026-08-16T06:00:00Z"),
)
