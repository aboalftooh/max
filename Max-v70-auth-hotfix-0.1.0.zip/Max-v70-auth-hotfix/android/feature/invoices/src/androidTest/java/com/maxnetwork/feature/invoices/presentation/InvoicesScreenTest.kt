package com.maxnetwork.feature.invoices.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.assertDoesNotExist
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performImeAction
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.feature.invoices.domain.InvoiceCursor
import com.maxnetwork.feature.invoices.domain.InvoiceDetails
import com.maxnetwork.feature.invoices.domain.InvoiceId
import com.maxnetwork.feature.invoices.domain.InvoiceItem
import com.maxnetwork.feature.invoices.domain.InvoiceKind
import com.maxnetwork.feature.invoices.domain.InvoiceSummary
import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

class InvoicesScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun listUsesFullWidthSearchAndDesignSystemRows() {
        setInvoicesContent(InvoicesUiState(items = listOf(SUMMARY)))

        composeRule.onNodeWithTag("invoices_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("max_top_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_search_field").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_search_button").assertDoesNotExist()
        composeRule.onNodeWithTag("invoice_${ID.value}").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_amount_${ID.value}").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_kind_${ID.value}").assertIsDisplayed()
    }

    @Test
    fun searchImeActionSubmitsSearch() {
        var searches = 0
        setInvoicesContent(
            state = InvoicesUiState(searchText = "INV-1001", items = listOf(SUMMARY)),
            onSearch = { searches += 1 },
        )

        composeRule.onNodeWithTag("invoice_search_field").performClick().performImeAction()
        composeRule.runOnIdle { assertEquals(1, searches) }
    }

    @Test
    fun blockingLoadingUsesDesignSystemFeedback() {
        setInvoicesContent(InvoicesUiState(initialLoading = true))

        composeRule.onNodeWithTag("invoices_loading").assertIsDisplayed()
        composeRule.onNodeWithTag("max_state_Loading").assertIsDisplayed()
    }

    @Test
    fun inlineErrorKeepsExistingInvoicesVisible() {
        setInvoicesContent(
            InvoicesUiState(
                items = listOf(SUMMARY),
                errorMessage = "تعذر التحديث",
            ),
        )

        composeRule.onNodeWithTag("invoices_inline_error").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_${ID.value}").assertIsDisplayed()
    }

    @Test
    fun loadingMoreUsesDesignSystemFeedback() {
        setInvoicesContent(
            InvoicesUiState(
                items = listOf(SUMMARY),
                nextCursor = InvoiceCursor("next"),
                loadingMore = true,
            ),
        )

        composeRule.onNodeWithTag("invoice_loading_more").assertIsDisplayed()
    }

    @Test
    fun detailsUseSummaryGroupedFactsItemsAndTotals() {
        setDetailsContent(detailsState())

        composeRule.onNodeWithTag("invoice_summary_header").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_facts_group").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_items_group").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_item_0").assertIsDisplayed()

        composeRule.onNodeWithTag("invoice_details_content")
            .performScrollToNode(hasTestTag("invoice_details_total"))
        composeRule.onNodeWithTag("invoice_details_total").assertIsDisplayed()
    }

    @Test
    fun rtlAndLargeTextKeepInvoiceContentReachable() {
        setDetailsContent(
            state = detailsState(),
            fontScale = 2f,
            layoutDirection = LayoutDirection.Rtl,
        )

        composeRule.onNodeWithTag("max_top_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_summary_header").assertIsDisplayed()
        composeRule.onNodeWithTag("invoice_details_content")
            .performScrollToNode(hasTestTag("invoice_details_total"))
        composeRule.onNodeWithTag("invoice_details_total").assertIsDisplayed()
    }

    private fun setInvoicesContent(
        state: InvoicesUiState,
        onSearch: () -> Unit = {},
        fontScale: Float = 1f,
        layoutDirection: LayoutDirection = LayoutDirection.Rtl,
    ) {
        composeRule.setContent {
            InvoiceTestTheme(fontScale, layoutDirection) {
                InvoicesScreen(
                    state = state,
                    onSearchTextChanged = {},
                    onSearch = onSearch,
                    onInvoiceClick = {},
                    onRetry = {},
                    onLoadMore = {},
                    onBack = {},
                )
            }
        }
    }

    private fun setDetailsContent(
        state: InvoicesUiState,
        fontScale: Float = 1f,
        layoutDirection: LayoutDirection = LayoutDirection.Rtl,
    ) {
        composeRule.setContent {
            InvoiceTestTheme(fontScale, layoutDirection) {
                InvoiceDetailsScreen(
                    state = state,
                    onBack = {},
                    onRetry = {},
                )
            }
        }
    }

    private fun detailsState(): InvoicesUiState = InvoicesUiState(
        selectedDetails = InvoiceDetails(
            summary = SUMMARY,
            items = listOf(
                InvoiceItem(
                    name = "مساعد أمامي كورولا",
                    partNumber = "48510-09A70",
                    quantity = "2",
                    unitAmount = Money(100_000, CurrencyCode.SDG),
                    lineTotal = Money(200_000, CurrencyCode.SDG),
                ),
            ),
        ),
    )

    private companion object {
        val ID = InvoiceId("invoice-test")
        val SUMMARY = InvoiceSummary(
            id = ID,
            invoiceNumber = "INV-1001",
            kind = InvoiceKind.Sale,
            total = Money(200_000, CurrencyCode.SDG),
            occurredAt = Instant.parse("2026-08-16T06:00:00Z"),
        )
    }
}

@Composable
private fun InvoiceTestTheme(
    fontScale: Float,
    layoutDirection: LayoutDirection,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    MaxTheme(motionEnabled = false) {
        CompositionLocalProvider(
            LocalDensity provides Density(density = density.density, fontScale = fontScale),
            LocalLayoutDirection provides layoutDirection,
            content = content,
        )
    }
}
