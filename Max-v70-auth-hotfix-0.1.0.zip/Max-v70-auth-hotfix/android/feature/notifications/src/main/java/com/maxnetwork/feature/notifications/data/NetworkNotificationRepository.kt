package com.maxnetwork.feature.notifications.data

import com.maxnetwork.core.model.NotificationId
import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.MaxNotification
import com.maxnetwork.core.network.NotificationTargetType
import com.maxnetwork.core.network.NotificationType
import com.maxnetwork.feature.notifications.domain.NotificationCursor
import com.maxnetwork.feature.notifications.domain.NotificationFailure
import com.maxnetwork.feature.notifications.domain.NotificationItem
import com.maxnetwork.feature.notifications.domain.NotificationKind
import com.maxnetwork.feature.notifications.domain.NotificationPage
import com.maxnetwork.feature.notifications.domain.NotificationQuery
import com.maxnetwork.feature.notifications.domain.NotificationRepository
import com.maxnetwork.feature.notifications.domain.NotificationResult
import com.maxnetwork.feature.notifications.domain.NotificationTarget

class NetworkNotificationRepository(
    private val gateway: MaxGateway,
) : NotificationRepository {
    override suspend fun getNotifications(query: NotificationQuery): NotificationResult<NotificationPage> = when (
        val result = gateway.getNotifications(query.cursor?.value, query.limit)
    ) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> NotificationResult.Success(
            NotificationPage(
                items = result.value.items.map(MaxNotification::toDomain),
                nextCursor = result.value.nextCursor?.let(::NotificationCursor),
            ),
        )
    }

    override suspend fun markRead(notificationId: NotificationId): NotificationResult<Unit> = when (
        val result = gateway.markNotificationRead(notificationId.value)
    ) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> NotificationResult.Success(Unit)
    }
}

private fun MaxNotification.toDomain() = NotificationItem(
    id = NotificationId(id),
    kind = when (type) {
        NotificationType.RequestNeedsReply -> NotificationKind.RequestNeedsReply
        NotificationType.OutgoingRequestUpdated -> NotificationKind.OutgoingRequestUpdated
        NotificationType.PartAvailable -> NotificationKind.PartAvailable
        NotificationType.PartUnavailable -> NotificationKind.PartUnavailable
        NotificationType.BalanceMovement -> NotificationKind.BalanceMovement
        NotificationType.BalanceUpdated -> NotificationKind.BalanceUpdated
    },
    title = title,
    body = body,
    occurredAt = occurredAt,
    readAt = readAt,
    target = when (target.type) {
        NotificationTargetType.Conversation -> NotificationTarget.Conversation(requireNotNull(target.id))
        NotificationTargetType.Home -> NotificationTarget.Home
        NotificationTargetType.Invoice -> NotificationTarget.Invoice(requireNotNull(target.id))
        NotificationTargetType.None -> NotificationTarget.None
    },
)

private fun GatewayResult.Failure.toDomainFailure(): NotificationResult.Failure = NotificationResult.Failure(
    when (error.code) {
        ApiErrorCode.Unauthorized -> NotificationFailure.Unauthorized
        ApiErrorCode.NotFound -> NotificationFailure.NotFound
        ApiErrorCode.ServiceUnavailable -> if (error.traceId == "network-unavailable") {
            NotificationFailure.Offline
        } else {
            NotificationFailure.Unavailable(error.retryable)
        }
        else -> NotificationFailure.Unavailable(error.retryable)
    },
)
