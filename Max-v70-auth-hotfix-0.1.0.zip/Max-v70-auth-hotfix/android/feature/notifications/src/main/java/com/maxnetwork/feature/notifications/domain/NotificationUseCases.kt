package com.maxnetwork.feature.notifications.domain

import com.maxnetwork.core.model.NotificationId

class LoadNotificationsPageUseCase(
    private val repository: NotificationRepository,
) {
    suspend operator fun invoke(query: NotificationQuery = NotificationQuery()): NotificationResult<NotificationPage> =
        repository.getNotifications(query)
}

class MarkNotificationReadUseCase(
    private val repository: NotificationRepository,
) {
    suspend operator fun invoke(notificationId: NotificationId): NotificationResult<Unit> =
        repository.markRead(notificationId)
}
