package com.maxnetwork.feature.notifications.domain

interface PushRegistrationRepository {
    suspend fun register(accessToken: String, registration: PushRegistration): PushRegistrationResult
    suspend fun unregister(accessToken: String, installationId: PushInstallationId): PushRegistrationResult
}

class RegisterPushInstallationUseCase(
    private val repository: PushRegistrationRepository,
) {
    suspend operator fun invoke(accessToken: String, registration: PushRegistration): PushRegistrationResult {
        require(accessToken.isNotBlank())
        return repository.register(accessToken, registration)
    }
}

class UnregisterPushInstallationUseCase(
    private val repository: PushRegistrationRepository,
) {
    suspend operator fun invoke(accessToken: String, installationId: PushInstallationId): PushRegistrationResult {
        require(accessToken.isNotBlank())
        return repository.unregister(accessToken, installationId)
    }
}
