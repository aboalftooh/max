package com.maxnetwork.feature.notifications.presentation

import com.maxnetwork.feature.notifications.domain.NotificationCursor
import com.maxnetwork.feature.notifications.domain.NotificationItem

data class NotificationsUiState(
    val items: List<NotificationItem> = emptyList(),
    val nextCursor: NotificationCursor? = null,
    val loaded: Boolean = false,
    val initialLoading: Boolean = false,
    val loadingMore: Boolean = false,
    val errorMessage: String? = null,
    val routingNotificationId: String? = null,
) {
    val unreadCount: Int get() = items.count { !it.isRead }
    val canLoadMore: Boolean get() = nextCursor != null && !initialLoading && !loadingMore
}
