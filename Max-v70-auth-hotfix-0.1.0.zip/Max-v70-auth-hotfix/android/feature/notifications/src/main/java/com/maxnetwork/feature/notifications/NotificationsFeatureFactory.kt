package com.maxnetwork.feature.notifications

import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.notifications.data.NetworkNotificationRepository
import com.maxnetwork.feature.notifications.data.NetworkPushRegistrationRepository
import com.maxnetwork.feature.notifications.domain.LoadNotificationsPageUseCase
import com.maxnetwork.feature.notifications.domain.MarkNotificationReadUseCase
import com.maxnetwork.feature.notifications.domain.RegisterPushInstallationUseCase
import com.maxnetwork.feature.notifications.domain.UnregisterPushInstallationUseCase

data class NotificationUseCases(
    val loadPage: LoadNotificationsPageUseCase,
    val markRead: MarkNotificationReadUseCase,
    val registerPush: RegisterPushInstallationUseCase,
    val unregisterPush: UnregisterPushInstallationUseCase,
)

data class NotificationFeatureDependencies(
    val useCases: NotificationUseCases,
)

object NotificationsFeatureFactory {
    fun create(gateway: MaxGateway): NotificationFeatureDependencies {
        val repository = NetworkNotificationRepository(gateway)
        val pushRepository = NetworkPushRegistrationRepository(gateway)
        return NotificationFeatureDependencies(
            useCases = NotificationUseCases(
                loadPage = LoadNotificationsPageUseCase(repository),
                markRead = MarkNotificationReadUseCase(repository),
                registerPush = RegisterPushInstallationUseCase(pushRepository),
                unregisterPush = UnregisterPushInstallationUseCase(pushRepository),
            ),
        )
    }
}
