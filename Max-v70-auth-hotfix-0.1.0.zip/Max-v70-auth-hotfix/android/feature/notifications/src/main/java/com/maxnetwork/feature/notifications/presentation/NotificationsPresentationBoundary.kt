package com.maxnetwork.feature.notifications.presentation

/** Placeholder boundary. Presentation must not access DAO or network clients directly. */
internal object NotificationsPresentationBoundary
