package com.maxnetwork.feature.notifications.presentation

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.maxnetwork.feature.notifications.domain.LoadNotificationsPageUseCase
import com.maxnetwork.feature.notifications.domain.MarkNotificationReadUseCase
import com.maxnetwork.feature.notifications.domain.NotificationFailure
import com.maxnetwork.feature.notifications.domain.NotificationItem
import com.maxnetwork.feature.notifications.domain.NotificationQuery
import com.maxnetwork.feature.notifications.domain.NotificationResult
import com.maxnetwork.feature.notifications.domain.NotificationTarget
import java.time.Instant

class NotificationsViewModel(
    private val loadPage: LoadNotificationsPageUseCase,
    private val markRead: MarkNotificationReadUseCase,
) {
    var state by mutableStateOf(NotificationsUiState())
        private set

    suspend fun start() {
        if (state.items.isNotEmpty() || state.initialLoading) return
        refresh()
    }

    suspend fun refresh() {
        state = state.copy(initialLoading = true, loadingMore = false, errorMessage = null)
        when (val result = loadPage(NotificationQuery(limit = PAGE_SIZE))) {
            is NotificationResult.Success -> state = state.copy(
                items = result.value.items,
                nextCursor = result.value.nextCursor,
                loaded = true,
                initialLoading = false,
                loadingMore = false,
                errorMessage = null,
            )
            is NotificationResult.Failure -> state = state.copy(
                loaded = true,
                initialLoading = false,
                loadingMore = false,
                errorMessage = result.reason.userMessage(),
            )
        }
    }

    suspend fun loadMore() {
        val cursor = state.nextCursor ?: return
        if (!state.canLoadMore) return
        state = state.copy(loadingMore = true, errorMessage = null)
        when (val result = loadPage(NotificationQuery(cursor = cursor, limit = PAGE_SIZE))) {
            is NotificationResult.Success -> state = state.copy(
                items = (state.items + result.value.items).distinctBy { it.id },
                nextCursor = result.value.nextCursor,
                loadingMore = false,
                errorMessage = null,
            )
            is NotificationResult.Failure -> state = state.copy(
                loadingMore = false,
                errorMessage = result.reason.userMessage(),
            )
        }
    }

    suspend fun markReadAndResolve(item: NotificationItem): NotificationTarget? {
        state = state.copy(routingNotificationId = item.id.value, errorMessage = null)
        return when (val result = markRead(item.id)) {
            is NotificationResult.Success -> {
                state = state.copy(
                    items = state.items.map { current ->
                        if (current.id == item.id && !current.isRead) {
                            current.copy(readAt = maxOf(Instant.now(), current.occurredAt))
                        } else {
                            current
                        }
                    },
                    routingNotificationId = null,
                    errorMessage = null,
                )
                item.target.takeUnless { it == NotificationTarget.None }
            }
            is NotificationResult.Failure -> {
                state = state.copy(
                    routingNotificationId = null,
                    errorMessage = result.reason.userMessage(),
                )
                null
            }
        }
    }

    fun clear() {
        state = NotificationsUiState()
    }

    private companion object {
        const val PAGE_SIZE = 50
    }
}

private fun NotificationFailure.userMessage(): String = when (this) {
    NotificationFailure.Offline -> "لا يوجد اتصال بالإنترنت. حاول مجددًا."
    NotificationFailure.Unauthorized -> "انتهت الجلسة. سجّل الدخول من جديد."
    NotificationFailure.NotFound -> "الإشعار غير موجود."
    is NotificationFailure.Unavailable -> "تعذر تحميل الإشعارات حاليًا."
}
