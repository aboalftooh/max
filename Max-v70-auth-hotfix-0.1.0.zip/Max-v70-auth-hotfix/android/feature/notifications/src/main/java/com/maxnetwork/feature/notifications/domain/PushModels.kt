package com.maxnetwork.feature.notifications.domain

@JvmInline
value class PushInstallationId(val value: String) {
    init { require(value.matches(Regex("^[A-Za-z0-9_-]{16,128}$"))) }
}

@JvmInline
value class PushToken(val value: String) {
    init { require(value.length in 16..4096) }
}

/**
 * System-notification launch targets are intentionally coarse because the existing immutable
 * PendingIntent contract carries no target id. Precise Conversation/Invoice routing is resolved
 * from the authenticated notification inbox model, never from an arbitrary route string.
 */
enum class PushNavigationTarget {
    Home,
    Notifications,
    IncomingOrders,
    OutgoingOrders,
    Balance,
}

data class PushRegistration(
    val installationId: PushInstallationId,
    val token: PushToken,
    val appVersion: String,
) {
    init { require(appVersion.isNotBlank() && appVersion.length <= 64) }
}

data class PushMessage(
    val notificationId: String,
    val kind: NotificationKind,
    val target: PushNavigationTarget,
    val title: String,
    val body: String,
) {
    init {
        require(notificationId.matches(Regex("^[A-Za-z0-9_-]{1,128}$")))
        require(title.isNotBlank() && title.length <= 80 && !title.hasControlCharacters())
        require(body.isNotBlank() && body.length <= 180 && !body.hasControlCharacters())
    }
}

object PushMessageParser {
    fun parse(data: Map<String, String>): PushMessage? = runCatching {
        require(data["schema"] == "1")
        val kind = when (data.getValue("type")) {
            "REQUEST_NEEDS_REPLY" -> NotificationKind.RequestNeedsReply
            "OUTGOING_REQUEST_UPDATED" -> NotificationKind.OutgoingRequestUpdated
            "PART_AVAILABLE" -> NotificationKind.PartAvailable
            "PART_UNAVAILABLE" -> NotificationKind.PartUnavailable
            "BALANCE_MOVEMENT" -> NotificationKind.BalanceMovement
            "BALANCE_UPDATED" -> NotificationKind.BalanceUpdated
            else -> error("Unknown notification type")
        }
        val target = when (data.getValue("target")) {
            "HOME" -> PushNavigationTarget.Home
            "CONVERSATION", "INVOICE", "NONE" -> PushNavigationTarget.Notifications
            // Backward-compatible parsing for already-deployed v43-v49 push envelopes.
            "INCOMING_ORDERS" -> PushNavigationTarget.IncomingOrders
            "OUTGOING_ORDERS" -> PushNavigationTarget.OutgoingOrders
            "BALANCE" -> PushNavigationTarget.Balance
            else -> error("Unknown push target")
        }
        require(kind.isCompatibleWith(target))
        PushMessage(
            notificationId = data.getValue("notificationId"),
            kind = kind,
            target = target,
            title = data.getValue("title"),
            body = data.getValue("body"),
        )
    }.getOrNull()
}


private fun NotificationKind.isCompatibleWith(target: PushNavigationTarget): Boolean = when (target) {
    PushNavigationTarget.IncomingOrders -> this == NotificationKind.RequestNeedsReply
    PushNavigationTarget.OutgoingOrders -> this == NotificationKind.OutgoingRequestUpdated ||
        this == NotificationKind.PartAvailable || this == NotificationKind.PartUnavailable
    PushNavigationTarget.Balance, PushNavigationTarget.Home ->
        this == NotificationKind.BalanceMovement || this == NotificationKind.BalanceUpdated
    PushNavigationTarget.Notifications -> true
}

private fun String.hasControlCharacters(): Boolean = any { it.code < 32 && it != '\n' }

sealed interface PushRegistrationFailure {
    data object Unauthorized : PushRegistrationFailure
    data object Offline : PushRegistrationFailure
    data class Unavailable(val retryable: Boolean) : PushRegistrationFailure
}

sealed interface PushRegistrationResult {
    data object Success : PushRegistrationResult
    data class Failure(val reason: PushRegistrationFailure) : PushRegistrationResult
}
