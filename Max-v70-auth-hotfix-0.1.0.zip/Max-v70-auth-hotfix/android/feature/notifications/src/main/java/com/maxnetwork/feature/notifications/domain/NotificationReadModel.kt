package com.maxnetwork.feature.notifications.domain

import com.maxnetwork.core.model.NotificationId
import java.time.Instant

enum class NotificationKind {
    RequestNeedsReply,
    OutgoingRequestUpdated,
    PartAvailable,
    PartUnavailable,
    BalanceMovement,
    BalanceUpdated,
}

sealed interface NotificationTarget {
    data class Conversation(val conversationId: String) : NotificationTarget {
        init { require(conversationId.isNotBlank()) }
    }

    data object Home : NotificationTarget

    data class Invoice(val invoiceId: String) : NotificationTarget {
        init { require(invoiceId.isNotBlank()) }
    }

    data object None : NotificationTarget
}

data class NotificationItem(
    val id: NotificationId,
    val kind: NotificationKind,
    val title: String,
    val body: String,
    val occurredAt: Instant,
    val readAt: Instant?,
    val target: NotificationTarget,
) {
    init {
        require(id.value.isNotBlank())
        require(title.isNotBlank())
        require(body.isNotBlank())
        require(readAt == null || !readAt.isBefore(occurredAt))
    }

    val isRead: Boolean get() = readAt != null
}

@JvmInline
value class NotificationCursor(val value: String) {
    init { require(value.isNotBlank()) }
}

data class NotificationQuery(
    val cursor: NotificationCursor? = null,
    val limit: Int = 20,
) {
    init { require(limit in 1..50) }
}

data class NotificationPage(
    val items: List<NotificationItem>,
    val nextCursor: NotificationCursor?,
)

sealed interface NotificationFailure {
    data object Offline : NotificationFailure
    data object Unauthorized : NotificationFailure
    data object NotFound : NotificationFailure
    data class Unavailable(val retryable: Boolean) : NotificationFailure
}

sealed interface NotificationResult<out T> {
    data class Success<T>(val value: T) : NotificationResult<T>
    data class Failure(val reason: NotificationFailure) : NotificationResult<Nothing>
}
