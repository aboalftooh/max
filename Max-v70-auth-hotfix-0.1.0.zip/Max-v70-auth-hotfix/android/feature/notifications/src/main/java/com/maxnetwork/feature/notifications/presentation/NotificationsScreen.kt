package com.maxnetwork.feature.notifications.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.component.MaxBadge
import com.maxnetwork.core.designsystem.component.MaxBannerTone
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxEmptyState
import com.maxnetwork.core.designsystem.component.MaxErrorState
import com.maxnetwork.core.designsystem.component.MaxInlineBanner
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxLoadingState
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxSecondaryButton
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxScreenInsets
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.notifications.domain.NotificationItem
import com.maxnetwork.feature.notifications.domain.NotificationKind
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun NotificationsScreen(
    state: NotificationsUiState,
    onNotificationClick: (NotificationItem) -> Unit,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    MaxScaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("notifications_screen"),
        topBar = { MaxTopBar(title = "الإشعارات", onBack = onBack) },
    ) { contentPadding ->
        when {
            state.initialLoading && state.items.isEmpty() -> MaxLoadingState(
                title = "جارٍ تحميل الإشعارات",
                message = "ستظهر تحديثاتك هنا فور اكتمال التحميل",
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("notifications_loading"),
            )

            state.errorMessage != null && state.items.isEmpty() -> MaxErrorState(
                title = "تعذر تحميل الإشعارات",
                message = state.errorMessage,
                actionText = "إعادة المحاولة",
                onAction = onRetry,
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("notifications_error"),
            )

            state.items.isEmpty() -> MaxEmptyState(
                title = "لا توجد إشعارات",
                message = "ستظهر هنا تحديثات طلباتك ورصيدك وفواتيرك.",
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("notifications_empty"),
            )

            else -> NotificationsListContent(
                state = state,
                onNotificationClick = onNotificationClick,
                onLoadMore = onLoadMore,
                modifier = Modifier.padding(contentPadding),
            )
        }
    }
}

@Composable
private fun NotificationsListContent(
    state: NotificationsUiState,
    onNotificationClick: (NotificationItem) -> Unit,
    onLoadMore: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(
                horizontal = MaxScreenInsets.compactHorizontal,
                vertical = MaxSpacing.md,
            ),
        verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
    ) {
        if (state.errorMessage != null) {
            MaxInlineBanner(
                message = "تعذر تحديث الإشعارات. المعروض هو آخر محتوى متاح. ${state.errorMessage}",
                tone = MaxBannerTone.Error,
                modifier = Modifier.testTag("notifications_inline_error"),
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("notifications_list"),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
        ) {
            item(key = "notifications_list_container") {
                MaxListContainer {
                    state.items.forEachIndexed { index, item ->
                        NotificationRow(
                            item = item,
                            routing = state.routingNotificationId == item.id.value,
                            onClick = { onNotificationClick(item) },
                        )
                        if (index < state.items.lastIndex) MaxDivider()
                    }
                }
            }

            if (state.loadingMore) {
                item(key = "notifications_loading_more") {
                    MaxInlineBanner(
                        message = "جارٍ تحميل المزيد من الإشعارات…",
                        modifier = Modifier.testTag("notifications_loading_more"),
                    )
                }
            } else if (state.canLoadMore) {
                item(key = "notifications_load_more") {
                    MaxSecondaryButton(
                        text = "تحميل المزيد",
                        onClick = onLoadMore,
                        testTag = "notifications_load_more",
                    )
                }
            }
        }
    }
}

@Composable
private fun NotificationRow(
    item: NotificationItem,
    routing: Boolean,
    onClick: () -> Unit,
) {
    val unread = !item.isRead
    MaxListRow(
        title = item.title,
        supportingText = item.body,
        leadingIcon = item.kind.icon(),
        enabled = !routing,
        selected = unread,
        modifier = Modifier
            .semantics {
                stateDescription = if (unread) "غير مقروء" else "مقروء"
            }
            .testTag("notification_${item.id.value}"),
        trailingContent = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(MaxSpacing.xxs),
            ) {
                MaxText(
                    text = NOTIFICATION_TIME.format(item.occurredAt),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.testTag("notification_time_${item.id.value}"),
                )
                if (unread) {
                    MaxBadge(
                        text = "غير مقروء",
                        selected = true,
                        modifier = Modifier.testTag("notification_unread_${item.id.value}"),
                    )
                }
                if (routing) {
                    MaxBadge(
                        text = "جارٍ الفتح…",
                        modifier = Modifier
                            .semantics { liveRegion = LiveRegionMode.Polite }
                            .testTag("notification_opening_${item.id.value}"),
                    )
                }
            }
        },
        onClick = onClick,
    )
}

private fun NotificationKind.icon(): ImageVector = when (this) {
    NotificationKind.RequestNeedsReply,
    NotificationKind.OutgoingRequestUpdated,
    -> MaxIcons.Conversations

    NotificationKind.PartAvailable,
    NotificationKind.PartUnavailable,
    -> MaxIcons.Notifications

    NotificationKind.BalanceMovement,
    NotificationKind.BalanceUpdated,
    -> MaxIcons.Home
}

private val NOTIFICATION_TIME: DateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy • HH:mm")
    .withZone(ZoneId.systemDefault())
