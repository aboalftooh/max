package com.maxnetwork.feature.notifications.data

import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.PushInstallationRegistration
import com.maxnetwork.core.network.PushProvider
import com.maxnetwork.feature.notifications.domain.PushInstallationId
import com.maxnetwork.feature.notifications.domain.PushRegistration
import com.maxnetwork.feature.notifications.domain.PushRegistrationFailure
import com.maxnetwork.feature.notifications.domain.PushRegistrationRepository
import com.maxnetwork.feature.notifications.domain.PushRegistrationResult

class NetworkPushRegistrationRepository(
    private val gateway: MaxGateway,
) : PushRegistrationRepository {
    override suspend fun register(
        accessToken: String,
        registration: PushRegistration,
    ): PushRegistrationResult = gateway.registerPushInstallation(
        accessToken = accessToken,
        installationId = registration.installationId.value,
        registration = PushInstallationRegistration(
            provider = PushProvider.Fcm,
            token = registration.token.value,
            appVersion = registration.appVersion,
        ),
    ).toPushResult()

    override suspend fun unregister(
        accessToken: String,
        installationId: PushInstallationId,
    ): PushRegistrationResult = gateway.unregisterPushInstallation(accessToken, installationId.value).toPushResult()
}

private fun GatewayResult<Unit>.toPushResult(): PushRegistrationResult = when (this) {
    is GatewayResult.Success -> PushRegistrationResult.Success
    is GatewayResult.Failure -> PushRegistrationResult.Failure(
        when (error.code) {
            ApiErrorCode.Unauthorized -> PushRegistrationFailure.Unauthorized
            ApiErrorCode.ServiceUnavailable -> if (error.traceId == "network-unavailable") {
                PushRegistrationFailure.Offline
            } else {
                PushRegistrationFailure.Unavailable(error.retryable)
            }
            else -> PushRegistrationFailure.Unavailable(error.retryable)
        },
    )
}
