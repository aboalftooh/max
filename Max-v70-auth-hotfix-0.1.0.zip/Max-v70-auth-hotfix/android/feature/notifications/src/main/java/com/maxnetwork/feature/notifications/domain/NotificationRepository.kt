package com.maxnetwork.feature.notifications.domain

import com.maxnetwork.core.model.NotificationId

interface NotificationRepository {
    suspend fun getNotifications(query: NotificationQuery): NotificationResult<NotificationPage>
    suspend fun markRead(notificationId: NotificationId): NotificationResult<Unit>
}
