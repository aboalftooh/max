package com.maxnetwork.feature.notifications.data

import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.PushInstallationRegistration
import com.maxnetwork.core.testing.FakeMaxGateway
import com.maxnetwork.feature.notifications.domain.NotificationKind
import com.maxnetwork.feature.notifications.domain.PushInstallationId
import com.maxnetwork.feature.notifications.domain.PushMessageParser
import com.maxnetwork.feature.notifications.domain.PushNavigationTarget
import com.maxnetwork.feature.notifications.domain.PushRegistration
import com.maxnetwork.feature.notifications.domain.PushRegistrationResult
import com.maxnetwork.feature.notifications.domain.PushToken
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private var checks = 0
private fun verify(value: Boolean, message: String) {
    check(value) { message }
    checks += 1
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var value: Result<T>? = null
    block.startCoroutine(
        object : Continuation<T> {
            override val context = EmptyCoroutineContext
            override fun resumeWith(result: Result<T>) { value = result }
        },
    )
    return requireNotNull(value).getOrThrow()
}

private class CapturingGateway : MaxGateway by FakeMaxGateway() {
    var registeredToken: String? = null
    var registeredInstallation: String? = null
    var authorization: String? = null
    var unregisteredInstallation: String? = null

    override suspend fun registerPushInstallation(
        accessToken: String,
        installationId: String,
        registration: PushInstallationRegistration,
    ): GatewayResult<Unit> {
        authorization = accessToken
        registeredInstallation = installationId
        registeredToken = registration.token
        return GatewayResult.Success(Unit)
    }

    override suspend fun unregisterPushInstallation(
        accessToken: String,
        installationId: String,
    ): GatewayResult<Unit> {
        authorization = accessToken
        unregisteredInstallation = installationId
        return GatewayResult.Success(Unit)
    }
}

fun main() {
    val incoming = PushMessageParser.parse(
        mapOf(
            "schema" to "1",
            "notificationId" to "notification-1",
            "type" to "REQUEST_NEEDS_REPLY",
            "target" to "INCOMING_ORDERS",
            "title" to "طلب يحتاج ردك",
            "body" to "افتح الطلب الوارد للاطلاع والرد.",
        ),
    )
    verify(incoming != null, "valid incoming payload parsed")
    verify(incoming?.kind == NotificationKind.RequestNeedsReply, "incoming type mapped")
    verify(incoming?.target == PushNavigationTarget.IncomingOrders, "incoming target mapped")

    val outgoingTypes = listOf("OUTGOING_REQUEST_UPDATED", "PART_AVAILABLE", "PART_UNAVAILABLE")
    outgoingTypes.forEach { type ->
        val parsed = PushMessageParser.parse(
            mapOf(
                "schema" to "1",
                "notificationId" to "notification-$type",
                "type" to type,
                "target" to "OUTGOING_ORDERS",
                "title" to "تحديث طلب",
                "body" to "افتح الطلب الصادر للاطلاع على التحديث.",
            ),
        )
        verify(parsed?.target == PushNavigationTarget.OutgoingOrders, "$type maps outgoing")
    }

    val balanceTypes = listOf("BALANCE_MOVEMENT", "BALANCE_UPDATED")
    balanceTypes.forEach { type ->
        val parsed = PushMessageParser.parse(
            mapOf(
                "schema" to "1",
                "notificationId" to "notification-$type",
                "type" to type,
                "target" to "BALANCE",
                "title" to "تحديث الرصيد",
                "body" to "افتح شاشة الرصيد للاطلاع على آخر تحديث.",
            ),
        )
        verify(parsed?.target == PushNavigationTarget.Balance, "$type maps balance")
    }

    verify(PushMessageParser.parse(emptyMap()) == null, "missing schema rejected")
    verify(PushMessageParser.parse(mapOf("schema" to "2")) == null, "unknown schema rejected")
    verify(
        PushMessageParser.parse(
            mapOf(
                "schema" to "1",
                "notificationId" to "notification-2",
                "type" to "BALANCE_UPDATED",
                "target" to "OUTGOING_ORDERS",
                "title" to "عنوان",
                "body" to "نص",
            ),
        ) == null,
        "type target mismatch rejected",
    )
    verify(
        PushMessageParser.parse(
            mapOf(
                "schema" to "1",
                "notificationId" to "notification-3",
                "type" to "BALANCE_UPDATED",
                "target" to "https://evil.invalid",
                "title" to "عنوان",
                "body" to "نص",
            ),
        ) == null,
        "arbitrary URL target rejected",
    )
    verify(
        PushMessageParser.parse(
            mapOf(
                "schema" to "1",
                "notificationId" to "notification-4",
                "type" to "BALANCE_UPDATED",
                "target" to "BALANCE",
                "title" to "x".repeat(81),
                "body" to "نص",
            ),
        ) == null,
        "oversized title rejected",
    )
    verify(
        PushMessageParser.parse(
            mapOf(
                "schema" to "1",
                "notificationId" to "notification-5",
                "type" to "BALANCE_UPDATED",
                "target" to "BALANCE",
                "title" to "عنوان",
                "body" to "bad\u0000body",
            ),
        ) == null,
        "control characters rejected",
    )

    val gateway = CapturingGateway()
    val repository = NetworkPushRegistrationRepository(gateway)
    val installation = PushInstallationId("installation-android-0001")
    val token = PushToken("fcm-token-${"z".repeat(40)}")
    val registration = PushRegistration(installation, token, "0.1.0")
    val registered = runSuspend { repository.register("access-token", registration) }
    verify(registered == PushRegistrationResult.Success, "network registration succeeds")
    verify(gateway.authorization == "access-token", "access token forwarded explicitly")
    verify(gateway.registeredInstallation == installation.value, "installation forwarded")
    verify(gateway.registeredToken == token.value, "provider token forwarded")

    val unregistered = runSuspend { repository.unregister("access-token", installation) }
    verify(unregistered == PushRegistrationResult.Success, "network unregister succeeds")
    verify(gateway.unregisteredInstallation == installation.value, "unregister installation forwarded")

    verify(runCatching { PushInstallationId("short") }.isFailure, "short installation rejected")
    verify(runCatching { PushToken("tiny") }.isFailure, "short token rejected")
    verify(runCatching { PushRegistration(installation, token, "") }.isFailure, "blank app version rejected")

    println("PushRegistrationTest: $checks/$checks checks passed")
}
