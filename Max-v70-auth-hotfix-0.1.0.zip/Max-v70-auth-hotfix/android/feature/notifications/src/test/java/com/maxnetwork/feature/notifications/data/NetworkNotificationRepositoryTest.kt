package com.maxnetwork.feature.notifications.data

import com.maxnetwork.core.model.NotificationId
import com.maxnetwork.core.network.ApiError
import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.CursorPage
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.MaxNotification
import com.maxnetwork.core.network.NotificationType
import com.maxnetwork.core.testing.FakeFixtures
import com.maxnetwork.core.testing.FakeMaxGateway
import com.maxnetwork.feature.notifications.domain.NotificationFailure
import com.maxnetwork.feature.notifications.domain.NotificationKind
import com.maxnetwork.feature.notifications.domain.NotificationQuery
import com.maxnetwork.feature.notifications.domain.NotificationResult
import java.time.Instant
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private var checks = 0
private fun verify(value: Boolean, message: String) {
    check(value) { message }
    checks += 1
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var value: Result<T>? = null
    block.startCoroutine(
        object : Continuation<T> {
            override val context = EmptyCoroutineContext
            override fun resumeWith(result: Result<T>) {
                value = result
            }
        },
    )
    return requireNotNull(value).getOrThrow()
}

private class NotificationFailureGateway(
    private val failure: GatewayResult.Failure,
) : MaxGateway by FakeMaxGateway() {
    override suspend fun getNotifications(cursor: String?, limit: Int): GatewayResult<CursorPage<MaxNotification>> = failure
    override suspend fun markNotificationRead(notificationId: String): GatewayResult<Unit> = failure
}

fun main() {
    val now = Instant.parse("2026-07-29T09:00:00Z")
    val networkItems = NotificationType.entries.mapIndexed { index, type ->
        MaxNotification(
            id = "notification-${index + 1}",
            type = type,
            title = "عنوان ${index + 1}",
            body = "نص الإشعار ${index + 1}",
            occurredAt = now.minusSeconds(index.toLong() * 60),
            readAt = null,
        )
    }
    val fixtures = FakeFixtures.default().copy(notifications = networkItems)
    val gateway = FakeMaxGateway(fixtures = fixtures, now = { now.plusSeconds(60) })
    val repository = NetworkNotificationRepository(gateway)

    val result = runSuspend { repository.getNotifications(NotificationQuery(limit = 20)) }
    verify(result is NotificationResult.Success, "notifications load")
    val page = (result as NotificationResult.Success).value
    verify(page.items.size == 6, "all notification types loaded")
    verify(page.nextCursor == null, "single page has no cursor")
    verify(
        page.items.map { it.kind } == listOf(
            NotificationKind.RequestNeedsReply,
            NotificationKind.OutgoingRequestUpdated,
            NotificationKind.PartAvailable,
            NotificationKind.PartUnavailable,
            NotificationKind.BalanceMovement,
            NotificationKind.BalanceUpdated,
        ),
        "network types map exhaustively",
    )
    verify(page.items.none { it.isRead }, "unread state preserved")
    verify(page.items.all { it.id.value.isNotBlank() && it.title.isNotBlank() && it.body.isNotBlank() }, "content preserved")

    val firstId = page.items.first().id
    val marked = runSuspend { repository.markRead(firstId) }
    verify(marked is NotificationResult.Success, "mark read succeeds")
    val refreshed = runSuspend { repository.getNotifications(NotificationQuery()) } as NotificationResult.Success
    verify(refreshed.value.items.first { it.id == firstId }.isRead, "read state returned by gateway")
    verify(
        refreshed.value.items.first { it.id == NotificationId("notification-2") }.readAt == null,
        "other notifications remain unread",
    )

    val unauthorized = NetworkNotificationRepository(
        NotificationFailureGateway(
            GatewayResult.Failure(ApiError(ApiErrorCode.Unauthorized, "unauthorized", "trace", false)),
        ),
    )
    val unauthorizedResult = runSuspend { unauthorized.getNotifications(NotificationQuery()) }
    verify(
        unauthorizedResult is NotificationResult.Failure && unauthorizedResult.reason == NotificationFailure.Unauthorized,
        "unauthorized mapping",
    )

    val offline = NetworkNotificationRepository(
        NotificationFailureGateway(
            GatewayResult.Failure(
                ApiError(ApiErrorCode.ServiceUnavailable, "offline", "network-unavailable", true),
            ),
        ),
    )
    val offlineResult = runSuspend { offline.getNotifications(NotificationQuery()) }
    verify(offlineResult is NotificationResult.Failure && offlineResult.reason == NotificationFailure.Offline, "offline mapping")

    val missing = NetworkNotificationRepository(
        NotificationFailureGateway(
            GatewayResult.Failure(ApiError(ApiErrorCode.NotFound, "missing", "trace", false)),
        ),
    )
    val missingResult = runSuspend { missing.markRead(NotificationId("missing")) }
    verify(missingResult is NotificationResult.Failure && missingResult.reason == NotificationFailure.NotFound, "not-found mapping")

    verify(runCatching { NotificationQuery(limit = 0) }.isFailure, "zero limit rejected")
    verify(runCatching { NotificationQuery(limit = 51) }.isFailure, "oversized limit rejected")
    verify(runCatching { NotificationId("") }.isSuccess, "core identifier stays transport-only")

    println("NetworkNotificationRepositoryTest: $checks/$checks checks passed")
}
