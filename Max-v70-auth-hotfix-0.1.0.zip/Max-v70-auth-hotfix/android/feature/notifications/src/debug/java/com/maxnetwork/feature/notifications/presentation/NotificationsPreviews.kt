package com.maxnetwork.feature.notifications.presentation

import androidx.compose.runtime.Composable
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.core.model.NotificationId
import com.maxnetwork.feature.notifications.domain.NotificationCursor
import com.maxnetwork.feature.notifications.domain.NotificationItem
import com.maxnetwork.feature.notifications.domain.NotificationKind
import com.maxnetwork.feature.notifications.domain.NotificationTarget
import java.time.Instant

@MaxComponentPreviews
@Composable
private fun NotificationsScreenPreview() {
    MaxTheme(motionEnabled = false) {
        NotificationsScreen(
            state = NotificationsUiState(
                items = listOf(
                    previewNotification(
                        id = "notification-1",
                        kind = NotificationKind.RequestNeedsReply,
                        title = "طلبك يحتاج ردًا",
                        body = "لديك تحديث جديد من المحل.",
                    ),
                    previewNotification(
                        id = "notification-2",
                        kind = NotificationKind.BalanceUpdated,
                        title = "تم تحديث الرصيد",
                        body = "أضيفت حركة جديدة إلى رصيدك.",
                        read = true,
                    ),
                ),
                nextCursor = NotificationCursor("next-page"),
            ),
            onNotificationClick = {},
            onRetry = {},
            onLoadMore = {},
            onBack = {},
        )
    }
}

@MaxComponentPreviews
@Composable
private fun NotificationsEmptyPreview() {
    MaxTheme(motionEnabled = false) {
        NotificationsScreen(
            state = NotificationsUiState(),
            onNotificationClick = {},
            onRetry = {},
            onLoadMore = {},
            onBack = {},
        )
    }
}

private fun previewNotification(
    id: String,
    kind: NotificationKind,
    title: String,
    body: String,
    read: Boolean = false,
): NotificationItem = NotificationItem(
    id = NotificationId(id),
    kind = kind,
    title = title,
    body = body,
    occurredAt = Instant.parse("2026-08-16T06:00:00Z"),
    readAt = if (read) Instant.parse("2026-08-16T06:05:00Z") else null,
    target = NotificationTarget.Home,
)
