package com.maxnetwork.feature.notifications.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.assertDoesNotExist
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.core.model.NotificationId
import com.maxnetwork.feature.notifications.domain.NotificationCursor
import com.maxnetwork.feature.notifications.domain.NotificationItem
import com.maxnetwork.feature.notifications.domain.NotificationKind
import com.maxnetwork.feature.notifications.domain.NotificationTarget
import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

class NotificationsScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun populatedListUsesDesignSystemHierarchyAndUnreadSemantics() {
        setNotificationsContent(NotificationsUiState(items = listOf(UNREAD, READ)))

        composeRule.onNodeWithTag("notifications_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("max_top_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("notifications_list").assertIsDisplayed()
        composeRule.onNodeWithTag("notification_${UNREAD.id.value}")
            .assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, "غير مقروء"))
        composeRule.onNodeWithTag("notification_unread_${UNREAD.id.value}").assertIsDisplayed()
        composeRule.onNodeWithTag("notification_time_${UNREAD.id.value}").assertIsDisplayed()
        composeRule.onNodeWithTag("notification_${READ.id.value}")
            .assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, "مقروء"))
        composeRule.onNodeWithTag("notification_unread_${READ.id.value}").assertDoesNotExist()
    }

    @Test
    fun blockingLoadingUsesDesignSystemState() {
        setNotificationsContent(NotificationsUiState(initialLoading = true))

        composeRule.onNodeWithTag("notifications_loading").assertIsDisplayed()
        composeRule.onNodeWithTag("max_state_Loading").assertIsDisplayed()
    }

    @Test
    fun inlineErrorKeepsExistingNotificationsVisible() {
        setNotificationsContent(
            NotificationsUiState(
                items = listOf(UNREAD),
                errorMessage = "تعذر التحديث",
            ),
        )

        composeRule.onNodeWithTag("notifications_inline_error").assertIsDisplayed()
        composeRule.onNodeWithTag("notification_${UNREAD.id.value}").assertIsDisplayed()
    }

    @Test
    fun loadingMoreUsesDesignSystemFeedback() {
        setNotificationsContent(
            NotificationsUiState(
                items = listOf(UNREAD),
                nextCursor = NotificationCursor("next"),
                loadingMore = true,
            ),
        )

        composeRule.onNodeWithTag("notifications_loading_more").assertIsDisplayed()
    }

    @Test
    fun loadMoreUsesSharedActionAndPreservesCallback() {
        var loadMoreCalls = 0
        setNotificationsContent(
            state = NotificationsUiState(
                items = listOf(UNREAD),
                nextCursor = NotificationCursor("next"),
            ),
            onLoadMore = { loadMoreCalls += 1 },
        )

        composeRule.onNodeWithTag("notifications_load_more").performClick()
        composeRule.runOnIdle { assertEquals(1, loadMoreCalls) }
    }

    @Test
    fun routingStateIsCompactAndVisible() {
        setNotificationsContent(
            NotificationsUiState(
                items = listOf(UNREAD),
                routingNotificationId = UNREAD.id.value,
            ),
        )

        composeRule.onNodeWithTag("notification_opening_${UNREAD.id.value}").assertIsDisplayed()
    }

    @Test
    fun rtlAndLargeTextKeepNotificationContentReachable() {
        setNotificationsContent(
            state = NotificationsUiState(items = listOf(UNREAD)),
            fontScale = 2f,
            layoutDirection = LayoutDirection.Rtl,
        )

        composeRule.onNodeWithTag("max_top_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("notification_${UNREAD.id.value}").assertIsDisplayed()
        composeRule.onNodeWithTag("notification_time_${UNREAD.id.value}").assertIsDisplayed()
    }

    private fun setNotificationsContent(
        state: NotificationsUiState,
        onLoadMore: () -> Unit = {},
        fontScale: Float = 1f,
        layoutDirection: LayoutDirection = LayoutDirection.Rtl,
    ) {
        composeRule.setContent {
            NotificationTestTheme(fontScale, layoutDirection) {
                NotificationsScreen(
                    state = state,
                    onNotificationClick = {},
                    onRetry = {},
                    onLoadMore = onLoadMore,
                    onBack = {},
                )
            }
        }
    }

    private companion object {
        val UNREAD = notification(
            id = "notification-unread",
            kind = NotificationKind.RequestNeedsReply,
            readAt = null,
        )
        val READ = notification(
            id = "notification-read",
            kind = NotificationKind.BalanceUpdated,
            readAt = Instant.parse("2026-08-16T06:05:00Z"),
        )

        fun notification(
            id: String,
            kind: NotificationKind,
            readAt: Instant?,
        ): NotificationItem = NotificationItem(
            id = NotificationId(id),
            kind = kind,
            title = "تحديث جديد",
            body = "هناك تحديث مرتبط بحسابك.",
            occurredAt = Instant.parse("2026-08-16T06:00:00Z"),
            readAt = readAt,
            target = NotificationTarget.Home,
        )
    }
}

@Composable
private fun NotificationTestTheme(
    fontScale: Float,
    layoutDirection: LayoutDirection,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    MaxTheme(motionEnabled = false) {
        CompositionLocalProvider(
            LocalDensity provides Density(density = density.density, fontScale = fontScale),
            LocalLayoutDirection provides layoutDirection,
            content = content,
        )
    }
}
