package com.maxnetwork.feature.home.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertDoesNotExist
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.Density
import com.maxnetwork.core.designsystem.theme.MaxTheme
import org.junit.Rule
import org.junit.Test

class HomeScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun normalStateUsesReferenceHierarchyAndShellOwnsPrimaryAction() {
        setHomeContent(
            state = HomeUiState(
                storeName = StoreDisplayName("متجر الاختبار"),
                balanceAmount = "125,000 ج.س",
                balanceStatus = "دائن",
                balanceTone = HomeFinancialTone.Positive,
                movements = listOf(
                    HomeMovementUi(
                        id = "1",
                        label = "شلنا",
                        amount = "125,000 ج.س",
                        date = "16/08/2026",
                        time = "10:45",
                        tone = HomeFinancialTone.Positive,
                    ),
                    HomeMovementUi(
                        id = "2",
                        label = "شال",
                        amount = "25,000 ج.س",
                        date = "15/08/2026",
                        time = "17:20",
                        tone = HomeFinancialTone.Negative,
                    ),
                ),
                unreadNotifications = 4,
            ),
        )

        composeRule.onNodeWithTag("home_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("home_store_name").assertIsDisplayed()
        composeRule.onNodeWithTag("home_balance_card").assertIsDisplayed()
        composeRule.onNodeWithTag("home_movements_title").assertIsDisplayed()
        composeRule.onNodeWithTag("home_movements_list").assertIsDisplayed()
        composeRule.onNodeWithTag("home_notifications_badge").assertIsDisplayed()
        composeRule.onNodeWithTag("home_request_fab").assertDoesNotExist()
    }

    @Test
    fun loadingStateUsesDesignSystemFeedback() {
        setHomeContent(state = HomeUiState(balanceLoading = true))

        composeRule.onNodeWithTag("home_balance_loading").assertIsDisplayed()
        composeRule.onNodeWithTag("max_state_Loading").assertIsDisplayed()
        composeRule.onNodeWithTag("home_balance_card").assertDoesNotExist()
    }

    @Test
    fun errorStateUsesDesignSystemFeedback() {
        setHomeContent(state = HomeUiState(balanceErrorMessage = "تعذر التحميل"))

        composeRule.onNodeWithTag("home_balance_error").assertIsDisplayed()
        composeRule.onNodeWithTag("max_state_Error").assertIsDisplayed()
        composeRule.onNodeWithTag("home_balance_card").assertDoesNotExist()
    }

    @Test
    fun emptyMovementsUseDesignSystemFeedback() {
        setHomeContent(
            state = HomeUiState(
                balanceAmount = "0 ج.س",
                balanceStatus = "متوازن",
            ),
        )

        composeRule.onNodeWithTag("home_balance_card").assertIsDisplayed()
        composeRule.onNodeWithTag("home_movements_empty").assertIsDisplayed()
        composeRule.onNodeWithTag("max_state_Empty").assertIsDisplayed()
    }

    @Test
    fun largeTextKeepsPrimaryHomeContentReachable() {
        setHomeContent(
            state = HomeUiState(
                storeName = StoreDisplayName("متجر بخط كبير"),
                balanceAmount = "1,250,000 ج.س",
                balanceStatus = "دائن",
                movements = listOf(
                    HomeMovementUi(
                        id = "large-text",
                        label = "شلنا",
                        amount = "125,000 ج.س",
                        date = "16/08/2026",
                        time = "10:45",
                        tone = HomeFinancialTone.Positive,
                    ),
                ),
            ),
            fontScale = 2f,
        )

        composeRule.onNodeWithTag("home_compact_header").assertIsDisplayed()
        composeRule.onNodeWithTag("home_balance_amount").assertIsDisplayed()
        composeRule.onNodeWithTag("home_movements_title").assertIsDisplayed()
    }

    private fun setHomeContent(
        state: HomeUiState,
        fontScale: Float = 1f,
    ) {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                WithFontScale(fontScale) {
                    HomeScreen(
                        state = state,
                        actions = HomeActions(onRequestPart = {}, onNotifications = {}),
                    )
                }
            }
        }
    }
}

@Composable
private fun WithFontScale(
    fontScale: Float,
    content: @Composable () -> Unit,
) {
    val currentDensity = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(
            density = currentDensity.density,
            fontScale = fontScale,
        ),
        content = content,
    )
}
