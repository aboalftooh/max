package com.maxnetwork.feature.home.presentation

/** Placeholder boundary. Presentation must not access DAO or network clients directly. */
internal object HomePresentationBoundary
