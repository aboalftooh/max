package com.maxnetwork.feature.home.domain

/** Public feature capability; navigation and wiring remain in :app. */
object HomeFeature {
    const val ROUTE = "home"
}
