package com.maxnetwork.feature.home.data

/** Placeholder boundary. Data implementations will implement domain-owned contracts. */
internal object HomeDataBoundary
