package com.maxnetwork.feature.home.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxEmptyState
import com.maxnetwork.core.designsystem.component.MaxErrorState
import com.maxnetwork.core.designsystem.component.MaxHeroContainer
import com.maxnetwork.core.designsystem.component.MaxIconButton
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxLoadingState
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxSectionHeader
import com.maxnetwork.core.designsystem.component.MaxStatusPill
import com.maxnetwork.core.designsystem.component.MaxStatusTone
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.theme.MaxScreenInsets
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTypeRoles

@JvmInline
value class StoreDisplayName(val value: String)

enum class HomeFinancialTone {
    Positive,
    Negative,
    Neutral,
}

data class HomeMovementUi(
    val id: String,
    val label: String,
    val amount: String,
    val date: String,
    val time: String,
    val tone: HomeFinancialTone,
)

data class HomeUiState(
    val storeName: StoreDisplayName? = null,
    val balanceAmount: String? = null,
    val balanceStatus: String = "متوازن",
    val balanceTone: HomeFinancialTone = HomeFinancialTone.Neutral,
    val movements: List<HomeMovementUi> = emptyList(),
    val unreadNotifications: Int = 0,
    val balanceLoading: Boolean = false,
    val balanceErrorMessage: String? = null,
)

data class HomeActions(
    val onRequestPart: () -> Unit,
    val onNotifications: () -> Unit,
)

@Composable
fun HomeScreen(
    state: HomeUiState,
    actions: HomeActions,
    modifier: Modifier = Modifier,
) {
    MaxScaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen"),
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .padding(
                    horizontal = MaxScreenInsets.compactHorizontal,
                    vertical = MaxSpacing.lg,
                ),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.sectionGap),
        ) {
            HomeHeader(
                storeName = state.storeName,
                unreadNotifications = state.unreadNotifications,
                onNotifications = actions.onNotifications,
            )

            when {
                state.balanceLoading && state.balanceAmount == null -> {
                    HomeFeedbackArea(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_balance_loading"),
                    ) {
                        MaxLoadingState(
                            title = "جارٍ تحميل الرصيد",
                            message = "سيظهر الرصيد والسجل فور اكتمال التحميل",
                        )
                    }
                }

                state.balanceErrorMessage != null && state.balanceAmount == null -> {
                    HomeFeedbackArea(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_balance_error"),
                    ) {
                        MaxErrorState(
                            title = "تعذر تحميل الرصيد",
                            message = state.balanceErrorMessage,
                        )
                    }
                }

                else -> {
                    HomeBalanceCard(state)
                    MaxSectionHeader(
                        title = "السجل",
                        modifier = Modifier.testTag("home_movements_title"),
                    )
                    HomeMovementHistory(
                        movements = state.movements,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeHeader(
    storeName: StoreDisplayName?,
    unreadNotifications: Int,
    onNotifications: () -> Unit,
) {
    val contextName = storeName?.value?.takeIf { it.isNotBlank() }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("home_compact_header"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(MaxSpacing.md),
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.xxs),
        ) {
            if (contextName == null) {
                MaxText(
                    text = "max",
                    style = MaterialTheme.typography.titleLarge,
                )
            } else {
                MaxText(
                    text = contextName,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.testTag("home_store_name"),
                )
            }
            MaxText(
                text = if (contextName == null) "الرئيسية" else "max",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.testTag("home_header_subtitle"),
            )
        }

        MaxIconButton(
            icon = MaxIcons.Notifications,
            contentDescription = if (unreadNotifications > 0) {
                "الإشعارات، $unreadNotifications غير مقروءة"
            } else {
                "الإشعارات"
            },
            onClick = onNotifications,
            badgeCount = unreadNotifications,
            testTag = "home_notifications",
        )
    }
}

@Composable
private fun HomeBalanceCard(state: HomeUiState) {
    val semanticAmount = state.balanceAmount ?: "غير متاح"
    MaxHeroContainer(
        modifier = Modifier
            .semantics {
                contentDescription = "الرصيد $semanticAmount، ${state.balanceStatus}"
            }
            .testTag("home_balance_card"),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
        ) {
            MaxText(
                text = "الرصيد",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
            )
            MaxText(
                text = state.balanceAmount ?: "—",
                style = MaxTypeRoles.displayAmount,
                textAlign = TextAlign.Center,
                maxLines = 2,
                modifier = Modifier.testTag("home_balance_amount"),
            )
            MaxStatusPill(
                text = state.balanceStatus,
                tone = state.balanceTone.toStatusTone(),
                modifier = Modifier.testTag("home_balance_status"),
            )
        }
    }
}

@Composable
private fun HomeMovementHistory(
    movements: List<HomeMovementUi>,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center,
    ) {
        if (movements.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("home_movements_empty"),
                contentAlignment = Alignment.Center,
            ) {
                MaxEmptyState(
                    title = "لا توجد حركات حتى الآن",
                    message = "ستظهر الحركات المالية هنا عند تسجيلها",
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("home_movements_list"),
            ) {
                item(key = "movement_container") {
                    MaxListContainer {
                        movements.forEachIndexed { index, movement ->
                            HomeMovementRow(movement)
                            if (index < movements.lastIndex) {
                                MaxDivider()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeMovementRow(movement: HomeMovementUi) {
    MaxListRow(
        title = movement.label,
        supportingText = "${movement.date} • ${movement.time}",
        modifier = Modifier
            .semantics {
                contentDescription = "${movement.label} ${movement.amount}، ${movement.date} ${movement.time}"
            }
            .testTag("home_movement_${movement.id}"),
        trailingContent = {
            MaxStatusPill(
                text = movement.amount,
                tone = movement.tone.toStatusTone(),
                modifier = Modifier.testTag("home_movement_amount_${movement.id}"),
            )
        },
    )
}

@Composable
private fun HomeFeedbackArea(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

private fun HomeFinancialTone.toStatusTone(): MaxStatusTone = when (this) {
    HomeFinancialTone.Positive -> MaxStatusTone.Success
    HomeFinancialTone.Negative -> MaxStatusTone.Error
    HomeFinancialTone.Neutral -> MaxStatusTone.Neutral
}
