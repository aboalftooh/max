package com.maxnetwork.feature.home.presentation

import androidx.compose.runtime.Composable
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxTheme

private val PreviewMovements = listOf(
    HomeMovementUi(
        id = "preview-1",
        label = "شلنا",
        amount = "125,000 ج.س",
        date = "16/08/2026",
        time = "10:45",
        tone = HomeFinancialTone.Positive,
    ),
    HomeMovementUi(
        id = "preview-2",
        label = "شال",
        amount = "42,500 ج.س",
        date = "15/08/2026",
        time = "17:20",
        tone = HomeFinancialTone.Negative,
    ),
)

@MaxComponentPreviews
@Composable
private fun HomeNormalPreview() {
    MaxTheme {
        HomeScreen(
            state = HomeUiState(
                storeName = StoreDisplayName("المنصوري عون الله"),
                balanceAmount = "82,500 ج.س",
                balanceStatus = "دائن",
                balanceTone = HomeFinancialTone.Positive,
                movements = PreviewMovements,
                unreadNotifications = 3,
            ),
            actions = HomeActions(onRequestPart = {}, onNotifications = {}),
        )
    }
}

@MaxComponentPreviews
@Composable
private fun HomeLoadingPreview() {
    MaxTheme {
        HomeScreen(
            state = HomeUiState(balanceLoading = true),
            actions = HomeActions(onRequestPart = {}, onNotifications = {}),
        )
    }
}

@MaxComponentPreviews
@Composable
private fun HomeErrorPreview() {
    MaxTheme {
        HomeScreen(
            state = HomeUiState(balanceErrorMessage = "تعذر الاتصال بالخدمة"),
            actions = HomeActions(onRequestPart = {}, onNotifications = {}),
        )
    }
}

@MaxComponentPreviews
@Composable
private fun HomeEmptyPreview() {
    MaxTheme {
        HomeScreen(
            state = HomeUiState(
                balanceAmount = "0 ج.س",
                balanceStatus = "متوازن",
            ),
            actions = HomeActions(onRequestPart = {}, onNotifications = {}),
        )
    }
}
