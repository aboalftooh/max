package com.maxnetwork.feature.profile.presentation

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.assertDoesNotExist
import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.feature.profile.domain.MaxSupportContact
import com.maxnetwork.feature.profile.domain.ProfileSnapshot
import com.maxnetwork.feature.profile.domain.UserProfile
import org.junit.Rule
import org.junit.Test

class ProfileScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun showsGroupedProfileValuesAndPasswordAction() {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                ProfileScreen(
                    state = ProfileUiState(snapshot = fixture()),
                    actions = ProfileActions(),
                )
            }
        }

        composeRule.onNodeWithTag("profile_name").assertIsDisplayed()
        composeRule.onNodeWithTag("profile_store_name").assertIsDisplayed()
        composeRule.onNodeWithTag("profile_phone").assertIsDisplayed()
        composeRule.onNodeWithTag("profile_change_password").assertIsDisplayed()
        composeRule.onNodeWithText("المدينة").assertDoesNotExist()
        composeRule.onNodeWithText("حالة الحساب").assertDoesNotExist()
        composeRule.onNodeWithText("إعدادات الإشعارات").assertDoesNotExist()
        composeRule.onNodeWithText("الشروط").assertDoesNotExist()
    }

    @Test
    fun passwordDialogKeepsThreePasswordFieldsAndActions() {
        var dismissed = false
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                ProfileScreen(
                    state = ProfileUiState(
                        snapshot = fixture(),
                        passwordChange = PasswordChangeUiState(
                            visible = true,
                            errorMessage = "راجع البيانات.",
                        ),
                    ),
                    actions = ProfileActions(onDismissPasswordChange = { dismissed = true }),
                )
            }
        }

        composeRule.onNodeWithTag("profile_password_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("current_password").assertIsDisplayed()
        composeRule.onNodeWithTag("new_password").assertIsDisplayed()
        composeRule.onNodeWithTag("confirm_password").assertIsDisplayed()
        composeRule.onNodeWithText("راجع البيانات.").assertIsDisplayed()
        composeRule.onNodeWithTag("max_dialog_dismiss").performClick()
        composeRule.runOnIdle { org.junit.Assert.assertTrue(dismissed) }
    }

    @Test
    fun privacyContainsAllSixTopicsUnderRtlFontScaleTwo() {
        composeRule.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(
                LocalLayoutDirection provides LayoutDirection.Rtl,
                LocalDensity provides Density(density.density, fontScale = 2f),
            ) {
                MaxTheme(motionEnabled = false) {
                    PrivacyScreen(onBack = {})
                }
            }
        }

        repeat(6) { index ->
            composeRule.onNodeWithTag("privacy_item_$index").assertExists()
        }
    }

    private fun fixture() = ProfileSnapshot(
        profile = UserProfile("user", "store", "محمد أحمد", "النجمة", "+249912000000"),
        support = MaxSupportContact("+249912000001", "https://wa.me/249912000001"),
    )
}
