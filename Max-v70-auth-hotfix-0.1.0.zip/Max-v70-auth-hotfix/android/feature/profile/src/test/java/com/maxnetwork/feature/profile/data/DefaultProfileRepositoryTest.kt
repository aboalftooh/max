package com.maxnetwork.feature.profile.data

import com.maxnetwork.core.testing.FakeFixtures
import com.maxnetwork.core.testing.FakeMaxGateway
import com.maxnetwork.feature.profile.domain.ProfileResult
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DefaultProfileRepositoryTest {
    @Test
    fun loadsOnlyCurrentUserAndStoreFields() = runTest {
        val repository = DefaultProfileRepository(FakeMaxGateway(FakeFixtures.default()))

        val result = repository.loadProfile()

        assertTrue(result is ProfileResult.Success)
        val snapshot = (result as ProfileResult.Success).value
        assertEquals("محمد أحمد", snapshot.profile.name)
        assertEquals("النجمة لقطع الغيار", snapshot.profile.storeName)
        assertEquals("+249912000000", snapshot.profile.phone)
    }

    @Test
    fun clearRemovesCachedSnapshotWithoutExposingIt() = runTest {
        val repository = DefaultProfileRepository(FakeMaxGateway(FakeFixtures.default()))
        repository.loadProfile()

        repository.clearLocalProfile()
        val reloaded = repository.loadProfile()

        assertTrue(reloaded is ProfileResult.Success)
    }
    @Test
    fun deletionReturnsTrackableReceiptWithoutEditingFinancialData() = runTest {
        val repository = DefaultProfileRepository(FakeMaxGateway(FakeFixtures.default()))

        val result = repository.requestAccountDeletion()

        assertTrue(result is ProfileResult.Success)
        val receipt = (result as ProfileResult.Success).value
        assertEquals("delete-req-001", receipt.requestId)
    }

}
