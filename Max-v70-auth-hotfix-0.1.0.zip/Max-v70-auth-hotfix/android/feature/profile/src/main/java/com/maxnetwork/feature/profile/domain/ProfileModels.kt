package com.maxnetwork.feature.profile.domain

data class UserProfile(
    val userId: String,
    val storeId: String,
    val name: String,
    val storeName: String,
    val phone: String,
)

data class MaxSupportContact(
    val phone: String,
    val whatsappUrl: String,
) {
    fun preferredChannel(): SupportChannel? = when {
        whatsappUrl.isSafeWhatsappUrl() -> SupportChannel.WhatsApp(whatsappUrl)
        phone.isSafePhone() -> SupportChannel.Phone(phone)
        else -> null
    }
}

sealed interface SupportChannel {
    data class WhatsApp(val httpsUrl: String) : SupportChannel
    data class Phone(val number: String) : SupportChannel
}

data class ProfileSnapshot(
    val profile: UserProfile,
    val support: MaxSupportContact,
)


data class AccountDeletionReceipt(
    val requestId: String,
    val requestedAt: java.time.Instant,
    val scheduledFor: java.time.Instant,
)

sealed interface ProfileResult<out T> {
    data class Success<T>(val value: T) : ProfileResult<T>
    data class Failure(val reason: ProfileFailure) : ProfileResult<Nothing>
}

enum class ProfileFailure {
    Unauthorized,
    Offline,
    Unavailable,
    InvalidData,
}

internal fun String.isSafeWhatsappUrl(): Boolean =
    startsWith("https://wa.me/") || startsWith("https://api.whatsapp.com/")

internal fun String.isSafePhone(): Boolean {
    val normalized = filterNot(Char::isWhitespace)
    return normalized.matches(Regex("^\\+?[0-9]{8,15}$"))
}
