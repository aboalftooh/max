package com.maxnetwork.feature.profile

import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.profile.data.DefaultProfileRepository
import com.maxnetwork.feature.profile.domain.ProfileRepository
import com.maxnetwork.feature.profile.domain.usecase.ClearLocalProfileUseCase
import com.maxnetwork.feature.profile.domain.usecase.LoadProfileUseCase
import com.maxnetwork.feature.profile.domain.usecase.RequestAccountDeletionUseCase

data class ProfileUseCases(
    val load: LoadProfileUseCase,
    val clearLocal: ClearLocalProfileUseCase,
    val requestDeletion: RequestAccountDeletionUseCase,
)

data class ProfileFeatureDependencies(
    val repository: ProfileRepository,
    val useCases: ProfileUseCases,
)

object ProfileFeatureFactory {
    fun create(gateway: MaxGateway): ProfileFeatureDependencies {
        val repository = DefaultProfileRepository(gateway)
        return ProfileFeatureDependencies(
            repository = repository,
            useCases = ProfileUseCases(
                load = LoadProfileUseCase(repository),
                clearLocal = ClearLocalProfileUseCase(repository),
                requestDeletion = RequestAccountDeletionUseCase(repository),
            ),
        )
    }
}
