package com.maxnetwork.feature.profile.data

import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.ChangeProfilePasswordCommand
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.profile.domain.AccountDeletionReceipt
import com.maxnetwork.feature.profile.domain.MaxSupportContact
import com.maxnetwork.feature.profile.domain.ProfileFailure
import com.maxnetwork.feature.profile.domain.ProfileRepository
import com.maxnetwork.feature.profile.domain.ProfileResult
import com.maxnetwork.feature.profile.domain.ProfileSnapshot
import com.maxnetwork.feature.profile.domain.UserProfile
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal class DefaultProfileRepository(
    private val gateway: MaxGateway,
) : ProfileRepository {
    private val mutex = Mutex()
    private var cached: ProfileSnapshot? = null

    override suspend fun loadProfile(): ProfileResult<ProfileSnapshot> = mutex.withLock {
        cached?.let { return ProfileResult.Success(it) }
        val profile = when (val result = gateway.getProfile()) {
            is GatewayResult.Success -> result.value
            is GatewayResult.Failure -> return result.toProfileFailure()
        }
        val support = when (val result = gateway.getSupportContact()) {
            is GatewayResult.Success -> result.value
            is GatewayResult.Failure -> return result.toProfileFailure()
        }
        val snapshot = ProfileSnapshot(
            profile = UserProfile(
                userId = profile.userId,
                storeId = profile.storeId,
                name = profile.name,
                storeName = profile.storeName,
                phone = profile.phone,
            ),
            support = MaxSupportContact(
                phone = support.phone,
                whatsappUrl = support.whatsappUrl,
            ),
        )
        cached = snapshot
        ProfileResult.Success(snapshot)
    }

    override suspend fun requestAccountDeletion(): ProfileResult<AccountDeletionReceipt> =
        when (val result = gateway.requestAccountDeletion()) {
            is GatewayResult.Success -> ProfileResult.Success(
                AccountDeletionReceipt(
                    requestId = result.value.requestId,
                    requestedAt = result.value.requestedAt,
                    scheduledFor = result.value.scheduledFor,
                ),
            )
            is GatewayResult.Failure -> result.toProfileFailure()
        }

    override suspend fun changePassword(
        currentPassword: String,
        newPassword: String,
    ): ProfileResult<Unit> = when (
        val result = gateway.changeProfilePassword(
            ChangeProfilePasswordCommand(
                currentPassword = currentPassword,
                newPassword = newPassword,
            ),
        )
    ) {
        is GatewayResult.Success -> ProfileResult.Success(Unit)
        is GatewayResult.Failure -> result.toProfileFailure()
    }

    override fun clearLocalProfile() {
        cached = null
    }
}

private fun GatewayResult.Failure.toProfileFailure(): ProfileResult.Failure = ProfileResult.Failure(
    reason = when (error.code) {
        ApiErrorCode.Unauthorized, ApiErrorCode.Forbidden -> ProfileFailure.Unauthorized
        ApiErrorCode.ServiceUnavailable -> if (error.retryable) ProfileFailure.Offline else ProfileFailure.Unavailable
        ApiErrorCode.InvalidRequest,
        ApiErrorCode.NotFound,
        ApiErrorCode.Conflict,
        ApiErrorCode.RateLimited,
        ApiErrorCode.AttachmentRejected,
        ApiErrorCode.Unknown -> ProfileFailure.Unavailable
    },
)
