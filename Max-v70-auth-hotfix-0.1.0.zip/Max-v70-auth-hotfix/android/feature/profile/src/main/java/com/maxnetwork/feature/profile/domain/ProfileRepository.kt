package com.maxnetwork.feature.profile.domain

interface ProfileRepository {
    suspend fun loadProfile(): ProfileResult<ProfileSnapshot>
    suspend fun requestAccountDeletion(): ProfileResult<AccountDeletionReceipt>
    suspend fun changePassword(currentPassword: String, newPassword: String): ProfileResult<Unit>
    fun clearLocalProfile()
}
