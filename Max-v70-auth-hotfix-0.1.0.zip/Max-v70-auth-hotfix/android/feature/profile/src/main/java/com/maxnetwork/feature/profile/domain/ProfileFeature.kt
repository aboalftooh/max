package com.maxnetwork.feature.profile.domain

/** Public feature capability; navigation and wiring remain in :app. */
object ProfileFeature {
    const val ROUTE = "profile"
}
