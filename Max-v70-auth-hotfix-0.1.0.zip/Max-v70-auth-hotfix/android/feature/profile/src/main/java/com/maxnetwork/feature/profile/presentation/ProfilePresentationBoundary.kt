package com.maxnetwork.feature.profile.presentation

/** Placeholder boundary. Presentation must not access DAO or network clients directly. */
internal object ProfilePresentationBoundary
