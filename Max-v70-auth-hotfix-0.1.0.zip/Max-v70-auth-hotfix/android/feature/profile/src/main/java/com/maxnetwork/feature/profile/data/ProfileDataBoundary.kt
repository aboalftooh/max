package com.maxnetwork.feature.profile.data

/** Placeholder boundary. Data implementations will implement domain-owned contracts. */
internal object ProfileDataBoundary
