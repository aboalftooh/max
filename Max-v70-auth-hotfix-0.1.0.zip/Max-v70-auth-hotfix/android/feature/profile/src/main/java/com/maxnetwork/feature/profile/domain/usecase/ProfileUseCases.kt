package com.maxnetwork.feature.profile.domain.usecase

import com.maxnetwork.feature.profile.domain.AccountDeletionReceipt
import com.maxnetwork.feature.profile.domain.ProfileRepository
import com.maxnetwork.feature.profile.domain.ProfileResult
import com.maxnetwork.feature.profile.domain.ProfileSnapshot

class LoadProfileUseCase(
    private val repository: ProfileRepository,
) {
    suspend operator fun invoke(): ProfileResult<ProfileSnapshot> = repository.loadProfile()
}

class ClearLocalProfileUseCase(
    private val repository: ProfileRepository,
) {
    operator fun invoke() = repository.clearLocalProfile()
}


class RequestAccountDeletionUseCase(
    private val repository: ProfileRepository,
) {
    suspend operator fun invoke(): ProfileResult<AccountDeletionReceipt> = repository.requestAccountDeletion()
}

class ChangeProfilePasswordUseCase(
    private val repository: ProfileRepository,
) {
    suspend operator fun invoke(currentPassword: String, newPassword: String): ProfileResult<Unit> =
        repository.changePassword(currentPassword, newPassword)
}
