package com.maxnetwork.feature.profile.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.maxnetwork.feature.profile.domain.ProfileFailure
import com.maxnetwork.feature.profile.domain.ProfileResult
import com.maxnetwork.feature.profile.domain.ProfileSnapshot
import com.maxnetwork.feature.profile.domain.SupportChannel
import com.maxnetwork.feature.profile.domain.usecase.ChangeProfilePasswordUseCase
import com.maxnetwork.feature.profile.domain.usecase.ClearLocalProfileUseCase
import com.maxnetwork.feature.profile.domain.usecase.LoadProfileUseCase
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

data class PasswordChangeUiState(
    val visible: Boolean = false,
    val currentPassword: String = "",
    val newPassword: String = "",
    val confirmation: String = "",
    val submitting: Boolean = false,
    val errorMessage: String? = null,
)

data class ProfileUiState(
    val loading: Boolean = false,
    val snapshot: ProfileSnapshot? = null,
    val error: ProfileUiError? = null,
    val passwordChange: PasswordChangeUiState = PasswordChangeUiState(),
    val passwordChanged: Boolean = false,
)

enum class ProfileUiError {
    Offline,
    Unauthorized,
    Unavailable,
}

sealed interface ProfileUiEvent {
    data class OpenSupport(val channel: SupportChannel) : ProfileUiEvent
    data object SupportUnavailable : ProfileUiEvent
}

class ProfileViewModel(
    private val loadProfile: LoadProfileUseCase,
    private val clearLocalProfile: ClearLocalProfileUseCase,
    private val changePassword: ChangeProfilePasswordUseCase? = null,
) : ViewModel() {
    private val mutableState = MutableStateFlow(ProfileUiState())
    val state: StateFlow<ProfileUiState> = mutableState.asStateFlow()

    private val eventChannel = Channel<ProfileUiEvent>(capacity = Channel.BUFFERED)
    val events = eventChannel.receiveAsFlow()

    fun load() {
        if (mutableState.value.loading || mutableState.value.snapshot != null) return
        viewModelScope.launch {
            val previous = mutableState.value
            mutableState.value = previous.copy(loading = true, error = null)
            mutableState.value = when (val result = loadProfile()) {
                is ProfileResult.Success -> previous.copy(loading = false, snapshot = result.value, error = null)
                is ProfileResult.Failure -> previous.copy(loading = false, error = result.reason.toUiError())
            }
        }
    }

    fun retry() {
        mutableState.value = mutableState.value.copy(loading = false, snapshot = null, error = null)
        load()
    }

    fun openSupport() {
        val channel = mutableState.value.snapshot?.support?.preferredChannel()
        eventChannel.trySend(
            if (channel == null) ProfileUiEvent.SupportUnavailable else ProfileUiEvent.OpenSupport(channel),
        )
    }

    fun showPasswordChange() {
        mutableState.value = mutableState.value.copy(
            passwordChange = PasswordChangeUiState(visible = true),
            passwordChanged = false,
        )
    }

    fun dismissPasswordChange() {
        if (mutableState.value.passwordChange.submitting) return
        mutableState.value = mutableState.value.copy(passwordChange = PasswordChangeUiState())
    }

    fun onCurrentPasswordChanged(value: String) = updatePasswordChange { it.copy(currentPassword = value, errorMessage = null) }

    fun onNewPasswordChanged(value: String) = updatePasswordChange { it.copy(newPassword = value, errorMessage = null) }

    fun onPasswordConfirmationChanged(value: String) = updatePasswordChange { it.copy(confirmation = value, errorMessage = null) }

    fun submitPasswordChange() {
        val form = mutableState.value.passwordChange
        if (form.submitting) return
        val validationError = when {
            form.currentPassword.isEmpty() -> "أدخل كلمة المرور الحالية."
            form.currentPassword.length > PASSWORD_MAX_LENGTH -> "كلمة المرور الحالية غير صالحة."
            form.newPassword.length !in PASSWORD_MIN_LENGTH..PASSWORD_MAX_LENGTH ->
                "كلمة المرور الجديدة يجب أن تكون من 6 إلى 128 خانة."
            form.newPassword != form.confirmation -> "تأكيد كلمة المرور غير مطابق."
            else -> null
        }
        if (validationError != null) {
            updatePasswordChange { it.copy(errorMessage = validationError) }
            return
        }

        updatePasswordChange { it.copy(submitting = true, errorMessage = null) }
        viewModelScope.launch {
            val useCase = changePassword
            if (useCase == null) {
                updatePasswordChange { it.copy(submitting = false, errorMessage = "تعذر تغيير كلمة المرور حاليًا.") }
                return@launch
            }
            when (val result = useCase(form.currentPassword, form.newPassword)) {
                is ProfileResult.Success -> {
                    mutableState.value = mutableState.value.copy(
                        passwordChange = PasswordChangeUiState(),
                        passwordChanged = true,
                    )
                }
                is ProfileResult.Failure -> updatePasswordChange {
                    it.copy(submitting = false, errorMessage = result.reason.passwordChangeMessage())
                }
            }
        }
    }

    fun clear() {
        clearLocalProfile()
        mutableState.value = ProfileUiState()
    }

    private fun updatePasswordChange(block: (PasswordChangeUiState) -> PasswordChangeUiState) {
        mutableState.value = mutableState.value.copy(passwordChange = block(mutableState.value.passwordChange))
    }

    private companion object {
        const val PASSWORD_MIN_LENGTH = 6
        const val PASSWORD_MAX_LENGTH = 128
    }
}

private fun ProfileFailure.toUiError(): ProfileUiError = when (this) {
    ProfileFailure.Unauthorized -> ProfileUiError.Unauthorized
    ProfileFailure.Offline -> ProfileUiError.Offline
    ProfileFailure.Unavailable, ProfileFailure.InvalidData -> ProfileUiError.Unavailable
}

private fun ProfileFailure.passwordChangeMessage(): String = when (this) {
    ProfileFailure.Unauthorized -> "كلمة المرور الحالية غير صحيحة أو انتهت الجلسة."
    ProfileFailure.Offline -> "تعذر الاتصال. تحقق من الإنترنت وأعد المحاولة."
    ProfileFailure.Unavailable, ProfileFailure.InvalidData -> "تعذر تغيير كلمة المرور حاليًا."
}
