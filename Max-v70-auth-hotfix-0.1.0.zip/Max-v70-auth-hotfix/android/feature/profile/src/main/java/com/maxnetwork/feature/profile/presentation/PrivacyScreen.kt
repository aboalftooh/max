package com.maxnetwork.feature.profile.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxScreenInsets
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxSpacing

data class PrivacyItem(
    val title: String,
    val body: String,
)

object MaxPrivacyContent {
    val items = listOf(
        PrivacyItem("البيانات التي نجمعها", "نجمع بيانات الحساب والطلبات والحركات اللازمة لتشغيل max ومتابعة الخدمة."),
        PrivacyItem("المخزون", "لا يعرض max مخزون أي محل داخل التطبيق."),
        PrivacyItem("خصوصية التعامل", "لا تظهر أسماء المحلات المنافسة داخل الطلبات."),
        PrivacyItem("مصدر بيانات العمليات", "فيرتو هو مصدر بيانات الفواتير والمدفوعات والحركات المالية الظاهرة في max."),
        PrivacyItem("استخدام البيانات", "نستخدم البيانات للتشغيل والمتابعة وتحسين موثوقية الخدمة فقط."),
        PrivacyItem("الاحتفاظ اللازم", "تُحفظ البيانات اللازمة للتشغيل والتدقيق وفق سياسة الخصوصية المعتمدة."),
    )
}

@Composable
fun PrivacyScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    MaxScaffold(
        modifier = modifier.testTag("privacy_screen"),
        topBar = { MaxTopBar(title = "الخصوصية", onBack = onBack) },
    ) { contentPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = MaxSizes.readableContentMaxWidth)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = MaxScreenInsets.compactHorizontal),
                verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
            ) {
                MaxPrivacyContent.items.forEachIndexed { index, item ->
                    MaxListContainer(modifier = Modifier.testTag("privacy_item_$index")) {
                        Column(
                            modifier = Modifier.padding(MaxSpacing.md),
                            verticalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
                        ) {
                            MaxText(item.title, style = MaterialTheme.typography.titleMedium)
                            MaxText(
                                text = item.body,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}
