package com.maxnetwork.feature.profile.presentation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.maxnetwork.core.designsystem.component.MaxBannerTone
import com.maxnetwork.core.designsystem.component.MaxDialog
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxInlineBanner
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxSectionHeader
import com.maxnetwork.core.designsystem.component.MaxStateKind
import com.maxnetwork.core.designsystem.component.MaxStateScreen
import com.maxnetwork.core.designsystem.component.MaxTextField
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.pattern.MaxSettingsPattern
import com.maxnetwork.feature.profile.domain.ProfileSnapshot

enum class ProfileDeletionStep {
    None,
    First,
    Final,
}

data class ProfileAccountActionState(
    val deletionStep: ProfileDeletionStep = ProfileDeletionStep.None,
    val deleting: Boolean = false,
    val deletionErrorMessage: String? = null,
    val loggingOut: Boolean = false,
)

data class ProfileActions(
    val onBack: () -> Unit = {},
    val onRetry: () -> Unit = {},
    val onChangePassword: () -> Unit = {},
    val onCurrentPasswordChanged: (String) -> Unit = {},
    val onNewPasswordChanged: (String) -> Unit = {},
    val onPasswordConfirmationChanged: (String) -> Unit = {},
    val onSubmitPasswordChange: () -> Unit = {},
    val onDismissPasswordChange: () -> Unit = {},
    val onContactMax: () -> Unit = {},
    val onPrivacy: () -> Unit = {},
    val onLogout: () -> Unit = {},
    val onDeleteAccount: () -> Unit = {},
    val onContinueDeletion: () -> Unit = {},
    val onConfirmDeletion: () -> Unit = {},
    val onCancelDeletion: () -> Unit = {},
)

@Composable
fun ProfileScreen(
    state: ProfileUiState,
    actions: ProfileActions,
    modifier: Modifier = Modifier,
    @Suppress("UNUSED_PARAMETER") accountActionState: ProfileAccountActionState = ProfileAccountActionState(),
) {
    MaxScaffold(
        modifier = modifier.testTag("profile_screen"),
        topBar = { MaxTopBar(title = "الملف الشخصي", onBack = actions.onBack) },
    ) { contentPadding ->
        when {
            state.loading -> MaxStateScreen(
                title = "جارٍ التحميل",
                message = "نجهز بيانات حسابك.",
                kind = MaxStateKind.Loading,
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("profile_loading"),
            )
            state.error != null -> MaxStateScreen(
                title = "تعذر تحميل الحساب",
                message = state.error.message(),
                kind = MaxStateKind.Error,
                actionText = "إعادة المحاولة",
                onAction = actions.onRetry,
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("profile_error"),
            )
            state.snapshot != null -> ProfileContent(
                snapshot = state.snapshot,
                passwordChanged = state.passwordChanged,
                actions = actions,
                contentPadding = contentPadding,
            )
            else -> MaxStateScreen(
                title = "لا توجد بيانات",
                message = "أعد المحاولة لعرض الملف الشخصي.",
                kind = MaxStateKind.Empty,
                actionText = "إعادة المحاولة",
                onAction = actions.onRetry,
                modifier = Modifier.padding(contentPadding),
            )
        }
    }

    if (state.passwordChange.visible) {
        PasswordChangeDialog(state.passwordChange, actions)
    }
}

@Composable
private fun ProfileContent(
    snapshot: ProfileSnapshot,
    passwordChanged: Boolean,
    actions: ProfileActions,
    contentPadding: PaddingValues,
) {
    MaxSettingsPattern(
        modifier = Modifier
            .padding(contentPadding)
            .testTag("profile_content"),
    ) {
        MaxSectionHeader("بيانات الحساب")
        MaxListContainer {
            ProfileValue(label = "الاسم", value = snapshot.profile.name, testTag = "profile_name")
            MaxDivider()
            ProfileValue(label = "اسم المحل", value = snapshot.profile.storeName, testTag = "profile_store_name")
            MaxDivider()
            ProfileValue(label = "رقم الهاتف", value = snapshot.profile.phone, testTag = "profile_phone")
        }

        MaxSectionHeader("الأمان")
        MaxListContainer {
            MaxListRow(
                title = "تغيير كلمة المرور",
                supportingText = "6–128 خانة، دون شروط تركيب إضافية",
                modifier = Modifier.testTag("profile_change_password"),
                onClick = actions.onChangePassword,
            )
        }

        if (passwordChanged) {
            MaxInlineBanner(
                message = "تم تغيير كلمة المرور وإلغاء الجلسات الأخرى.",
                tone = MaxBannerTone.Success,
                modifier = Modifier.testTag("profile_password_changed"),
            )
        }
    }
}

@Composable
private fun PasswordChangeDialog(
    state: PasswordChangeUiState,
    actions: ProfileActions,
) {
    MaxDialog(
        title = "تغيير كلمة المرور",
        onDismissRequest = actions.onDismissPasswordChange,
        confirmText = "حفظ",
        onConfirm = actions.onSubmitPasswordChange,
        dismissText = "إلغاء",
        onDismiss = actions.onDismissPasswordChange,
        loading = state.submitting,
        errorMessage = state.errorMessage,
        modifier = Modifier.testTag("profile_password_dialog"),
    ) {
        PasswordField(
            label = "كلمة المرور الحالية",
            value = state.currentPassword,
            onValueChange = actions.onCurrentPasswordChanged,
            testTag = "current_password",
        )
        PasswordField(
            label = "كلمة المرور الجديدة",
            value = state.newPassword,
            onValueChange = actions.onNewPasswordChanged,
            testTag = "new_password",
        )
        PasswordField(
            label = "تأكيد كلمة المرور",
            value = state.confirmation,
            onValueChange = actions.onPasswordConfirmationChanged,
            testTag = "confirm_password",
        )
    }
}

@Composable
private fun PasswordField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    testTag: String,
) {
    MaxTextField(
        value = value,
        onValueChange = onValueChange,
        label = label,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        testTag = testTag,
    )
}

@Composable
private fun ProfileValue(
    label: String,
    value: String,
    testTag: String,
) {
    MaxListRow(
        title = value,
        supportingText = label,
        modifier = Modifier.testTag(testTag),
    )
}

private fun ProfileUiError.message(): String = when (this) {
    ProfileUiError.Offline -> "تحقق من اتصال الإنترنت ثم أعد المحاولة."
    ProfileUiError.Unauthorized -> "انتهت الجلسة. سجّل الدخول مرة أخرى."
    ProfileUiError.Unavailable -> "الخدمة غير متاحة حاليًا."
}
