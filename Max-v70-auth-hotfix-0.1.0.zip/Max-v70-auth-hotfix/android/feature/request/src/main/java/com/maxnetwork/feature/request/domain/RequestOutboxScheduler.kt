package com.maxnetwork.feature.request.domain

interface RequestOutboxScheduler {
    fun schedule()
}
