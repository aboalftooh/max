package com.maxnetwork.feature.request.data.outbox

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.maxnetwork.feature.request.domain.RequestOutboxScheduler

internal object RequestOutboxRuntime {
    @Volatile
    private var processor: RequestOutboxProcessor? = null

    fun install(value: RequestOutboxProcessor) {
        processor = value
    }

    fun requireProcessor(): RequestOutboxProcessor = requireNotNull(processor) {
        "Request outbox runtime was not initialized"
    }
}

internal class WorkManagerRequestOutboxScheduler(
    context: Context,
) : RequestOutboxScheduler {
    private val workManager = WorkManager.getInstance(context.applicationContext)

    override fun schedule() {
        val request = OneTimeWorkRequestBuilder<RequestOutboxWorker>()
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build(),
            )
            .build()
        workManager.enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.KEEP, request)
    }

    private companion object {
        const val WORK_NAME = "max-request-outbox"
    }
}

class RequestOutboxWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = when (RequestOutboxRuntime.requireProcessor().processNext()) {
        RequestProcessResult.NothingToProcess -> Result.success()
        is RequestProcessResult.Accepted -> Result.success()
        is RequestProcessResult.Retry -> Result.retry()
        is RequestProcessResult.Rejected -> Result.failure()
    }
}
