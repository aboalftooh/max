package com.maxnetwork.feature.request.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.maxnetwork.feature.request.domain.RequestOutboxScheduler
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.domain.RequestDraftId
import com.maxnetwork.feature.request.domain.RequestIdempotencyKey
import com.maxnetwork.feature.request.domain.RequestOutboxState
import com.maxnetwork.feature.request.domain.usecase.EnqueueRequestUseCase
import com.maxnetwork.feature.request.domain.usecase.AcknowledgeAcceptedRequestUseCase
import com.maxnetwork.feature.request.domain.usecase.DeleteRequestDraftUseCase
import com.maxnetwork.feature.request.domain.usecase.LoadRequestDraftUseCase
import com.maxnetwork.feature.request.domain.usecase.ObserveRequestOutboxUseCase
import com.maxnetwork.feature.request.domain.usecase.SaveRequestDraftUseCase
import java.time.Instant
import java.util.UUID
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

sealed interface RequestUiEvent {
    data class Accepted(
        val requestId: String,
        val conversationId: String,
        val acceptedAt: Instant,
    ) : RequestUiEvent
}

class RequestViewModel(
    private val loadDraft: LoadRequestDraftUseCase,
    private val saveDraft: SaveRequestDraftUseCase,
    private val observeOutbox: ObserveRequestOutboxUseCase,
    private val enqueueRequest: EnqueueRequestUseCase,
    private val acknowledgeAccepted: AcknowledgeAcceptedRequestUseCase,
    private val deleteDraft: DeleteRequestDraftUseCase,
    private val scheduler: RequestOutboxScheduler,
    private val idFactory: () -> RequestDraftId = { RequestDraftId(UUID.randomUUID().toString()) },
) : ViewModel() {
    private val reducer = RequestComposerReducer()
    private val mutableState = MutableStateFlow(reducer.state)
    private val mutableLatestOutbox = MutableStateFlow<com.maxnetwork.feature.request.domain.RequestOutboxItem?>(null)
    private val mutableEvents = MutableSharedFlow<RequestUiEvent>(
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    private var draftId: RequestDraftId = idFactory()
    private var emittedAcceptedRequestId: String? = null
    private var acceptedKey: RequestIdempotencyKey? = null

    val state: StateFlow<RequestPartUiState> = mutableState.asStateFlow()
    val latestOutbox: StateFlow<com.maxnetwork.feature.request.domain.RequestOutboxItem?> = mutableLatestOutbox.asStateFlow()
    val events: SharedFlow<RequestUiEvent> = mutableEvents.asSharedFlow()

    init {
        viewModelScope.launch {
            val draft = loadDraft()
            if (draft != null) draftId = draft.id
            apply(RequestComposerAction.DraftLoaded(draft?.content))
        }
        viewModelScope.launch {
            observeOutbox().collect { item ->
                mutableLatestOutbox.value = item
                when (item?.state) {
                    null -> Unit
                    RequestOutboxState.Pending,
                    RequestOutboxState.UploadingImage,
                    RequestOutboxState.UploadingAudio,
                    RequestOutboxState.Submitting,
                    -> apply(RequestComposerAction.SubmissionPending)
                    RequestOutboxState.RetryableFailure -> apply(
                        RequestComposerAction.SubmissionFailed(
                            item.lastError ?: "تعذر الإرسال. سيعاد تلقائيًا عند توفر الشبكة.",
                        ),
                    )
                    RequestOutboxState.PermanentFailure -> apply(
                        RequestComposerAction.SubmissionFailed(item.lastError ?: "تعذر قبول الطلب."),
                    )
                    RequestOutboxState.Accepted -> {
                        acceptedKey = item.key
                        apply(RequestComposerAction.SubmissionAccepted)
                        val requestId = requireNotNull(item.serverRequestId)
                        val acceptedAt = requireNotNull(item.acceptedAt)
                        if (emittedAcceptedRequestId != requestId) {
                            emittedAcceptedRequestId = requestId
                            mutableEvents.emit(
                                RequestUiEvent.Accepted(
                                    requestId = requestId,
                                    conversationId = requireNotNull(item.conversationId),
                                    acceptedAt = acceptedAt,
                                ),
                            )
                        }
                    }
                    RequestOutboxState.Acknowledged -> Unit
                }
            }
        }
    }

    fun onTextChanged(value: String) = apply(RequestComposerAction.TextChanged(value.take(2_000)))
    fun onImageChanged(attachment: RequestAttachmentRef?) = apply(RequestComposerAction.ImageChanged(attachment))
    fun onAudioChanged(attachment: RequestAttachmentRef?) = apply(RequestComposerAction.AudioChanged(attachment))
    fun submit() = apply(RequestComposerAction.SubmitClicked)
    fun retry() = apply(RequestComposerAction.RetryClicked)
    fun markSubmissionFailed(message: String) = apply(RequestComposerAction.SubmissionFailed(message))

    fun consumeAcceptedRequest() {
        val key = acceptedKey ?: return
        viewModelScope.launch {
            acknowledgeAccepted(key)
            deleteDraft()
            acceptedKey = null
            draftId = idFactory()
            apply(RequestComposerAction.DraftLoaded(null))
        }
    }

    private fun apply(action: RequestComposerAction) {
        val transition = reducer.dispatch(action)
        mutableState.value = transition.state
        when (val command = transition.command) {
            RequestComposerCommand.None -> Unit
            is RequestComposerCommand.Persist -> viewModelScope.launch {
                saveDraft(draftId, command.content)
            }
            is RequestComposerCommand.Submit -> viewModelScope.launch {
                saveDraft(draftId, command.content)
                enqueueRequest(draftId, command.content)
                apply(RequestComposerAction.SubmissionPending)
                scheduler.schedule()
            }
        }
    }
}
