package com.maxnetwork.feature.request.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

internal data class RequestDraftWithAttachments(
    val draft: RequestDraftEntity,
    val attachments: List<RequestAttachmentEntity>,
)

@Dao
internal interface RequestDraftDao {
    @Query("SELECT * FROM request_drafts LIMIT 1")
    fun observeDraftEntity(): Flow<RequestDraftEntity?>

    @Query("SELECT * FROM request_drafts LIMIT 1")
    suspend fun getDraftEntity(): RequestDraftEntity?

    @Query("SELECT * FROM request_attachment_refs WHERE draftId = :draftId")
    suspend fun getAttachments(draftId: String): List<RequestAttachmentEntity>

    @Upsert
    suspend fun upsertDraft(entity: RequestDraftEntity)

    @Upsert
    suspend fun upsertAttachment(entity: RequestAttachmentEntity)

    @Query("DELETE FROM request_attachment_refs WHERE draftId = :draftId")
    suspend fun deleteAttachmentsForDraft(draftId: String)

    @Query("DELETE FROM request_drafts")
    suspend fun deleteDraftRows()

    @Transaction
    suspend fun replaceDraft(
        draft: RequestDraftEntity,
        attachments: List<RequestAttachmentEntity>,
    ) {
        deleteAttachmentsForDraft(draft.id)
        upsertDraft(draft)
        attachments.forEach { upsertAttachment(it) }
    }

    @Transaction
    suspend fun loadDraft(): RequestDraftWithAttachments? {
        val draft = getDraftEntity() ?: return null
        return RequestDraftWithAttachments(draft, getAttachments(draft.id))
    }

    @Transaction
    suspend fun clearDraft() {
        deleteDraftRows()
        // Attachment rows are removed by the database foreign ownership policy in repository cleanup.
    }
}
