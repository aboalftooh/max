package com.maxnetwork.feature.request.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "request_outbox",
    indices = [Index(value = ["draftId"], unique = true), Index(value = ["state"])],
)
internal data class RequestOutboxEntity(
    @PrimaryKey val idempotencyKey: String,
    val draftId: String,
    val text: String,
    val imageAttachmentId: String?,
    val audioAttachmentId: String?,
    val state: String,
    val attemptCount: Int,
    val lastError: String?,
    val imageUploadId: String?,
    val audioUploadId: String?,
    val serverRequestId: String?,
    val acceptedAtEpochMillis: Long?,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "request_outbox_attachments",
    primaryKeys = ["idempotencyKey", "kind"],
)
internal data class RequestOutboxAttachmentEntity(
    val idempotencyKey: String,
    val kind: String,
    val attachmentId: String,
    val privateRelativePath: String,
    val mimeType: String,
    val byteSize: Long,
    val durationSeconds: Int?,
)
