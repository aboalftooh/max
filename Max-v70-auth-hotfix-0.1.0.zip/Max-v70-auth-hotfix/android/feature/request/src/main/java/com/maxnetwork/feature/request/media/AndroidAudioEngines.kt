package com.maxnetwork.feature.request.media

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import java.io.File

class AndroidAudioRecorderEngine(context: Context) : AudioRecorderEngine {
    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var mediaRecorder: MediaRecorder? = null
    private var interruption: (() -> Unit)? = null
    private var focusRequest: AudioFocusRequest? = null

    override val isRecording: Boolean
        get() = mediaRecorder != null

    override fun start(target: AudioCaptureTarget, onInterrupted: () -> Unit) {
        check(mediaRecorder == null) { "Recorder is already active" }
        interruption = onInterrupted
        requestFocus()
        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(appContext)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        try {
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioEncodingBitRate(96_000)
            recorder.setAudioSamplingRate(44_100)
            recorder.setMaxDuration(60_000)
            recorder.setMaxFileSize(5L * 1024L * 1024L)
            recorder.setOutputFile(target.file.absolutePath)
            recorder.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED ||
                    what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED
                ) {
                    interruption?.invoke()
                }
            }
            recorder.prepare()
            recorder.start()
            mediaRecorder = recorder
        } catch (error: Throwable) {
            recorder.release()
            abandonFocus()
            interruption = null
            throw error
        }
    }

    override fun stop() {
        val recorder = mediaRecorder ?: return
        mediaRecorder = null
        try {
            recorder.stop()
        } finally {
            recorder.reset()
            recorder.release()
            abandonFocus()
            interruption = null
        }
    }

    override fun cancel() {
        val recorder = mediaRecorder ?: return
        mediaRecorder = null
        runCatching(recorder::stop)
        recorder.reset()
        recorder.release()
        abandonFocus()
        interruption = null
    }

    private fun requestFocus() {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
            .setAudioAttributes(attributes)
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS ||
                    change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT ||
                    change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK
                ) interruption?.invoke()
            }
            .build()
        check(audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            "Microphone audio focus was not granted"
        }
        focusRequest = request
    }

    private fun abandonFocus() {
        focusRequest?.let(audioManager::abandonAudioFocusRequest)
        focusRequest = null
    }
}

class AndroidAudioPlayerEngine(context: Context) : AudioPlayerEngine {
    private var player: MediaPlayer? = null

    override val isPlaying: Boolean
        get() = player?.isPlaying == true

    override fun play(file: File, onCompleted: () -> Unit) {
        stop()
        player = MediaPlayer().apply {
            setDataSource(file.absolutePath)
            setOnCompletionListener {
                stop()
                onCompleted()
            }
            prepare()
            start()
        }
    }

    override fun stop() {
        player?.let { current ->
            runCatching { if (current.isPlaying) current.stop() }
            current.reset()
            current.release()
        }
        player = null
    }
}

fun interface RequestAudioControllerFactory {
    fun create(scope: kotlinx.coroutines.CoroutineScope): RequestAudioController
}

class AndroidRequestAudioControllerFactory(
    private val context: Context,
    private val attachmentRoot: File,
) : RequestAudioControllerFactory {
    override fun create(scope: kotlinx.coroutines.CoroutineScope): RequestAudioController = RequestAudioController(
        recorder = AndroidAudioRecorderEngine(context),
        player = AndroidAudioPlayerEngine(context),
        fileStore = PrivateAudioFileStore(File(attachmentRoot, "audio")),
        scope = scope,
        elapsedRealtimeMillis = android.os.SystemClock::elapsedRealtime,
    )
}
