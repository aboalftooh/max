package com.maxnetwork.feature.request.domain

import java.time.Instant

@JvmInline
value class RequestDraftId(val value: String) {
    init {
        require(value.isNotBlank()) { "Request draft id must not be blank" }
    }
}

@JvmInline
value class LocalAttachmentId(val value: String) {
    init {
        require(value.isNotBlank()) { "Attachment id must not be blank" }
    }
}

enum class RequestStatus {
    Draft,
    Pending,
    Provided,
    NotAvailable,
}

enum class RequestSource {
    App,
    Verto,
    MaxTeam,
}

enum class RequestAttachmentKind {
    Image,
    Audio,
}

data class RequestAttachmentRef(
    val id: LocalAttachmentId,
    val kind: RequestAttachmentKind,
    val mimeType: String,
    val byteSize: Long,
    val durationSeconds: Int? = null,
) {
    init {
        require(mimeType.isNotBlank()) { "Attachment mime type must not be blank" }
        require(byteSize >= 0L) { "Attachment size must not be negative" }
        require(durationSeconds == null || durationSeconds >= 0) { "Duration must not be negative" }
        require(kind == RequestAttachmentKind.Audio || durationSeconds == null) {
            "Only audio attachments may declare duration"
        }
    }
}

data class RequestContent(
    val text: String = "",
    val image: RequestAttachmentRef? = null,
    val audio: RequestAttachmentRef? = null,
) {
    init {
        require(image == null || image.kind == RequestAttachmentKind.Image) {
            "Image slot accepts only image attachments"
        }
        require(audio == null || audio.kind == RequestAttachmentKind.Audio) {
            "Audio slot accepts only audio attachments"
        }
    }

    fun normalized(): RequestContent = copy(text = text.trim())

    fun hasAnyContent(): Boolean = text.isNotBlank() || image != null || audio != null

    fun totalAttachmentBytes(): Long = (image?.byteSize ?: 0L) + (audio?.byteSize ?: 0L)
}

data class RequestDraft(
    val id: RequestDraftId,
    val content: RequestContent,
    val status: RequestStatus = RequestStatus.Draft,
    val source: RequestSource = RequestSource.App,
    val updatedAt: Instant,
) {
    init {
        require(status == RequestStatus.Draft) { "A local draft must keep Draft status" }
        require(source == RequestSource.App) { "A local draft must originate from the app" }
    }
}

sealed interface RequestValidationResult {
    data object Valid : RequestValidationResult
    data class Invalid(val reason: RequestValidationError) : RequestValidationResult
}

enum class RequestValidationError {
    EmptyContent,
    TextTooLong,
    UnsupportedImageType,
    ImageTooLarge,
    UnsupportedAudioType,
    AudioTooLong,
    AudioTooLarge,
    AttachmentsTooLarge,
}

object RequestDraftPolicy {
    const val MAX_TEXT_LENGTH = 2_000
    const val MAX_IMAGE_BYTES = 8L * 1024L * 1024L
    const val MAX_AUDIO_BYTES = 5L * 1024L * 1024L
    const val MAX_TOTAL_ATTACHMENT_BYTES = 12L * 1024L * 1024L
    const val MAX_AUDIO_DURATION_SECONDS = 60

    private val allowedImageMimeTypes = setOf("image/jpeg", "image/png", "image/webp")
    private val allowedAudioMimeTypes = setOf("audio/mp4", "audio/aac", "audio/m4a")

    fun validate(content: RequestContent): RequestValidationResult {
        val normalized = content.normalized()
        if (!normalized.hasAnyContent()) return RequestValidationResult.Invalid(RequestValidationError.EmptyContent)
        if (normalized.text.length > MAX_TEXT_LENGTH) {
            return RequestValidationResult.Invalid(RequestValidationError.TextTooLong)
        }
        normalized.image?.let { image ->
            if (image.mimeType !in allowedImageMimeTypes) {
                return RequestValidationResult.Invalid(RequestValidationError.UnsupportedImageType)
            }
            if (image.byteSize > MAX_IMAGE_BYTES) {
                return RequestValidationResult.Invalid(RequestValidationError.ImageTooLarge)
            }
        }
        normalized.audio?.let { audio ->
            if (audio.mimeType !in allowedAudioMimeTypes) {
                return RequestValidationResult.Invalid(RequestValidationError.UnsupportedAudioType)
            }
            if ((audio.durationSeconds ?: 0) > MAX_AUDIO_DURATION_SECONDS) {
                return RequestValidationResult.Invalid(RequestValidationError.AudioTooLong)
            }
            if (audio.byteSize > MAX_AUDIO_BYTES) {
                return RequestValidationResult.Invalid(RequestValidationError.AudioTooLarge)
            }
        }
        if (normalized.totalAttachmentBytes() > MAX_TOTAL_ATTACHMENT_BYTES) {
            return RequestValidationResult.Invalid(RequestValidationError.AttachmentsTooLarge)
        }
        return RequestValidationResult.Valid
    }
}

/** A draft never creates or mutates a financial operation (BR-006). */
data class DraftSaveResult(
    val draft: RequestDraft,
    val financialMovementCreated: Boolean = false,
) {
    init {
        require(!financialMovementCreated) { "Saving a request draft must never create a financial movement" }
    }
}
