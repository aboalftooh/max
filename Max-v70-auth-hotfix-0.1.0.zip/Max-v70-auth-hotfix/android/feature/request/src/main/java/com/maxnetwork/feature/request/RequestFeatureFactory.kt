package com.maxnetwork.feature.request

import android.content.Context
import androidx.room.Room
import com.maxnetwork.core.common.SystemClockProvider
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.request.data.DefaultRequestDraftRepository
import com.maxnetwork.feature.request.data.DefaultRequestOutboxRepository
import com.maxnetwork.feature.request.data.outbox.RequestOutboxProcessor
import com.maxnetwork.feature.request.data.outbox.RequestOutboxRuntime
import com.maxnetwork.feature.request.domain.RequestOutboxScheduler
import com.maxnetwork.feature.request.data.outbox.WorkManagerRequestOutboxScheduler
import com.maxnetwork.feature.request.data.local.RequestDraftDatabase
import com.maxnetwork.feature.request.domain.RequestDraftRepository
import com.maxnetwork.feature.request.domain.RequestOutboxRepository
import com.maxnetwork.feature.request.domain.usecase.DeleteRequestDraftUseCase
import com.maxnetwork.feature.request.domain.usecase.LoadRequestDraftUseCase
import com.maxnetwork.feature.request.domain.usecase.EnqueueRequestUseCase
import com.maxnetwork.feature.request.domain.usecase.AcknowledgeAcceptedRequestUseCase
import com.maxnetwork.feature.request.domain.usecase.ObserveRequestOutboxUseCase
import com.maxnetwork.feature.request.domain.usecase.ObserveRequestDraftUseCase
import com.maxnetwork.feature.request.domain.usecase.SaveRequestDraftUseCase
import com.maxnetwork.feature.request.domain.usecase.ValidateRequestContentUseCase
import com.maxnetwork.feature.request.media.AndroidRequestAudioControllerFactory
import com.maxnetwork.feature.request.media.AndroidRequestImageManager
import com.maxnetwork.feature.request.media.RequestAudioControllerFactory
import com.maxnetwork.feature.request.media.RequestImageManager
import java.io.File

private const val REQUEST_DATABASE_NAME = "max-request-drafts.db"

data class RequestDraftUseCases(
    val observe: ObserveRequestDraftUseCase,
    val load: LoadRequestDraftUseCase,
    val save: SaveRequestDraftUseCase,
    val delete: DeleteRequestDraftUseCase,
    val validate: ValidateRequestContentUseCase,
    val observeOutbox: ObserveRequestOutboxUseCase,
    val enqueue: EnqueueRequestUseCase,
    val acknowledgeAccepted: AcknowledgeAcceptedRequestUseCase,
)

data class RequestFeatureDependencies(
    val repository: RequestDraftRepository,
    val outboxRepository: RequestOutboxRepository,
    val useCases: RequestDraftUseCases,
    val outboxScheduler: RequestOutboxScheduler,
    val attachmentRoot: File,
    val imageManager: RequestImageManager,
    val audioControllerFactory: RequestAudioControllerFactory,
)

object RequestFeatureFactory {
    fun create(context: Context, gateway: MaxGateway): RequestFeatureDependencies {
        val appContext = context.applicationContext
        val database = Room.databaseBuilder(
            appContext,
            RequestDraftDatabase::class.java,
            REQUEST_DATABASE_NAME,
        )
            .addMigrations(RequestDraftDatabase.MIGRATION_1_2)
            .build()
        val attachmentRoot = File(appContext.filesDir, "request-attachments").apply { mkdirs() }
        val repository = DefaultRequestDraftRepository(database, attachmentRoot)
        val outboxRepository = DefaultRequestOutboxRepository(database, attachmentRoot, SystemClockProvider)
        val processor = RequestOutboxProcessor(outboxRepository, gateway)
        RequestOutboxRuntime.install(processor)
        val scheduler = WorkManagerRequestOutboxScheduler(appContext)
        return RequestFeatureDependencies(
            repository = repository,
            outboxRepository = outboxRepository,
            useCases = RequestDraftUseCases(
                observe = ObserveRequestDraftUseCase(repository),
                load = LoadRequestDraftUseCase(repository),
                save = SaveRequestDraftUseCase(repository, SystemClockProvider),
                delete = DeleteRequestDraftUseCase(repository),
                validate = ValidateRequestContentUseCase(),
                observeOutbox = ObserveRequestOutboxUseCase(outboxRepository),
                enqueue = EnqueueRequestUseCase(outboxRepository),
                acknowledgeAccepted = AcknowledgeAcceptedRequestUseCase(outboxRepository),
            ),
            outboxScheduler = scheduler,
            attachmentRoot = attachmentRoot,
            imageManager = AndroidRequestImageManager(appContext, attachmentRoot),
            audioControllerFactory = AndroidRequestAudioControllerFactory(appContext, attachmentRoot),
        )
    }
}
