package com.maxnetwork.feature.request.presentation

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.component.MaxBannerTone
import com.maxnetwork.core.designsystem.component.MaxDestructiveButton
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxInlineBanner
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxSecondaryButton
import com.maxnetwork.core.designsystem.component.MaxStatusPill
import com.maxnetwork.core.designsystem.component.MaxStatusTone
import com.maxnetwork.core.designsystem.component.MaxTertiaryButton
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.media.AudioCaptureResult
import com.maxnetwork.feature.request.media.RequestAudioControllerFactory
import com.maxnetwork.feature.request.media.RequestAudioFailure
import com.maxnetwork.feature.request.media.RequestAudioState
import kotlinx.coroutines.launch

@Composable
fun RequestAudioAttachmentSection(
    controllerFactory: RequestAudioControllerFactory,
    currentAttachment: RequestAttachmentRef?,
    onAttachmentChanged: suspend (RequestAttachmentRef?) -> Unit,
    onFailure: (RequestAudioFailure) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val controller = remember(controllerFactory) { controllerFactory.create(scope) }
    val state by controller.state.collectAsState()
    val lifecycleOwner = LocalLifecycleOwner.current

    LaunchedEffect(currentAttachment?.id?.value) { controller.restore(currentAttachment) }
    LaunchedEffect(state) {
        val ready = state as? RequestAudioState.Ready ?: return@LaunchedEffect
        if (ready.attachment.id != currentAttachment?.id) onAttachmentChanged(ready.attachment)
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            controller.start()?.let { result ->
                if (result is AudioCaptureResult.Failure) onFailure(result.reason)
            }
        } else {
            controller.reportPermissionDenied()
            onFailure(RequestAudioFailure.PermissionDenied)
        }
    }

    DisposableEffect(lifecycleOwner, controller) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) controller.onHostStopped()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            controller.close()
        }
    }

    MaxListContainer(
        modifier = modifier.testTag("request_audio_attachment_state"),
    ) {
        MaxListRow(
            title = "تسجيل صوتي",
            supportingText = audioStateMessage(state),
            trailingContent = { AudioStatePill(state) },
        )
        MaxDivider()
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
        ) {
            AudioActions(
                state = state,
                currentAttachment = currentAttachment,
                onStart = {
                    if (
                        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        controller.start()?.let { result ->
                            if (result is AudioCaptureResult.Failure) onFailure(result.reason)
                        }
                    } else {
                        permission.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                onStop = {
                    scope.launch {
                        when (val result = controller.stop()) {
                            is AudioCaptureResult.Success -> onAttachmentChanged(result.attachment)
                            is AudioCaptureResult.Failure -> onFailure(result.reason)
                        }
                    }
                },
                onPlayToggle = { attachment ->
                    if (state is RequestAudioState.Playing) controller.stopPlayback() else controller.play(attachment)
                },
                onDelete = { attachment ->
                    controller.delete(attachment)
                    scope.launch { onAttachmentChanged(null) }
                },
            )

            val failure = state as? RequestAudioState.Failed
            if (failure != null) {
                MaxInlineBanner(
                    message = audioFailureMessage(failure.reason),
                    modifier = Modifier.testTag(
                        if (failure.reason == RequestAudioFailure.PermissionDenied) {
                            "request_audio_permission_denied"
                        } else {
                            "request_audio_error"
                        },
                    ),
                    tone = MaxBannerTone.Error,
                )
            }

            MaxText(
                text = "نحتاج الميكروفون فقط أثناء التسجيل، وبحد أقصى 60 ثانية.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.testTag("request_audio_permission_explanation"),
            )
        }
    }
}

@Composable
private fun AudioActions(
    state: RequestAudioState,
    currentAttachment: RequestAttachmentRef?,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onPlayToggle: (RequestAttachmentRef) -> Unit,
    onDelete: (RequestAttachmentRef) -> Unit,
) {
    if (state is RequestAudioState.Recording) {
        MaxPrimaryButton(
            text = "إيقاف التسجيل",
            onClick = onStop,
            testTag = "request_audio_stop",
        )
        return
    }

    MaxSecondaryButton(
        text = if (currentAttachment == null) "تسجيل صوتي" else "استبدال التسجيل",
        onClick = onStart,
        testTag = "request_audio_start",
    )

    val playable = when (state) {
        is RequestAudioState.Ready -> state.attachment
        is RequestAudioState.Playing -> state.attachment
        else -> currentAttachment
    }
    if (playable != null) {
        MaxTertiaryButton(
            text = if (state is RequestAudioState.Playing) "إيقاف الاستماع" else "استماع",
            onClick = { onPlayToggle(playable) },
            fullWidth = true,
            testTag = "request_audio_play",
        )
        MaxDestructiveButton(
            text = "حذف التسجيل",
            onClick = { onDelete(playable) },
            testTag = "request_audio_delete",
        )
    }
}

@Composable
private fun AudioStatePill(state: RequestAudioState) {
    when (state) {
        RequestAudioState.Idle -> MaxStatusPill(
            text = "غير مرفق",
            tone = MaxStatusTone.Neutral,
        )

        is RequestAudioState.Recording -> MaxStatusPill(
            text = "جارٍ التسجيل",
            tone = MaxStatusTone.Warning,
            icon = MaxIcons.Alert,
            modifier = Modifier.testTag("request_audio_recording_indicator"),
        )

        is RequestAudioState.Ready -> MaxStatusPill(
            text = "مرفق",
            tone = MaxStatusTone.Success,
            icon = MaxIcons.Check,
        )

        is RequestAudioState.Playing -> MaxStatusPill(
            text = "جارٍ الاستماع",
            tone = MaxStatusTone.Neutral,
        )

        is RequestAudioState.Failed -> MaxStatusPill(
            text = "يحتاج إجراء",
            tone = MaxStatusTone.Error,
            icon = MaxIcons.Alert,
        )
    }
}

private fun audioStateMessage(state: RequestAudioState): String = when (state) {
    RequestAudioState.Idle -> "لا يوجد تسجيل مرفق."
    is RequestAudioState.Recording -> "جارٍ التسجيل ${state.elapsedSeconds}ث."
    is RequestAudioState.Ready -> "مدة التسجيل ${state.durationSeconds}ث."
    is RequestAudioState.Playing -> "جارٍ الاستماع إلى تسجيل مدته ${state.durationSeconds}ث."
    is RequestAudioState.Failed -> audioFailureMessage(state.reason)
}

private fun audioFailureMessage(failure: RequestAudioFailure): String = when (failure) {
    RequestAudioFailure.PermissionDenied -> "اسمح بالميكروفون لتسجيل رسالة صوتية، أو أرسل الطلب بدون تسجيل."
    RequestAudioFailure.RecorderUnavailable -> "تعذر بدء التسجيل."
    RequestAudioFailure.RecordingTooShort -> "التسجيل قصير جدًا."
    RequestAudioFailure.RecordingTooLong -> "تجاوز التسجيل 60 ثانية."
    RequestAudioFailure.FileTooLarge -> "حجم التسجيل أكبر من المسموح."
    RequestAudioFailure.FileMissing -> "ملف التسجيل غير موجود."
    RequestAudioFailure.PlaybackUnavailable -> "تعذر تشغيل التسجيل."
    RequestAudioFailure.Interrupted -> "توقف التسجيل بسبب مقاطعة."
}
