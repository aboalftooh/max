package com.maxnetwork.feature.request.presentation

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import com.maxnetwork.core.designsystem.component.MaxDestructiveButton
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxSecondaryButton
import com.maxnetwork.core.designsystem.component.MaxStatusPill
import com.maxnetwork.core.designsystem.component.MaxStatusTone
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.media.CameraCaptureTarget
import com.maxnetwork.feature.request.media.ImageImportFailure
import com.maxnetwork.feature.request.media.ImageImportResult
import com.maxnetwork.feature.request.media.RequestImageManager
import kotlinx.coroutines.launch

/** Camera and gallery controls only. Preview is deliberately rendered later by [RequestImageAttachmentPreview]. */
@Composable
fun RequestImageAttachmentSection(
    imageManager: RequestImageManager,
    currentAttachment: RequestAttachmentRef?,
    onAttachmentChanged: suspend (RequestAttachmentRef?) -> Unit,
    onFailure: (ImageImportFailure) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    var busy by rememberSaveable { mutableStateOf(false) }
    var pendingCameraUri by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingCameraPath by rememberSaveable { mutableStateOf<String?>(null) }

    fun apply(result: ImageImportResult) {
        busy = false
        when (result) {
            is ImageImportResult.Success -> scope.launch { onAttachmentChanged(result.image.attachment) }
            is ImageImportResult.Failure -> onFailure(result.reason)
        }
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { captured ->
        val uri = pendingCameraUri
        val path = pendingCameraPath
        pendingCameraUri = null
        pendingCameraPath = null
        if (!captured || uri == null || path == null) {
            busy = false
            onFailure(ImageImportFailure.Cancelled)
        } else {
            scope.launch { apply(imageManager.importFromCamera(CameraCaptureTarget(Uri.parse(uri), path))) }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) {
            busy = false
            onFailure(ImageImportFailure.Cancelled)
        } else {
            scope.launch { apply(imageManager.importFromPicker(uri)) }
        }
    }

    MaxListContainer(
        modifier = modifier.testTag("request_image_actions"),
    ) {
        MaxListRow(
            title = "صورة القطعة",
            supportingText = if (currentAttachment == null) {
                "التقط صورة أو اخترها من المعرض."
            } else {
                "يمكنك استبدال الصورة المرفقة."
            },
            trailingContent = {
                if (busy) {
                    MaxStatusPill(
                        text = "جارٍ التجهيز",
                        tone = MaxStatusTone.Warning,
                        modifier = Modifier.testTag("request_image_busy"),
                    )
                }
            },
        )
        MaxDivider()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(MaxSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
        ) {
            MaxSecondaryButton(
                text = "الكاميرا",
                enabled = !busy,
                onClick = {
                    runCatching { imageManager.createCameraTarget() }
                        .onSuccess { target ->
                            pendingCameraUri = target.uri.toString()
                            pendingCameraPath = target.privateTempPath
                            busy = true
                            camera.launch(target.uri)
                        }
                        .onFailure {
                            busy = false
                            onFailure(ImageImportFailure.WriteFailed)
                        }
                },
                modifier = Modifier.weight(1f),
                fullWidth = false,
                testTag = "request_take_photo",
            )
            MaxSecondaryButton(
                text = "المعرض",
                enabled = !busy,
                onClick = {
                    busy = true
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.weight(1f),
                fullWidth = false,
                testTag = "request_pick_image",
            )
        }
    }
}

@Composable
fun RequestImageAttachmentPreview(
    imageManager: RequestImageManager,
    currentAttachment: RequestAttachmentRef?,
    onAttachmentChanged: suspend (RequestAttachmentRef?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    var preview by remember(currentAttachment?.id?.value) { mutableStateOf<android.graphics.Bitmap?>(null) }

    LaunchedEffect(currentAttachment?.id?.value) {
        preview = currentAttachment?.let { imageManager.loadPreview(it) }
    }

    if (currentAttachment == null) return

    MaxListContainer(
        modifier = modifier.testTag("request_image_attachment_state"),
    ) {
        Column(
            modifier = Modifier.padding(MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
        ) {
            MaxStatusPill(
                text = "صورة مرفقة",
                tone = MaxStatusTone.Success,
                modifier = Modifier.testTag("request_image_attached_status"),
            )
            preview?.let { bitmap ->
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "معاينة صورة القطعة",
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(androidx.compose.material3.MaterialTheme.shapes.medium)
                        .testTag("request_image_preview"),
                    contentScale = ContentScale.Crop,
                )
            }
            MaxText("تُزال بيانات الموقع من الصورة قبل الحفظ.")
            MaxDestructiveButton(
                text = "حذف الصورة",
                onClick = {
                    scope.launch {
                        imageManager.delete(currentAttachment)
                        preview = null
                        onAttachmentChanged(null)
                    }
                },
                testTag = "request_remove_image",
            )
        }
    }
}
