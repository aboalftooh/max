package com.maxnetwork.feature.request.data

/** Placeholder boundary. Data implementations will implement domain-owned contracts. */
internal object RequestDataBoundary
