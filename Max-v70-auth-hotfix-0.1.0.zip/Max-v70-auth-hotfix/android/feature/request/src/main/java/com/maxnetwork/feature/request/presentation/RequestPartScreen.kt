package com.maxnetwork.feature.request.presentation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import com.maxnetwork.core.designsystem.component.MaxBannerTone
import com.maxnetwork.core.designsystem.component.MaxBottomActionBar
import com.maxnetwork.core.designsystem.component.MaxInlineBanner
import com.maxnetwork.core.designsystem.component.MaxLoadingState
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxSectionHeader
import com.maxnetwork.core.designsystem.component.MaxTextField
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.pattern.MaxFormPattern
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.media.ImageImportFailure
import com.maxnetwork.feature.request.media.RequestAudioControllerFactory
import com.maxnetwork.feature.request.media.RequestAudioFailure
import com.maxnetwork.feature.request.media.RequestImageManager

data class RequestPartActions(
    val onTextChanged: (String) -> Unit,
    val onImageChanged: suspend (RequestAttachmentRef?) -> Unit,
    val onAudioChanged: suspend (RequestAttachmentRef?) -> Unit,
    val onImageFailure: (ImageImportFailure) -> Unit,
    val onAudioFailure: (RequestAudioFailure) -> Unit,
    val onSubmit: () -> Unit,
    val onRetry: () -> Unit,
    val onBack: () -> Unit,
)

@Composable
fun RequestPartScreen(
    state: RequestPartUiState,
    imageManager: RequestImageManager?,
    audioControllerFactory: RequestAudioControllerFactory?,
    actions: RequestPartActions,
    modifier: Modifier = Modifier,
) {
    MaxScaffold(
        modifier = modifier.testTag("request_part_screen"),
        topBar = { MaxTopBar(title = "اطلب قطعة", onBack = actions.onBack) },
    ) { contentPadding ->
        if (state.phase == RequestComposerPhase.Loading) {
            MaxLoadingState(
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("request_loading_state"),
                title = "جارٍ تحميل الطلب",
                message = "نجهّز المسودة المحفوظة.",
            )
        } else {
            RequestPartForm(
                state = state,
                imageManager = imageManager,
                audioControllerFactory = audioControllerFactory,
                actions = actions,
                contentPadding = contentPadding,
            )
        }
    }
}

@Composable
private fun RequestPartForm(
    state: RequestPartUiState,
    imageManager: RequestImageManager?,
    audioControllerFactory: RequestAudioControllerFactory?,
    actions: RequestPartActions,
    contentPadding: PaddingValues,
) {
    MaxFormPattern(
        modifier = Modifier
            .padding(contentPadding)
            .imePadding(),
        sections = {
            MaxSectionHeader("تفاصيل الطلب")
            MaxTextField(
                value = state.content.text,
                onValueChange = actions.onTextChanged,
                label = "وصف القطعة",
                placeholder = "مثال: مساعد أمامي كورولا 2015",
                supportingText = "${state.content.text.length}/2000",
                singleLine = false,
                minLines = 4,
                maxLines = 7,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                testTag = "request_text_input",
            )

            if (imageManager != null || audioControllerFactory != null) {
                MaxSectionHeader("المرفقات")
            }
            if (imageManager != null) {
                RequestImageAttachmentSection(
                    imageManager = imageManager,
                    currentAttachment = state.content.image,
                    onAttachmentChanged = actions.onImageChanged,
                    onFailure = actions.onImageFailure,
                )
                RequestImageAttachmentPreview(
                    imageManager = imageManager,
                    currentAttachment = state.content.image,
                    onAttachmentChanged = actions.onImageChanged,
                )
            }
            if (audioControllerFactory != null) {
                RequestAudioAttachmentSection(
                    controllerFactory = audioControllerFactory,
                    currentAttachment = state.content.audio,
                    onAttachmentChanged = actions.onAudioChanged,
                    onFailure = actions.onAudioFailure,
                )
            }

            RequestSubmissionState(state)
        },
        actions = {
            MaxBottomActionBar {
                MaxPrimaryButton(
                    text = if (state.phase == RequestComposerPhase.Failed) "إعادة المحاولة" else "إرسال الطلب",
                    onClick = if (state.phase == RequestComposerPhase.Failed) actions.onRetry else actions.onSubmit,
                    enabled = state.canSubmit,
                    loading = state.phase == RequestComposerPhase.Uploading,
                    testTag = "request_submit",
                )
            }
        },
    )
}

@Composable
private fun RequestSubmissionState(state: RequestPartUiState) {
    when (state.phase) {
        RequestComposerPhase.Loading,
        RequestComposerPhase.Draft,
        -> Unit

        RequestComposerPhase.Uploading -> MaxInlineBanner(
            message = "جارٍ تجهيز الطلب…",
            modifier = Modifier.testTag("request_uploading_state"),
        )

        RequestComposerPhase.Pending -> MaxInlineBanner(
            message = state.message ?: "تم حفظ الطلب وسيرسل عند توفر الإنترنت.",
            modifier = Modifier.testTag("request_pending_state"),
        )

        RequestComposerPhase.Accepted -> MaxInlineBanner(
            message = "تم إرسال الطلب وفتح المحادثة.",
            modifier = Modifier.testTag("request_accepted_state"),
            tone = MaxBannerTone.Success,
        )

        RequestComposerPhase.Failed -> MaxInlineBanner(
            message = state.message ?: "تعذر إرسال الطلب.",
            modifier = Modifier.testTag("request_failed_state"),
            tone = MaxBannerTone.Error,
        )
    }
}
