package com.maxnetwork.feature.request.domain

import kotlinx.coroutines.flow.Flow

interface RequestDraftRepository {
    fun observeActiveDraft(): Flow<RequestDraft?>
    suspend fun loadActiveDraft(): RequestDraft?
    suspend fun saveDraft(draft: RequestDraft): DraftSaveResult
    suspend fun deleteDraft()
}
