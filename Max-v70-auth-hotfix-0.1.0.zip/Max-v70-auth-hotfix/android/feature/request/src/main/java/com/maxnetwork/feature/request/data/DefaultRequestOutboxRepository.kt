package com.maxnetwork.feature.request.data

import androidx.room.withTransaction
import com.maxnetwork.core.common.ClockProvider
import com.maxnetwork.feature.request.data.local.RequestDraftDatabase
import com.maxnetwork.feature.request.data.local.RequestOutboxAttachmentEntity
import com.maxnetwork.feature.request.data.local.RequestOutboxEntity
import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.OutboxEnqueueResult
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.domain.RequestContent
import com.maxnetwork.feature.request.domain.RequestDraftId
import com.maxnetwork.feature.request.domain.RequestIdempotencyKey
import com.maxnetwork.feature.request.domain.RequestOutboxItem
import com.maxnetwork.feature.request.domain.RequestOutboxRepository
import com.maxnetwork.feature.request.domain.RequestOutboxState
import java.io.File
import java.time.Instant
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

internal class DefaultRequestOutboxRepository(
    private val database: RequestDraftDatabase,
    private val attachmentRoot: File,
    private val clock: ClockProvider,
) : RequestOutboxRepository {
    private val dao = database.requestOutboxDao()

    override fun observeLatest(): Flow<RequestOutboxItem?> = dao.observeLatest().map { entity ->
        entity?.toDomain(dao.attachments(entity.idempotencyKey))
    }

    override suspend fun enqueue(
        draftId: RequestDraftId,
        content: RequestContent,
    ): OutboxEnqueueResult {
        val normalized = content.normalized()
        require(normalized.hasAnyContent()) { "Outbox requires request content" }
        val now = clock.now()
        val key = RequestIdempotencyKey("request:${draftId.value}")
        val attachments = listOfNotNull(normalized.image, normalized.audio).map { attachment ->
            RequestOutboxAttachmentEntity(
                idempotencyKey = key.value,
                kind = attachment.kind.name,
                attachmentId = attachment.id.value,
                privateRelativePath = resolveExistingPrivatePath(attachment.id),
                mimeType = attachment.mimeType,
                byteSize = attachment.byteSize,
                durationSeconds = attachment.durationSeconds,
            )
        }
        val entity = RequestOutboxEntity(
            idempotencyKey = key.value,
            draftId = draftId.value,
            text = normalized.text,
            imageAttachmentId = normalized.image?.id?.value,
            audioAttachmentId = normalized.audio?.id?.value,
            state = RequestOutboxState.Pending.name,
            attemptCount = 0,
            lastError = null,
            imageUploadId = null,
            audioUploadId = null,
            serverRequestId = null,
            acceptedAtEpochMillis = null,
            createdAtEpochMillis = now.toEpochMilli(),
            updatedAtEpochMillis = now.toEpochMilli(),
        )
        val created = database.withTransaction { dao.insertWithAttachments(entity, attachments) }
        val persisted = requireNotNull(dao.get(key.value)).toDomain(dao.attachments(key.value))
        return OutboxEnqueueResult(persisted, created)
    }

    override suspend fun loadNextProcessable(): RequestOutboxItem? = dao.nextProcessable()?.let { entity ->
        entity.toDomain(dao.attachments(entity.idempotencyKey))
    }

    override suspend fun updateState(
        key: RequestIdempotencyKey,
        state: RequestOutboxState,
        error: String?,
    ) {
        dao.updateState(
            key = key.value,
            state = state.name,
            error = error,
            attemptDelta = if (state == RequestOutboxState.RetryableFailure) 1 else 0,
            updatedAt = clock.now().toEpochMilli(),
        )
    }

    override suspend fun saveUploadId(
        key: RequestIdempotencyKey,
        kind: RequestAttachmentKind,
        uploadId: String,
    ) {
        require(uploadId.isNotBlank())
        when (kind) {
            RequestAttachmentKind.Image -> dao.setImageUploadId(key.value, uploadId, clock.now().toEpochMilli())
            RequestAttachmentKind.Audio -> dao.setAudioUploadId(key.value, uploadId, clock.now().toEpochMilli())
        }
    }

    override suspend fun uploadId(
        key: RequestIdempotencyKey,
        kind: RequestAttachmentKind,
    ): String? = dao.get(key.value)?.let { entity ->
        when (kind) {
            RequestAttachmentKind.Image -> entity.imageUploadId
            RequestAttachmentKind.Audio -> entity.audioUploadId
        }
    }

    override suspend fun attachmentBytes(
        key: RequestIdempotencyKey,
        kind: RequestAttachmentKind,
    ): ByteArray? {
        val attachment = dao.attachments(key.value).firstOrNull { it.kind == kind.name } ?: return null
        val root = attachmentRoot.canonicalFile.toPath()
        val candidate = File(attachmentRoot, attachment.privateRelativePath).canonicalFile.toPath()
        require(candidate.startsWith(root)) { "Outbox attachment escaped private storage" }
        val file = candidate.toFile()
        return if (file.isFile) file.readBytes() else null
    }

    override suspend fun markAccepted(
        key: RequestIdempotencyKey,
        requestId: String,
        acceptedAt: Instant,
    ) {
        dao.markAccepted(key.value, requestId, acceptedAt.toEpochMilli())
    }

    override suspend fun acknowledge(key: RequestIdempotencyKey) {
        dao.updateState(
            key = key.value,
            state = RequestOutboxState.Acknowledged.name,
            error = null,
            attemptDelta = 0,
            updatedAt = clock.now().toEpochMilli(),
        )
    }

    private fun resolveExistingPrivatePath(id: LocalAttachmentId): String {
        val candidate = attachmentRoot.walkTopDown()
            .firstOrNull { it.isFile && it.nameWithoutExtension == id.value }
            ?: error("Attachment file is not stored in app-private storage")
        val root = attachmentRoot.canonicalFile.toPath()
        val file = candidate.canonicalFile.toPath()
        require(file.startsWith(root)) { "Attachment path escaped private storage" }
        return root.relativize(file).toString()
    }
}

private fun RequestOutboxEntity.toDomain(
    attachments: List<RequestOutboxAttachmentEntity>,
): RequestOutboxItem {
    val refs = attachments.associateBy { it.kind }
    fun attachment(kind: RequestAttachmentKind): RequestAttachmentRef? = refs[kind.name]?.let {
        RequestAttachmentRef(
            id = LocalAttachmentId(it.attachmentId),
            kind = kind,
            mimeType = it.mimeType,
            byteSize = it.byteSize,
            durationSeconds = it.durationSeconds,
        )
    }
    return RequestOutboxItem(
        key = RequestIdempotencyKey(idempotencyKey),
        draftId = RequestDraftId(draftId),
        content = RequestContent(
            text = text,
            image = attachment(RequestAttachmentKind.Image),
            audio = attachment(RequestAttachmentKind.Audio),
        ),
        state = RequestOutboxState.valueOf(state),
        attemptCount = attemptCount,
        lastError = lastError,
        serverRequestId = serverRequestId,
        acceptedAt = acceptedAtEpochMillis?.let(Instant::ofEpochMilli),
        createdAt = Instant.ofEpochMilli(createdAtEpochMillis),
        updatedAt = Instant.ofEpochMilli(updatedAtEpochMillis),
    )
}
