package com.maxnetwork.feature.request.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.StatFs
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.domain.RequestDraftPolicy
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID

private const val MAX_IMAGE_DIMENSION = 2_048
private const val MIN_FREE_SPACE_BYTES = 16L * 1024L * 1024L
private const val JPEG_START_QUALITY = 88
private const val JPEG_MIN_QUALITY = 52
private const val JPEG_QUALITY_STEP = 8

class AndroidRequestImageManager(
    context: Context,
    attachmentRoot: File,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) : RequestImageManager {
    private val appContext = context.applicationContext
    private val imageRoot = File(attachmentRoot, "images").apply { mkdirs() }
    private val cameraRoot = File(appContext.cacheDir, "request-camera").apply { mkdirs() }

    override fun createCameraTarget(): CameraCaptureTarget {
        ensurePrivateDirectory(cameraRoot)
        val file = File.createTempFile("camera-", ".jpg", cameraRoot)
        val uri = FileProvider.getUriForFile(
            appContext,
            "${appContext.packageName}.request-files",
            file,
        )
        return CameraCaptureTarget(uri = uri, privateTempPath = file.absolutePath)
    }

    override suspend fun importFromPicker(uri: Uri): ImageImportResult = withContext(ioDispatcher) {
        import(uri, deleteSourceAfterImport = false)
    }

    override suspend fun importFromCamera(target: CameraCaptureTarget): ImageImportResult = withContext(ioDispatcher) {
        val temp = safeCameraFile(target.privateTempPath)
            ?: return@withContext ImageImportResult.Failure(ImageImportFailure.PermissionLost)
        val result = import(Uri.fromFile(temp), deleteSourceAfterImport = true)
        if (temp.exists()) temp.delete()
        result
    }

    override suspend fun loadPreview(attachment: RequestAttachmentRef): Bitmap? = withContext(ioDispatcher) {
        findImageFile(attachment)?.let { file -> BitmapFactory.decodeFile(file.absolutePath) }
    }

    override suspend fun delete(attachment: RequestAttachmentRef) = withContext(ioDispatcher) {
        findImageFile(attachment)?.delete()
        Unit
    }

    override fun discardCameraTarget(target: CameraCaptureTarget) {
        safeCameraFile(target.privateTempPath)?.delete()
    }

    private fun import(source: Uri, deleteSourceAfterImport: Boolean): ImageImportResult {
        if (!hasEnoughSpace()) return ImageImportResult.Failure(ImageImportFailure.NotEnoughSpace)
        val decoded = try {
            decodeSanitizedBitmap(source)
        } catch (_: SecurityException) {
            return ImageImportResult.Failure(ImageImportFailure.PermissionLost)
        } catch (_: IOException) {
            return ImageImportResult.Failure(ImageImportFailure.ReadFailed)
        } ?: return ImageImportResult.Failure(ImageImportFailure.UnsupportedImage)

        val id = LocalAttachmentId(UUID.randomUUID().toString())
        val destination = File(imageRoot, "${id.value}.jpg")
        val written = try {
            writeBoundedJpeg(decoded, destination)
        } catch (_: IOException) {
            false
        } finally {
            decoded.recycle()
        }
        if (deleteSourceAfterImport) source.path?.let(::File)?.takeIf(File::exists)?.delete()
        if (!written) {
            destination.delete()
            return ImageImportResult.Failure(ImageImportFailure.TooLarge)
        }
        val preview = BitmapFactory.decodeFile(destination.absolutePath)
            ?: return ImageImportResult.Failure(ImageImportFailure.WriteFailed)
        val attachment = RequestAttachmentRef(
            id = id,
            kind = RequestAttachmentKind.Image,
            mimeType = "image/jpeg",
            byteSize = destination.length(),
        )
        return ImageImportResult.Success(ImportedRequestImage(attachment, preview))
    }

    private fun decodeSanitizedBitmap(uri: Uri): Bitmap? {
        val orientation = readOrientation(uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val sample = calculateSampleSize(bounds.outWidth, bounds.outHeight)
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = open(uri).use { BitmapFactory.decodeStream(it, null, options) } ?: return null
        return rotate(decoded, orientation)
    }

    private fun readOrientation(uri: Uri): Int = try {
        open(uri).use { stream ->
            ExifInterface(stream).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL,
            )
        }
    } catch (_: IOException) {
        ExifInterface.ORIENTATION_NORMAL
    }

    private fun open(uri: Uri) = when (uri.scheme) {
        "file" -> requireNotNull(uri.path).let(::File).inputStream()
        else -> requireNotNull(appContext.contentResolver.openInputStream(uri))
    }

    private fun calculateSampleSize(width: Int, height: Int): Int {
        var sample = 1
        while (width / sample > MAX_IMAGE_DIMENSION * 2 || height / sample > MAX_IMAGE_DIMENSION * 2) {
            sample *= 2
        }
        return sample
    }

    private fun rotate(bitmap: Bitmap, orientation: Int): Bitmap {
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return bitmap
        val rotated = Bitmap.createBitmap(
            bitmap,
            0,
            0,
            bitmap.width,
            bitmap.height,
            Matrix().apply { postRotate(degrees) },
            true,
        )
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }

    private fun writeBoundedJpeg(bitmap: Bitmap, destination: File): Boolean {
        var quality = JPEG_START_QUALITY
        do {
            FileOutputStream(destination, false).use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)) return false
                output.fd.sync()
            }
            if (destination.length() <= RequestDraftPolicy.MAX_IMAGE_BYTES) return true
            quality -= JPEG_QUALITY_STEP
        } while (quality >= JPEG_MIN_QUALITY)
        return false
    }

    private fun hasEnoughSpace(): Boolean = StatFs(imageRoot.absolutePath).availableBytes >= MIN_FREE_SPACE_BYTES

    private fun findImageFile(attachment: RequestAttachmentRef): File? =
        File(imageRoot, "${attachment.id.value}.jpg").takeIf(File::exists)

    private fun safeCameraFile(path: String): File? {
        val file = File(path).canonicalFile
        return file.takeIf { it.toPath().startsWith(cameraRoot.canonicalFile.toPath()) }
    }

    private fun ensurePrivateDirectory(directory: File) {
        check(directory.exists() || directory.mkdirs()) { "Unable to prepare private camera directory" }
    }
}
