package com.maxnetwork.feature.request.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        RequestDraftEntity::class,
        RequestAttachmentEntity::class,
        RequestOutboxEntity::class,
        RequestOutboxAttachmentEntity::class,
    ],
    version = 2,
    exportSchema = true,
)
internal abstract class RequestDraftDatabase : RoomDatabase() {
    abstract fun requestDraftDao(): RequestDraftDao
    abstract fun requestOutboxDao(): RequestOutboxDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS request_outbox (
                        idempotencyKey TEXT NOT NULL PRIMARY KEY,
                        draftId TEXT NOT NULL,
                        text TEXT NOT NULL,
                        imageAttachmentId TEXT,
                        audioAttachmentId TEXT,
                        state TEXT NOT NULL,
                        attemptCount INTEGER NOT NULL,
                        lastError TEXT,
                        imageUploadId TEXT,
                        audioUploadId TEXT,
                        serverRequestId TEXT,
                        acceptedAtEpochMillis INTEGER,
                        createdAtEpochMillis INTEGER NOT NULL,
                        updatedAtEpochMillis INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_request_outbox_draftId ON request_outbox(draftId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_request_outbox_state ON request_outbox(state)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS request_outbox_attachments (
                        idempotencyKey TEXT NOT NULL,
                        kind TEXT NOT NULL,
                        attachmentId TEXT NOT NULL,
                        privateRelativePath TEXT NOT NULL,
                        mimeType TEXT NOT NULL,
                        byteSize INTEGER NOT NULL,
                        durationSeconds INTEGER,
                        PRIMARY KEY(idempotencyKey, kind)
                    )
                    """.trimIndent(),
                )
            }
        }
    }
}
