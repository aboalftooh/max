package com.maxnetwork.feature.request.data.local

import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.domain.RequestContent
import com.maxnetwork.feature.request.domain.RequestDraft
import com.maxnetwork.feature.request.domain.RequestDraftId
import com.maxnetwork.feature.request.domain.RequestSource
import com.maxnetwork.feature.request.domain.RequestStatus
import java.time.Instant

internal data class PersistedRequestDraft(
    val draft: RequestDraft,
    val attachmentPaths: Map<LocalAttachmentId, String>,
)

internal fun RequestDraft.toEntities(
    attachmentPaths: Map<LocalAttachmentId, String>,
): Pair<RequestDraftEntity, List<RequestAttachmentEntity>> {
    val draftEntity = RequestDraftEntity(
        id = id.value,
        text = content.text,
        imageAttachmentId = content.image?.id?.value,
        audioAttachmentId = content.audio?.id?.value,
        updatedAtEpochMillis = updatedAt.toEpochMilli(),
    )
    val attachments = listOfNotNull(content.image, content.audio).map { attachment ->
        RequestAttachmentEntity(
            id = attachment.id.value,
            draftId = id.value,
            kind = attachment.kind.name,
            privateRelativePath = requireNotNull(attachmentPaths[attachment.id]) {
                "Private attachment path is required for ${attachment.id.value}"
            },
            mimeType = attachment.mimeType,
            byteSize = attachment.byteSize,
            durationSeconds = attachment.durationSeconds,
        )
    }
    return draftEntity to attachments
}

internal fun RequestDraftWithAttachments.toDomain(): PersistedRequestDraft {
    val refs = attachments.associateBy { it.id }
    fun attachment(id: String?, expectedKind: RequestAttachmentKind): RequestAttachmentRef? {
        val entity = id?.let(refs::get) ?: return null
        val kind = RequestAttachmentKind.valueOf(entity.kind)
        require(kind == expectedKind) { "Attachment kind does not match draft slot" }
        return RequestAttachmentRef(
            id = LocalAttachmentId(entity.id),
            kind = kind,
            mimeType = entity.mimeType,
            byteSize = entity.byteSize,
            durationSeconds = entity.durationSeconds,
        )
    }
    return PersistedRequestDraft(
        draft = RequestDraft(
            id = RequestDraftId(draft.id),
            content = RequestContent(
                text = draft.text,
                image = attachment(draft.imageAttachmentId, RequestAttachmentKind.Image),
                audio = attachment(draft.audioAttachmentId, RequestAttachmentKind.Audio),
            ),
            status = RequestStatus.Draft,
            source = RequestSource.App,
            updatedAt = Instant.ofEpochMilli(draft.updatedAtEpochMillis),
        ),
        attachmentPaths = attachments.associate { LocalAttachmentId(it.id) to it.privateRelativePath },
    )
}
