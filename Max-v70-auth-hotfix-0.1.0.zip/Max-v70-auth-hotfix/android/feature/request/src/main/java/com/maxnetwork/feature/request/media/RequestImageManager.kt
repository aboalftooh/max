package com.maxnetwork.feature.request.media

import android.graphics.Bitmap
import android.net.Uri
import com.maxnetwork.feature.request.domain.RequestAttachmentRef

data class CameraCaptureTarget(
    val uri: Uri,
    val privateTempPath: String,
)

data class ImportedRequestImage(
    val attachment: RequestAttachmentRef,
    val preview: Bitmap,
)

sealed interface ImageImportResult {
    data class Success(val image: ImportedRequestImage) : ImageImportResult
    data class Failure(val reason: ImageImportFailure) : ImageImportResult
}

enum class ImageImportFailure {
    Cancelled,
    PermissionLost,
    NotEnoughSpace,
    UnsupportedImage,
    TooLarge,
    ReadFailed,
    WriteFailed,
}

interface RequestImageManager {
    fun createCameraTarget(): CameraCaptureTarget
    suspend fun importFromPicker(uri: Uri): ImageImportResult
    suspend fun importFromCamera(target: CameraCaptureTarget): ImageImportResult
    suspend fun loadPreview(attachment: RequestAttachmentRef): Bitmap?
    suspend fun delete(attachment: RequestAttachmentRef)
    fun discardCameraTarget(target: CameraCaptureTarget)
}
