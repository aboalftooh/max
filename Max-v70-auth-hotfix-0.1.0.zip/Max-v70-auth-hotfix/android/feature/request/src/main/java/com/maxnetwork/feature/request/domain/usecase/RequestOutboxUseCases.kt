package com.maxnetwork.feature.request.domain.usecase

import com.maxnetwork.feature.request.domain.RequestContent
import com.maxnetwork.feature.request.domain.RequestDraftId
import com.maxnetwork.feature.request.domain.RequestOutboxRepository

class ObserveRequestOutboxUseCase(private val repository: RequestOutboxRepository) {
    operator fun invoke() = repository.observeLatest()
}

class EnqueueRequestUseCase(private val repository: RequestOutboxRepository) {
    suspend operator fun invoke(draftId: RequestDraftId, content: RequestContent) = repository.enqueue(draftId, content)
}

class AcknowledgeAcceptedRequestUseCase(private val repository: RequestOutboxRepository) {
    suspend operator fun invoke(key: com.maxnetwork.feature.request.domain.RequestIdempotencyKey) = repository.acknowledge(key)
}
