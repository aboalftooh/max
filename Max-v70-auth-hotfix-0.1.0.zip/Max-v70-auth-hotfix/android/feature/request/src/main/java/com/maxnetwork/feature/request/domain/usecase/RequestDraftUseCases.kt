package com.maxnetwork.feature.request.domain.usecase

import com.maxnetwork.core.common.ClockProvider
import com.maxnetwork.feature.request.domain.DraftSaveResult
import com.maxnetwork.feature.request.domain.RequestContent
import com.maxnetwork.feature.request.domain.RequestDraft
import com.maxnetwork.feature.request.domain.RequestDraftId
import com.maxnetwork.feature.request.domain.RequestDraftRepository
import com.maxnetwork.feature.request.domain.RequestDraftPolicy
import com.maxnetwork.feature.request.domain.RequestSource
import com.maxnetwork.feature.request.domain.RequestStatus
import com.maxnetwork.feature.request.domain.RequestValidationResult
import kotlinx.coroutines.flow.Flow

class ObserveRequestDraftUseCase(private val repository: RequestDraftRepository) {
    operator fun invoke(): Flow<RequestDraft?> = repository.observeActiveDraft()
}

class LoadRequestDraftUseCase(private val repository: RequestDraftRepository) {
    suspend operator fun invoke(): RequestDraft? = repository.loadActiveDraft()
}

class SaveRequestDraftUseCase(
    private val repository: RequestDraftRepository,
    private val clockProvider: ClockProvider,
) {
    suspend operator fun invoke(
        id: RequestDraftId,
        content: RequestContent,
    ): DraftSaveResult = repository.saveDraft(
        RequestDraft(
            id = id,
            content = content.normalized(),
            status = RequestStatus.Draft,
            source = RequestSource.App,
            updatedAt = clockProvider.now(),
        ),
    )
}

class DeleteRequestDraftUseCase(private val repository: RequestDraftRepository) {
    suspend operator fun invoke() = repository.deleteDraft()
}

class ValidateRequestContentUseCase {
    operator fun invoke(content: RequestContent): RequestValidationResult = RequestDraftPolicy.validate(content)
}
