package com.maxnetwork.feature.request.data

import androidx.room.withTransaction
import com.maxnetwork.feature.request.data.local.RequestDraftDatabase
import com.maxnetwork.feature.request.data.local.toDomain
import com.maxnetwork.feature.request.data.local.toEntities
import com.maxnetwork.feature.request.domain.DraftSaveResult
import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestDraft
import com.maxnetwork.feature.request.domain.RequestDraftRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.File

internal class DefaultRequestDraftRepository(
    private val database: RequestDraftDatabase,
    private val attachmentRoot: File,
) : RequestDraftRepository {
    private val dao = database.requestDraftDao()

    override fun observeActiveDraft(): Flow<RequestDraft?> = dao.observeDraftEntity().map {
        dao.loadDraft()?.toDomain()?.draft
    }

    override suspend fun loadActiveDraft(): RequestDraft? = dao.loadDraft()?.toDomain()?.draft

    override suspend fun saveDraft(draft: RequestDraft): DraftSaveResult {
        val paths = listOfNotNull(draft.content.image, draft.content.audio).associate { attachment ->
            attachment.id to resolveExistingPrivatePath(attachment.id)
        }
        val (draftEntity, attachments) = draft.toEntities(paths)
        database.withTransaction { dao.replaceDraft(draftEntity, attachments) }
        return DraftSaveResult(draft = draft)
    }

    override suspend fun deleteDraft() {
        val persisted = dao.loadDraft()?.toDomain()
        database.withTransaction {
            dao.deleteAttachmentsForDraft(persisted?.draft?.id?.value.orEmpty())
            dao.deleteDraftRows()
        }
        persisted?.attachmentPaths?.values?.forEach { relativePath ->
            File(attachmentRoot, relativePath).takeIf(File::exists)?.delete()
        }
    }

    private fun resolveExistingPrivatePath(id: LocalAttachmentId): String {
        val candidate = attachmentRoot.walkTopDown()
            .firstOrNull { file -> file.isFile && file.nameWithoutExtension == id.value }
            ?: error("Attachment file is not stored in the app-private attachment directory")
        val rootPath = attachmentRoot.canonicalFile.toPath()
        val candidatePath = candidate.canonicalFile.toPath()
        require(candidatePath.startsWith(rootPath)) { "Attachment path escaped the private directory" }
        return rootPath.relativize(candidatePath).toString()
    }
}
