package com.maxnetwork.feature.request.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
internal interface RequestOutboxDao {
    @Query("SELECT * FROM request_outbox ORDER BY createdAtEpochMillis DESC LIMIT 1")
    fun observeLatest(): Flow<RequestOutboxEntity?>

    @Query("SELECT * FROM request_outbox WHERE idempotencyKey = :key")
    suspend fun get(key: String): RequestOutboxEntity?

    @Query("SELECT * FROM request_outbox WHERE state IN ('Pending','RetryableFailure','UploadingImage','UploadingAudio','Submitting') ORDER BY createdAtEpochMillis ASC LIMIT 1")
    suspend fun nextProcessable(): RequestOutboxEntity?

    @Query("SELECT * FROM request_outbox_attachments WHERE idempotencyKey = :key")
    suspend fun attachments(key: String): List<RequestOutboxAttachmentEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(entity: RequestOutboxEntity): Long

    @Upsert
    suspend fun upsertAttachment(entity: RequestOutboxAttachmentEntity)

    @Query("UPDATE request_outbox SET state = :state, lastError = :error, attemptCount = attemptCount + :attemptDelta, updatedAtEpochMillis = :updatedAt WHERE idempotencyKey = :key")
    suspend fun updateState(key: String, state: String, error: String?, attemptDelta: Int, updatedAt: Long)

    @Query("UPDATE request_outbox SET imageUploadId = :uploadId, updatedAtEpochMillis = :updatedAt WHERE idempotencyKey = :key")
    suspend fun setImageUploadId(key: String, uploadId: String, updatedAt: Long)

    @Query("UPDATE request_outbox SET audioUploadId = :uploadId, updatedAtEpochMillis = :updatedAt WHERE idempotencyKey = :key")
    suspend fun setAudioUploadId(key: String, uploadId: String, updatedAt: Long)

    @Query("UPDATE request_outbox SET state = 'Accepted', serverRequestId = :requestId, acceptedAtEpochMillis = :acceptedAt, lastError = NULL, updatedAtEpochMillis = :acceptedAt WHERE idempotencyKey = :key")
    suspend fun markAccepted(key: String, requestId: String, acceptedAt: Long)

    @Transaction
    suspend fun insertWithAttachments(
        entity: RequestOutboxEntity,
        attachments: List<RequestOutboxAttachmentEntity>,
    ): Boolean {
        val inserted = insert(entity) != -1L
        if (inserted) attachments.forEach { upsertAttachment(it) }
        return inserted
    }
}
