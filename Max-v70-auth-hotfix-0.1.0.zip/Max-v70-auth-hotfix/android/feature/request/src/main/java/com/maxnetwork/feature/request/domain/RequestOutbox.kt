package com.maxnetwork.feature.request.domain

import java.time.Instant
import kotlinx.coroutines.flow.Flow

@JvmInline
value class RequestIdempotencyKey(val value: String) {
    init { require(value.isNotBlank()) }
}

enum class RequestOutboxState {
    Pending,
    UploadingImage,
    UploadingAudio,
    Submitting,
    Accepted,
    Acknowledged,
    RetryableFailure,
    PermanentFailure,
}

data class RequestOutboxItem(
    val key: RequestIdempotencyKey,
    val draftId: RequestDraftId,
    val content: RequestContent,
    val state: RequestOutboxState,
    val attemptCount: Int,
    val lastError: String?,
    val serverRequestId: String?,
    val acceptedAt: Instant?,
    val createdAt: Instant,
    val updatedAt: Instant,
) {
    init {
        require(attemptCount >= 0)
        val receiptRequired = state == RequestOutboxState.Accepted || state == RequestOutboxState.Acknowledged
        require(receiptRequired == (serverRequestId != null && acceptedAt != null))
    }

    val isTerminal: Boolean get() = state in setOf(
        RequestOutboxState.Accepted,
        RequestOutboxState.Acknowledged,
        RequestOutboxState.PermanentFailure,
    )

    /** v48 backend contract uses a deterministic conversation id for every accepted request. */
    val conversationId: String? get() = serverRequestId?.let { "conversation-$it" }
}

data class OutboxEnqueueResult(
    val item: RequestOutboxItem,
    val created: Boolean,
    val financialMovementCreated: Boolean = false,
) {
    init { require(!financialMovementCreated) { "Request submission must never create a financial movement" } }
}

interface RequestOutboxRepository {
    fun observeLatest(): Flow<RequestOutboxItem?>
    suspend fun enqueue(draftId: RequestDraftId, content: RequestContent): OutboxEnqueueResult
    suspend fun loadNextProcessable(): RequestOutboxItem?
    suspend fun updateState(key: RequestIdempotencyKey, state: RequestOutboxState, error: String? = null)
    suspend fun saveUploadId(key: RequestIdempotencyKey, kind: RequestAttachmentKind, uploadId: String)
    suspend fun uploadId(key: RequestIdempotencyKey, kind: RequestAttachmentKind): String?
    suspend fun attachmentBytes(key: RequestIdempotencyKey, kind: RequestAttachmentKind): ByteArray?
    suspend fun markAccepted(key: RequestIdempotencyKey, requestId: String, acceptedAt: Instant)
    suspend fun acknowledge(key: RequestIdempotencyKey)
}
