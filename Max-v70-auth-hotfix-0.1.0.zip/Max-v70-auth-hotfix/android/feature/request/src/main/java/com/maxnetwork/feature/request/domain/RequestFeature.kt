package com.maxnetwork.feature.request.domain

/** Public feature capability; navigation and wiring remain in :app. */
object RequestFeature {
    const val ROUTE = "request"
}
