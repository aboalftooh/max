package com.maxnetwork.feature.request.data.outbox

import com.maxnetwork.core.network.ApiError
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.MediaType
import com.maxnetwork.core.network.MediaUploadIntent
import com.maxnetwork.core.network.MediaUploadPayload
import com.maxnetwork.core.network.SubmitRequestCommand
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestIdempotencyKey
import com.maxnetwork.feature.request.domain.RequestOutboxItem
import com.maxnetwork.feature.request.domain.RequestOutboxRepository
import com.maxnetwork.feature.request.domain.RequestOutboxState

sealed interface RequestProcessResult {
    data object NothingToProcess : RequestProcessResult
    data class Accepted(val requestId: String) : RequestProcessResult
    data class Retry(val reason: String) : RequestProcessResult
    data class Rejected(val reason: String) : RequestProcessResult
}

class RequestOutboxProcessor(
    private val repository: RequestOutboxRepository,
    private val gateway: MaxGateway,
) {
    suspend fun processNext(): RequestProcessResult {
        val item = repository.loadNextProcessable() ?: return RequestProcessResult.NothingToProcess
        val imageUploadId = uploadIfRequired(item, RequestAttachmentKind.Image)
        if (imageUploadId is UploadOutcome.Failed) return imageUploadId.toProcessResult(item.key)
        val audioUploadId = uploadIfRequired(item, RequestAttachmentKind.Audio)
        if (audioUploadId is UploadOutcome.Failed) return audioUploadId.toProcessResult(item.key)

        repository.updateState(item.key, RequestOutboxState.Submitting)
        return when (
            val result = gateway.submitRequest(
                SubmitRequestCommand(
                    clientRequestId = item.key.value,
                    text = item.content.text.takeIf(String::isNotBlank),
                    imageUploadId = (imageUploadId as UploadOutcome.Ready).uploadId,
                    audioUploadId = (audioUploadId as UploadOutcome.Ready).uploadId,
                ),
            )
        ) {
            is GatewayResult.Success -> {
                repository.markAccepted(item.key, result.value.requestId, result.value.acceptedAt)
                RequestProcessResult.Accepted(result.value.requestId)
            }
            is GatewayResult.Failure -> handleFailure(item.key, result.error)
        }
    }

    private suspend fun uploadIfRequired(
        item: RequestOutboxItem,
        kind: RequestAttachmentKind,
    ): UploadOutcome {
        val attachment = when (kind) {
            RequestAttachmentKind.Image -> item.content.image
            RequestAttachmentKind.Audio -> item.content.audio
        } ?: return UploadOutcome.Ready(null)
        repository.uploadId(item.key, kind)?.let { return UploadOutcome.Ready(it) }
        repository.updateState(
            item.key,
            if (kind == RequestAttachmentKind.Image) RequestOutboxState.UploadingImage else RequestOutboxState.UploadingAudio,
        )
        val slot = when (
            val result = gateway.createMediaUploadIntent(
                MediaUploadIntent(
                    mediaType = if (kind == RequestAttachmentKind.Image) MediaType.Image else MediaType.Audio,
                    contentType = attachment.mimeType,
                    contentLengthBytes = attachment.byteSize,
                ),
            )
        ) {
            is GatewayResult.Success -> result.value
            is GatewayResult.Failure -> return UploadOutcome.Failed(result.error)
        }
        val bytes = repository.attachmentBytes(item.key, kind)
            ?: return UploadOutcome.Failed(attachmentMissingError())
        return when (val upload = gateway.uploadMedia(slot, MediaUploadPayload(attachment.mimeType, bytes))) {
            is GatewayResult.Success -> {
                repository.saveUploadId(item.key, kind, slot.uploadId)
                UploadOutcome.Ready(slot.uploadId)
            }
            is GatewayResult.Failure -> UploadOutcome.Failed(upload.error)
        }
    }

    private suspend fun UploadOutcome.Failed.toProcessResult(key: RequestIdempotencyKey): RequestProcessResult =
        handleFailure(key, error)

    private suspend fun handleFailure(
        key: RequestIdempotencyKey,
        error: ApiError,
    ): RequestProcessResult {
        val state = if (error.retryable) RequestOutboxState.RetryableFailure else RequestOutboxState.PermanentFailure
        repository.updateState(key, state, error.message)
        return if (error.retryable) RequestProcessResult.Retry(error.message) else RequestProcessResult.Rejected(error.message)
    }
}

private sealed interface UploadOutcome {
    data class Ready(val uploadId: String?) : UploadOutcome
    data class Failed(val error: ApiError) : UploadOutcome
}

private fun attachmentMissingError(): ApiError = ApiError(
    code = com.maxnetwork.core.network.ApiErrorCode.AttachmentRejected,
    message = "ملف المرفق غير موجود",
    traceId = "local-attachment-missing",
    retryable = false,
)
