package com.maxnetwork.feature.request.presentation

import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.domain.RequestContent
import com.maxnetwork.feature.request.domain.RequestDraftPolicy
import com.maxnetwork.feature.request.domain.RequestValidationError
import com.maxnetwork.feature.request.domain.RequestValidationResult

enum class RequestComposerPhase {
    Loading,
    Draft,
    Uploading,
    Pending,
    Accepted,
    Failed,
}

data class RequestPartUiState(
    val content: RequestContent = RequestContent(),
    val phase: RequestComposerPhase = RequestComposerPhase.Loading,
    val message: String? = null,
) {
    val canSubmit: Boolean
        get() = phase != RequestComposerPhase.Loading &&
            phase !in setOf(RequestComposerPhase.Uploading, RequestComposerPhase.Pending, RequestComposerPhase.Accepted) &&
            RequestDraftPolicy.validate(content) == RequestValidationResult.Valid
}

sealed interface RequestComposerCommand {
    data object None : RequestComposerCommand
    data class Persist(val content: RequestContent) : RequestComposerCommand
    data class Submit(val content: RequestContent) : RequestComposerCommand
}

sealed interface RequestComposerAction {
    data class DraftLoaded(val content: RequestContent?) : RequestComposerAction
    data class TextChanged(val value: String) : RequestComposerAction
    data class ImageChanged(val attachment: RequestAttachmentRef?) : RequestComposerAction
    data class AudioChanged(val attachment: RequestAttachmentRef?) : RequestComposerAction
    data object SubmitClicked : RequestComposerAction
    data object RetryClicked : RequestComposerAction
    data object SubmissionPending : RequestComposerAction
    data class SubmissionFailed(val message: String) : RequestComposerAction
    data object SubmissionAccepted : RequestComposerAction
}

data class RequestComposerTransition(
    val state: RequestPartUiState,
    val command: RequestComposerCommand = RequestComposerCommand.None,
)

class RequestComposerReducer(
    initialState: RequestPartUiState = RequestPartUiState(),
) {
    var state: RequestPartUiState = initialState
        private set

    fun dispatch(action: RequestComposerAction): RequestComposerTransition {
        val transition = when (action) {
            is RequestComposerAction.DraftLoaded -> transition(
                state.copy(
                    content = action.content ?: RequestContent(),
                    phase = RequestComposerPhase.Draft,
                    message = null,
                ),
            )
            is RequestComposerAction.TextChanged -> contentChanged(state.content.copy(text = action.value))
            is RequestComposerAction.ImageChanged -> contentChanged(state.content.copy(image = action.attachment))
            is RequestComposerAction.AudioChanged -> contentChanged(state.content.copy(audio = action.attachment))
            RequestComposerAction.SubmitClicked -> submit(state.content)
            RequestComposerAction.RetryClicked -> submit(state.content)
            RequestComposerAction.SubmissionPending -> transition(
                state.copy(phase = RequestComposerPhase.Pending, message = "تم حفظ الطلب وسيرسل عند توفر الإنترنت."),
            )
            is RequestComposerAction.SubmissionFailed -> transition(
                state.copy(phase = RequestComposerPhase.Failed, message = action.message),
            )
            RequestComposerAction.SubmissionAccepted -> transition(
                state.copy(phase = RequestComposerPhase.Accepted, message = null),
            )
        }
        state = transition.state
        return transition
    }

    private fun contentChanged(content: RequestContent) = transition(
        state.copy(content = content, phase = RequestComposerPhase.Draft, message = null),
        RequestComposerCommand.Persist(content),
    )

    private fun submit(content: RequestContent): RequestComposerTransition = when (val result = RequestDraftPolicy.validate(content)) {
        RequestValidationResult.Valid -> transition(
            state.copy(phase = RequestComposerPhase.Uploading, message = null),
            RequestComposerCommand.Submit(content.normalized()),
        )
        is RequestValidationResult.Invalid -> transition(
            state.copy(phase = RequestComposerPhase.Failed, message = result.reason.toArabicMessage()),
        )
    }

    private fun transition(
        next: RequestPartUiState,
        command: RequestComposerCommand = RequestComposerCommand.None,
    ) = RequestComposerTransition(next, command)
}

internal fun RequestValidationError.toArabicMessage(): String = when (this) {
    RequestValidationError.EmptyContent -> "أضف وصفًا أو صورة أو تسجيلًا صوتيًا."
    RequestValidationError.TextTooLong -> "النص أطول من الحد المسموح."
    RequestValidationError.UnsupportedImageType -> "صيغة الصورة غير مدعومة."
    RequestValidationError.ImageTooLarge -> "حجم الصورة أكبر من المسموح."
    RequestValidationError.UnsupportedAudioType -> "صيغة التسجيل غير مدعومة."
    RequestValidationError.AudioTooLong -> "التسجيل أطول من 60 ثانية."
    RequestValidationError.AudioTooLarge -> "حجم التسجيل أكبر من المسموح."
    RequestValidationError.AttachmentsTooLarge -> "الحجم الإجمالي للمرفقات أكبر من المسموح."
}
