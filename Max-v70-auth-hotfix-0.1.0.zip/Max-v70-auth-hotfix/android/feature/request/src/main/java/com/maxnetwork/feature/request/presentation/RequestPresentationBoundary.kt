package com.maxnetwork.feature.request.presentation

/** Placeholder boundary. Presentation must not access DAO or network clients directly. */
internal object RequestPresentationBoundary
