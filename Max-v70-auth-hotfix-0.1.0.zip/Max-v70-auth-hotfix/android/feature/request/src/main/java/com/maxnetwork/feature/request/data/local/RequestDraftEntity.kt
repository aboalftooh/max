package com.maxnetwork.feature.request.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "request_drafts")
internal data class RequestDraftEntity(
    @PrimaryKey val id: String,
    val text: String,
    val imageAttachmentId: String?,
    val audioAttachmentId: String?,
    val updatedAtEpochMillis: Long,
)

@Entity(tableName = "request_attachment_refs")
internal data class RequestAttachmentEntity(
    @PrimaryKey val id: String,
    val draftId: String,
    val kind: String,
    val privateRelativePath: String,
    val mimeType: String,
    val byteSize: Long,
    val durationSeconds: Int?,
)
