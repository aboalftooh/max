package com.maxnetwork.feature.request.media

import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.domain.RequestDraftPolicy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

internal const val AUDIO_TICK_MILLIS = 1_000L

data class AudioCaptureTarget(
    val id: LocalAttachmentId,
    val file: File,
)

interface AudioRecorderEngine {
    val isRecording: Boolean
    fun start(target: AudioCaptureTarget, onInterrupted: () -> Unit)
    fun stop()
    fun cancel()
}

interface AudioPlayerEngine {
    val isPlaying: Boolean
    fun play(file: File, onCompleted: () -> Unit)
    fun stop()
}

interface AudioFileStore {
    fun createCaptureTarget(): AudioCaptureTarget
    fun finalizeCapture(target: AudioCaptureTarget, durationSeconds: Int): AudioFinalizeResult
    fun resolve(attachment: RequestAttachmentRef): File?
    fun delete(attachment: RequestAttachmentRef)
    fun discard(target: AudioCaptureTarget)
}

sealed interface AudioFinalizeResult {
    data class Success(val attachment: RequestAttachmentRef) : AudioFinalizeResult
    data class Failure(val reason: RequestAudioFailure) : AudioFinalizeResult
}

enum class RequestAudioFailure {
    PermissionDenied,
    RecorderUnavailable,
    RecordingTooShort,
    RecordingTooLong,
    FileTooLarge,
    FileMissing,
    PlaybackUnavailable,
    Interrupted,
}

sealed interface RequestAudioState {
    data object Idle : RequestAudioState
    data class Recording(val elapsedSeconds: Int) : RequestAudioState
    data class Ready(val attachment: RequestAttachmentRef, val durationSeconds: Int) : RequestAudioState
    data class Playing(val attachment: RequestAttachmentRef, val durationSeconds: Int) : RequestAudioState
    data class Failed(val reason: RequestAudioFailure, val previous: RequestAttachmentRef? = null) : RequestAudioState
}

sealed interface AudioCaptureResult {
    data class Success(val attachment: RequestAttachmentRef) : AudioCaptureResult
    data class Failure(val reason: RequestAudioFailure) : AudioCaptureResult
}

class RequestAudioController(
    private val recorder: AudioRecorderEngine,
    private val player: AudioPlayerEngine,
    private val fileStore: AudioFileStore,
    private val scope: CoroutineScope,
    private val elapsedRealtimeMillis: () -> Long,
) {
    private val mutableState = MutableStateFlow<RequestAudioState>(RequestAudioState.Idle)
    val state: StateFlow<RequestAudioState> = mutableState.asStateFlow()

    private var target: AudioCaptureTarget? = null
    private var recordingStartedAt = 0L
    private var timer: Job? = null

    fun restore(attachment: RequestAttachmentRef?) {
        if (recorder.isRecording || player.isPlaying) return
        mutableState.value = if (attachment == null) {
            RequestAudioState.Idle
        } else {
            RequestAudioState.Ready(attachment, attachment.durationSeconds ?: 0)
        }
    }

    fun start(): AudioCaptureResult? {
        if (recorder.isRecording) return null
        player.stop()
        val newTarget = runCatching(fileStore::createCaptureTarget).getOrElse {
            mutableState.value = RequestAudioState.Failed(RequestAudioFailure.RecorderUnavailable)
            return AudioCaptureResult.Failure(RequestAudioFailure.RecorderUnavailable)
        }
        return runCatching {
            recorder.start(newTarget) { scope.launch { stop(interrupted = true) } }
            target = newTarget
            recordingStartedAt = elapsedRealtimeMillis()
            mutableState.value = RequestAudioState.Recording(0)
            startTimer()
            null
        }.getOrElse {
            fileStore.discard(newTarget)
            mutableState.value = RequestAudioState.Failed(RequestAudioFailure.RecorderUnavailable)
            AudioCaptureResult.Failure(RequestAudioFailure.RecorderUnavailable)
        }
    }

    suspend fun stop(interrupted: Boolean = false): AudioCaptureResult {
        val active = target ?: return AudioCaptureResult.Failure(RequestAudioFailure.RecordingTooShort)
        target = null
        timer?.cancel()
        timer = null
        val duration = elapsedSeconds().coerceAtMost(RequestDraftPolicy.MAX_AUDIO_DURATION_SECONDS)
        runCatching(recorder::stop).onFailure {
            fileStore.discard(active)
            mutableState.value = RequestAudioState.Failed(RequestAudioFailure.RecordingTooShort)
            return AudioCaptureResult.Failure(RequestAudioFailure.RecordingTooShort)
        }
        return when (val finalized = fileStore.finalizeCapture(active, duration)) {
            is AudioFinalizeResult.Success -> {
                mutableState.value = RequestAudioState.Ready(finalized.attachment, duration)
                AudioCaptureResult.Success(finalized.attachment)
            }
            is AudioFinalizeResult.Failure -> {
                mutableState.value = RequestAudioState.Failed(
                    reason = if (interrupted && finalized.reason == RequestAudioFailure.RecordingTooShort) {
                        RequestAudioFailure.Interrupted
                    } else {
                        finalized.reason
                    },
                )
                AudioCaptureResult.Failure(finalized.reason)
            }
        }
    }

    fun play(attachment: RequestAttachmentRef) {
        val file = fileStore.resolve(attachment)
        if (file == null) {
            mutableState.value = RequestAudioState.Failed(RequestAudioFailure.FileMissing, attachment)
            return
        }
        runCatching {
            player.play(file) {
                mutableState.value = RequestAudioState.Ready(attachment, attachment.durationSeconds ?: 0)
            }
            mutableState.value = RequestAudioState.Playing(attachment, attachment.durationSeconds ?: 0)
        }.onFailure {
            mutableState.value = RequestAudioState.Failed(RequestAudioFailure.PlaybackUnavailable, attachment)
        }
    }

    fun stopPlayback() {
        val current = mutableState.value
        player.stop()
        if (current is RequestAudioState.Playing) {
            mutableState.value = RequestAudioState.Ready(current.attachment, current.durationSeconds)
        }
    }

    fun delete(attachment: RequestAttachmentRef) {
        stopPlayback()
        fileStore.delete(attachment)
        mutableState.value = RequestAudioState.Idle
    }

    fun reportPermissionDenied() {
        mutableState.value = RequestAudioState.Failed(RequestAudioFailure.PermissionDenied)
    }

    fun onHostStopped() {
        stopPlayback()
        if (recorder.isRecording) scope.launch { stop(interrupted = true) }
    }

    fun close() {
        timer?.cancel()
        timer = null
        player.stop()
        recorder.cancel()
        target?.let(fileStore::discard)
        target = null
        if (mutableState.value is RequestAudioState.Recording) mutableState.value = RequestAudioState.Idle
    }

    suspend fun enforceDurationLimitNow() {
        if (recorder.isRecording && elapsedSeconds() >= RequestDraftPolicy.MAX_AUDIO_DURATION_SECONDS) {
            stop()
        }
    }

    private fun startTimer() {
        timer?.cancel()
        timer = scope.launch {
            while (recorder.isRecording) {
                delay(AUDIO_TICK_MILLIS)
                val elapsed = elapsedSeconds()
                mutableState.value = RequestAudioState.Recording(elapsed)
                if (elapsed >= RequestDraftPolicy.MAX_AUDIO_DURATION_SECONDS) {
                    stop()
                    break
                }
            }
        }
    }

    private fun elapsedSeconds(): Int =
        ((elapsedRealtimeMillis() - recordingStartedAt).coerceAtLeast(0L) / 1_000L).toInt()
}

class PrivateAudioFileStore(private val audioRoot: File) : AudioFileStore {
    init {
        check(audioRoot.exists() || audioRoot.mkdirs()) { "Unable to prepare private audio directory" }
    }

    override fun createCaptureTarget(): AudioCaptureTarget {
        val id = LocalAttachmentId(java.util.UUID.randomUUID().toString())
        return AudioCaptureTarget(id, File(audioRoot, "${id.value}.m4a"))
    }

    override fun finalizeCapture(target: AudioCaptureTarget, durationSeconds: Int): AudioFinalizeResult {
        if (!target.file.exists() || target.file.length() == 0L) {
            discard(target)
            return AudioFinalizeResult.Failure(RequestAudioFailure.RecordingTooShort)
        }
        if (durationSeconds > RequestDraftPolicy.MAX_AUDIO_DURATION_SECONDS) {
            discard(target)
            return AudioFinalizeResult.Failure(RequestAudioFailure.RecordingTooLong)
        }
        if (target.file.length() > RequestDraftPolicy.MAX_AUDIO_BYTES) {
            discard(target)
            return AudioFinalizeResult.Failure(RequestAudioFailure.FileTooLarge)
        }
        return AudioFinalizeResult.Success(
            RequestAttachmentRef(
                id = target.id,
                kind = RequestAttachmentKind.Audio,
                mimeType = "audio/mp4",
                byteSize = target.file.length(),
                durationSeconds = durationSeconds,
            ),
        )
    }

    override fun resolve(attachment: RequestAttachmentRef): File? =
        File(audioRoot, "${attachment.id.value}.m4a").takeIf(File::exists)

    override fun delete(attachment: RequestAttachmentRef) {
        resolve(attachment)?.delete()
    }

    override fun discard(target: AudioCaptureTarget) {
        target.file.takeIf(File::exists)?.delete()
    }
}
