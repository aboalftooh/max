package com.maxnetwork.feature.request.media

import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class RequestAudioControllerTest {
    @Test
    fun hostStopReleasesMicrophone() = runBlocking {
        val recorder = FakeRecorder()
        val controller = RequestAudioController(
            recorder,
            FakePlayer(),
            FakeStore(),
            CoroutineScope(Dispatchers.Unconfined),
        ) { 1_000L }
        controller.start()
        assertTrue(recorder.isRecording)
        controller.onHostStopped()
        assertFalse(recorder.isRecording)
    }
}

private class FakeRecorder : AudioRecorderEngine {
    override var isRecording = false
    private var interrupted: (() -> Unit)? = null
    override fun start(target: AudioCaptureTarget, onInterrupted: () -> Unit) {
        target.file.writeBytes(byteArrayOf(1, 2, 3))
        isRecording = true
        interrupted = onInterrupted
    }
    override fun stop() { isRecording = false }
    override fun cancel() { isRecording = false }
}

private class FakePlayer : AudioPlayerEngine {
    override var isPlaying = false
    override fun play(file: File, onCompleted: () -> Unit) { isPlaying = true }
    override fun stop() { isPlaying = false }
}

private class FakeStore : AudioFileStore {
    private val file = File.createTempFile("audio", ".m4a")
    override fun createCaptureTarget() = AudioCaptureTarget(LocalAttachmentId("audio"), file)
    override fun finalizeCapture(target: AudioCaptureTarget, durationSeconds: Int) = AudioFinalizeResult.Success(
        RequestAttachmentRef(target.id, RequestAttachmentKind.Audio, "audio/mp4", target.file.length(), durationSeconds),
    )
    override fun resolve(attachment: RequestAttachmentRef) = file
    override fun delete(attachment: RequestAttachmentRef) { file.delete() }
    override fun discard(target: AudioCaptureTarget) { target.file.delete() }
}
