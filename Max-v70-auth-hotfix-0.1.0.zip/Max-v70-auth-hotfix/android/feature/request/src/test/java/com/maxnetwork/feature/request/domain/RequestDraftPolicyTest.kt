package com.maxnetwork.feature.request.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class RequestDraftPolicyTest {
    @Test
    fun textImageAndAudioAreEachAcceptedAsRequestContent() {
        val image = RequestAttachmentRef(LocalAttachmentId("image"), RequestAttachmentKind.Image, "image/jpeg", 100)
        val audio = RequestAttachmentRef(LocalAttachmentId("audio"), RequestAttachmentKind.Audio, "audio/mp4", 100, 5)

        assertEquals(RequestValidationResult.Valid, RequestDraftPolicy.validate(RequestContent(text = "قطعة")))
        assertEquals(RequestValidationResult.Valid, RequestDraftPolicy.validate(RequestContent(image = image)))
        assertEquals(RequestValidationResult.Valid, RequestDraftPolicy.validate(RequestContent(audio = audio)))
    }

    @Test
    fun emptyContentIsRejectedWithShortReason() {
        assertEquals(
            RequestValidationResult.Invalid(RequestValidationError.EmptyContent),
            RequestDraftPolicy.validate(RequestContent()),
        )
    }

    @Test
    fun savingDraftCanNeverClaimFinancialMovement() {
        val draft = RequestDraft(
            id = RequestDraftId("draft"),
            content = RequestContent(text = "فلتر"),
            updatedAt = Instant.EPOCH,
        )
        val result = DraftSaveResult(draft)
        assertFalse(result.financialMovementCreated)
        assertTrue(result.draft.content.hasAnyContent())
    }
}
