package com.maxnetwork.feature.request.presentation

import androidx.compose.runtime.Composable
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.feature.request.domain.RequestContent

private val PreviewActions = RequestPartActions(
    onTextChanged = {},
    onImageChanged = {},
    onAudioChanged = {},
    onImageFailure = {},
    onAudioFailure = {},
    onSubmit = {},
    onRetry = {},
    onBack = {},
)

@MaxComponentPreviews
@Composable
private fun RequestDraftPreview() {
    MaxTheme {
        RequestPartScreen(
            state = RequestPartUiState(
                content = RequestContent(text = "مساعد أمامي كورولا 2015"),
                phase = RequestComposerPhase.Draft,
            ),
            imageManager = null,
            audioControllerFactory = null,
            actions = PreviewActions,
        )
    }
}

@MaxComponentPreviews
@Composable
private fun RequestLoadingPreview() {
    MaxTheme {
        RequestPartScreen(
            state = RequestPartUiState(phase = RequestComposerPhase.Loading),
            imageManager = null,
            audioControllerFactory = null,
            actions = PreviewActions,
        )
    }
}

@MaxComponentPreviews
@Composable
private fun RequestPendingPreview() {
    MaxTheme {
        RequestPartScreen(
            state = RequestPartUiState(
                content = RequestContent(text = "مساعد أمامي كورولا 2015"),
                phase = RequestComposerPhase.Pending,
                message = "تم حفظ الطلب وسيرسل عند توفر الإنترنت.",
            ),
            imageManager = null,
            audioControllerFactory = null,
            actions = PreviewActions,
        )
    }
}

@MaxComponentPreviews
@Composable
private fun RequestFailedPreview() {
    MaxTheme {
        RequestPartScreen(
            state = RequestPartUiState(
                content = RequestContent(text = "مساعد أمامي كورولا 2015"),
                phase = RequestComposerPhase.Failed,
                message = "تعذر الإرسال. حاول مرة أخرى.",
            ),
            imageManager = null,
            audioControllerFactory = null,
            actions = PreviewActions,
        )
    }
}
