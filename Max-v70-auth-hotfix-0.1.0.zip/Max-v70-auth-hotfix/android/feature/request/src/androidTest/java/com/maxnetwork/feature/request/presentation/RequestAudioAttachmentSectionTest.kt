package com.maxnetwork.feature.request.presentation

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.media.AudioCaptureTarget
import com.maxnetwork.feature.request.media.AudioFileStore
import com.maxnetwork.feature.request.media.AudioFinalizeResult
import com.maxnetwork.feature.request.media.AudioPlayerEngine
import com.maxnetwork.feature.request.media.AudioRecorderEngine
import com.maxnetwork.feature.request.media.RequestAudioController
import com.maxnetwork.feature.request.media.RequestAudioControllerFactory
import java.io.File
import org.junit.Rule
import org.junit.Test

class RequestAudioAttachmentSectionTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun permissionDeniedStateKeepsRecoveryActionUsable() {
        val harness = AudioHarness()
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                RequestAudioAttachmentSection(
                    controllerFactory = harness.factory,
                    currentAttachment = null,
                    onAttachmentChanged = {},
                    onFailure = {},
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.runOnIdle { harness.controller.reportPermissionDenied() }

        composeRule.onNodeWithTag("request_audio_permission_denied").assertIsDisplayed()
        composeRule.onNodeWithTag("request_audio_start").assertIsDisplayed()
        composeRule.onNodeWithTag("request_audio_permission_explanation").assertIsDisplayed()
    }

    @Test
    fun restoredAudioShowsPlaybackAndDeleteActions() {
        val harness = AudioHarness()
        val attachment = RequestAttachmentRef(
            id = LocalAttachmentId("audio-test"),
            kind = RequestAttachmentKind.Audio,
            mimeType = "audio/mp4",
            byteSize = 1L,
            durationSeconds = 12,
        )
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                RequestAudioAttachmentSection(
                    controllerFactory = harness.factory,
                    currentAttachment = attachment,
                    onAttachmentChanged = {},
                    onFailure = {},
                )
            }
        }

        composeRule.onNodeWithTag("request_audio_play").assertIsDisplayed()
        composeRule.onNodeWithTag("request_audio_delete").assertIsDisplayed()
    }
}

private class AudioHarness {
    lateinit var controller: RequestAudioController

    val factory = RequestAudioControllerFactory { scope ->
        RequestAudioController(
            recorder = FakeRecorder(),
            player = FakePlayer(),
            fileStore = FakeAudioStore(),
            scope = scope,
            elapsedRealtimeMillis = { 0L },
        ).also { controller = it }
    }
}

private class FakeRecorder : AudioRecorderEngine {
    override val isRecording: Boolean = false
    override fun start(target: AudioCaptureTarget, onInterrupted: () -> Unit) = Unit
    override fun stop() = Unit
    override fun cancel() = Unit
}

private class FakePlayer : AudioPlayerEngine {
    override val isPlaying: Boolean = false
    override fun play(file: File, onCompleted: () -> Unit) = Unit
    override fun stop() = Unit
}

private class FakeAudioStore : AudioFileStore {
    override fun createCaptureTarget(): AudioCaptureTarget = error("Not used")
    override fun finalizeCapture(target: AudioCaptureTarget, durationSeconds: Int): AudioFinalizeResult = error("Not used")
    override fun resolve(attachment: RequestAttachmentRef): File? = null
    override fun delete(attachment: RequestAttachmentRef) = Unit
    override fun discard(target: AudioCaptureTarget) = Unit
}
