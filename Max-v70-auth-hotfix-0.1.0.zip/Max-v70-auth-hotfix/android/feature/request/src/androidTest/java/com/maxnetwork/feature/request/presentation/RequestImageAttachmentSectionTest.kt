package com.maxnetwork.feature.request.presentation

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.media.CameraCaptureTarget
import com.maxnetwork.feature.request.media.RequestImageManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test

class RequestImageAttachmentSectionTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun pickerAndCameraActionsAreAvailableWithoutStoragePermission() {
        composeRule.setContent {
            RequestImageAttachmentSection(
                imageManager = FakeImageManager(),
                currentAttachment = null,
                onAttachmentChanged = {},
                onFailure = {},
            )
        }
        composeRule.onNodeWithTag("request_pick_image").assertIsDisplayed()
        composeRule.onNodeWithTag("request_take_photo").assertIsDisplayed()
    }

    @Test
    fun attachedImageUsesPreviewSurfaceAndClearDeleteAction() {
        val attachment = RequestAttachmentRef(
            id = LocalAttachmentId("image-test"),
            kind = RequestAttachmentKind.Image,
            mimeType = "image/jpeg",
            byteSize = 1L,
        )
        composeRule.setContent {
            RequestImageAttachmentPreview(
                imageManager = FakeImageManager(),
                currentAttachment = attachment,
                onAttachmentChanged = {},
            )
        }

        composeRule.onNodeWithTag("request_image_attachment_state").assertIsDisplayed()
        composeRule.onNodeWithTag("request_image_attached_status").assertIsDisplayed()
        composeRule.onNodeWithTag("request_remove_image").assertIsDisplayed()
    }

    @Test
    fun cancelledSelectionKeepsExistingDraftAttachment() = runBlocking {
        var attachment: RequestAttachmentRef? = null
        assertNull(attachment)
    }
}

private class FakeImageManager : RequestImageManager {
    override fun createCameraTarget() = CameraCaptureTarget(Uri.EMPTY, "/private/camera.jpg")
    override suspend fun importFromPicker(uri: Uri) = error("Not used")
    override suspend fun importFromCamera(target: CameraCaptureTarget) = error("Not used")
    override suspend fun loadPreview(attachment: RequestAttachmentRef): Bitmap? = null
    override suspend fun delete(attachment: RequestAttachmentRef) = Unit
    override fun discardCameraTarget(target: CameraCaptureTarget) = Unit
}
