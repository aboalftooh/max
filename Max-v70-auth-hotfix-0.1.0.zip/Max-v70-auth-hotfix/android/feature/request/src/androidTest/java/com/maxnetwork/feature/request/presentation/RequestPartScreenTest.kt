package com.maxnetwork.feature.request.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.Density
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.feature.request.domain.RequestContent
import org.junit.Rule
import org.junit.Test

class RequestPartScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun draftUsesDesignSystemFormAndUnifiedTopBar() {
        setRequestContent(
            RequestPartUiState(
                content = RequestContent(text = "مساعد أمامي كورولا 2015"),
                phase = RequestComposerPhase.Draft,
            ),
        )

        composeRule.onNodeWithTag("request_part_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("max_top_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("request_text_input").assertIsDisplayed()
        composeRule.onNodeWithTag("request_submit").assertIsDisplayed().assertIsEnabled()
    }

    @Test
    fun loadingUsesDesignSystemFeedbackState() {
        setRequestContent(RequestPartUiState(phase = RequestComposerPhase.Loading))

        composeRule.onNodeWithTag("request_loading_state").assertIsDisplayed()
        composeRule.onNodeWithTag("max_state_Loading").assertIsDisplayed()
    }

    @Test
    fun failedSubmissionUsesSemanticErrorBannerAndRetryAction() {
        setRequestContent(
            RequestPartUiState(
                content = RequestContent(text = "مساعد أمامي كورولا 2015"),
                phase = RequestComposerPhase.Failed,
                message = "تعذر الإرسال.",
            ),
        )

        composeRule.onNodeWithTag("request_failed_state").assertIsDisplayed()
        composeRule.onNodeWithTag("request_submit").assertIsDisplayed().assertIsEnabled()
    }

    @Test
    fun pendingSubmissionKeepsStatusVisible() {
        setRequestContent(
            RequestPartUiState(
                content = RequestContent(text = "مساعد أمامي كورولا 2015"),
                phase = RequestComposerPhase.Pending,
                message = "تم حفظ الطلب وسيرسل عند توفر الإنترنت.",
            ),
        )

        composeRule.onNodeWithTag("request_pending_state").assertIsDisplayed()
        composeRule.onNodeWithTag("request_submit").assertIsDisplayed()
    }

    @Test
    fun largeTextKeepsComposerAndPrimaryActionReachable() {
        setRequestContent(
            state = RequestPartUiState(
                content = RequestContent(text = "مساعد أمامي كورولا 2015"),
                phase = RequestComposerPhase.Draft,
            ),
            fontScale = 2f,
        )

        composeRule.onNodeWithTag("request_text_input").assertIsDisplayed()
        composeRule.onNodeWithTag("request_submit").assertIsDisplayed()
    }

    private fun setRequestContent(
        state: RequestPartUiState,
        fontScale: Float = 1f,
    ) {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                WithRequestFontScale(fontScale) {
                    RequestPartScreen(
                        state = state,
                        imageManager = null,
                        audioControllerFactory = null,
                        actions = RequestPartActions(
                            onTextChanged = {},
                            onImageChanged = {},
                            onAudioChanged = {},
                            onImageFailure = {},
                            onAudioFailure = {},
                            onSubmit = {},
                            onRetry = {},
                            onBack = {},
                        ),
                    )
                }
            }
        }
    }
}

@Composable
private fun WithRequestFontScale(
    fontScale: Float,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(density = density.density, fontScale = fontScale),
        content = content,
    )
}
