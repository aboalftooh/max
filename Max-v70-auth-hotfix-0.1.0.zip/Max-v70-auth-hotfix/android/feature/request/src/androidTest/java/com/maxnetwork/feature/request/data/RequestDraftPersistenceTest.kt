package com.maxnetwork.feature.request.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.maxnetwork.feature.request.data.local.RequestDraftDatabase
import com.maxnetwork.feature.request.data.local.RequestDraftEntity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RequestDraftPersistenceTest {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val databaseName = "request-draft-persistence-test.db"

    @After
    fun cleanup() {
        context.deleteDatabase(databaseName)
    }

    @Test
    fun draftRestoresAfterDatabaseIsClosedAndReopened() = runBlocking {
        val first = openDatabase()
        first.requestDraftDao().upsertDraft(
            RequestDraftEntity(
                id = "active",
                text = "طقم بواجي",
                imageAttachmentId = null,
                audioAttachmentId = null,
                updatedAtEpochMillis = 100L,
            ),
        )
        first.close()

        val second = openDatabase()
        val restored = second.requestDraftDao().getDraftEntity()
        assertNotNull(restored)
        assertEquals("طقم بواجي", restored?.text)
        second.close()
    }

    private fun openDatabase(): RequestDraftDatabase = Room.databaseBuilder(
        context,
        RequestDraftDatabase::class.java,
        databaseName,
    ).build()
}
