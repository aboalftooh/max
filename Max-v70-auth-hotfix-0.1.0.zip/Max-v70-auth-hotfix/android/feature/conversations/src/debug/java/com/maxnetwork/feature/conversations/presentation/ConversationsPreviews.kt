package com.maxnetwork.feature.conversations.presentation

import androidx.compose.runtime.Composable
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.feature.conversations.domain.ConversationAuthor
import com.maxnetwork.feature.conversations.domain.ConversationId
import com.maxnetwork.feature.conversations.domain.ConversationMessage
import com.maxnetwork.feature.conversations.domain.ConversationSummary
import java.time.Instant

@MaxComponentPreviews
@Composable
private fun ConversationsScreenPreview() {
    MaxTheme(motionEnabled = false) {
        ConversationsScreen(
            state = ConversationsListUiState(
                items = listOf(
                    previewConversation(
                        id = "conversation-1",
                        title = "مساعد أمامي كورولا 2015",
                        unreadCount = 3,
                    ),
                    previewConversation(
                        id = "conversation-2",
                        title = "فانوس خلفي هايلوكس",
                        unreadCount = 0,
                    ),
                ),
            ),
            onOpenConversation = {},
            onRetry = {},
            onBack = {},
        )
    }
}

@MaxComponentPreviews
@Composable
private fun ConversationsEmptyPreview() {
    MaxTheme(motionEnabled = false) {
        ConversationsScreen(
            state = ConversationsListUiState(),
            onOpenConversation = {},
            onRetry = {},
            onBack = {},
        )
    }
}

@MaxComponentPreviews
@Composable
private fun ConversationThreadPreview() {
    val id = ConversationId("conversation-preview")
    val now = Instant.parse("2026-08-16T00:00:00Z")
    MaxTheme(motionEnabled = false) {
        ConversationThreadScreen(
            state = ConversationThreadUiState(
                conversationId = id,
                conversationTitle = "مساعد أمامي كورولا 2015",
                latestSequence = 3,
                messages = listOf(
                    previewMessage(
                        conversationId = id,
                        id = "m1",
                        sequence = 1,
                        author = ConversationAuthor.Store,
                        text = "محتاج مساعد أمامي",
                        createdAt = now,
                    ),
                    previewMessage(
                        conversationId = id,
                        id = "m2",
                        sequence = 2,
                        author = ConversationAuthor.Max,
                        text = "متوفر. أرفقنا الصورة.",
                        createdAt = now.plusSeconds(120),
                        withImage = true,
                    ),
                    previewMessage(
                        conversationId = id,
                        id = "m3",
                        sequence = 3,
                        author = ConversationAuthor.System,
                        text = "تم تحديث حالة الطلب",
                        createdAt = now.plusSeconds(240),
                    ),
                ),
            ),
            onBack = {},
            onRetry = {},
        )
    }
}

private fun previewConversation(
    id: String,
    title: String,
    unreadCount: Int,
): ConversationSummary {
    val createdAt = Instant.parse("2026-08-16T00:00:00Z")
    return ConversationSummary(
        id = ConversationId(id),
        requestId = "request-$id",
        title = title,
        createdAt = createdAt,
        lastMessageAt = createdAt.plusSeconds(3_600),
        latestSequence = 4,
        lastReadSequence = if (unreadCount > 0) 1 else 4,
        unreadCount = unreadCount,
    )
}

private fun previewMessage(
    conversationId: ConversationId,
    id: String,
    sequence: Long,
    author: ConversationAuthor,
    text: String,
    createdAt: Instant,
    withImage: Boolean = false,
): ConversationMessage = ConversationMessage(
    id = id,
    conversationId = conversationId,
    sequence = sequence,
    author = author,
    text = text,
    imageMediaId = if (withImage) "image-$id" else null,
    audioMediaId = null,
    createdAt = createdAt,
)
