package com.maxnetwork.feature.conversations.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertDoesNotExist
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.Density
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.feature.conversations.domain.ConversationAuthor
import com.maxnetwork.feature.conversations.domain.ConversationId
import com.maxnetwork.feature.conversations.domain.ConversationMessage
import com.maxnetwork.feature.conversations.domain.ConversationSummary
import java.time.Instant
import org.junit.Rule
import org.junit.Test

class ConversationsScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun listShowsDesignSystemHierarchyAndUnreadBadge() {
        setConversationsContent(
            ConversationsListUiState(items = listOf(summary(unreadCount = 2))),
        )

        composeRule.onNodeWithTag("conversations_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("max_top_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("conversations_list").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_row_${ID.value}").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_unread_count_${ID.value}").assertIsDisplayed()
    }

    @Test
    fun listLoadingUsesDesignSystemFeedback() {
        setConversationsContent(ConversationsListUiState(loading = true))

        composeRule.onNodeWithTag("conversations_loading").assertIsDisplayed()
        composeRule.onNodeWithTag("max_state_Loading").assertIsDisplayed()
    }

    @Test
    fun staleListErrorKeepsExistingRowsVisible() {
        setConversationsContent(
            ConversationsListUiState(
                items = listOf(summary(unreadCount = 0)),
                errorMessage = "تعذر الاتصال",
            ),
        )

        composeRule.onNodeWithTag("conversations_stale_error").assertIsDisplayed()
        composeRule.onNodeWithTag("conversations_stale_retry").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_row_${ID.value}").assertIsDisplayed()
    }

    @Test
    fun threadDifferentiatesMessageDirectionAndShowsSupportedAttachments() {
        setThreadContent(
            ConversationThreadUiState(
                conversationId = ID,
                conversationTitle = "مساعد أمامي",
                latestSequence = 3,
                messages = listOf(
                    message("m1", 1, ConversationAuthor.Store, text = "محتاج مساعد أمامي"),
                    message("m2", 2, ConversationAuthor.Max, text = "متوفر", imageMediaId = "image-1"),
                    message(
                        id = "m3",
                        sequence = 3,
                        author = ConversationAuthor.System,
                        text = "تم تحديث الطلب",
                        audioMediaId = "audio-1",
                    ),
                ),
            ),
        )

        composeRule.onNodeWithTag("conversation_message_1_outgoing").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_message_2_incoming").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_message_3_system").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_image_attachment_2").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_audio_attachment_3").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_composer").assertDoesNotExist()
    }

    @Test
    fun staleThreadErrorKeepsExistingMessagesVisible() {
        setThreadContent(
            ConversationThreadUiState(
                conversationId = ID,
                conversationTitle = "مساعد أمامي",
                latestSequence = 1,
                messages = listOf(message("m1", 1, ConversationAuthor.Store, text = "رسالة محفوظة")),
                errorMessage = "تعذر التحديث",
            ),
        )

        composeRule.onNodeWithTag("conversation_thread_stale_error").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_thread_stale_retry").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_message_1").assertIsDisplayed()
    }

    @Test
    fun largeTextKeepsThreadIdentityAndMessagesReachable() {
        setThreadContent(
            state = ConversationThreadUiState(
                conversationId = ID,
                conversationTitle = "عنوان محادثة طويل للاختبار",
                latestSequence = 1,
                messages = listOf(
                    message(
                        id = "m1",
                        sequence = 1,
                        author = ConversationAuthor.Max,
                        text = "رسالة طويلة لاختبار تكبير الخط " +
                            "وإبقاء المحتوى الأساسي متاحًا.",
                    ),
                ),
            ),
            fontScale = 2f,
        )

        composeRule.onNodeWithTag("max_top_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_messages").assertIsDisplayed()
        composeRule.onNodeWithTag("conversation_message_1").assertIsDisplayed()
    }

    private fun setConversationsContent(
        state: ConversationsListUiState,
        fontScale: Float = 1f,
    ) {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                WithConversationFontScale(fontScale) {
                    ConversationsScreen(
                        state = state,
                        onOpenConversation = {},
                        onRetry = {},
                        onBack = {},
                    )
                }
            }
        }
    }

    private fun setThreadContent(
        state: ConversationThreadUiState,
        fontScale: Float = 1f,
    ) {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                WithConversationFontScale(fontScale) {
                    ConversationThreadScreen(
                        state = state,
                        onBack = {},
                        onRetry = {},
                    )
                }
            }
        }
    }

    private fun summary(unreadCount: Int) = ConversationSummary(
        id = ID,
        requestId = "request-1",
        title = "مساعد أمامي",
        createdAt = NOW,
        lastMessageAt = NOW.plusSeconds(60),
        latestSequence = 2,
        lastReadSequence = if (unreadCount > 0) 0 else 2,
        unreadCount = unreadCount,
    )

    private fun message(
        id: String,
        sequence: Long,
        author: ConversationAuthor,
        text: String,
        imageMediaId: String? = null,
        audioMediaId: String? = null,
    ) = ConversationMessage(
        id = id,
        conversationId = ID,
        sequence = sequence,
        author = author,
        text = text,
        imageMediaId = imageMediaId,
        audioMediaId = audioMediaId,
        createdAt = NOW.plusSeconds(sequence * 60),
    )

    private companion object {
        val ID = ConversationId("conversation-test")
        val NOW: Instant = Instant.parse("2026-08-16T00:00:00Z")
    }
}

@Composable
private fun WithConversationFontScale(
    fontScale: Float,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(density = density.density, fontScale = fontScale),
        content = content,
    )
}
