package com.maxnetwork.feature.conversations.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import com.maxnetwork.core.designsystem.component.MaxBadge
import com.maxnetwork.core.designsystem.component.MaxBannerTone
import com.maxnetwork.core.designsystem.component.MaxEmptyState
import com.maxnetwork.core.designsystem.component.MaxErrorState
import com.maxnetwork.core.designsystem.component.MaxInlineBanner
import com.maxnetwork.core.designsystem.component.MaxLoadingState
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxSecondaryButton
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxElevation
import com.maxnetwork.core.designsystem.theme.MaxScreenInsets
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.conversations.domain.ConversationAuthor
import com.maxnetwork.feature.conversations.domain.ConversationMessage
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun ConversationThreadScreen(
    state: ConversationThreadUiState,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    MaxScaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("conversation_thread_screen"),
        topBar = {
            MaxTopBar(
                title = state.conversationTitle ?: "المحادثة",
                onBack = onBack,
            )
        },
    ) { contentPadding ->
        when {
            state.loading && state.messages.isEmpty() -> MaxLoadingState(
                title = "جارٍ تحميل المحادثة",
                message = "سيظهر سجل الرسائل فور اكتمال التحميل",
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("conversation_thread_loading"),
            )

            state.errorMessage != null && state.messages.isEmpty() -> MaxErrorState(
                title = "تعذر تحميل المحادثة",
                message = state.errorMessage,
                actionText = "إعادة المحاولة",
                onAction = onRetry,
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("conversation_thread_error"),
            )

            state.messages.isEmpty() -> MaxEmptyState(
                title = "لا توجد رسائل",
                message = "لم تصل تحديثات لهذه المحادثة بعد.",
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("conversation_thread_empty"),
            )

            else -> ConversationMessagesContent(
                state = state,
                onRetry = onRetry,
                modifier = Modifier.padding(contentPadding),
            )
        }
    }
}

@Composable
private fun ConversationMessagesContent(
    state: ConversationThreadUiState,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(
                horizontal = MaxScreenInsets.compactHorizontal,
                vertical = MaxSpacing.md,
            ),
        verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
    ) {
        state.errorMessage?.let { error ->
            Column(verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm)) {
                MaxInlineBanner(
                    message = "تعذر تحديث المحادثة. " +
                        "المعروض هو آخر محتوى متاح. " + error,
                    tone = MaxBannerTone.Error,
                    modifier = Modifier.testTag("conversation_thread_stale_error"),
                )
                MaxSecondaryButton(
                    text = "إعادة المحاولة",
                    onClick = onRetry,
                    testTag = "conversation_thread_stale_retry",
                )
            }
        }
        if (state.loading) {
            MaxInlineBanner(
                message = "جارٍ تحديث المحادثة…",
                modifier = Modifier.testTag("conversation_thread_refreshing"),
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("conversation_messages"),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
        ) {
            items(state.messages, key = { it.id }) { message ->
                MessageCard(message)
            }
        }
    }
}

@Suppress("LongMethod")
@Composable
private fun MessageCard(message: ConversationMessage) {
    val alignment = when (message.author) {
        ConversationAuthor.Store -> Alignment.CenterStart
        ConversationAuthor.Max -> Alignment.CenterEnd
        ConversationAuthor.System -> Alignment.Center
    }
    val sidePadding = when (message.author) {
        ConversationAuthor.Store -> Modifier.padding(end = MaxSpacing.xl)
        ConversationAuthor.Max -> Modifier.padding(start = MaxSpacing.xl)
        ConversationAuthor.System -> Modifier.padding(horizontal = MaxSpacing.md)
    }
    val directionDescription = when (message.author) {
        ConversationAuthor.Store -> "صادرة"
        ConversationAuthor.Max -> "واردة"
        ConversationAuthor.System -> "نظام"
    }
    val directionTag = when (message.author) {
        ConversationAuthor.Store -> "outgoing"
        ConversationAuthor.Max -> "incoming"
        ConversationAuthor.System -> "system"
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .then(sidePadding)
            .semantics { stateDescription = directionDescription }
            .testTag("conversation_message_${message.sequence}_$directionTag"),
        contentAlignment = alignment,
    ) {
        Surface(
            color = when (message.author) {
                ConversationAuthor.Store -> MaterialTheme.colorScheme.primaryContainer
                ConversationAuthor.Max -> MaterialTheme.colorScheme.surface
                ConversationAuthor.System -> MaterialTheme.colorScheme.surfaceVariant
            },
            contentColor = when (message.author) {
                ConversationAuthor.Store -> MaterialTheme.colorScheme.onPrimaryContainer
                ConversationAuthor.Max -> MaterialTheme.colorScheme.onSurface
                ConversationAuthor.System -> MaterialTheme.colorScheme.onSurfaceVariant
            },
            shape = MaterialTheme.shapes.large,
            shadowElevation = if (message.author == ConversationAuthor.Max) {
                MaxElevation.subtle
            } else {
                MaxElevation.none
            },
            modifier = Modifier.testTag("conversation_message_${message.sequence}"),
        ) {
            Column(
                modifier = Modifier.padding(MaxSpacing.md),
                verticalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
            ) {
                MessageMetadata(message)
                message.text?.let { text ->
                    MaxText(
                        text = text,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
                MessageAttachments(message)
            }
        }
    }
}

@Composable
private fun MessageMetadata(message: ConversationMessage) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MaxText(
            text = when (message.author) {
                ConversationAuthor.Store -> "أنت"
                ConversationAuthor.Max -> "max"
                ConversationAuthor.System -> "النظام"
            },
            style = MaterialTheme.typography.labelLarge,
        )
        MaxText(
            text = THREAD_TIME.format(message.createdAt),
            style = MaterialTheme.typography.bodySmall,
            color = when (message.author) {
                ConversationAuthor.Store -> MaterialTheme.colorScheme.onPrimaryContainer
                ConversationAuthor.Max, ConversationAuthor.System -> MaterialTheme.colorScheme.onSurfaceVariant
            },
            modifier = Modifier.testTag("conversation_message_time_${message.sequence}"),
        )
    }
}

@Composable
private fun MessageAttachments(message: ConversationMessage) {
    if (message.imageMediaId == null && message.audioMediaId == null) return
    Row(
        horizontalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.testTag("conversation_message_attachments_${message.sequence}"),
    ) {
        if (message.imageMediaId != null) {
            MaxBadge(
                text = "صورة مرفقة",
                modifier = Modifier.testTag("conversation_image_attachment_${message.sequence}"),
            )
        }
        if (message.audioMediaId != null) {
            MaxBadge(
                text = "تسجيل صوتي مرفق",
                modifier = Modifier.testTag("conversation_audio_attachment_${message.sequence}"),
            )
        }
    }
}

private val THREAD_TIME: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd • HH:mm")
    .withZone(ZoneId.systemDefault())
