package com.maxnetwork.feature.conversations.domain

class LoadConversationsUseCase(
    private val repository: ConversationRepository,
) {
    suspend operator fun invoke(): ConversationReadResult<List<ConversationSummary>> = repository.getConversations()
}

class LoadConversationThreadUseCase(
    private val repository: ConversationRepository,
) {
    suspend operator fun invoke(id: ConversationId): ConversationReadResult<ConversationThread> = repository.getMessages(id)
}

class MarkConversationReadUseCase(
    private val repository: ConversationRepository,
) {
    suspend operator fun invoke(id: ConversationId, throughSequence: Long): ConversationReadResult<Long> {
        require(throughSequence >= 0)
        return repository.markRead(id, throughSequence)
    }
}
