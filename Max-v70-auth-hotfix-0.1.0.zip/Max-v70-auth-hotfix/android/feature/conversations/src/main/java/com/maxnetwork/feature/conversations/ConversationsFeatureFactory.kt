package com.maxnetwork.feature.conversations

import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.conversations.data.NetworkConversationRepository
import com.maxnetwork.feature.conversations.domain.LoadConversationThreadUseCase
import com.maxnetwork.feature.conversations.domain.LoadConversationsUseCase
import com.maxnetwork.feature.conversations.domain.MarkConversationReadUseCase

data class ConversationsUseCases(
    val loadList: LoadConversationsUseCase,
    val loadThread: LoadConversationThreadUseCase,
    val markRead: MarkConversationReadUseCase,
)

data class ConversationsFeatureDependencies(
    val useCases: ConversationsUseCases,
)

object ConversationsFeatureFactory {
    fun create(gateway: MaxGateway): ConversationsFeatureDependencies {
        val repository = NetworkConversationRepository(gateway)
        return ConversationsFeatureDependencies(
            useCases = ConversationsUseCases(
                loadList = LoadConversationsUseCase(repository),
                loadThread = LoadConversationThreadUseCase(repository),
                markRead = MarkConversationReadUseCase(repository),
            ),
        )
    }
}
