package com.maxnetwork.feature.conversations.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import com.maxnetwork.core.designsystem.component.MaxBadge
import com.maxnetwork.core.designsystem.component.MaxBannerTone
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxEmptyState
import com.maxnetwork.core.designsystem.component.MaxErrorState
import com.maxnetwork.core.designsystem.component.MaxInlineBanner
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxLoadingState
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxSecondaryButton
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTopBar
import com.maxnetwork.core.designsystem.theme.MaxScreenInsets
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.feature.conversations.domain.ConversationId
import com.maxnetwork.feature.conversations.domain.ConversationSummary
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun ConversationsScreen(
    state: ConversationsListUiState,
    onOpenConversation: (ConversationId) -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    MaxScaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("conversations_screen"),
        topBar = { MaxTopBar(title = "المحادثات", onBack = onBack) },
    ) { contentPadding ->
        when {
            state.loading && state.items.isEmpty() -> MaxLoadingState(
                title = "جارٍ تحميل المحادثات",
                message = "ستظهر محادثات الطلبات هنا فور اكتمال التحميل",
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("conversations_loading"),
            )

            state.errorMessage != null && state.items.isEmpty() -> MaxErrorState(
                title = "تعذر تحميل المحادثات",
                message = state.errorMessage,
                actionText = "إعادة المحاولة",
                onAction = onRetry,
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("conversations_error"),
            )

            state.items.isEmpty() -> MaxEmptyState(
                title = "لا توجد محادثات بعد",
                message = "بعد قبول أول طلب ستظهر محادثته هنا.",
                modifier = Modifier
                    .padding(contentPadding)
                    .testTag("conversations_empty"),
            )

            else -> ConversationsListContent(
                state = state,
                onOpenConversation = onOpenConversation,
                onRetry = onRetry,
                modifier = Modifier.padding(contentPadding),
            )
        }
    }
}

@Composable
private fun ConversationsListContent(
    state: ConversationsListUiState,
    onOpenConversation: (ConversationId) -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(
                horizontal = MaxScreenInsets.compactHorizontal,
                vertical = MaxSpacing.md,
            ),
        verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
    ) {
        when {
            state.errorMessage != null -> Column(
                verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
            ) {
                MaxInlineBanner(
                    message = "تعذر تحديث المحادثات. " +
                        "المعروض هو آخر محتوى متاح. " + state.errorMessage,
                    tone = MaxBannerTone.Error,
                    modifier = Modifier.testTag("conversations_stale_error"),
                )
                MaxSecondaryButton(
                    text = "إعادة المحاولة",
                    onClick = onRetry,
                    testTag = "conversations_stale_retry",
                )
            }

            state.loading -> MaxInlineBanner(
                message = "جارٍ تحديث المحادثات…",
                modifier = Modifier.testTag("conversations_refreshing"),
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("conversations_list"),
        ) {
            item(key = "conversation_list_container") {
                MaxListContainer {
                    state.items.forEachIndexed { index, item ->
                        ConversationRow(item = item, onOpenConversation = onOpenConversation)
                        if (index < state.items.lastIndex) {
                            MaxDivider()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConversationRow(
    item: ConversationSummary,
    onOpenConversation: (ConversationId) -> Unit,
) {
    val unread = item.unreadCount > 0
    MaxListRow(
        title = item.title,
        supportingText = if (unread) "لديك رسائل جديدة" else "تمت قراءة آخر تحديث",
        modifier = Modifier
            .semantics {
                stateDescription = if (unread) {
                    "غير مقروءة، ${item.unreadCount} رسائل جديدة"
                } else {
                    "مقروءة"
                }
            }
            .testTag("conversation_row_${item.id.value}"),
        trailingContent = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(MaxSpacing.xxs),
            ) {
                MaxText(
                    text = LIST_TIME.format(item.lastMessageAt),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.testTag("conversation_time_${item.id.value}"),
                )
                if (unread) {
                    MaxBadge(
                        text = item.unreadCount.toString(),
                        selected = true,
                        modifier = Modifier.testTag("conversation_unread_count_${item.id.value}"),
                    )
                }
            }
        },
        onClick = { onOpenConversation(item.id) },
    )
}

private val LIST_TIME: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd • HH:mm")
    .withZone(ZoneId.systemDefault())
