package com.maxnetwork.feature.conversations.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.maxnetwork.feature.conversations.domain.ConversationId
import com.maxnetwork.feature.conversations.domain.ConversationReadFailure
import com.maxnetwork.feature.conversations.domain.ConversationReadResult
import com.maxnetwork.feature.conversations.domain.LoadConversationThreadUseCase
import com.maxnetwork.feature.conversations.domain.LoadConversationsUseCase
import com.maxnetwork.feature.conversations.domain.MarkConversationReadUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ConversationsViewModel(
    private val loadList: LoadConversationsUseCase,
    private val loadThread: LoadConversationThreadUseCase,
    private val markRead: MarkConversationReadUseCase,
) : ViewModel() {
    private val mutableState = MutableStateFlow(ConversationsUiState())
    val state: StateFlow<ConversationsUiState> = mutableState.asStateFlow()

    fun start() {
        if (mutableState.value.list.loading) return
        refreshList()
    }

    fun refreshList() {
        viewModelScope.launch {
            mutableState.value = mutableState.value.copy(
                list = mutableState.value.list.copy(loading = true, errorMessage = null),
            )
            when (val result = loadList()) {
                is ConversationReadResult.Success -> mutableState.value = mutableState.value.copy(
                    list = ConversationsListUiState(items = result.value),
                )
                is ConversationReadResult.Failure -> mutableState.value = mutableState.value.copy(
                    list = mutableState.value.list.copy(loading = false, errorMessage = result.reason.message()),
                )
            }
        }
    }

    fun openConversation(id: ConversationId) {
        viewModelScope.launch {
            val current = mutableState.value
            val previousThread = current.thread.takeIf { it.conversationId == id }
            val title = current.list.items.firstOrNull { it.id == id }?.title ?: previousThread?.conversationTitle
            mutableState.value = current.copy(
                thread = ConversationThreadUiState(
                    conversationId = id,
                    conversationTitle = title,
                    loading = true,
                    latestSequence = previousThread?.latestSequence ?: 0,
                    messages = previousThread?.messages.orEmpty(),
                ),
            )
            when (val result = loadThread(id)) {
                is ConversationReadResult.Failure -> {
                    val loadingThread = mutableState.value.thread
                    mutableState.value = mutableState.value.copy(
                        thread = loadingThread.copy(
                            loading = false,
                            errorMessage = result.reason.message(),
                        ),
                    )
                }

                is ConversationReadResult.Success -> {
                    val thread = result.value
                    mutableState.value = mutableState.value.copy(
                        thread = ConversationThreadUiState(
                            conversationId = id,
                            conversationTitle = title,
                            latestSequence = thread.latestSequence,
                            messages = thread.messages,
                        ),
                    )
                    markLoadedThreadRead(id, thread.latestSequence)
                }
            }
        }
    }

    fun retryThread() {
        mutableState.value.thread.conversationId?.let(::openConversation)
    }

    fun clear() {
        mutableState.value = ConversationsUiState()
    }

    private suspend fun markLoadedThreadRead(id: ConversationId, latestSequence: Long) {
        if (latestSequence <= 0) return
        when (val result = markRead(id, latestSequence)) {
            is ConversationReadResult.Failure -> Unit
            is ConversationReadResult.Success -> {
                val updated = mutableState.value.list.items.map { item ->
                    if (item.id == id) {
                        item.copy(
                            lastReadSequence = result.value,
                            unreadCount = if (result.value >= item.latestSequence) 0 else item.unreadCount,
                        )
                    } else {
                        item
                    }
                }
                mutableState.value = mutableState.value.copy(
                    list = mutableState.value.list.copy(items = updated),
                )
            }
        }
    }
}

private fun ConversationReadFailure.message(): String = when (this) {
    ConversationReadFailure.Offline ->
        "تعذر الاتصال. تحقق من الإنترنت وحاول مرة أخرى."
    ConversationReadFailure.Unauthorized -> "انتهت الجلسة. سجل الدخول مرة أخرى."
    ConversationReadFailure.NotFound -> "المحادثة غير موجودة."
    ConversationReadFailure.Conflict -> "تعذر تحديث حالة القراءة. أعد فتح المحادثة."
    is ConversationReadFailure.Unavailable -> "تعذر تحميل المحادثات حاليًا."
}
