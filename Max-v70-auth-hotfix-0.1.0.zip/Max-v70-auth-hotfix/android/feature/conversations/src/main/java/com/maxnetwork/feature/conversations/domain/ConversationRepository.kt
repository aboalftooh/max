package com.maxnetwork.feature.conversations.domain

interface ConversationRepository {
    suspend fun getConversations(): ConversationReadResult<List<ConversationSummary>>
    suspend fun getMessages(id: ConversationId): ConversationReadResult<ConversationThread>
    suspend fun markRead(id: ConversationId, throughSequence: Long): ConversationReadResult<Long>
}
