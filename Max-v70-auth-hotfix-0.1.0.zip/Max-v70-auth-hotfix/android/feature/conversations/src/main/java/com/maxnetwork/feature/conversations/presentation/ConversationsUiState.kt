package com.maxnetwork.feature.conversations.presentation

import com.maxnetwork.feature.conversations.domain.ConversationId
import com.maxnetwork.feature.conversations.domain.ConversationMessage
import com.maxnetwork.feature.conversations.domain.ConversationSummary

data class ConversationsListUiState(
    val loading: Boolean = false,
    val items: List<ConversationSummary> = emptyList(),
    val errorMessage: String? = null,
)

data class ConversationThreadUiState(
    val conversationId: ConversationId? = null,
    val conversationTitle: String? = null,
    val loading: Boolean = false,
    val latestSequence: Long = 0,
    val messages: List<ConversationMessage> = emptyList(),
    val errorMessage: String? = null,
)

data class ConversationsUiState(
    val list: ConversationsListUiState = ConversationsListUiState(),
    val thread: ConversationThreadUiState = ConversationThreadUiState(),
)
