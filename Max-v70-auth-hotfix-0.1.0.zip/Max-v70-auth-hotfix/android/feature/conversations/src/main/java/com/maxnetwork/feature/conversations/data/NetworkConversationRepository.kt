package com.maxnetwork.feature.conversations.data

import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.ConversationAuthorType as NetworkConversationAuthorType
import com.maxnetwork.core.network.ConversationMessage as NetworkConversationMessage
import com.maxnetwork.core.network.ConversationSummary as NetworkConversationSummary
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.conversations.domain.ConversationAuthor
import com.maxnetwork.feature.conversations.domain.ConversationId
import com.maxnetwork.feature.conversations.domain.ConversationMessage
import com.maxnetwork.feature.conversations.domain.ConversationReadFailure
import com.maxnetwork.feature.conversations.domain.ConversationReadResult
import com.maxnetwork.feature.conversations.domain.ConversationRepository
import com.maxnetwork.feature.conversations.domain.ConversationSummary
import com.maxnetwork.feature.conversations.domain.ConversationThread

class NetworkConversationRepository(
    private val gateway: MaxGateway,
) : ConversationRepository {
    override suspend fun getConversations(): ConversationReadResult<List<ConversationSummary>> = when (
        val result = gateway.getConversations()
    ) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> ConversationReadResult.Success(result.value.map(NetworkConversationSummary::toDomain))
    }

    override suspend fun getMessages(id: ConversationId): ConversationReadResult<ConversationThread> = when (
        val result = gateway.getConversationMessages(id.value)
    ) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> ConversationReadResult.Success(
            ConversationThread(
                conversationId = ConversationId(result.value.conversationId),
                latestSequence = result.value.latestSequence,
                messages = result.value.items.map(NetworkConversationMessage::toDomain).sortedBy { it.sequence },
            ),
        )
    }

    override suspend fun markRead(id: ConversationId, throughSequence: Long): ConversationReadResult<Long> = when (
        val result = gateway.markConversationRead(id.value, throughSequence)
    ) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> ConversationReadResult.Success(result.value.lastReadSequence)
    }
}

private fun NetworkConversationSummary.toDomain() = ConversationSummary(
    id = ConversationId(id),
    requestId = requestId,
    title = title,
    createdAt = createdAt,
    lastMessageAt = lastMessageAt,
    latestSequence = latestSequence,
    lastReadSequence = lastReadSequence,
    unreadCount = unreadCount,
)

private fun NetworkConversationMessage.toDomain() = ConversationMessage(
    id = id,
    conversationId = ConversationId(conversationId),
    sequence = sequence,
    author = when (authorType) {
        NetworkConversationAuthorType.Store -> ConversationAuthor.Store
        NetworkConversationAuthorType.Max -> ConversationAuthor.Max
        NetworkConversationAuthorType.System -> ConversationAuthor.System
    },
    text = text,
    imageMediaId = imageMediaId,
    audioMediaId = audioMediaId,
    createdAt = createdAt,
)

private fun GatewayResult.Failure.toDomainFailure(): ConversationReadResult.Failure = ConversationReadResult.Failure(
    when (error.code) {
        ApiErrorCode.Unauthorized, ApiErrorCode.Forbidden -> ConversationReadFailure.Unauthorized
        ApiErrorCode.NotFound -> ConversationReadFailure.NotFound
        ApiErrorCode.Conflict -> ConversationReadFailure.Conflict
        ApiErrorCode.ServiceUnavailable -> if (error.traceId == "network-unavailable") {
            ConversationReadFailure.Offline
        } else {
            ConversationReadFailure.Unavailable(error.retryable)
        }
        else -> ConversationReadFailure.Unavailable(error.retryable)
    },
)
