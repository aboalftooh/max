package com.maxnetwork.feature.conversations.domain

import java.time.Instant

@JvmInline
value class ConversationId(val value: String) {
    init { require(value.isNotBlank()) }
}

enum class ConversationAuthor {
    Store,
    Max,
    System,
}

data class ConversationSummary(
    val id: ConversationId,
    val requestId: String,
    val title: String,
    val createdAt: Instant,
    val lastMessageAt: Instant,
    val latestSequence: Long,
    val lastReadSequence: Long,
    val unreadCount: Int,
) {
    init {
        require(requestId.isNotBlank())
        require(title.isNotBlank() && title.length <= 80)
        require(!lastMessageAt.isBefore(createdAt))
        require(latestSequence >= 0)
        require(lastReadSequence in 0..latestSequence)
        require(unreadCount >= 0)
    }
}

data class ConversationMessage(
    val id: String,
    val conversationId: ConversationId,
    val sequence: Long,
    val author: ConversationAuthor,
    val text: String?,
    val imageMediaId: String?,
    val audioMediaId: String?,
    val createdAt: Instant,
) {
    init {
        require(id.isNotBlank())
        require(sequence > 0)
        require(text?.isNotBlank() == true || imageMediaId != null || audioMediaId != null)
    }
}

data class ConversationThread(
    val conversationId: ConversationId,
    val latestSequence: Long,
    val messages: List<ConversationMessage>,
) {
    init {
        require(latestSequence >= 0)
        require(messages.all { it.conversationId == conversationId })
        require(messages.zipWithNext().all { (left, right) -> left.sequence < right.sequence })
        require(messages.lastOrNull()?.sequence?.let { it <= latestSequence } != false)
    }
}

sealed interface ConversationReadFailure {
    data object Offline : ConversationReadFailure
    data object Unauthorized : ConversationReadFailure
    data object NotFound : ConversationReadFailure
    data object Conflict : ConversationReadFailure
    data class Unavailable(val retryable: Boolean) : ConversationReadFailure
}

sealed interface ConversationReadResult<out T> {
    data class Success<T>(val value: T) : ConversationReadResult<T>
    data class Failure(val reason: ConversationReadFailure) : ConversationReadResult<Nothing>
}
