package com.maxnetwork.feature.conversations.presentation

import com.maxnetwork.feature.conversations.domain.ConversationAuthor
import com.maxnetwork.feature.conversations.domain.ConversationId
import com.maxnetwork.feature.conversations.domain.ConversationMessage
import com.maxnetwork.feature.conversations.domain.ConversationReadFailure
import com.maxnetwork.feature.conversations.domain.ConversationReadResult
import com.maxnetwork.feature.conversations.domain.ConversationRepository
import com.maxnetwork.feature.conversations.domain.ConversationSummary
import com.maxnetwork.feature.conversations.domain.ConversationThread
import com.maxnetwork.feature.conversations.domain.LoadConversationThreadUseCase
import com.maxnetwork.feature.conversations.domain.LoadConversationsUseCase
import com.maxnetwork.feature.conversations.domain.MarkConversationReadUseCase
import java.time.Instant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class ConversationsViewModelTest {
    private val dispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `list exposes title time and unread count data`() = runTest(dispatcher) {
        val repository = RecordingRepository()
        val viewModel = viewModel(repository)

        viewModel.start()
        advanceUntilIdle()

        val item = viewModel.state.value.list.items.single()
        assertEquals("مساعد أمامي", item.title)
        assertEquals(2, item.unreadCount)
        assertFalse(viewModel.state.value.list.loading)
    }

    @Test
    fun `opening thread marks read through loaded latest sequence`() = runTest(dispatcher) {
        val repository = RecordingRepository()
        val viewModel = viewModel(repository)
        viewModel.start()
        advanceUntilIdle()

        viewModel.openConversation(ID)
        advanceUntilIdle()

        assertEquals(3L, repository.markedThrough)
        assertEquals(3L, viewModel.state.value.thread.latestSequence)
        assertEquals("مساعد أمامي", viewModel.state.value.thread.conversationTitle)
        assertEquals(0, viewModel.state.value.list.items.single().unreadCount)
        assertEquals(3L, viewModel.state.value.list.items.single().lastReadSequence)
    }

    @Test
    fun `thread failure remains retryable presentation state`() = runTest(dispatcher) {
        val repository = RecordingRepository(threadFailure = ConversationReadFailure.Offline)
        val viewModel = viewModel(repository)

        viewModel.openConversation(ID)
        advanceUntilIdle()

        assertTrue(viewModel.state.value.thread.errorMessage?.isNotBlank() == true)
        assertEquals(null, repository.markedThrough)
    }


    @Test
    fun `retry failure preserves stale thread content and exposes error`() = runTest(dispatcher) {
        val repository = RecordingRepository()
        val viewModel = viewModel(repository)
        viewModel.start()
        advanceUntilIdle()
        viewModel.openConversation(ID)
        advanceUntilIdle()

        repository.threadFailure = ConversationReadFailure.Offline
        viewModel.retryThread()
        advanceUntilIdle()

        assertEquals(2, viewModel.state.value.thread.messages.size)
        assertTrue(viewModel.state.value.thread.errorMessage?.isNotBlank() == true)
        assertFalse(viewModel.state.value.thread.loading)
    }

    private fun viewModel(repository: ConversationRepository) = ConversationsViewModel(
        loadList = LoadConversationsUseCase(repository),
        loadThread = LoadConversationThreadUseCase(repository),
        markRead = MarkConversationReadUseCase(repository),
    )

    private class RecordingRepository(
        var threadFailure: ConversationReadFailure? = null,
    ) : ConversationRepository {
        var markedThrough: Long? = null

        override suspend fun getConversations() = ConversationReadResult.Success(listOf(SUMMARY))

        override suspend fun getMessages(id: ConversationId): ConversationReadResult<ConversationThread> {
            threadFailure?.let { return ConversationReadResult.Failure(it) }
            return ConversationReadResult.Success(
                ConversationThread(
                    conversationId = id,
                    latestSequence = 3,
                    messages = listOf(
                        ConversationMessage(
                            id = "m1",
                            conversationId = id,
                            sequence = 1,
                            author = ConversationAuthor.Store,
                            text = "مساعد أمامي",
                            imageMediaId = null,
                            audioMediaId = null,
                            createdAt = NOW,
                        ),
                        ConversationMessage(
                            id = "m3",
                            conversationId = id,
                            sequence = 3,
                            author = ConversationAuthor.Max,
                            text = "تم التحديث",
                            imageMediaId = null,
                            audioMediaId = null,
                            createdAt = NOW.plusSeconds(60),
                        ),
                    ),
                ),
            )
        }

        override suspend fun markRead(id: ConversationId, throughSequence: Long): ConversationReadResult<Long> {
            markedThrough = throughSequence
            return ConversationReadResult.Success(throughSequence)
        }
    }

    private companion object {
        val ID = ConversationId("conversation-req-1")
        val NOW: Instant = Instant.parse("2026-08-15T10:00:00Z")
        val SUMMARY = ConversationSummary(
            id = ID,
            requestId = "req-1",
            title = "مساعد أمامي",
            createdAt = NOW,
            lastMessageAt = NOW.plusSeconds(60),
            latestSequence = 3,
            lastReadSequence = 1,
            unreadCount = 2,
        )
    }
}
