package com.maxnetwork.feature.balance.presentation

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.feature.balance.domain.BalanceMovementKind
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BalanceFormattingTest {
    @Test
    fun `money uses Sudanese pound label without ownership wording`() {
        val text = Money(-185_000, CurrencyCode.SDG).toSdgText()
        assertTrue(text.contains("ج.س"))
        assertFalse(text.contains("لي"))
        assertFalse(text.contains("علي"))
    }

    @Test
    fun `all movement kinds have short Arabic labels`() {
        val labels = BalanceMovementKind.entries.map { it.displayName() }
        assertTrue(labels.containsAll(listOf("طلب وارد", "طلب صادر", "دفعة", "استلام", "تصحيح", "مرتجع")))
    }
}
