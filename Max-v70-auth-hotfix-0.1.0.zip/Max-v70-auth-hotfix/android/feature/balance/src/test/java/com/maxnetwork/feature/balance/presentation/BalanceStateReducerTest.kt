package com.maxnetwork.feature.balance.presentation

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.feature.balance.domain.BalanceCursor
import com.maxnetwork.feature.balance.domain.BalanceMovement
import com.maxnetwork.feature.balance.domain.BalanceMovementId
import com.maxnetwork.feature.balance.domain.BalanceMovementKind
import com.maxnetwork.feature.balance.domain.BalanceMovementPage
import com.maxnetwork.feature.balance.domain.BalanceReadFailure
import com.maxnetwork.feature.balance.domain.BalanceSnapshot
import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BalanceStateReducerTest {
    @Test
    fun `refresh loads balance and first page`() {
        val reducer = BalanceStateReducer()
        reducer.refreshing()
        reducer.balanceLoaded(BalanceSnapshot(money(18_500), Instant.EPOCH))
        reducer.pageLoaded(BalanceMovementPage(listOf(movement("1", 5_000)), BalanceCursor("next")), false)

        assertEquals(18_500L, reducer.state.balance?.minorUnits)
        assertEquals(listOf("1"), reducer.state.movements.map { it.id.value })
        assertTrue(reducer.state.canLoadMore)
        assertFalse(reducer.state.initialLoading)
    }

    @Test
    fun `pages preserve server order and remove overlap`() {
        val reducer = BalanceStateReducer()
        reducer.balanceLoaded(BalanceSnapshot(money(0), null))
        reducer.pageLoaded(
            BalanceMovementPage(listOf(movement("3", 3_000), movement("2", -2_000)), BalanceCursor("2")),
            false,
        )
        reducer.loadingMore()
        reducer.pageLoaded(
            BalanceMovementPage(listOf(movement("2", -2_000), movement("1", 1_000)), null),
            true,
        )

        assertEquals(listOf("3", "2", "1"), reducer.state.movements.map { it.id.value })
        assertFalse(reducer.state.canLoadMore)
    }

    @Test
    fun `offline failure keeps loaded balance and movements`() {
        val reducer = BalanceStateReducer()
        reducer.balanceLoaded(BalanceSnapshot(money(9_000), Instant.EPOCH))
        reducer.pageLoaded(BalanceMovementPage(listOf(movement("1", 9_000)), null), false)
        reducer.failed(BalanceReadFailure.Offline)

        assertEquals(9_000L, reducer.state.balance?.minorUnits)
        assertEquals(1, reducer.state.movements.size)
        assertTrue(reducer.state.offline)
        assertTrue(reducer.state.errorMessage?.contains("الإنترنت") == true)
    }

    @Test
    fun `clear removes tenant data`() {
        val reducer = BalanceStateReducer()
        reducer.balanceLoaded(BalanceSnapshot(money(9_000), Instant.EPOCH))
        reducer.pageLoaded(BalanceMovementPage(listOf(movement("1", 9_000)), null), false)
        reducer.clear()

        assertEquals(BalanceUiState(), reducer.state)
    }

    private fun money(value: Long) = Money(value, CurrencyCode.SDG)

    private fun movement(id: String, delta: Long) = BalanceMovement(
        id = BalanceMovementId(id),
        kind = if (delta > 0) BalanceMovementKind.IncomingOrder else BalanceMovementKind.OutgoingOrder,
        amount = money(kotlin.math.abs(delta)),
        delta = money(delta),
        balanceAfter = money(delta),
        occurredAt = Instant.EPOCH,
    )
}
