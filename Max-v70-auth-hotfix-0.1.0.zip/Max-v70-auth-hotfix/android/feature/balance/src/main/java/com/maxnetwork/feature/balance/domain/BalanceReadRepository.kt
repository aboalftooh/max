package com.maxnetwork.feature.balance.domain

interface BalanceReadRepository {
    suspend fun getBalance(): BalanceReadResult<BalanceSnapshot>
    suspend fun getMovements(query: BalanceMovementQuery): BalanceReadResult<BalanceMovementPage>
}
