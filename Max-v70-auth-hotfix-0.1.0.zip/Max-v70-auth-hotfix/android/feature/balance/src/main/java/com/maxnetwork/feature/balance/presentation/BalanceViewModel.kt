package com.maxnetwork.feature.balance.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.maxnetwork.feature.balance.domain.BalanceMovementQuery
import com.maxnetwork.feature.balance.domain.BalanceReadResult
import com.maxnetwork.feature.balance.domain.LoadBalanceMovementsPageUseCase
import com.maxnetwork.feature.balance.domain.LoadBalanceUseCase
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BalanceViewModel(
    private val loadBalance: LoadBalanceUseCase,
    private val loadMovementsPage: LoadBalanceMovementsPageUseCase,
) : ViewModel() {
    private val reducer = BalanceStateReducer()
    private val mutableState = MutableStateFlow(reducer.state)
    private var loading = false
    private var loadJob: Job? = null

    val state: StateFlow<BalanceUiState> = mutableState.asStateFlow()

    fun refresh() {
        if (loading) return
        loading = true
        reducer.refreshing()
        publish()
        loadJob = viewModelScope.launch {
            when (val balanceResult = loadBalance()) {
                is BalanceReadResult.Failure -> reducer.failed(balanceResult.reason)
                is BalanceReadResult.Success -> {
                    reducer.balanceLoaded(balanceResult.value)
                    when (val pageResult = loadMovementsPage(BalanceMovementQuery())) {
                        is BalanceReadResult.Failure -> reducer.failed(pageResult.reason)
                        is BalanceReadResult.Success -> reducer.pageLoaded(pageResult.value, append = false)
                    }
                }
            }
            loading = false
            loadJob = null
            publish()
        }
    }

    fun loadMore() {
        val cursor = reducer.state.nextCursor ?: return
        if (loading || !reducer.state.canLoadMore) return
        loading = true
        reducer.loadingMore()
        publish()
        loadJob = viewModelScope.launch {
            when (val result = loadMovementsPage(BalanceMovementQuery(cursor = cursor))) {
                is BalanceReadResult.Failure -> reducer.failed(result.reason)
                is BalanceReadResult.Success -> reducer.pageLoaded(result.value, append = true)
            }
            loading = false
            loadJob = null
            publish()
        }
    }

    fun clear() {
        loadJob?.cancel()
        loadJob = null
        loading = false
        reducer.clear()
        publish()
    }

    private fun publish() {
        mutableState.value = reducer.state
    }
}
