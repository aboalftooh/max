package com.maxnetwork.feature.balance

import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.balance.data.NetworkBalanceReadRepository
import com.maxnetwork.feature.balance.domain.LoadBalanceMovementsPageUseCase
import com.maxnetwork.feature.balance.domain.LoadBalanceUseCase

data class BalanceUseCases(
    val loadBalance: LoadBalanceUseCase,
    val loadMovementsPage: LoadBalanceMovementsPageUseCase,
)

data class BalanceFeatureDependencies(
    val useCases: BalanceUseCases,
)

object BalanceFeatureFactory {
    fun create(gateway: MaxGateway): BalanceFeatureDependencies {
        val repository = NetworkBalanceReadRepository(gateway)
        return BalanceFeatureDependencies(
            useCases = BalanceUseCases(
                loadBalance = LoadBalanceUseCase(repository),
                loadMovementsPage = LoadBalanceMovementsPageUseCase(repository),
            ),
        )
    }
}
