package com.maxnetwork.feature.balance.data

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.BalanceMovement as NetworkMovement
import com.maxnetwork.core.network.BalanceMovementType as NetworkMovementType
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.MoneyAmount
import com.maxnetwork.feature.balance.domain.BalanceCursor
import com.maxnetwork.feature.balance.domain.BalanceMovement
import com.maxnetwork.feature.balance.domain.BalanceMovementId
import com.maxnetwork.feature.balance.domain.BalanceMovementKind
import com.maxnetwork.feature.balance.domain.BalanceMovementPage
import com.maxnetwork.feature.balance.domain.BalanceMovementQuery
import com.maxnetwork.feature.balance.domain.BalanceReadFailure
import com.maxnetwork.feature.balance.domain.BalanceReadRepository
import com.maxnetwork.feature.balance.domain.BalanceReadResult
import com.maxnetwork.feature.balance.domain.BalanceSnapshot

class NetworkBalanceReadRepository(
    private val gateway: MaxGateway,
) : BalanceReadRepository {
    override suspend fun getBalance(): BalanceReadResult<BalanceSnapshot> = when (val result = gateway.getBalance()) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> BalanceReadResult.Success(
            BalanceSnapshot(
                balance = result.value.balance.toDomainMoney(),
                asOf = result.value.asOf,
            ),
        )
    }

    override suspend fun getMovements(query: BalanceMovementQuery): BalanceReadResult<BalanceMovementPage> = when (
        val result = gateway.getBalanceMovements(query.cursor?.value, query.limit)
    ) {
        is GatewayResult.Failure -> result.toDomainFailure()
        is GatewayResult.Success -> BalanceReadResult.Success(
            BalanceMovementPage(
                items = result.value.items.map(NetworkMovement::toDomain),
                nextCursor = result.value.nextCursor?.let(::BalanceCursor),
            ),
        )
    }
}

private fun NetworkMovement.toDomain() = BalanceMovement(
    id = BalanceMovementId(id),
    kind = when (type) {
        NetworkMovementType.IncomingOrder -> BalanceMovementKind.IncomingOrder
        NetworkMovementType.OutgoingOrder -> BalanceMovementKind.OutgoingOrder
        NetworkMovementType.Payment -> BalanceMovementKind.Payment
        NetworkMovementType.Receipt -> BalanceMovementKind.Receipt
        NetworkMovementType.Correction -> BalanceMovementKind.Correction
        NetworkMovementType.Return -> BalanceMovementKind.Return
    },
    amount = amount.toDomainMoney(),
    delta = delta.toDomainMoney(),
    balanceAfter = balanceAfter.toDomainMoney(),
    occurredAt = occurredAt,
)

private fun MoneyAmount.toDomainMoney(): Money {
    require(currency == "SDG") { "Max V1 supports SDG only" }
    return Money(minorUnits, CurrencyCode.SDG)
}

private fun GatewayResult.Failure.toDomainFailure(): BalanceReadResult.Failure = BalanceReadResult.Failure(
    when (error.code) {
        ApiErrorCode.Unauthorized -> BalanceReadFailure.Unauthorized
        ApiErrorCode.ServiceUnavailable -> if (error.traceId == "network-unavailable") {
            BalanceReadFailure.Offline
        } else {
            BalanceReadFailure.Unavailable(error.retryable)
        }
        else -> BalanceReadFailure.Unavailable(error.retryable)
    },
)
