package com.maxnetwork.feature.balance.domain

class LoadBalanceUseCase(
    private val repository: BalanceReadRepository,
) {
    suspend operator fun invoke(): BalanceReadResult<BalanceSnapshot> = repository.getBalance()
}

class LoadBalanceMovementsPageUseCase(
    private val repository: BalanceReadRepository,
) {
    suspend operator fun invoke(query: BalanceMovementQuery): BalanceReadResult<BalanceMovementPage> =
        repository.getMovements(query)
}
