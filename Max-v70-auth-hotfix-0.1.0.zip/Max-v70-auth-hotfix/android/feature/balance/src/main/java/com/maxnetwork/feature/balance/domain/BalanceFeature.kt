package com.maxnetwork.feature.balance.domain

/** Public feature capability; navigation and wiring remain in :app. */
object BalanceFeature {
    const val ROUTE = "balance"
}
