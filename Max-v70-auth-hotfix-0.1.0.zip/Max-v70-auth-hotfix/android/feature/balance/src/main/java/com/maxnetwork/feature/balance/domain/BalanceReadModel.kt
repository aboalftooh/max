package com.maxnetwork.feature.balance.domain

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import java.time.Instant

@JvmInline
value class BalanceMovementId(val value: String) {
    init { require(value.isNotBlank()) }
}

enum class BalanceMovementKind {
    IncomingOrder,
    OutgoingOrder,
    Payment,
    Receipt,
    Correction,
    Return,
}

data class BalanceSnapshot(
    val balance: Money,
    val asOf: Instant?,
) {
    init { require(balance.currency == CurrencyCode.SDG) }
}

data class BalanceMovement(
    val id: BalanceMovementId,
    val kind: BalanceMovementKind,
    val amount: Money,
    val delta: Money,
    val balanceAfter: Money,
    val occurredAt: Instant,
) {
    init {
        require(amount.currency == CurrencyCode.SDG)
        require(delta.currency == CurrencyCode.SDG)
        require(balanceAfter.currency == CurrencyCode.SDG)
        require(amount.minorUnits > 0)
        require(delta.minorUnits != 0L)
        require(delta.minorUnits != Long.MIN_VALUE)
        require(kotlin.math.abs(delta.minorUnits) == amount.minorUnits)
    }
}

@JvmInline
value class BalanceCursor(val value: String) {
    init { require(value.isNotBlank()) }
}

data class BalanceMovementQuery(
    val cursor: BalanceCursor? = null,
    val limit: Int = 20,
) {
    init { require(limit in 1..50) }
}

data class BalanceMovementPage(
    val items: List<BalanceMovement>,
    val nextCursor: BalanceCursor?,
)

sealed interface BalanceReadFailure {
    data object Offline : BalanceReadFailure
    data object Unauthorized : BalanceReadFailure
    data class Unavailable(val retryable: Boolean) : BalanceReadFailure
}

sealed interface BalanceReadResult<out T> {
    data class Success<T>(val value: T) : BalanceReadResult<T>
    data class Failure(val reason: BalanceReadFailure) : BalanceReadResult<Nothing>
}
