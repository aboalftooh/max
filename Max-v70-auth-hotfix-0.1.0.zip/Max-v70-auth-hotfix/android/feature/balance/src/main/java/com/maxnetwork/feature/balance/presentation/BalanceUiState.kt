package com.maxnetwork.feature.balance.presentation

import com.maxnetwork.core.model.Money
import com.maxnetwork.feature.balance.domain.BalanceCursor
import com.maxnetwork.feature.balance.domain.BalanceMovement
import com.maxnetwork.feature.balance.domain.BalanceMovementPage
import com.maxnetwork.feature.balance.domain.BalanceReadFailure
import com.maxnetwork.feature.balance.domain.BalanceSnapshot

data class BalanceUiState(
    val balance: Money? = null,
    val movements: List<BalanceMovement> = emptyList(),
    val nextCursor: BalanceCursor? = null,
    val initialLoading: Boolean = false,
    val loadingMore: Boolean = false,
    val offline: Boolean = false,
    val errorMessage: String? = null,
) {
    val canLoadMore: Boolean get() = nextCursor != null && !initialLoading && !loadingMore && errorMessage == null
    val hasContent: Boolean get() = balance != null
}

class BalanceStateReducer {
    var state: BalanceUiState = BalanceUiState()
        private set

    fun refreshing() {
        state = state.copy(
            initialLoading = true,
            loadingMore = false,
            errorMessage = null,
        )
    }

    fun balanceLoaded(snapshot: BalanceSnapshot) {
        state = state.copy(
            balance = snapshot.balance,
            offline = false,
            errorMessage = null,
        )
    }

    fun loadingMore() {
        if (state.canLoadMore) {
            state = state.copy(loadingMore = true, errorMessage = null)
        }
    }

    fun pageLoaded(page: BalanceMovementPage, append: Boolean) {
        val merged = if (append) state.movements + page.items else page.items
        state = state.copy(
            movements = merged.distinctBy { it.id },
            nextCursor = page.nextCursor,
            initialLoading = false,
            loadingMore = false,
            offline = false,
            errorMessage = null,
        )
    }

    fun failed(failure: BalanceReadFailure) {
        state = state.copy(
            initialLoading = false,
            loadingMore = false,
            offline = failure == BalanceReadFailure.Offline,
            errorMessage = failure.userMessage(),
        )
    }

    fun clear() {
        state = BalanceUiState()
    }
}

private fun BalanceReadFailure.userMessage(): String = when (this) {
    BalanceReadFailure.Offline -> "لا يوجد اتصال بالإنترنت. حاول مجددًا."
    BalanceReadFailure.Unauthorized -> "انتهت الجلسة. سجّل الدخول من جديد."
    is BalanceReadFailure.Unavailable -> "تعذر تحميل الرصيد حاليًا."
}
