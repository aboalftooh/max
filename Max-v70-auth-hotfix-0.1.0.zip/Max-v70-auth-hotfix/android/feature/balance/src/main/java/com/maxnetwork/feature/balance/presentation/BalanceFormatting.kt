package com.maxnetwork.feature.balance.presentation

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.feature.balance.domain.BalanceMovementKind
import java.math.BigDecimal
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val SudanLocale = Locale.Builder().setLanguage("ar").setRegion("SD").build()
private val DateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", SudanLocale)
private val TimeFormatter = DateTimeFormatter.ofPattern("HH:mm", SudanLocale)

fun Money.toSdgText(includeSign: Boolean = true): String {
    require(currency == CurrencyCode.SDG)
    val value = BigDecimal.valueOf(minorUnits, 2)
    val formatter = NumberFormat.getNumberInstance(SudanLocale).apply {
        minimumFractionDigits = if (minorUnits % 100L == 0L) 0 else 2
        maximumFractionDigits = 2
        isGroupingUsed = true
    }
    val formatted = formatter.format(if (includeSign) value else value.abs())
    return "$formatted ج.س"
}

fun Money.balanceStatusLabel(): String = when {
    minorUnits > 0L -> "دائن"
    minorUnits < 0L -> "مدين"
    else -> "متوازن"
}

fun Money.movementDirectionLabel(): String = when {
    minorUnits > 0L -> "شلنا"
    minorUnits < 0L -> "شال"
    else -> "بدون تغيير"
}

internal fun BalanceMovementKind.displayName(): String = when (this) {
    BalanceMovementKind.IncomingOrder -> "طلب وارد"
    BalanceMovementKind.OutgoingOrder -> "طلب صادر"
    BalanceMovementKind.Payment -> "دفعة"
    BalanceMovementKind.Receipt -> "استلام"
    BalanceMovementKind.Correction -> "تصحيح"
    BalanceMovementKind.Return -> "مرتجع"
}

fun Instant.toBalanceDate(zoneId: ZoneId = ZoneId.systemDefault()): String =
    DateFormatter.format(atZone(zoneId))

fun Instant.toBalanceTime(zoneId: ZoneId = ZoneId.systemDefault()): String =
    TimeFormatter.format(atZone(zoneId))
