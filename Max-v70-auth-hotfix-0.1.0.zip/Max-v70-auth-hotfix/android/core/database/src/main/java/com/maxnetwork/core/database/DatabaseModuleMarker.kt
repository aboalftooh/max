package com.maxnetwork.core.database

/** Marker only. Room implementation starts in its scheduled session. */
object DatabaseModuleMarker
