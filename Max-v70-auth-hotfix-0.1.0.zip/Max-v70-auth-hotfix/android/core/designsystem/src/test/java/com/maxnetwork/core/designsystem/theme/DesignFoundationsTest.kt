package com.maxnetwork.core.designsystem.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.junit.Assert.assertEquals
import org.junit.Test

class DesignFoundationsTest {
    @Test
    fun semanticLightPaletteMatchesConstitution() {
        assertEquals(Color(0xFF16A34A), MaxColors.primary)
        assertEquals(Color(0xFF087C41), MaxColors.primaryStrong)
        assertEquals(Color(0xFF57C063), MaxColors.primarySoft)
        assertEquals(Color(0xFFF7F8FA), MaxColors.background)
        assertEquals(Color(0xFFFFFFFF), MaxColors.surface)
        assertEquals(Color(0xFF202334), MaxColors.onSurface)
        assertEquals(Color(0xFF6B7280), MaxColors.onSurfaceVariant)
        assertEquals(Color(0xFFE5E7EB), MaxColors.outline)
        assertEquals(Color(0xFF159447), MaxColors.success)
        assertEquals(Color(0xFFEAF8EF), MaxColors.successContainer)
        assertEquals(Color(0xFFC62828), MaxColors.error)
        assertEquals(Color(0xFFFDECEC), MaxColors.errorContainer)
        assertEquals(Color(0xFFC58A12), MaxColors.warning)
        assertEquals(Color(0xFFFFF7E2), MaxColors.warningContainer)
    }

    @Test
    fun spacingInsetsSizesAndMotionMatchConstitution() {
        assertEquals(4.dp, MaxSpacing.xxs)
        assertEquals(8.dp, MaxSpacing.xs)
        assertEquals(12.dp, MaxSpacing.sm)
        assertEquals(16.dp, MaxSpacing.md)
        assertEquals(20.dp, MaxSpacing.mdPlus)
        assertEquals(24.dp, MaxSpacing.lg)
        assertEquals(32.dp, MaxSpacing.xl)
        assertEquals(40.dp, MaxSpacing.xlPlus)
        assertEquals(48.dp, MaxSpacing.xxl)
        assertEquals(20.dp, MaxScreenInsets.compactHorizontal)
        assertEquals(24.dp, MaxScreenInsets.wideHorizontal)
        assertEquals(48.dp, MaxSizes.minimumTouchTarget)
        assertEquals(150, MaxMotion.fastMillis)
        assertEquals(250, MaxMotion.standardMillis)
        assertEquals(400, MaxMotion.emphasizedMillis)
    }

    @Test
    fun namedTypographyRolesMatchConstitution() {
        assertEquals(52.sp, MaxTypeRoles.displayAmount.fontSize)
        assertEquals(60.sp, MaxTypeRoles.displayAmount.lineHeight)
        assertEquals(FontWeight.ExtraBold, MaxTypeRoles.displayAmount.fontWeight)
        assertEquals(28.sp, MaxTypeRoles.pageTitle.fontSize)
        assertEquals(22.sp, MaxTypeRoles.sectionTitle.fontSize)
        assertEquals(18.sp, MaxTypeRoles.title.fontSize)
        assertEquals(16.sp, MaxTypeRoles.bodyLarge.fontSize)
        assertEquals(14.sp, MaxTypeRoles.body.fontSize)
        assertEquals(14.sp, MaxTypeRoles.label.fontSize)
        assertEquals(12.sp, MaxTypeRoles.metadata.fontSize)
        assertEquals(12.sp, MaxTypeRoles.navLabel.fontSize)
    }
}
