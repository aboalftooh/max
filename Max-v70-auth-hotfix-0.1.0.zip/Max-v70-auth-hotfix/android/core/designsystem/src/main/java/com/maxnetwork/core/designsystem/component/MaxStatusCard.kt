package com.maxnetwork.core.designsystem.component

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.semantics
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.theme.LocalMaxMotionEnabled
import com.maxnetwork.core.designsystem.theme.LocalMaxStatusColors
import com.maxnetwork.core.designsystem.theme.MaxMotion
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxSpacing

enum class MaxRequestStatus {
    NeedsReply,
    Provided,
    Unavailable,
}

@Composable
fun MaxStatusCard(
    title: String,
    supportingText: String,
    status: MaxRequestStatus,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    val statusColors = LocalMaxStatusColors.current
    val motionEnabled = LocalMaxMotionEnabled.current
    val containerColor: Color
    val contentColor: Color
    val icon: ImageVector
    val description: String
    when (status) {
        MaxRequestStatus.NeedsReply -> {
            containerColor = statusColors.attentionContainer
            contentColor = statusColors.onAttentionContainer
            icon = MaxIcons.Alert
            description = "يحتاج ردًا"
        }
        MaxRequestStatus.Provided -> {
            containerColor = statusColors.positiveContainer
            contentColor = statusColors.onPositiveContainer
            icon = MaxIcons.Check
            description = "تم توفيره"
        }
        MaxRequestStatus.Unavailable -> {
            containerColor = statusColors.unavailableContainer
            contentColor = statusColors.onUnavailableContainer
            icon = MaxIcons.Alert
            description = "غير موجود"
        }
    }
    val animatedAlpha = if (motionEnabled && status == MaxRequestStatus.NeedsReply) {
        val transition = rememberInfiniteTransition(label = "request-status-pulse")
        val alpha by transition.animateFloat(
            initialValue = 0.78f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = MaxMotion.statusPulseMillis),
                repeatMode = RepeatMode.Reverse,
            ),
            label = "request-status-alpha",
        )
        alpha
    } else {
        1f
    }
    Surface(
        onClick = onClick ?: {},
        enabled = onClick != null,
        modifier = modifier
            .fillMaxWidth()
            .alpha(animatedAlpha)
            .semantics { stateDescription = description }
            .testTag("max_status_${status.name}"),
        color = containerColor,
        contentColor = contentColor,
        shape = MaterialTheme.shapes.large,
    ) {
        Row(
            modifier = Modifier.padding(MaxSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(MaxSpacing.md),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(MaxSizes.statusIcon),
            )
            Column(
                verticalArrangement = Arrangement.spacedBy(MaxSpacing.xxs),
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(supportingText, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
