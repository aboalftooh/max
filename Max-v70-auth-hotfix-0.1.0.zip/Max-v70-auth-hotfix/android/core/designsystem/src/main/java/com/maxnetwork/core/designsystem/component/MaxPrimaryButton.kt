package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

@Suppress("LongParameterList")
@Composable
fun MaxPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    leadingIcon: ImageVector? = null,
    fullWidth: Boolean = true,
    testTag: String = "max_primary_button",
) {
    Button(
        onClick = onClick,
        modifier = maxActionModifier(modifier, testTag, fullWidth),
        enabled = enabled && !loading,
        shape = MaterialTheme.shapes.medium,
        colors = ButtonDefaults.buttonColors(
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        ),
    ) {
        MaxButtonContent(text = text, loading = loading, leadingIcon = leadingIcon)
    }
}

@Suppress("LongParameterList")
@Composable
fun MaxSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    leadingIcon: ImageVector? = null,
    fullWidth: Boolean = true,
    testTag: String = "max_secondary_button",
) {
    OutlinedButton(
        onClick = onClick,
        modifier = maxActionModifier(modifier, testTag, fullWidth),
        enabled = enabled && !loading,
        shape = MaterialTheme.shapes.medium,
    ) {
        MaxButtonContent(text = text, loading = loading, leadingIcon = leadingIcon)
    }
}

@Composable
fun MaxTertiaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: ImageVector? = null,
    fullWidth: Boolean = false,
    testTag: String = "max_tertiary_button",
) {
    TextButton(
        onClick = onClick,
        modifier = maxActionModifier(modifier, testTag, fullWidth),
        enabled = enabled,
        shape = MaterialTheme.shapes.medium,
    ) {
        MaxButtonContent(text = text, loading = false, leadingIcon = leadingIcon)
    }
}

@Suppress("LongParameterList")
@Composable
fun MaxDestructiveButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    leadingIcon: ImageVector? = null,
    fullWidth: Boolean = true,
    testTag: String = "max_destructive_button",
) {
    Button(
        onClick = onClick,
        modifier = maxActionModifier(modifier, testTag, fullWidth),
        enabled = enabled && !loading,
        shape = MaterialTheme.shapes.medium,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error,
            contentColor = MaterialTheme.colorScheme.onError,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        ),
    ) {
        MaxButtonContent(text = text, loading = loading, leadingIcon = leadingIcon)
    }
}

@Composable
private fun MaxButtonContent(
    text: String,
    loading: Boolean,
    leadingIcon: ImageVector?,
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(MaxSizes.buttonProgress),
                color = androidx.compose.material3.LocalContentColor.current,
                strokeWidth = MaxSizes.progressStroke,
            )
        } else if (leadingIcon != null) {
            MaxIcon(
                imageVector = leadingIcon,
                contentDescription = null,
                modifier = Modifier.size(MaxSizes.iconSmall),
                tint = androidx.compose.material3.LocalContentColor.current,
            )
        }
        MaxText(text = text, style = MaterialTheme.typography.labelLarge)
    }
}

private fun maxActionModifier(
    modifier: Modifier,
    testTag: String,
    fullWidth: Boolean,
): Modifier {
    val widthModifier = if (fullWidth) modifier.fillMaxWidth() else modifier
    return widthModifier
        .heightIn(min = MaxSizes.minimumTouchTarget)
        .semantics { role = Role.Button }
        .testTag(testTag)
}

@MaxComponentPreviews
@Composable
private fun MaxActionsPreview() {
    MaxTheme {
        androidx.compose.foundation.layout.Column(
            modifier = Modifier,
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
        ) {
            MaxPrimaryButton("إجراء أساسي", {}, leadingIcon = MaxIcons.Check)
            MaxSecondaryButton("إجراء ثانوي", {}, enabled = false)
            MaxTertiaryButton("إجراء نصي", {})
            MaxDestructiveButton("حذف", {}, loading = true)
        }
    }
}
