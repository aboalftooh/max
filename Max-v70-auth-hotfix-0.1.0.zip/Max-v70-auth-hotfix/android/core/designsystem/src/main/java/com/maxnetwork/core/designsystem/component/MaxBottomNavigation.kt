package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxBottomNavigationShape
import com.maxnetwork.core.designsystem.theme.MaxElevation
import com.maxnetwork.core.designsystem.theme.MaxPillShape
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

data class MaxBottomNavigationItem(
    val key: String,
    val label: String,
    val icon: ImageVector,
    val enabled: Boolean = true,
    val badgeCount: Int? = null,
)

data class MaxBottomNavigationPrimaryAction(
    val icon: ImageVector,
    val contentDescription: String,
    val testTag: String = "bottom_primary_action",
)

@Composable
fun MaxBottomNavigation(
    items: List<MaxBottomNavigationItem>,
    selectedKey: String,
    onSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    primaryAction: MaxBottomNavigationPrimaryAction? = null,
    onPrimaryAction: () -> Unit = {},
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("bottom_bar"),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = if (primaryAction == null) MaxSpacing.none else MaxSpacing.md),
            shape = MaxBottomNavigationShape,
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
            shadowElevation = MaxElevation.subtleRaised,
        ) {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = MaxElevation.none,
            ) {
                val insertionIndex = if (primaryAction == null) items.size else items.size / 2
                items.forEachIndexed { index, item ->
                    if (primaryAction != null && index == insertionIndex) {
                        Spacer(modifier = Modifier.width(MaxSizes.bottomNavigationPrimaryActionSlot))
                    }
                    MaxBottomNavigationDestination(
                        item = item,
                        selected = item.key == selectedKey,
                        onSelected = onSelected,
                    )
                }
                if (primaryAction != null && insertionIndex == items.size) {
                    Spacer(modifier = Modifier.width(MaxSizes.bottomNavigationPrimaryActionSlot))
                }
            }
        }

        if (primaryAction != null) {
            FloatingActionButton(
                onClick = onPrimaryAction,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .size(MaxSizes.bottomNavigationPrimaryAction)
                    .testTag(primaryAction.testTag),
                shape = MaxPillShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                elevation = FloatingActionButtonDefaults.elevation(
                    defaultElevation = MaxElevation.floatingPrimaryAction,
                    pressedElevation = MaxElevation.floatingPrimaryAction,
                    focusedElevation = MaxElevation.floatingPrimaryAction,
                    hoveredElevation = MaxElevation.floatingPrimaryAction,
                ),
            ) {
                MaxIcon(
                    imageVector = primaryAction.icon,
                    contentDescription = primaryAction.contentDescription,
                )
            }
        }
    }
}

@Composable
private fun RowScope.MaxBottomNavigationDestination(
    item: MaxBottomNavigationItem,
    selected: Boolean,
    onSelected: (String) -> Unit,
) {
    NavigationBarItem(
        selected = selected,
        onClick = { onSelected(item.key) },
        enabled = item.enabled,
        icon = {
            BadgedBox(
                badge = {
                    item.badgeCount?.takeIf { it > 0 }?.let { count ->
                        Badge { MaxText(count.toString()) }
                    }
                },
            ) {
                MaxIcon(
                    imageVector = item.icon,
                    contentDescription = item.label,
                )
            }
        },
        label = { MaxText(item.label, style = MaterialTheme.typography.labelMedium) },
        modifier = Modifier.testTag("bottom_tab_${item.key}"),
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = MaterialTheme.colorScheme.primary,
            selectedTextColor = MaterialTheme.colorScheme.primary,
            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
        ),
    )
}

@MaxComponentPreviews
@Composable
private fun MaxBottomNavigationPreview() {
    MaxTheme {
        MaxBottomNavigation(
            items = listOf(
                MaxBottomNavigationItem("home", "الرئيسية", MaxIcons.Home),
                MaxBottomNavigationItem("chat", "المحادثات", MaxIcons.Conversations, badgeCount = 3),
                MaxBottomNavigationItem("invoice", "الفواتير", MaxIcons.Invoices),
                MaxBottomNavigationItem("settings", "الإعدادات", MaxIcons.Settings),
            ),
            selectedKey = "home",
            onSelected = {},
            primaryAction = MaxBottomNavigationPrimaryAction(
                icon = MaxIcons.Add,
                contentDescription = "طلب جديد",
            ),
        )
    }
}
