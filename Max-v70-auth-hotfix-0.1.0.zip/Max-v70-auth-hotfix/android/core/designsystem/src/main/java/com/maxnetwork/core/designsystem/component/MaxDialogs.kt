package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

@Suppress("LongParameterList")
@Composable
fun MaxDialog(
    title: String,
    onDismissRequest: () -> Unit,
    confirmText: String,
    onConfirm: () -> Unit,
    modifier: Modifier = Modifier,
    dismissText: String? = null,
    onDismiss: (() -> Unit)? = null,
    loading: Boolean = false,
    errorMessage: String? = null,
    content: @Composable (() -> Unit)? = null,
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        modifier = modifier,
        shape = MaterialTheme.shapes.large,
        title = { MaxText(title, style = MaterialTheme.typography.headlineSmall) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm)) {
                content?.invoke()
                errorMessage?.let { MaxInlineBanner(it, tone = MaxBannerTone.Error) }
            }
        },
        confirmButton = {
            MaxPrimaryButton(
                text = confirmText,
                onClick = onConfirm,
                loading = loading,
                fullWidth = false,
                testTag = "max_dialog_confirm",
            )
        },
        dismissButton = if (dismissText != null && onDismiss != null) {
            {
                MaxTertiaryButton(
                    text = dismissText,
                    onClick = onDismiss,
                    fullWidth = false,
                    testTag = "max_dialog_dismiss",
                )
            }
        } else {
            null
        },
    )
}

@Suppress("LongParameterList")
@Composable
fun MaxConfirmationDialog(
    title: String,
    message: String,
    confirmText: String,
    dismissText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    destructive: Boolean = false,
    loading: Boolean = false,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = modifier,
        shape = MaterialTheme.shapes.large,
        title = { MaxText(title, style = MaterialTheme.typography.headlineSmall) },
        text = { MaxText(message, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        confirmButton = {
            if (destructive) {
                MaxDestructiveButton(confirmText, onConfirm, loading = loading, fullWidth = false)
            } else {
                MaxPrimaryButton(confirmText, onConfirm, loading = loading, fullWidth = false)
            }
        },
        dismissButton = { MaxTertiaryButton(dismissText, onDismiss, fullWidth = false) },
    )
}

@MaxComponentPreviews
@Composable
private fun MaxDialogPreview() {
    MaxTheme {
        MaxConfirmationDialog(
            title = "تأكيد الإجراء",
            message = "هل تريد المتابعة؟",
            confirmText = "تأكيد",
            dismissText = "إلغاء",
            onConfirm = {},
            onDismiss = {},
        )
    }
}

@MaxComponentPreviews
@Composable
private fun MaxGenericDialogPreview() {
    MaxTheme {
        MaxDialog(
            title = "تغيير كلمة المرور",
            onDismissRequest = {},
            confirmText = "حفظ",
            onConfirm = {},
            dismissText = "إلغاء",
            onDismiss = {},
            content = { MaxText("محتوى الحوار") },
        )
    }
}
