package com.maxnetwork.core.designsystem.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

/**
 * Canonical MAX semantic colors.
 *
 * Feature UI must consume these values through [MaxTheme]/MaterialTheme or a MAX component;
 * it must not duplicate the literals locally.
 */
object MaxColors {
    val primary = Color(0xFF16A34A)
    val primaryStrong = Color(0xFF087C41)
    val primarySoft = Color(0xFF57C063)
    val onPrimary = Color(0xFFFFFFFF)

    val background = Color(0xFFF7F8FA)
    val surface = Color(0xFFFFFFFF)
    val surfaceSubtle = Color(0xFFF2F4F7)
    val onSurface = Color(0xFF202334)
    val onSurfaceVariant = Color(0xFF6B7280)
    val outline = Color(0xFFE5E7EB)

    val success = Color(0xFF159447)
    val successContainer = Color(0xFFEAF8EF)
    val error = Color(0xFFC62828)
    val errorContainer = Color(0xFFFDECEC)
    val warning = Color(0xFFC58A12)
    val warningContainer = Color(0xFFFFF7E2)

    // Accessibility aliases preserve the approved family while meeting contrast for text/icons.
    val warningAccessible = Color(0xFF825900)
}

internal object MaxDarkColors {
    val primary = Color(0xFF6FD48A)
    val onPrimary = Color(0xFF063D20)
    val primaryContainer = Color(0xFF0A5E32)
    val onPrimaryContainer = Color(0xFFD9FBE3)
    val background = Color(0xFF101612)
    val surface = Color(0xFF171E19)
    val surfaceSubtle = Color(0xFF202922)
    val onSurface = Color(0xFFF1F5F2)
    val onSurfaceVariant = Color(0xFFB7C1BA)
    val outline = Color(0xFF667269)
    val success = Color(0xFF6FD48A)
    val successContainer = Color(0xFF123B21)
    val error = Color(0xFFFFB4AB)
    val errorContainer = Color(0xFF5C1A1A)
    val warning = Color(0xFFF0C36B)
    val warningContainer = Color(0xFF473A16)
    val unavailable = Color(0xFFB7C1BA)
    val unavailableContainer = Color(0xFF2A332C)
}

@Immutable
data class MaxStatusColors(
    val success: Color,
    val onSuccess: Color,
    val successContainer: Color,
    val onSuccessContainer: Color,
    val warning: Color,
    val onWarning: Color,
    val warningContainer: Color,
    val onWarningContainer: Color,
    val error: Color,
    val onError: Color,
    val errorContainer: Color,
    val onErrorContainer: Color,
    val unavailable: Color,
    val onUnavailable: Color,
    val unavailableContainer: Color,
    val onUnavailableContainer: Color,
) {
    // Compatibility aliases for components/features that predate SESSION-54.
    val positive: Color get() = success
    val onPositive: Color get() = onSuccess
    val positiveContainer: Color get() = successContainer
    val onPositiveContainer: Color get() = onSuccessContainer
    val attention: Color get() = warning
    val onAttention: Color get() = onWarning
    val attentionContainer: Color get() = warningContainer
    val onAttentionContainer: Color get() = onWarningContainer
}

internal val LightStatusColors = MaxStatusColors(
    success = MaxColors.success,
    onSuccess = MaxColors.onPrimary,
    successContainer = MaxColors.successContainer,
    onSuccessContainer = MaxColors.primaryStrong,
    warning = MaxColors.warning,
    onWarning = MaxColors.onSurface,
    warningContainer = MaxColors.warningContainer,
    onWarningContainer = MaxColors.warningAccessible,
    error = MaxColors.error,
    onError = MaxColors.onPrimary,
    errorContainer = MaxColors.errorContainer,
    onErrorContainer = MaxColors.error,
    unavailable = MaxColors.onSurfaceVariant,
    onUnavailable = MaxColors.onPrimary,
    unavailableContainer = MaxColors.surfaceSubtle,
    onUnavailableContainer = MaxColors.onSurface,
)

internal val DarkStatusColors = MaxStatusColors(
    success = MaxDarkColors.success,
    onSuccess = MaxDarkColors.background,
    successContainer = MaxDarkColors.successContainer,
    onSuccessContainer = MaxDarkColors.success,
    warning = MaxDarkColors.warning,
    onWarning = MaxDarkColors.background,
    warningContainer = MaxDarkColors.warningContainer,
    onWarningContainer = MaxDarkColors.warning,
    error = MaxDarkColors.error,
    onError = MaxDarkColors.background,
    errorContainer = MaxDarkColors.errorContainer,
    onErrorContainer = MaxDarkColors.error,
    unavailable = MaxDarkColors.unavailable,
    onUnavailable = MaxDarkColors.background,
    unavailableContainer = MaxDarkColors.unavailableContainer,
    onUnavailableContainer = MaxDarkColors.onSurfaceVariant,
)
