package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.LocalMaxStatusColors
import com.maxnetwork.core.designsystem.theme.MaxPillShape
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

@Suppress("LongParameterList")
@Composable
fun MaxText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = MaterialTheme.typography.bodyMedium,
    color: Color = Color.Unspecified,
    textAlign: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
) {
    Text(
        text = text,
        modifier = modifier,
        style = style,
        color = color,
        textAlign = textAlign,
        maxLines = maxLines,
        overflow = overflow,
    )
}

@Composable
fun MaxIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    Icon(
        imageVector = imageVector,
        contentDescription = contentDescription,
        modifier = modifier,
        tint = tint,
    )
}

@Composable
fun MaxDivider(modifier: Modifier = Modifier) {
    HorizontalDivider(modifier = modifier, color = MaterialTheme.colorScheme.outline)
}

@Composable
fun MaxSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    testTag: String = "max_switch",
) {
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        enabled = enabled,
        modifier = modifier
            .sizeIn(
                minWidth = MaxSizes.minimumTouchTarget,
                minHeight = MaxSizes.minimumTouchTarget,
            )
            .testTag(testTag),
    )
}

@Composable
fun MaxBadge(
    text: String,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    enabled: Boolean = true,
) {
    val containerColor = when {
        !enabled -> MaterialTheme.colorScheme.surfaceVariant
        selected -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val contentColor = when {
        !enabled -> MaterialTheme.colorScheme.onSurfaceVariant
        selected -> MaterialTheme.colorScheme.onPrimaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        modifier = modifier.defaultMinSize(minHeight = MaxSizes.badgeMinHeight),
        color = containerColor,
        contentColor = contentColor,
        shape = MaxPillShape,
    ) {
        Box(
            modifier = Modifier.padding(horizontal = MaxSpacing.sm, vertical = MaxSpacing.xxs),
            contentAlignment = Alignment.Center,
        ) {
            MaxText(text = text, style = MaterialTheme.typography.labelMedium)
        }
    }
}

enum class MaxStatusTone { Success, Warning, Error, Neutral }

@Composable
fun MaxStatusPill(
    text: String,
    tone: MaxStatusTone,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    val statusColors = LocalMaxStatusColors.current
    val (container, content) = when (tone) {
        MaxStatusTone.Success -> statusColors.successContainer to statusColors.onSuccessContainer
        MaxStatusTone.Warning -> statusColors.warningContainer to statusColors.onWarningContainer
        MaxStatusTone.Error -> statusColors.errorContainer to statusColors.onErrorContainer
        MaxStatusTone.Neutral -> statusColors.unavailableContainer to statusColors.onUnavailableContainer
    }
    Surface(modifier = modifier, color = container, contentColor = content, shape = MaxPillShape) {
        Row(
            modifier = Modifier.padding(horizontal = MaxSpacing.sm, vertical = MaxSpacing.xxs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) {
                MaxIcon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(MaxSizes.iconSmall),
                    tint = content,
                )
            }
            MaxText(
                text = text,
                modifier = if (icon == null) Modifier else Modifier.padding(start = MaxSpacing.xxs),
                style = MaterialTheme.typography.labelMedium,
            )
        }
    }
}

@Composable
fun MaxIconContainer(
    icon: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
) {
    val container = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val content = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Surface(
        modifier = modifier.size(MaxSizes.iconContainer),
        color = container,
        contentColor = content,
        shape = MaterialTheme.shapes.medium,
    ) {
        Box(contentAlignment = Alignment.Center) {
            MaxIcon(
                imageVector = icon,
                contentDescription = contentDescription,
                modifier = Modifier.size(MaxSizes.iconSmall),
                tint = content,
            )
        }
    }
}

@MaxComponentPreviews
@Composable
private fun MaxPrimitivesPreview() {
    MaxTheme {
        Column(
            modifier = Modifier.padding(MaxSpacing.md),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
        ) {
            MaxText("نص أساسي")
            MaxDivider()
            MaxSwitch(checked = true, onCheckedChange = {})
            MaxBadge("محدد", selected = true)
            MaxStatusPill("مكتمل", MaxStatusTone.Success, icon = MaxIcons.Check)
            MaxIconContainer(MaxIcons.Notifications, "إشعارات", selected = true)
        }
    }
}
