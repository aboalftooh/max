@file:Suppress("TooManyFunctions")

package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.LocalMaxStatusColors
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

enum class MaxStateKind { Loading, Empty, Error, Offline, Success }

@Suppress("LongParameterList")
@Composable
fun MaxStateScreen(
    title: String,
    message: String,
    kind: MaxStateKind,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
) {
    val statusColors = LocalMaxStatusColors.current
    val icon = when (kind) {
        MaxStateKind.Success -> MaxIcons.Check
        MaxStateKind.Error, MaxStateKind.Empty, MaxStateKind.Offline -> MaxIcons.Alert
        MaxStateKind.Loading -> null
    }
    val color = when (kind) {
        MaxStateKind.Error -> MaterialTheme.colorScheme.error
        MaxStateKind.Success -> statusColors.success
        MaxStateKind.Offline, MaxStateKind.Empty -> MaterialTheme.colorScheme.onSurfaceVariant
        MaxStateKind.Loading -> MaterialTheme.colorScheme.primary
    }
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(MaxSpacing.lg)
            .testTag("max_state_${kind.name}"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (kind == MaxStateKind.Loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(MaxSizes.stateIcon),
                color = color,
                strokeWidth = MaxSizes.progressStroke,
            )
        } else if (icon != null) {
            MaxIcon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(MaxSizes.stateIcon),
            )
        }
        MaxText(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = MaxSpacing.md),
        )
        MaxText(
            text = message,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = MaxSpacing.xs),
        )
        if (actionText != null && onAction != null && kind != MaxStateKind.Loading) {
            MaxPrimaryButton(
                text = actionText,
                onClick = onAction,
                modifier = Modifier.padding(top = MaxSpacing.lg),
            )
        }
    }
}

@Composable
fun MaxLoadingState(
    modifier: Modifier = Modifier,
    title: String = "جارٍ التحميل",
    message: String = "يرجى الانتظار",
) = MaxStateScreen(title, message, MaxStateKind.Loading, modifier)

@Composable
fun MaxEmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
) = MaxStateScreen(title, message, MaxStateKind.Empty, modifier, actionText, onAction)

@Composable
fun MaxErrorState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
) = MaxStateScreen(title, message, MaxStateKind.Error, modifier, actionText, onAction)

@Composable
fun MaxOfflineState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
) = MaxStateScreen(title, message, MaxStateKind.Offline, modifier, actionText, onAction)

@Composable
fun MaxSuccessState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
) = MaxStateScreen(title, message, MaxStateKind.Success, modifier, actionText, onAction)

@MaxComponentPreviews
@Composable
private fun MaxStatesPreview() {
    MaxTheme {
        MaxErrorState(
            title = "تعذر التحميل",
            message = "تحقق من الاتصال وحاول مرة أخرى",
            actionText = "إعادة المحاولة",
            onAction = {},
        )
    }
}

@MaxComponentPreviews
@Composable
private fun MaxLoadingStatePreview() {
    MaxTheme { MaxLoadingState() }
}

@MaxComponentPreviews
@Composable
private fun MaxEmptyStatePreview() {
    MaxTheme { MaxEmptyState("لا توجد بيانات", "ستظهر البيانات هنا عند توفرها") }
}

@MaxComponentPreviews
@Composable
private fun MaxOfflineStatePreview() {
    MaxTheme { MaxOfflineState("أنت غير متصل", "تحقق من الشبكة", actionText = "إعادة المحاولة", onAction = {}) }
}

@MaxComponentPreviews
@Composable
private fun MaxSuccessStatePreview() {
    MaxTheme { MaxSuccessState("تم بنجاح", "اكتمل الإجراء") }
}
