package com.maxnetwork.core.designsystem.gallery

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.component.MaxBadge
import com.maxnetwork.core.designsystem.component.MaxBrandMark
import com.maxnetwork.core.designsystem.component.MaxDestructiveButton
import com.maxnetwork.core.designsystem.component.MaxDivider
import com.maxnetwork.core.designsystem.component.MaxErrorMessage
import com.maxnetwork.core.designsystem.component.MaxIconButton
import com.maxnetwork.core.designsystem.component.MaxIconContainer
import com.maxnetwork.core.designsystem.component.MaxInlineBanner
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxOtpField
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxRequestStatus
import com.maxnetwork.core.designsystem.component.MaxSearchField
import com.maxnetwork.core.designsystem.component.MaxSecondaryButton
import com.maxnetwork.core.designsystem.component.MaxSectionHeader
import com.maxnetwork.core.designsystem.component.MaxStatusCard
import com.maxnetwork.core.designsystem.component.MaxStatusPill
import com.maxnetwork.core.designsystem.component.MaxStatusTone
import com.maxnetwork.core.designsystem.component.MaxTertiaryButton
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.component.MaxTextField
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

@Suppress("LongMethod")
@Composable
fun MaxComponentGallery(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(MaxSpacing.lg)
            .testTag("max_component_gallery"),
        verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
    ) {
        MaxText("نظام تصميم max", style = MaterialTheme.typography.headlineMedium)
        MaxBrandMark()
        MaxSectionHeader("Primitives")
        MaxBadge("محدد", selected = true)
        MaxStatusPill("مكتمل", MaxStatusTone.Success, icon = MaxIcons.Check)
        MaxIconContainer(MaxIcons.Notifications, "إشعارات", selected = true)
        MaxDivider()
        MaxSectionHeader("Actions")
        MaxPrimaryButton(text = "إجراء أساسي", onClick = {})
        MaxPrimaryButton(text = "جارٍ التنفيذ", onClick = {}, loading = true)
        MaxSecondaryButton(text = "إجراء ثانوي", onClick = {}, enabled = false)
        MaxTertiaryButton(text = "إجراء نصي", onClick = {})
        MaxDestructiveButton(text = "حذف", onClick = {})
        MaxIconButton(MaxIcons.Notifications, "الإشعارات", {}, selected = true)
        MaxSectionHeader("Inputs")
        MaxTextField(value = "", onValueChange = {}, label = "حقل إدخال")
        MaxSearchField(value = "بحث", onValueChange = {}, placeholder = "بحث", onClear = {})
        MaxOtpField(value = "123", onValueChange = {})
        MaxSectionHeader("Rows + Feedback")
        MaxListContainer {
            MaxListRow(
                title = "عنصر قائمة",
                supportingText = "وصف مختصر",
                leadingIcon = MaxIcons.Invoices,
                selected = true,
            )
        }
        MaxStatusCard("طلب جديد", "منذ دقيقتين", MaxRequestStatus.NeedsReply)
        MaxInlineBanner("تم تحديث البيانات")
        MaxErrorMessage("تعذر تحميل البيانات. حاول مرة أخرى.")
    }
}

@MaxComponentPreviews
@Composable
private fun MaxComponentGalleryPreview() {
    MaxTheme(motionEnabled = false) {
        MaxComponentGallery()
    }
}
