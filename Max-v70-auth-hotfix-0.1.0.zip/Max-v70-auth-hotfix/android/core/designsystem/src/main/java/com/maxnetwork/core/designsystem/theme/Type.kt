package com.maxnetwork.core.designsystem.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.maxnetwork.core.designsystem.R

private val TajawalFamily = FontFamily(
    Font(R.font.tajawal_extralight, weight = FontWeight.ExtraLight),
    Font(R.font.tajawal_light, weight = FontWeight.Light),
    Font(R.font.tajawal_regular, weight = FontWeight.Normal),
    Font(R.font.tajawal_medium, weight = FontWeight.Medium),
    Font(R.font.tajawal_bold, weight = FontWeight.Bold),
    Font(R.font.tajawal_extrabold, weight = FontWeight.ExtraBold),
    Font(R.font.tajawal_black, weight = FontWeight.Black),
)

private fun maxTextStyle(
    weight: FontWeight,
    size: Int,
    lineHeight: Int,
) = TextStyle(
    fontFamily = TajawalFamily,
    fontWeight = weight,
    fontSize = size.sp,
    lineHeight = lineHeight.sp,
)

/** Named typography roles from the approved MAX Design Constitution. */
object MaxTypeRoles {
    val displayAmount = maxTextStyle(FontWeight.ExtraBold, 52, 60)
    val pageTitle = maxTextStyle(FontWeight.Bold, 28, 36)
    val sectionTitle = maxTextStyle(FontWeight.Bold, 22, 30)
    val title = maxTextStyle(FontWeight.Bold, 18, 26)
    val bodyLarge = maxTextStyle(FontWeight.Normal, 16, 26)
    val body = maxTextStyle(FontWeight.Normal, 14, 22)
    val label = maxTextStyle(FontWeight.Medium, 14, 20)
    val metadata = maxTextStyle(FontWeight.Normal, 12, 18)
    val navLabel = maxTextStyle(FontWeight.Medium, 12, 18)
}

/** Material 3 roles are aliases of the named MAX roles; no extra type scale exists. */
val MaxTypography = Typography(
    displayLarge = MaxTypeRoles.displayAmount,
    displayMedium = MaxTypeRoles.pageTitle,
    displaySmall = MaxTypeRoles.sectionTitle,
    headlineLarge = MaxTypeRoles.pageTitle,
    headlineMedium = MaxTypeRoles.sectionTitle,
    headlineSmall = MaxTypeRoles.title,
    titleLarge = MaxTypeRoles.title,
    titleMedium = MaxTypeRoles.title,
    titleSmall = MaxTypeRoles.label,
    bodyLarge = MaxTypeRoles.bodyLarge,
    bodyMedium = MaxTypeRoles.body,
    bodySmall = MaxTypeRoles.metadata,
    labelLarge = MaxTypeRoles.label,
    labelMedium = MaxTypeRoles.navLabel,
    labelSmall = MaxTypeRoles.navLabel,
)
