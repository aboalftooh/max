package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.layout.RowScope
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaxTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    backContentDescription: String = "رجوع",
    leadingContent: (@Composable () -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    TopAppBar(
        modifier = modifier.testTag("max_top_bar"),
        title = { MaxText(title, style = androidx.compose.material3.MaterialTheme.typography.titleLarge) },
        navigationIcon = {
            when {
                leadingContent != null -> leadingContent()
                onBack != null -> MaxIconButton(
                    icon = MaxIcons.BackRtl,
                    contentDescription = backContentDescription,
                    onClick = onBack,
                    testTag = "max_top_bar_back",
                )
            }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background,
            titleContentColor = androidx.compose.material3.MaterialTheme.colorScheme.onBackground,
        ),
    )
}

@MaxComponentPreviews
@Composable
private fun MaxTopBarPreview() {
    MaxTheme {
        MaxTopBar(
            title = "تفاصيل الفاتورة",
            onBack = {},
            actions = {
                MaxIconButton(MaxIcons.Notifications, "الإشعارات", {})
            },
        )
    }
}
