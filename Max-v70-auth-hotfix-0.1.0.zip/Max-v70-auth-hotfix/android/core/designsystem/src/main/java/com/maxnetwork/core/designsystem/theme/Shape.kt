package com.maxnetwork.core.designsystem.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

private val SmallShape = RoundedCornerShape(10.dp)
private val MediumShape = RoundedCornerShape(16.dp)
private val LargeShape = RoundedCornerShape(22.dp)
private val HeroShape = RoundedCornerShape(28.dp)

val MaxPillShape: Shape = RoundedCornerShape(percent = 50)
val MaxBottomNavigationShape: Shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)

val MaxShapes = Shapes(
    extraSmall = SmallShape,
    small = SmallShape,
    medium = MediumShape,
    large = LargeShape,
    extraLarge = HeroShape,
)
