package com.maxnetwork.core.designsystem.theme

import android.animation.ValueAnimator
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val LightColors = lightColorScheme(
    // Text-bearing primary actions use primaryStrong to satisfy 4.5:1 with white.
    primary = MaxColors.primaryStrong,
    onPrimary = MaxColors.onPrimary,
    primaryContainer = MaxColors.successContainer,
    onPrimaryContainer = MaxColors.primaryStrong,
    secondary = MaxColors.primary,
    onSecondary = MaxColors.onSurface,
    secondaryContainer = MaxColors.surfaceSubtle,
    onSecondaryContainer = MaxColors.onSurface,
    tertiary = MaxColors.warningAccessible,
    onTertiary = MaxColors.onPrimary,
    tertiaryContainer = MaxColors.warningContainer,
    onTertiaryContainer = MaxColors.warningAccessible,
    background = MaxColors.background,
    onBackground = MaxColors.onSurface,
    surface = MaxColors.surface,
    onSurface = MaxColors.onSurface,
    surfaceVariant = MaxColors.surfaceSubtle,
    onSurfaceVariant = MaxColors.onSurfaceVariant,
    outline = MaxColors.outline,
    outlineVariant = MaxColors.outline,
    error = MaxColors.error,
    onError = MaxColors.onPrimary,
    errorContainer = MaxColors.errorContainer,
    onErrorContainer = MaxColors.error,
)

private val DarkColors = darkColorScheme(
    primary = MaxDarkColors.primary,
    onPrimary = MaxDarkColors.onPrimary,
    primaryContainer = MaxDarkColors.primaryContainer,
    onPrimaryContainer = MaxDarkColors.onPrimaryContainer,
    secondary = MaxDarkColors.primary,
    onSecondary = MaxDarkColors.onPrimary,
    secondaryContainer = MaxDarkColors.surfaceSubtle,
    onSecondaryContainer = MaxDarkColors.onSurface,
    tertiary = MaxDarkColors.warning,
    onTertiary = MaxDarkColors.background,
    tertiaryContainer = MaxDarkColors.warningContainer,
    onTertiaryContainer = MaxDarkColors.warning,
    background = MaxDarkColors.background,
    onBackground = MaxDarkColors.onSurface,
    surface = MaxDarkColors.surface,
    onSurface = MaxDarkColors.onSurface,
    surfaceVariant = MaxDarkColors.surfaceSubtle,
    onSurfaceVariant = MaxDarkColors.onSurfaceVariant,
    outline = MaxDarkColors.outline,
    outlineVariant = MaxDarkColors.outline,
    error = MaxDarkColors.error,
    onError = MaxDarkColors.background,
    errorContainer = MaxDarkColors.errorContainer,
    onErrorContainer = MaxDarkColors.error,
)

val LocalMaxStatusColors = staticCompositionLocalOf { LightStatusColors }
val LocalMaxMotionEnabled = staticCompositionLocalOf { true }

@Composable
fun MaxTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    motionEnabled: Boolean? = null,
    content: @Composable () -> Unit,
) {
    val resolvedMotionEnabled = motionEnabled ?: ValueAnimator.areAnimatorsEnabled()
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalMaxStatusColors provides if (darkTheme) DarkStatusColors else LightStatusColors,
        LocalMaxMotionEnabled provides resolvedMotionEnabled,
    ) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkColors else LightColors,
            typography = MaxTypography,
            shapes = MaxShapes,
            content = content,
        )
    }
}
