package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.layout.size
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxTheme

@Composable
fun MaxIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    selected: Boolean = false,
    badgeCount: Int? = null,
    testTag: String = "max_icon_button",
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(MaxSizes.minimumTouchTarget)
            .testTag(testTag),
        enabled = enabled,
        colors = IconButtonDefaults.iconButtonColors(
            containerColor = if (selected) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                androidx.compose.ui.graphics.Color.Transparent
            },
            contentColor = if (selected) {
                MaterialTheme.colorScheme.onPrimaryContainer
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            },
        ),
    ) {
        BadgedBox(
            badge = {
                badgeCount?.takeIf { it > 0 }?.let { count ->
                    Badge(modifier = Modifier.testTag("${testTag}_badge")) {
                        MaxText(if (count > 99) "99+" else count.toString())
                    }
                }
            },
        ) {
            MaxIcon(
                imageVector = icon,
                contentDescription = contentDescription,
                modifier = Modifier.size(MaxSizes.iconMedium),
                tint = androidx.compose.material3.LocalContentColor.current,
            )
        }
    }
}

@MaxComponentPreviews
@Composable
private fun MaxIconButtonPreview() {
    MaxTheme {
        MaxIconButton(
            icon = MaxIcons.Notifications,
            contentDescription = "الإشعارات، 3 غير مقروءة",
            onClick = {},
            selected = true,
            badgeCount = 3,
        )
    }
}
