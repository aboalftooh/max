package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxColors
import com.maxnetwork.core.designsystem.theme.MaxElevation
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

@Suppress("LongParameterList")
@Composable
fun MaxScaffold(
    modifier: Modifier = Modifier,
    topBar: @Composable () -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    snackbarHostState: SnackbarHostState? = null,
    floatingActionButton: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
        topBar = topBar,
        bottomBar = bottomBar,
        snackbarHost = { snackbarHostState?.let { SnackbarHost(it) } },
        floatingActionButton = floatingActionButton,
        content = content,
    )
}

@Composable
fun MaxHeroContainer(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(
        horizontal = MaxSpacing.lg,
        vertical = MaxSpacing.xl,
    ),
    content: @Composable BoxScope.() -> Unit,
) {
    CompositionLocalProvider(LocalContentColor provides MaxColors.onPrimary) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .clip(MaterialTheme.shapes.extraLarge)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(MaxColors.primaryStrong, MaxColors.primarySoft),
                    ),
                )
                .padding(contentPadding),
            contentAlignment = Alignment.Center,
            content = content,
        )
    }
}

@Composable
fun MaxSectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MaxText(title, style = MaterialTheme.typography.headlineSmall)
        if (actionText != null && onAction != null) {
            MaxTertiaryButton(
                text = actionText,
                onClick = onAction,
                modifier = Modifier,
                testTag = "max_section_header_action",
            )
        }
    }
}

@Composable
fun MaxListContainer(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        shape = MaterialTheme.shapes.large,
        tonalElevation = MaxElevation.none,
        shadowElevation = MaxElevation.subtle,
    ) {
        Column(content = content)
    }
}

@Suppress("LongParameterList")
@Composable
fun MaxListRow(
    title: String,
    modifier: Modifier = Modifier,
    supportingText: String? = null,
    leadingIcon: ImageVector? = null,
    trailingContent: (@Composable RowScope.() -> Unit)? = null,
    enabled: Boolean = true,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    val rowModifier = if (onClick == null) {
        Modifier
    } else {
        Modifier.clickable(enabled = enabled, onClick = onClick)
    }
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
    ) {
        Row(
            modifier = rowModifier
                .fillMaxWidth()
                .heightIn(min = com.maxnetwork.core.designsystem.theme.MaxSizes.listRowMinHeight)
                .padding(horizontal = MaxSpacing.md, vertical = MaxSpacing.rowVertical),
            horizontalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (leadingIcon != null) {
                MaxIconContainer(
                    icon = leadingIcon,
                    contentDescription = null,
                    selected = selected,
                )
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(MaxSpacing.xxs)) {
                MaxText(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (enabled) androidx.compose.material3.LocalContentColor.current else MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (supportingText != null) {
                    MaxText(
                        text = supportingText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            trailingContent?.invoke(this)
        }
    }
}

@Composable
fun MaxBottomActionBar(
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = MaxElevation.subtleRaised,
    ) {
        Row(
            modifier = Modifier.padding(MaxSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
            verticalAlignment = Alignment.CenterVertically,
            content = content,
        )
    }
}

@MaxComponentPreviews
@Composable
private fun MaxStructurePreview() {
    MaxTheme {
        Column(verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm)) {
            MaxSectionHeader("الفواتير", actionText = "عرض الكل", onAction = {})
            MaxListContainer {
                MaxListRow(title = "فاتورة #104", supportingText = "اليوم", leadingIcon = MaxIcons.Invoices, selected = true)
                MaxDivider()
                MaxListRow(title = "فاتورة #103", supportingText = "أمس", onClick = {})
            }
            MaxBottomActionBar { MaxPrimaryButton("متابعة", {}) }
        }
    }
}

@MaxComponentPreviews
@Composable
private fun MaxScaffoldPreview() {
    MaxTheme {
        MaxScaffold(
            topBar = { MaxTopBar(title = "الرئيسية", onBack = null) },
            content = { paddingValues ->
                MaxText(
                    text = "محتوى الشاشة",
                    modifier = Modifier.padding(paddingValues),
                )
            },
        )
    }
}
