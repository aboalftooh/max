package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.LocalMaxStatusColors
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

enum class MaxBannerTone { Info, Success, Warning, Error }

@Composable
fun MaxInlineBanner(
    message: String,
    modifier: Modifier = Modifier,
    tone: MaxBannerTone = MaxBannerTone.Info,
) {
    val status = LocalMaxStatusColors.current
    val colors: Pair<Color, Color>
    val icon: ImageVector
    when (tone) {
        MaxBannerTone.Info -> {
            colors = MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
            icon = MaxIcons.Notifications
        }
        MaxBannerTone.Success -> {
            colors = status.successContainer to status.onSuccessContainer
            icon = MaxIcons.Check
        }
        MaxBannerTone.Warning -> {
            colors = status.warningContainer to status.onWarningContainer
            icon = MaxIcons.Alert
        }
        MaxBannerTone.Error -> {
            colors = status.errorContainer to status.onErrorContainer
            icon = MaxIcons.Alert
        }
    }
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .semantics { liveRegion = LiveRegionMode.Polite },
        color = colors.first,
        contentColor = colors.second,
        shape = MaterialTheme.shapes.medium,
    ) {
        Row(
            modifier = Modifier.padding(MaxSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
        ) {
            MaxIcon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(MaxSizes.iconMedium),
                tint = colors.second,
            )
            MaxText(message, modifier = Modifier.weight(1f), color = colors.second)
        }
    }
}

@MaxComponentPreviews
@Composable
private fun MaxInlineBannerPreview() {
    MaxTheme {
        androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(MaxSpacing.xs)) {
            MaxInlineBanner("معلومة مهمة")
            MaxInlineBanner("تم الحفظ", tone = MaxBannerTone.Success)
            MaxInlineBanner("راجع البيانات", tone = MaxBannerTone.Warning)
            MaxInlineBanner("تعذر الإرسال", tone = MaxBannerTone.Error)
        }
    }
}
