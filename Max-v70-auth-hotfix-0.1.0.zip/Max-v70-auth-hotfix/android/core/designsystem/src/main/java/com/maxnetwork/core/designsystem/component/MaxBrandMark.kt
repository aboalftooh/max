package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.maxnetwork.core.designsystem.theme.MaxSizes

private val BrandTeal = Color(0xFF07979C)
private val BrandGreen = Color(0xFF49B95E)
private val BrandGold = Color(0xFFF5C84B)

@Composable
fun MaxBrandMark(
    modifier: Modifier = Modifier,
    size: Dp = MaxSizes.brandMarkLarge,
    contentDescription: String = "شعار max",
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(24.dp))
            .semantics { this.contentDescription = contentDescription },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasSize = this.size
            drawRoundRect(
                brush = Brush.linearGradient(
                    colors = listOf(BrandTeal, BrandGreen),
                    start = Offset.Zero,
                    end = Offset(canvasSize.width, canvasSize.height),
                ),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(canvasSize.width * 0.22f),
            )

            val strokeWidth = canvasSize.minDimension * 0.085f
            val arcTopLeft = canvasSize.minDimension * 0.15f
            val arcSize = canvasSize.minDimension * 0.70f

            drawArc(
                color = Color.White,
                startAngle = 165f,
                sweepAngle = 185f,
                useCenter = false,
                topLeft = Offset(arcTopLeft, arcTopLeft),
                size = androidx.compose.ui.geometry.Size(arcSize, arcSize),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )
            val whiteArrow = Path().apply {
                moveTo(canvasSize.width * 0.73f, canvasSize.height * 0.15f)
                lineTo(canvasSize.width * 0.86f, canvasSize.height * 0.29f)
                lineTo(canvasSize.width * 0.68f, canvasSize.height * 0.34f)
                close()
            }
            drawPath(whiteArrow, Color.White)

            drawArc(
                color = BrandGold,
                startAngle = -12f,
                sweepAngle = 185f,
                useCenter = false,
                topLeft = Offset(arcTopLeft, arcTopLeft),
                size = androidx.compose.ui.geometry.Size(arcSize, arcSize),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )
            val goldArrow = Path().apply {
                moveTo(canvasSize.width * 0.27f, canvasSize.height * 0.85f)
                lineTo(canvasSize.width * 0.14f, canvasSize.height * 0.71f)
                lineTo(canvasSize.width * 0.32f, canvasSize.height * 0.66f)
                close()
            }
            drawPath(goldArrow, BrandGold)
        }

        Text(
            text = "max",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            fontWeight = FontWeight.Black,
        )
    }
}
