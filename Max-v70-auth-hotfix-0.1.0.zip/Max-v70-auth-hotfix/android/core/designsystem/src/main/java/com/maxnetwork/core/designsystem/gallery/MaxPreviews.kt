package com.maxnetwork.core.designsystem.gallery

import android.content.res.Configuration
import androidx.compose.ui.tooling.preview.Preview

@Preview(
    name = "Light RTL",
    group = "MAX",
    showBackground = true,
    locale = "ar",
    uiMode = Configuration.UI_MODE_NIGHT_NO,
)
@Preview(
    name = "Dark RTL",
    group = "MAX",
    showBackground = true,
    locale = "ar",
    uiMode = Configuration.UI_MODE_NIGHT_YES,
)
annotation class MaxComponentPreviews
