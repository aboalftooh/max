package com.maxnetwork.core.designsystem.component

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun MaxErrorMessage(
    message: String,
    modifier: Modifier = Modifier,
) {
    MaxInlineBanner(message = message, modifier = modifier, tone = MaxBannerTone.Error)
}
