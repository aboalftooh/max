package com.maxnetwork.core.designsystem.theme

import androidx.compose.runtime.Stable
import androidx.compose.ui.unit.dp

/** Canonical spacing scale. No feature-local spacing scale may be introduced. */
@Stable
object MaxSpacing {
    val none = 0.dp
    val xxs = 4.dp
    val xs = 8.dp
    val sm = 12.dp
    val md = 16.dp
    val mdPlus = 20.dp
    val lg = 24.dp
    val xl = 32.dp
    val xlPlus = 40.dp
    val xxl = 48.dp

    val sectionGap = lg
    val rowVertical = md
}

/** Screen content insets are semantic tokens, not screen-owned literals. */
@Stable
object MaxScreenInsets {
    val compactHorizontal = MaxSpacing.mdPlus
    val wideHorizontal = MaxSpacing.lg
}

@Stable
object MaxSizes {
    val minimumTouchTarget = 48.dp
    val fieldHeight = 56.dp
    val brandMarkLarge = 112.dp
    val statusIcon = 28.dp
    val stateIcon = 48.dp
    val iconSmall = 20.dp
    val iconMedium = 24.dp
    val iconLarge = 32.dp
    val iconContainer = 40.dp
    val buttonProgress = 20.dp
    val progressStroke = 2.dp
    val otpCell = 48.dp
    val badgeMinHeight = 24.dp
    val listRowMinHeight = 56.dp
    val readableContentMaxWidth = 720.dp
    val bottomNavigationPrimaryAction = 64.dp
    val bottomNavigationPrimaryActionSlot = 72.dp
}

@Stable
object MaxElevation {
    val none = 0.dp
    val subtle = 1.dp
    val subtleRaised = 2.dp
    val floatingPrimaryAction = 6.dp
    val dialog = 6.dp
}

@Stable
object MaxMotion {
    const val fastMillis = 150
    const val standardMillis = 250
    const val emphasizedMillis = 400
    const val statusPulseMillis = 1_200
}
