package com.maxnetwork.core.designsystem

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object MaxIcons {
    val BackRtl: ImageVector by lazy {
        ImageVector.Builder("BackRtl", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(9f, 5f)
                lineTo(16f, 12f)
                lineTo(9f, 19f)
                lineTo(7.6f, 17.6f)
                lineTo(13.2f, 12f)
                lineTo(7.6f, 6.4f)
                close()
            }
        }.build()
    }

    val Check: ImageVector by lazy {
        ImageVector.Builder("Check", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(9.2f, 16.2f)
                lineTo(4.8f, 11.8f)
                lineTo(3.4f, 13.2f)
                lineTo(9.2f, 19f)
                lineTo(21f, 7.2f)
                lineTo(19.6f, 5.8f)
                close()
            }
        }.build()
    }

    val Alert: ImageVector by lazy {
        ImageVector.Builder("Alert", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f)
                lineTo(1f, 21f)
                lineTo(23f, 21f)
                close()
                moveTo(11f, 8f)
                lineTo(13f, 8f)
                lineTo(13f, 14f)
                lineTo(11f, 14f)
                close()
                moveTo(11f, 16f)
                lineTo(13f, 16f)
                lineTo(13f, 18f)
                lineTo(11f, 18f)
                close()
            }
        }.build()
    }

    val Notifications: ImageVector by lazy {
        ImageVector.Builder("Notifications", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 22f)
                curveTo(13.1f, 22f, 14f, 21.1f, 14f, 20f)
                lineTo(10f, 20f)
                curveTo(10f, 21.1f, 10.9f, 22f, 12f, 22f)
                close()
                moveTo(18f, 16f)
                lineTo(18f, 11f)
                curveTo(18f, 7.9f, 16.4f, 5.3f, 13.5f, 4.4f)
                lineTo(13.5f, 3.5f)
                curveTo(13.5f, 2.7f, 12.8f, 2f, 12f, 2f)
                curveTo(11.2f, 2f, 10.5f, 2.7f, 10.5f, 3.5f)
                lineTo(10.5f, 4.4f)
                curveTo(7.6f, 5.3f, 6f, 7.9f, 6f, 11f)
                lineTo(6f, 16f)
                lineTo(4f, 18f)
                lineTo(20f, 18f)
                close()
            }
        }.build()
    }

    val Add: ImageVector by lazy {
        ImageVector.Builder("Add", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(11f, 5f)
                lineTo(13f, 5f)
                lineTo(13f, 11f)
                lineTo(19f, 11f)
                lineTo(19f, 13f)
                lineTo(13f, 13f)
                lineTo(13f, 19f)
                lineTo(11f, 19f)
                lineTo(11f, 13f)
                lineTo(5f, 13f)
                lineTo(5f, 11f)
                lineTo(11f, 11f)
                close()
            }
        }.build()
    }

    val Home: ImageVector by lazy {
        ImageVector.Builder("Home", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 11f)
                lineTo(12f, 3f)
                lineTo(21f, 11f)
                lineTo(21f, 21f)
                lineTo(14.5f, 21f)
                lineTo(14.5f, 15f)
                lineTo(9.5f, 15f)
                lineTo(9.5f, 21f)
                lineTo(3f, 21f)
                close()
            }
        }.build()
    }

    val Conversations: ImageVector by lazy {
        ImageVector.Builder("Conversations", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(4f, 4f)
                lineTo(20f, 4f)
                curveTo(21.1f, 4f, 22f, 4.9f, 22f, 6f)
                lineTo(22f, 16f)
                curveTo(22f, 17.1f, 21.1f, 18f, 20f, 18f)
                lineTo(9f, 18f)
                lineTo(4f, 22f)
                lineTo(4f, 18f)
                curveTo(2.9f, 18f, 2f, 17.1f, 2f, 16f)
                lineTo(2f, 6f)
                curveTo(2f, 4.9f, 2.9f, 4f, 4f, 4f)
                close()
            }
        }.build()
    }

    val Invoices: ImageVector by lazy {
        ImageVector.Builder("Invoices", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(5f, 2f)
                lineTo(19f, 2f)
                lineTo(19f, 22f)
                lineTo(16f, 20f)
                lineTo(13.5f, 22f)
                lineTo(11f, 20f)
                lineTo(8.5f, 22f)
                lineTo(5f, 20f)
                close()
                moveTo(8f, 7f)
                lineTo(16f, 7f)
                lineTo(16f, 9f)
                lineTo(8f, 9f)
                close()
                moveTo(8f, 12f)
                lineTo(16f, 12f)
                lineTo(16f, 14f)
                lineTo(8f, 14f)
                close()
            }
        }.build()
    }

    val Settings: ImageVector by lazy {
        ImageVector.Builder("Settings", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 8f)
                curveTo(9.8f, 8f, 8f, 9.8f, 8f, 12f)
                curveTo(8f, 14.2f, 9.8f, 16f, 12f, 16f)
                curveTo(14.2f, 16f, 16f, 14.2f, 16f, 12f)
                curveTo(16f, 9.8f, 14.2f, 8f, 12f, 8f)
                close()
                moveTo(10.5f, 2f)
                lineTo(13.5f, 2f)
                lineTo(14.2f, 4.3f)
                curveTo(15f, 4.6f, 15.8f, 5f, 16.4f, 5.5f)
                lineTo(18.8f, 5f)
                lineTo(20.3f, 7.6f)
                lineTo(18.6f, 9.4f)
                curveTo(18.8f, 10.2f, 19f, 11.1f, 19f, 12f)
                curveTo(19f, 12.9f, 18.8f, 13.8f, 18.6f, 14.6f)
                lineTo(20.3f, 16.4f)
                lineTo(18.8f, 19f)
                lineTo(16.4f, 18.5f)
                curveTo(15.8f, 19f, 15f, 19.4f, 14.2f, 19.7f)
                lineTo(13.5f, 22f)
                lineTo(10.5f, 22f)
                lineTo(9.8f, 19.7f)
                curveTo(9f, 19.4f, 8.2f, 19f, 7.6f, 18.5f)
                lineTo(5.2f, 19f)
                lineTo(3.7f, 16.4f)
                lineTo(5.4f, 14.6f)
                curveTo(5.2f, 13.8f, 5f, 12.9f, 5f, 12f)
                curveTo(5f, 11.1f, 5.2f, 10.2f, 5.4f, 9.4f)
                lineTo(3.7f, 7.6f)
                lineTo(5.2f, 5f)
                lineTo(7.6f, 5.5f)
                curveTo(8.2f, 5f, 9f, 4.6f, 9.8f, 4.3f)
                close()
            }
        }.build()
    }


    val Search: ImageVector by lazy {
        ImageVector.Builder("Search", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(10.5f, 4f)
                curveTo(6.9f, 4f, 4f, 6.9f, 4f, 10.5f)
                curveTo(4f, 14.1f, 6.9f, 17f, 10.5f, 17f)
                curveTo(12f, 17f, 13.4f, 16.5f, 14.5f, 15.6f)
                lineTo(19.2f, 20.3f)
                lineTo(20.6f, 18.9f)
                lineTo(15.9f, 14.2f)
                curveTo(16.6f, 13.2f, 17f, 11.9f, 17f, 10.5f)
                curveTo(17f, 6.9f, 14.1f, 4f, 10.5f, 4f)
                close()
                moveTo(10.5f, 6f)
                curveTo(13f, 6f, 15f, 8f, 15f, 10.5f)
                curveTo(15f, 13f, 13f, 15f, 10.5f, 15f)
                curveTo(8f, 15f, 6f, 13f, 6f, 10.5f)
                curveTo(6f, 8f, 8f, 6f, 10.5f, 6f)
                close()
            }
        }.build()
    }

    val Close: ImageVector by lazy {
        ImageVector.Builder("Close", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(6.4f, 5f)
                lineTo(12f, 10.6f)
                lineTo(17.6f, 5f)
                lineTo(19f, 6.4f)
                lineTo(13.4f, 12f)
                lineTo(19f, 17.6f)
                lineTo(17.6f, 19f)
                lineTo(12f, 13.4f)
                lineTo(6.4f, 19f)
                lineTo(5f, 17.6f)
                lineTo(10.6f, 12f)
                lineTo(5f, 6.4f)
                close()
            }
        }.build()
    }


}
