@file:Suppress("TooManyFunctions")

package com.maxnetwork.core.designsystem.pattern

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.component.MaxBottomActionBar
import com.maxnetwork.core.designsystem.component.MaxListContainer
import com.maxnetwork.core.designsystem.component.MaxListRow
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxSearchField
import com.maxnetwork.core.designsystem.component.MaxSectionHeader
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxScreenInsets
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

@Composable
fun MaxDashboardPattern(
    hero: @Composable () -> Unit,
    sections: @Composable ColumnScope.() -> Unit,
    modifier: Modifier = Modifier,
    header: (@Composable () -> Unit)? = null,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = MaxScreenInsets.compactHorizontal),
        verticalArrangement = Arrangement.spacedBy(MaxSpacing.sectionGap),
    ) {
        header?.invoke()
        hero()
        sections()
    }
}

@Suppress("LongParameterList")
@Composable
fun MaxSearchableListPattern(
    query: String,
    onQueryChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    header: (@Composable () -> Unit)? = null,
    stateContent: (@Composable () -> Unit)? = null,
    listContent: LazyListScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = MaxScreenInsets.compactHorizontal),
        verticalArrangement = Arrangement.spacedBy(MaxSpacing.md),
    ) {
        header?.invoke()
        MaxSearchField(query, onQueryChange, placeholder)
        if (stateContent != null) {
            stateContent()
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(MaxSpacing.xs),
                content = listContent,
            )
        }
    }
}

@Composable
fun MaxDetailsPattern(
    summary: @Composable () -> Unit,
    groups: @Composable ColumnScope.() -> Unit,
    modifier: Modifier = Modifier,
    header: (@Composable () -> Unit)? = null,
    actions: (@Composable () -> Unit)? = null,
) {
    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = MaxScreenInsets.compactHorizontal),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.sectionGap),
        ) {
            header?.invoke()
            summary()
            groups()
        }
        actions?.invoke()
    }
}

@Composable
fun MaxFormPattern(
    sections: @Composable ColumnScope.() -> Unit,
    modifier: Modifier = Modifier,
    header: (@Composable () -> Unit)? = null,
    actions: (@Composable () -> Unit)? = null,
) {
    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = MaxScreenInsets.compactHorizontal),
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.sectionGap),
        ) {
            header?.invoke()
            sections()
        }
        actions?.invoke()
    }
}

@Composable
fun MaxSettingsPattern(
    modifier: Modifier = Modifier,
    header: (@Composable () -> Unit)? = null,
    sections: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = MaxScreenInsets.compactHorizontal),
        verticalArrangement = Arrangement.spacedBy(MaxSpacing.sectionGap),
    ) {
        header?.invoke()
        sections()
    }
}

@Composable
fun MaxChatPattern(
    messages: @Composable () -> Unit,
    composer: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    header: (@Composable () -> Unit)? = null,
) {
    Column(modifier = modifier.fillMaxSize()) {
        header?.invoke()
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = MaxScreenInsets.compactHorizontal),
        ) {
            messages()
        }
        composer()
    }
}

@MaxComponentPreviews
@Composable
private fun MaxDashboardPatternPreview() {
    MaxTheme {
        MaxDashboardPattern(
            hero = {
                MaxListContainer {
                    MaxListRow(title = "الرصيد", supportingText = "125,000 ج.س", leadingIcon = MaxIcons.Home)
                }
            },
            sections = {
                MaxSectionHeader("الأحدث")
                MaxListContainer { MaxListRow(title = "فاتورة #104", supportingText = "اليوم") }
            },
        )
    }
}

@MaxComponentPreviews
@Composable
private fun MaxSearchableListPatternPreview() {
    MaxTheme {
        MaxSearchableListPattern("", {}, "بحث") {
            item { MaxListRow(title = "محادثة", supportingText = "الآن", leadingIcon = MaxIcons.Conversations) }
        }
    }
}

@MaxComponentPreviews
@Composable
private fun MaxDetailsPatternPreview() {
    MaxTheme {
        MaxDetailsPattern(
            summary = { MaxText("ملخص", style = MaterialTheme.typography.headlineSmall) },
            groups = { MaxListContainer { MaxListRow(title = "الحالة", supportingText = "مكتملة") } },
            actions = { MaxBottomActionBar { MaxPrimaryButton("إجراء", {}) } },
        )
    }
}

@MaxComponentPreviews
@Composable
private fun MaxFormPatternPreview() {
    MaxTheme {
        MaxFormPattern(
            sections = { MaxText("قسم النموذج") },
            actions = { MaxBottomActionBar { MaxPrimaryButton("إرسال", {}) } },
        )
    }
}

@MaxComponentPreviews
@Composable
private fun MaxSettingsPatternPreview() {
    MaxTheme {
        MaxSettingsPattern {
            MaxSectionHeader("الحساب")
            MaxListContainer { MaxListRow(title = "الخصوصية", leadingIcon = MaxIcons.Settings) }
        }
    }
}

@MaxComponentPreviews
@Composable
private fun MaxChatPatternPreview() {
    MaxTheme {
        MaxChatPattern(
            messages = { MaxText("رسالة تجريبية") },
            composer = {
                MaxBottomActionBar {
                    MaxPrimaryButton("إرسال", {})
                }
            },
        )
    }
}
