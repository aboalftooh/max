package com.maxnetwork.core.designsystem.component

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.gallery.MaxComponentPreviews
import com.maxnetwork.core.designsystem.theme.MaxSizes
import com.maxnetwork.core.designsystem.theme.MaxSpacing
import com.maxnetwork.core.designsystem.theme.MaxTheme

@Suppress("LongParameterList")
@Composable
fun MaxTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isError: Boolean = false,
    supportingText: String? = null,
    placeholder: String? = null,
    singleLine: Boolean = true,
    minLines: Int = 1,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    trailingIcon: (@Composable () -> Unit)? = null,
    testTag: String = "max_text_field",
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = MaxSizes.fieldHeight)
            .testTag(testTag),
        enabled = enabled,
        isError = isError,
        singleLine = singleLine,
        label = { MaxText(label) },
        placeholder = placeholder?.let { text -> { MaxText(text) } },
        supportingText = supportingText?.let { text -> { MaxText(text) } },
        minLines = minLines,
        maxLines = maxLines,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        visualTransformation = visualTransformation,
        trailingIcon = trailingIcon,
        shape = MaterialTheme.shapes.medium,
    )
}

@Suppress("LongParameterList")
@Composable
fun MaxSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isError: Boolean = false,
    supportingText: String? = null,
    onClear: (() -> Unit)? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    testTag: String = "max_search_field",
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = MaxSizes.fieldHeight)
            .testTag(testTag),
        enabled = enabled,
        isError = isError,
        singleLine = true,
        placeholder = { MaxText(placeholder) },
        supportingText = supportingText?.let { text -> { MaxText(text) } },
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        leadingIcon = {
            MaxIcon(
                imageVector = MaxIcons.Search,
                contentDescription = null,
                modifier = Modifier.size(MaxSizes.iconSmall),
            )
        },
        trailingIcon = if (value.isNotEmpty() && onClear != null) {
            {
                MaxIconButton(
                    icon = MaxIcons.Close,
                    contentDescription = "مسح البحث",
                    onClick = onClear,
                    testTag = "${testTag}_clear",
                )
            }
        } else {
            null
        },
        shape = MaterialTheme.shapes.medium,
    )
}

@Suppress("LongMethod", "LongParameterList")
@Composable
fun MaxOtpField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    length: Int = 6,
    enabled: Boolean = true,
    isError: Boolean = false,
    keyboardOptions: KeyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    testTag: String = "max_otp_field",
) {
    require(length > 0) { "OTP length must be positive" }
    val focusRequester = remember { FocusRequester() }
    val interactionSource = remember { MutableInteractionSource() }
    val borderColor = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline
    val activeBorder = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
    val normalizedValue = value.filter(Char::isDigit).take(length)

    BasicTextField(
        value = normalizedValue,
        onValueChange = { candidate -> onValueChange(candidate.filter(Char::isDigit).take(length)) },
        modifier = modifier
            .fillMaxWidth()
            .focusRequester(focusRequester)
            .testTag(testTag),
        enabled = enabled,
        textStyle = MaterialTheme.typography.titleLarge.copy(color = Color.Transparent),
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        cursorBrush = SolidColor(Color.Transparent),
        decorationBox = { innerTextField ->
            Box {
                innerTextField()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null,
                            enabled = enabled,
                            onClick = { focusRequester.requestFocus() },
                        ),
                    horizontalArrangement = Arrangement.spacedBy(
                        MaxSpacing.xxs,
                        Alignment.CenterHorizontally,
                    ),
                ) {
                    repeat(length) { index ->
                        val active = index == normalizedValue.length && normalizedValue.length < length
                        val cellBorder = if (active) activeBorder else borderColor
                        Box(
                            modifier = Modifier
                                .widthIn(min = MaxSizes.otpCell)
                                .heightIn(min = MaxSizes.otpCell)
                                .border(
                                    width = MaxSizes.progressStroke,
                                    color = cellBorder,
                                    shape = MaterialTheme.shapes.small,
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            MaxText(
                                text = normalizedValue.getOrNull(index)?.toString().orEmpty(),
                                style = MaterialTheme.typography.titleLarge,
                            )
                        }
                    }
                }
            }
        },
    )
}

@MaxComponentPreviews
@Composable
private fun MaxFieldsPreview() {
    MaxTheme {
        androidx.compose.foundation.layout.Column(
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.sm),
        ) {
            MaxTextField("", {}, "رقم الهاتف")
            MaxTextField("قيمة", {}, "حقل بخطأ", isError = true, supportingText = "راجع القيمة")
            MaxSearchField("فلتر", {}, "بحث", onClear = {})
            MaxSearchField("", {}, "بحث بخطأ", isError = true, supportingText = "تعذر البحث")
            MaxOtpField("123", {})
            MaxOtpField("123456", {}, isError = true)
        }
    }
}
