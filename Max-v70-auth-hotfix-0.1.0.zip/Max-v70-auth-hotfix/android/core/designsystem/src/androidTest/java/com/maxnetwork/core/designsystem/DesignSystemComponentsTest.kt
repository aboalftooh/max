package com.maxnetwork.core.designsystem

import androidx.compose.ui.test.assertDoesNotExist
import androidx.compose.ui.test.assertHeightIsAtLeast
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.unit.dp
import com.maxnetwork.core.designsystem.component.MaxOtpField
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxRequestStatus
import com.maxnetwork.core.designsystem.component.MaxStatusCard
import com.maxnetwork.core.designsystem.gallery.MaxComponentGallery
import com.maxnetwork.core.designsystem.theme.MaxTheme
import org.junit.Rule
import org.junit.Test

class DesignSystemComponentsTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun primaryButtonMeetsMinimumTouchTarget() {
        composeRule.setContent {
            MaxTheme { MaxPrimaryButton(text = "متابعة", onClick = {}) }
        }
        composeRule.onNodeWithTag("max_primary_button")
            .assertIsDisplayed()
            .assertHeightIsAtLeast(48.dp)
            .assertTextEquals("متابعة")
    }

    @Test
    fun otpFieldUsesCentralizedSixCellContract() {
        composeRule.setContent {
            MaxTheme { MaxOtpField(value = "123", onValueChange = {}) }
        }
        composeRule.onNodeWithTag("max_otp_field").assertIsDisplayed()
        composeRule.onNodeWithText("1").assertIsDisplayed()
        composeRule.onNodeWithText("2").assertIsDisplayed()
        composeRule.onNodeWithText("3").assertIsDisplayed()
    }

    @Test
    fun statusCardsExposeArabicStateAndGalleryRenders() {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                MaxComponentGallery()
                MaxStatusCard("طلب", "الآن", MaxRequestStatus.NeedsReply)
            }
        }
        composeRule.onNodeWithTag("max_component_gallery").assertIsDisplayed()
        composeRule.onNodeWithText("يحتاج ردًا").assertDoesNotExist()
        composeRule.onNodeWithTag("max_status_NeedsReply").assertIsDisplayed()
    }
}
