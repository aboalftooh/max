package com.maxnetwork.core.network

import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.SocketPolicy
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class RetrofitMaxGatewayTest {
    private lateinit var server: MockWebServer
    private val events = mutableListOf<AuthNetworkEvent>()

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun `login parses session and emits metadata-only events`() {
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "application/json")
                .setBody(
                    """
                    {
                      "accessToken":"secret-access-token",
                      "refreshToken":"secret-refresh-token",
                      "expiresAt":"2026-07-28T13:00:00Z"
                    }
                    """.trimIndent(),
                ),
        )
        val gateway = createGateway()

        val result = runSuspend {
            gateway.login(LoginCredentials(phone = "+249900000000", password = "private-password"))
        }

        assertTrue(result is GatewayResult.Success)
        assertEquals(
            listOf(
                AuthNetworkEvent(AuthNetworkOperation.Login, AuthNetworkOutcome.Started),
                AuthNetworkEvent(AuthNetworkOperation.Login, AuthNetworkOutcome.Succeeded),
            ),
            events,
        )
        val eventText = events.joinToString()
        assertTrue("secret-access-token" !in eventText)
        assertTrue("secret-refresh-token" !in eventText)
        assertTrue("private-password" !in eventText)
        assertEquals("/v1/auth/sessions", server.takeRequest().path)
    }

    @Test
    fun `unauthorized refresh maps to expired-session failure`() {
        server.enqueue(MockResponse().setResponseCode(401))
        val gateway = createGateway()

        val result = runSuspend { gateway.refreshSession("expired-refresh-token") }

        assertTrue(result is GatewayResult.Failure)
        assertEquals(ApiErrorCode.Unauthorized, (result as GatewayResult.Failure).error.code)
    }

    @Test
    fun `transport disconnect maps to retryable network failure`() {
        server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.DISCONNECT_AT_START))
        val gateway = createGateway()

        val result = runSuspend {
            gateway.login(LoginCredentials(phone = "+249900000000", password = "private-password"))
        }

        assertTrue(result is GatewayResult.Failure)
        val error = (result as GatewayResult.Failure).error
        assertEquals(ApiErrorCode.ServiceUnavailable, error.code)
        assertTrue(error.retryable)
    }

    @Test
    fun `logout sends bearer token without recording it`() {
        server.enqueue(MockResponse().setResponseCode(204))
        val gateway = createGateway()

        val result = runSuspend { gateway.logout("private-access-token") }

        assertEquals(GatewayResult.Success(Unit), result)
        val request = server.takeRequest()
        assertEquals("Bearer private-access-token", request.getHeader("Authorization"))
        assertTrue("private-access-token" !in events.joinToString())
    }


    @Test
    fun `password reset request uses generic challenge endpoint`() {
        server.enqueue(
            MockResponse()
                .setResponseCode(202)
                .setHeader("Content-Type", "application/json")
                .setBody(
                    """
                    {
                      "challengeId":"reset-challenge",
                      "expiresAt":"2026-07-28T13:10:00Z",
                      "resendAvailableAt":"2026-07-28T13:01:00Z",
                      "remainingAttempts":5
                    }
                    """.trimIndent(),
                ),
        )
        val gateway = createGateway()

        val result = runSuspend { gateway.requestPasswordReset("+249912000000") }

        assertTrue(result is GatewayResult.Success)
        val request = server.takeRequest()
        assertEquals("/v1/auth/password-reset/challenges", request.path)
        assertTrue(request.body.readUtf8().contains("+249912000000"))
    }

    @Test
    fun `password reset confirm sends code and new password without logging them`() {
        server.enqueue(MockResponse().setResponseCode(204))
        val gateway = createGateway()

        val result = runSuspend {
            gateway.resetPassword(
                ResetPasswordCommand(
                    phone = "+249912000000",
                    resetCode = "246810",
                    newPassword = "new-password-12",
                ),
            )
        }

        assertEquals(GatewayResult.Success(Unit), result)
        val request = server.takeRequest()
        assertEquals("/v1/auth/password-reset/confirm", request.path)
        assertTrue("246810" !in events.joinToString())
        assertTrue("new-password-12" !in events.joinToString())
    }


    @Test
    fun `protected reads use current bearer token and rotate without rebuilding gateway`() {
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "application/json")
                .setBody("""{"balance":{"minorUnits":0,"currency":"SDG"},"asOf":null}"""),
        )
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "application/json")
                .setBody("""{"balance":{"minorUnits":0,"currency":"SDG"},"asOf":null}"""),
        )
        val tokenStore = InMemoryBearerTokenStore().apply { update("first-token") }
        val gateway = createGateway(tokenStore)

        assertTrue(runSuspend { gateway.getBalance() } is GatewayResult.Success)
        assertEquals("Bearer first-token", server.takeRequest().getHeader("Authorization"))

        tokenStore.update("rotated-token")
        assertTrue(runSuspend { gateway.getBalance() } is GatewayResult.Success)
        assertEquals("Bearer rotated-token", server.takeRequest().getHeader("Authorization"))
    }

    @Test
    fun `authentication endpoints never inherit protected bearer token`() {
        server.enqueue(MockResponse().setResponseCode(401))
        val tokenStore = InMemoryBearerTokenStore().apply { update("must-not-leak") }
        val gateway = createGateway(tokenStore)

        runSuspend { gateway.login(LoginCredentials(phone = "+249900000000", password = "private-password")) }

        assertEquals(null, server.takeRequest().getHeader("Authorization"))
    }

    private fun createGateway(
        bearerTokenStore: BearerTokenStore = InMemoryBearerTokenStore(),
    ): RetrofitMaxGateway = RetrofitMaxGateway.createForTesting(
        baseUrl = server.url("/").toString(),
        eventSink = AuthNetworkEventSink { events += it },
        bearerTokenStore = bearerTokenStore,
    )

    private fun <T> runSuspend(block: suspend () -> T): T {
        val latch = CountDownLatch(1)
        var outcome: Result<T>? = null
        block.startCoroutine(
            object : Continuation<T> {
                override val context = EmptyCoroutineContext

                override fun resumeWith(result: Result<T>) {
                    outcome = result
                    latch.countDown()
                }
            },
        )
        check(latch.await(10, TimeUnit.SECONDS)) { "Suspend call timed out" }
        return outcome!!.getOrThrow()
    }
}
