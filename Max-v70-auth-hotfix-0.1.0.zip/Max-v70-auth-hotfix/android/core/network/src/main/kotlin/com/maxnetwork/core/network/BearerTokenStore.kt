package com.maxnetwork.core.network

import java.util.concurrent.atomic.AtomicReference

/**
 * Process-local bearer token bridge shared by the encrypted auth store and Retrofit.
 * The token is never persisted here and is cleared whenever the auth session is cleared.
 */
interface BearerTokenStore {
    fun current(): String?
    fun update(token: String?)
}

class InMemoryBearerTokenStore : BearerTokenStore {
    private val token = AtomicReference<String?>(null)

    override fun current(): String? = token.get()

    override fun update(token: String?) {
        this.token.set(token?.takeIf(String::isNotBlank))
    }
}

internal fun isProtectedMaxApiPath(path: String): Boolean {
    val apiPath = path.substring(path.indexOf("/v1/").takeIf { it >= 0 } ?: 0)
    return PROTECTED_PREFIXES.any(apiPath::startsWith)
}

private val PROTECTED_PREFIXES = listOf(
    "/v1/media/",
    "/v1/requests",
    "/v1/orders",
    "/v1/balance",
    "/v1/profile",
    "/v1/support",
    "/v1/privacy",
    "/v1/account-deletion",
    "/v1/notifications",
    "/v1/push/",
)
