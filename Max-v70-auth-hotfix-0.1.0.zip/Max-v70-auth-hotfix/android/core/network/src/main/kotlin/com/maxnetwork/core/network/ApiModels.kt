package com.maxnetwork.core.network

import java.time.Instant

sealed interface GatewayResult<out T> {
    data class Success<T>(val value: T) : GatewayResult<T>
    data class Failure(val error: ApiError) : GatewayResult<Nothing>
}

data class ApiError(
    val code: ApiErrorCode,
    val message: String,
    val traceId: String,
    val retryable: Boolean,
    val fieldErrors: Map<String, String> = emptyMap(),
)

enum class ApiErrorCode {
    InvalidRequest,
    Unauthorized,
    Forbidden,
    NotFound,
    Conflict,
    RateLimited,
    AttachmentRejected,
    ServiceUnavailable,
    Unknown,
}

data class CursorPage<T>(
    val items: List<T>,
    val nextCursor: String?,
)

data class RegistrationCodeValidation(
    val validationToken: String,
    val storeDisplayName: String,
    val expiresAt: Instant,
)

data class PhoneChallenge(
    val challengeId: String,
    val expiresAt: Instant,
    val resendAvailableAt: Instant,
    val remainingAttempts: Int,
)

data class VerifiedPhone(
    val verificationToken: String,
    val maskedPhone: String,
    val expiresAt: Instant,
)

data class Session(
    val accessToken: String,
    val refreshToken: String,
    val expiresAt: Instant,
)

enum class PhoneAuthNextAction {
    Dashboard,
    JoinCode,
}

data class PhoneAuthResolution(
    val nextAction: PhoneAuthNextAction,
    val session: Session?,
)

data class AccountCreation(
    val name: String,
    val phoneVerificationToken: String,
    val registrationValidationToken: String,
)

data class LoginCredentials(
    val phone: String,
    val password: String,
)

data class ResetPasswordCommand(
    val phone: String,
    val resetCode: String,
    val newPassword: String,
)

data class ChangeProfilePasswordCommand(
    val currentPassword: String,
    val newPassword: String,
)

data class MediaUploadIntent(
    val mediaType: MediaType,
    val contentType: String,
    val contentLengthBytes: Long,
)

data class MediaUploadSlot(
    val uploadId: String,
    val uploadUrl: String,
    val expiresAt: Instant,
)

data class MediaUploadPayload(
    val contentType: String,
    val bytes: ByteArray,
) {
    init {
        require(contentType.isNotBlank())
        require(bytes.isNotEmpty())
    }

    override fun equals(other: Any?): Boolean =
        other is MediaUploadPayload && contentType == other.contentType && bytes.contentEquals(other.bytes)

    override fun hashCode(): Int = 31 * contentType.hashCode() + bytes.contentHashCode()
}

enum class MediaType {
    Image,
    Audio,
}

data class SubmitRequestCommand(
    val clientRequestId: String,
    val text: String?,
    val imageUploadId: String?,
    val audioUploadId: String?,
)

data class RequestReceipt(
    val requestId: String,
    val clientRequestId: String,
    val acceptedAt: Instant,
    val conversationId: String = "conversation-$requestId",
)

enum class ConversationAuthorType {
    Store,
    Max,
    System,
}

data class ConversationSummary(
    val id: String,
    val requestId: String,
    val title: String,
    val createdAt: Instant,
    val lastMessageAt: Instant,
    val latestSequence: Long,
    val lastReadSequence: Long,
    val unreadCount: Int,
)

data class ConversationMessage(
    val id: String,
    val conversationId: String,
    val sequence: Long,
    val authorType: ConversationAuthorType,
    val text: String?,
    val imageMediaId: String?,
    val audioMediaId: String?,
    val createdAt: Instant,
)

data class ConversationMessages(
    val conversationId: String,
    val latestSequence: Long,
    val items: List<ConversationMessage>,
)

data class ConversationReadReceipt(
    val conversationId: String,
    val lastReadSequence: Long,
)

enum class OrderDirection {
    Incoming,
    Outgoing,
}

enum class OrderStatus {
    NeedsReply,
    Provided,
    Unavailable,
}

enum class OrderSource {
    App,
    Verto,
    MaxTeam,
}

data class SignedMedia(
    val url: String,
    val expiresAt: Instant,
    val contentType: String,
)

data class OrderContent(
    val text: String?,
    val image: SignedMedia?,
    val audio: SignedMedia?,
)

data class OrderSummary(
    val id: String,
    val direction: OrderDirection,
    val source: OrderSource,
    val status: OrderStatus,
    val content: OrderContent,
    val occurredAt: Instant,
    val invoiceReference: String?,
) {
    init {
        require(status != OrderStatus.Unavailable || invoiceReference == null)
    }
}

data class MoneyAmount(
    val minorUnits: Long,
    val currency: String = "SDG",
)

enum class InvoiceType {
    Sale,
    Purchase,
}

data class InvoiceSummary(
    val id: String,
    val invoiceNumber: String,
    val type: InvoiceType,
    val total: MoneyAmount,
    val occurredAt: Instant,
)

data class InvoiceItem(
    val name: String,
    val partNumber: String?,
    val quantity: String,
    val unitAmount: MoneyAmount?,
    val lineTotal: MoneyAmount?,
)

data class InvoiceDetails(
    val id: String,
    val invoiceNumber: String,
    val type: InvoiceType,
    val total: MoneyAmount,
    val occurredAt: Instant,
    val items: List<InvoiceItem>,
)

data class BalanceSnapshot(
    val balance: MoneyAmount,
    val asOf: Instant?,
)

enum class BalanceMovementType {
    IncomingOrder,
    OutgoingOrder,
    Payment,
    Receipt,
    Correction,
    Return,
}

data class BalanceMovement(
    val id: String,
    val type: BalanceMovementType,
    val amount: MoneyAmount,
    val delta: MoneyAmount,
    val balanceAfter: MoneyAmount,
    val occurredAt: Instant,
)

data class Profile(
    val userId: String,
    val storeId: String,
    val name: String,
    val storeName: String,
    val phone: String,
)

data class SupportContact(
    val phone: String,
    val whatsappUrl: String,
)

data class PrivacySummary(
    val version: String,
    val effectiveAt: Instant,
    val sections: List<PrivacySection>,
)

data class PrivacySection(
    val title: String,
    val body: String,
)

enum class NotificationType {
    RequestNeedsReply,
    OutgoingRequestUpdated,
    PartAvailable,
    PartUnavailable,
    BalanceMovement,
    BalanceUpdated,
}

enum class NotificationTargetType {
    Conversation,
    Home,
    Invoice,
    None,
}

data class NotificationTarget(
    val type: NotificationTargetType,
    val id: String? = null,
) {
    init {
        when (type) {
            NotificationTargetType.Conversation, NotificationTargetType.Invoice -> require(!id.isNullOrBlank())
            NotificationTargetType.Home, NotificationTargetType.None -> require(id == null)
        }
    }
}

data class MaxNotification(
    val id: String,
    val type: NotificationType,
    val title: String,
    val body: String,
    val occurredAt: Instant,
    val readAt: Instant?,
    val target: NotificationTarget = NotificationTarget(NotificationTargetType.None),
)

enum class PushProvider {
    Fcm,
}

data class PushInstallationRegistration(
    val provider: PushProvider,
    val token: String,
    val appVersion: String,
)

data class DeletionRequest(
    val requestId: String,
    val requestedAt: Instant,
    val scheduledFor: Instant,
)
