package com.maxnetwork.core.network

import com.squareup.moshi.JsonDataException
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.IOException
import java.time.DateTimeException
import java.time.Instant
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

/** Incremental HTTP implementation of MaxGateway. v12 completes authentication and password recovery. */
class RetrofitMaxGateway private constructor(
    private val authService: AuthApiService,
    private val requestService: RequestApiService,
    private val conversationService: ConversationApiService,
    private val balanceService: BalanceApiService,
    private val invoiceService: InvoiceApiService,
    private val notificationService: NotificationApiService,
    private val profileService: ProfileApiService,
    private val uploadClient: OkHttpClient,
    private val eventSink: AuthNetworkEventSink,
    private val bearerTokenStore: BearerTokenStore,
) : MaxGateway {
    override suspend fun validateRegistrationCode(code: String): GatewayResult<RegistrationCodeValidation> =
        executeAuth(AuthNetworkOperation.RegistrationCode) {
            val response = authService.validateRegistrationCode(RegistrationCodeBody(code))
            RegistrationCodeValidation(
                validationToken = response.validationToken,
                storeDisplayName = response.storeDisplayName,
                expiresAt = Instant.parse(response.expiresAt),
            )
        }

    override suspend fun requestPhoneChallenge(phone: String): GatewayResult<PhoneChallenge> =
        executeAuth(AuthNetworkOperation.PhoneChallenge) {
            val response = authService.createPhoneChallenge(PhoneBody(phone))
            PhoneChallenge(
                challengeId = response.challengeId,
                expiresAt = Instant.parse(response.expiresAt),
                resendAvailableAt = Instant.parse(response.resendAvailableAt),
                remainingAttempts = response.remainingAttempts,
            )
        }

    override suspend fun login(credentials: LoginCredentials): GatewayResult<Session> = executeSession(
        operation = AuthNetworkOperation.Login,
        block = { authService.login(LoginBody(phone = credentials.phone, password = credentials.password)) },
    )

    override suspend fun refreshSession(refreshToken: String): GatewayResult<Session> = executeSession(
        operation = AuthNetworkOperation.Refresh,
        block = { authService.refresh(RefreshBody(refreshToken = refreshToken)) },
    )

    override suspend fun logout(accessToken: String): GatewayResult<Unit> {
        eventSink.record(AuthNetworkEvent(AuthNetworkOperation.Logout, AuthNetworkOutcome.Started))
        return try {
            authService.logout(authorization = "Bearer $accessToken")
            eventSink.record(AuthNetworkEvent(AuthNetworkOperation.Logout, AuthNetworkOutcome.Succeeded))
            GatewayResult.Success(Unit)
        } catch (error: HttpException) {
            eventSink.record(AuthNetworkEvent(AuthNetworkOperation.Logout, AuthNetworkOutcome.Rejected))
            error.toGatewayFailure()
        } catch (error: IOException) {
            eventSink.record(AuthNetworkEvent(AuthNetworkOperation.Logout, AuthNetworkOutcome.Failed))
            networkFailure()
        }
    }

    private suspend fun executeSession(
        operation: AuthNetworkOperation,
        block: suspend () -> SessionBody,
    ): GatewayResult<Session> = executeAuth(operation) {
        val response = block()
        Session(
            accessToken = response.accessToken,
            refreshToken = response.refreshToken,
            expiresAt = Instant.parse(response.expiresAt),
        )
    }

    private suspend fun <T> executeAuth(
        operation: AuthNetworkOperation,
        block: suspend () -> T,
    ): GatewayResult<T> {
        eventSink.record(AuthNetworkEvent(operation, AuthNetworkOutcome.Started))
        return try {
            val response = block()
            eventSink.record(AuthNetworkEvent(operation, AuthNetworkOutcome.Succeeded))
            GatewayResult.Success(response)
        } catch (error: HttpException) {
            eventSink.record(AuthNetworkEvent(operation, AuthNetworkOutcome.Rejected))
            error.toGatewayFailure()
        } catch (error: IOException) {
            eventSink.record(AuthNetworkEvent(operation, AuthNetworkOutcome.Failed))
            networkFailure()
        } catch (error: JsonDataException) {
            eventSink.record(AuthNetworkEvent(operation, AuthNetworkOutcome.Failed))
            malformedResponseFailure()
        } catch (error: DateTimeException) {
            eventSink.record(AuthNetworkEvent(operation, AuthNetworkOutcome.Failed))
            malformedResponseFailure()
        }
    }

    override suspend fun verifyPhoneChallenge(
        challengeId: String,
        otp: String,
    ): GatewayResult<VerifiedPhone> = executeAuth(AuthNetworkOperation.VerifyPhone) {
        val response = authService.verifyPhoneChallenge(challengeId, OtpBody(otp))
        VerifiedPhone(
            verificationToken = response.verificationToken,
            maskedPhone = response.maskedPhone,
            expiresAt = Instant.parse(response.expiresAt),
        )
    }


    override suspend fun resolveVerifiedPhone(verificationToken: String): GatewayResult<PhoneAuthResolution> =
        executeAuth(AuthNetworkOperation.ResolvePhone) {
            val response = authService.resolveVerifiedPhone(PhoneVerificationResolutionBody(verificationToken))
            val action = when (response.nextAction) {
                "DASHBOARD" -> PhoneAuthNextAction.Dashboard
                "JOIN_CODE" -> PhoneAuthNextAction.JoinCode
                else -> throw JsonDataException("Unknown phone auth nextAction")
            }
            PhoneAuthResolution(
                nextAction = action,
                session = response.session?.let {
                    Session(
                        accessToken = it.accessToken,
                        refreshToken = it.refreshToken,
                        expiresAt = Instant.parse(it.expiresAt),
                    )
                },
            )
        }

    override suspend fun createAccount(command: AccountCreation): GatewayResult<Session> =
        executeAuth(AuthNetworkOperation.CreateAccount) {
            val response = authService.createAccount(
                AccountCreationBody(
                    name = command.name,
                    phoneVerificationToken = command.phoneVerificationToken,
                    registrationValidationToken = command.registrationValidationToken,
                ),
            )
            Session(
                accessToken = response.accessToken,
                refreshToken = response.refreshToken,
                expiresAt = Instant.parse(response.expiresAt),
            )
        }
    override suspend fun requestPasswordReset(phone: String): GatewayResult<PhoneChallenge> =
        executeAuth(AuthNetworkOperation.PasswordResetRequest) {
            val response = authService.requestPasswordReset(PhoneBody(phone))
            PhoneChallenge(
                challengeId = response.challengeId,
                expiresAt = Instant.parse(response.expiresAt),
                resendAvailableAt = Instant.parse(response.resendAvailableAt),
                remainingAttempts = response.remainingAttempts,
            )
        }

    override suspend fun resetPassword(command: ResetPasswordCommand): GatewayResult<Unit> =
        executeAuth(AuthNetworkOperation.PasswordResetConfirm) {
            authService.resetPassword(
                ResetPasswordBody(
                    phone = command.phone,
                    resetCode = command.resetCode,
                    newPassword = command.newPassword,
                ),
            )
            Unit
        }
    override suspend fun createMediaUploadIntent(intent: MediaUploadIntent): GatewayResult<MediaUploadSlot> =
        executeRequest {
            val response = requestService.createMediaUploadIntent(
                MediaUploadIntentBody(
                    mediaType = intent.mediaType.name.lowercase(),
                    contentType = intent.contentType,
                    contentLengthBytes = intent.contentLengthBytes,
                ),
            )
            MediaUploadSlot(
                uploadId = response.uploadId,
                uploadUrl = response.uploadUrl,
                expiresAt = Instant.parse(response.expiresAt),
            )
        }

    override suspend fun uploadMedia(
        slot: MediaUploadSlot,
        payload: MediaUploadPayload,
    ): GatewayResult<Unit> = try {
        val request = Request.Builder()
            .url(slot.uploadUrl)
            .put(payload.bytes.toRequestBody(payload.contentType.toMediaType()))
            .build()
        uploadClient.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                GatewayResult.Success(Unit)
            } else {
                GatewayResult.Failure(
                    ApiError(
                        code = if (response.code in 500..599) {
                            ApiErrorCode.ServiceUnavailable
                        } else {
                            ApiErrorCode.AttachmentRejected
                        },
                        message = "تعذر رفع المرفق",
                        traceId = response.header("x-trace-id") ?: "upload-rejected",
                        retryable = response.code in 500..599 || response.code == 408 || response.code == 429,
                    ),
                )
            }
        }
    } catch (_: IOException) {
        networkFailure()
    }

    override suspend fun submitRequest(command: SubmitRequestCommand): GatewayResult<RequestReceipt> =
        executeRequest {
            val response = requestService.submitRequest(
                idempotencyKey = command.clientRequestId,
                body = SubmitRequestBody(
                    text = command.text,
                    imageUploadId = command.imageUploadId,
                    audioUploadId = command.audioUploadId,
                ),
            )
            if (response.conversationId != "conversation-${response.requestId}") {
                throw JsonDataException("Unexpected conversation id for request receipt")
            }
            RequestReceipt(
                requestId = response.requestId,
                conversationId = response.conversationId,
                clientRequestId = response.clientRequestId,
                acceptedAt = Instant.parse(response.acceptedAt),
            )
        }

    override suspend fun getConversations(): GatewayResult<List<ConversationSummary>> {
        val authorization = bearerAuthorization() ?: return unauthorizedConversationFailure()
        return executeRequest {
            conversationService.getConversations(authorization).items.map(ConversationSummaryBody::toModel)
        }
    }

    override suspend fun getConversationMessages(conversationId: String): GatewayResult<ConversationMessages> {
        val authorization = bearerAuthorization() ?: return unauthorizedConversationFailure()
        return executeRequest {
            conversationService.getMessages(authorization, conversationId).toModel()
        }
    }

    override suspend fun markConversationRead(
        conversationId: String,
        throughSequence: Long,
    ): GatewayResult<ConversationReadReceipt> {
        val authorization = bearerAuthorization() ?: return unauthorizedConversationFailure()
        return executeRequest {
            conversationService.markRead(authorization, conversationId, MarkConversationReadBody(throughSequence)).toModel()
        }
    }

    private fun bearerAuthorization(): String? = bearerTokenStore.current()?.takeIf(String::isNotBlank)?.let { "Bearer $it" }

    private fun <T> unauthorizedConversationFailure(): GatewayResult<T> = GatewayResult.Failure(
        ApiError(
            code = ApiErrorCode.Unauthorized,
            message = "الجلسة غير صالحة",
            traceId = "conversation-auth-missing",
            retryable = false,
        ),
    )

    private suspend fun <T> executeRequest(block: suspend () -> T): GatewayResult<T> = try {
        GatewayResult.Success(block())
    } catch (error: HttpException) {
        error.toGatewayFailure()
    } catch (_: IOException) {
        networkFailure()
    } catch (_: JsonDataException) {
        malformedResponseFailure()
    } catch (_: DateTimeException) {
        malformedResponseFailure()
    }

    override suspend fun getOrders(
        direction: OrderDirection,
        cursor: String?,
        limit: Int,
    ): GatewayResult<CursorPage<OrderSummary>> = executeRequest {
        val page = requestService.getOrders(direction.name.uppercase(), cursor, limit.coerceIn(1, 50))
        CursorPage(page.items.map(OrderBody::toModel), page.nextCursor)
    }

    override suspend fun getOrder(orderId: String): GatewayResult<OrderSummary> = executeRequest {
        requestService.getOrder(orderId).toModel()
    }

    override suspend fun getInvoices(
        query: String?,
        cursor: String?,
        limit: Int,
    ): GatewayResult<CursorPage<InvoiceSummary>> = executeRequest {
        val page = invoiceService.getInvoices(query?.trim()?.takeIf(String::isNotEmpty), cursor, limit.coerceIn(1, 50))
        CursorPage(page.items.map(InvoiceSummaryBody::toModel), page.nextCursor)
    }

    override suspend fun getInvoice(invoiceId: String): GatewayResult<InvoiceDetails> = executeRequest {
        invoiceService.getInvoice(invoiceId).toModel()
    }
    override suspend fun getBalance(): GatewayResult<BalanceSnapshot> = executeRequest {
        balanceService.getBalance().toModel()
    }

    override suspend fun getBalanceMovements(
        cursor: String?,
        limit: Int,
    ): GatewayResult<CursorPage<BalanceMovement>> = executeRequest {
        val page = balanceService.getBalanceMovements(cursor, limit.coerceIn(1, 50))
        CursorPage(page.items.map(BalanceMovementBody::toModel), page.nextCursor)
    }

    override suspend fun getProfile(): GatewayResult<Profile> = executeRequest {
        profileService.getProfile().toModel()
    }

    override suspend fun getSupportContact(): GatewayResult<SupportContact> = executeRequest {
        profileService.getSupportContact().toModel()
    }

    override suspend fun getPrivacy(): GatewayResult<PrivacySummary> = executeRequest {
        profileService.getPrivacy().toModel()
    }

    override suspend fun requestAccountDeletion(): GatewayResult<DeletionRequest> = executeRequest {
        profileService.requestAccountDeletion().toModel()
    }

    override suspend fun changeProfilePassword(command: ChangeProfilePasswordCommand): GatewayResult<Unit> =
        executeRequest {
            profileService.changePassword(
                ChangeProfilePasswordBody(
                    currentPassword = command.currentPassword,
                    newPassword = command.newPassword,
                ),
            )
            Unit
        }
    override suspend fun getNotifications(
        cursor: String?,
        limit: Int,
    ): GatewayResult<CursorPage<MaxNotification>> = executeRequest {
        val page = notificationService.getNotifications(cursor, limit.coerceIn(1, 50))
        CursorPage(page.items.map(NotificationBody::toModel), page.nextCursor)
    }

    override suspend fun markNotificationRead(notificationId: String): GatewayResult<Unit> = executeRequest {
        notificationService.markRead(notificationId)
        Unit
    }

    override suspend fun markNotificationReadAuthenticated(
        accessToken: String,
        notificationId: String,
    ): GatewayResult<Unit> = executeRequest {
        notificationService.markReadAuthenticated(
            authorization = "Bearer $accessToken",
            notificationId = notificationId,
        )
        Unit
    }

    override suspend fun registerPushInstallation(
        accessToken: String,
        installationId: String,
        registration: PushInstallationRegistration,
    ): GatewayResult<Unit> = executeRequest {
        notificationService.registerPushInstallation(
            authorization = "Bearer $accessToken",
            installationId = installationId,
            body = PushRegistrationBody(
                provider = when (registration.provider) {
                    PushProvider.Fcm -> "FCM"
                },
                token = registration.token,
                appVersion = registration.appVersion,
            ),
        )
        Unit
    }

    override suspend fun unregisterPushInstallation(
        accessToken: String,
        installationId: String,
    ): GatewayResult<Unit> = executeRequest {
        notificationService.unregisterPushInstallation(
            authorization = "Bearer $accessToken",
            installationId = installationId,
        )
        Unit
    }

    companion object {
        fun create(
            baseUrl: String,
            eventSink: AuthNetworkEventSink = AuthNetworkEventSink.None,
            bearerTokenStore: BearerTokenStore = InMemoryBearerTokenStore(),
        ): RetrofitMaxGateway {
            require(baseUrl.startsWith("https://")) { "Max API base URL must use HTTPS" }
            return createInternal(
                baseUrl = baseUrl,
                eventSink = eventSink,
                bearerTokenStore = bearerTokenStore,
            )
        }

        internal fun createForTesting(
            baseUrl: String,
            eventSink: AuthNetworkEventSink = AuthNetworkEventSink.None,
            bearerTokenStore: BearerTokenStore = InMemoryBearerTokenStore(),
        ): RetrofitMaxGateway = createInternal(
            baseUrl = baseUrl,
            eventSink = eventSink,
            bearerTokenStore = bearerTokenStore,
        )

        private fun createInternal(
            baseUrl: String,
            eventSink: AuthNetworkEventSink,
            bearerTokenStore: BearerTokenStore,
        ): RetrofitMaxGateway {
            val normalizedBaseUrl = if (baseUrl.endsWith('/')) baseUrl else "$baseUrl/"
            val moshi = Moshi.Builder()
                .add(KotlinJsonAdapterFactory())
                .build()
            val apiClient = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val original = chain.request()
                    val token = bearerTokenStore.current()
                    val authenticated = if (
                        original.header("Authorization") == null &&
                        token != null &&
                        isProtectedMaxApiPath(original.url.encodedPath)
                    ) {
                        original.newBuilder()
                            .header("Authorization", "Bearer $token")
                            .build()
                    } else {
                        original
                    }
                    chain.proceed(authenticated)
                }
                .build()
            val uploadClient = OkHttpClient.Builder().build()
            val retrofit = Retrofit.Builder()
                .baseUrl(normalizedBaseUrl)
                .client(apiClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
            return RetrofitMaxGateway(
                authService = retrofit.create(AuthApiService::class.java),
                requestService = retrofit.create(RequestApiService::class.java),
                conversationService = retrofit.create(ConversationApiService::class.java),
                balanceService = retrofit.create(BalanceApiService::class.java),
                invoiceService = retrofit.create(InvoiceApiService::class.java),
                notificationService = retrofit.create(NotificationApiService::class.java),
                profileService = retrofit.create(ProfileApiService::class.java),
                uploadClient = uploadClient,
                eventSink = eventSink,
                bearerTokenStore = bearerTokenStore,
            )
        }
    }
}

private interface RequestApiService {
    @POST("v1/media/upload-intents")
    suspend fun createMediaUploadIntent(@Body body: MediaUploadIntentBody): MediaUploadSlotBody

    @POST("v1/requests")
    suspend fun submitRequest(
        @Header("Idempotency-Key") idempotencyKey: String,
        @Body body: SubmitRequestBody,
    ): RequestReceiptBody

    @GET("v1/orders")
    suspend fun getOrders(
        @Query("direction") direction: String,
        @Query("cursor") cursor: String?,
        @Query("limit") limit: Int,
    ): OrderPageBody

    @GET("v1/orders/{orderId}")
    suspend fun getOrder(@Path("orderId") orderId: String): OrderBody
}


private interface ConversationApiService {
    @GET("v1/conversations")
    suspend fun getConversations(@Header("Authorization") authorization: String): ConversationListBody

    @GET("v1/conversations/{conversationId}/messages")
    suspend fun getMessages(
        @Header("Authorization") authorization: String,
        @Path("conversationId") conversationId: String,
    ): ConversationMessagesBody

    @POST("v1/conversations/{conversationId}/read")
    suspend fun markRead(
        @Header("Authorization") authorization: String,
        @Path("conversationId") conversationId: String,
        @Body body: MarkConversationReadBody,
    ): ConversationReadBody
}

private data class ConversationListBody(val items: List<ConversationSummaryBody>)

private data class ConversationSummaryBody(
    val id: String,
    val requestId: String,
    val title: String,
    val createdAt: String,
    val lastMessageAt: String,
    val latestSequence: Long,
    val lastReadSequence: Long,
    val unreadCount: Int,
)

private data class ConversationMediaBody(val id: String)

private data class ConversationMessageBody(
    val id: String,
    val conversationId: String,
    val sequence: Long,
    val authorType: String,
    val text: String?,
    val imageMedia: ConversationMediaBody?,
    val audioMedia: ConversationMediaBody?,
    val createdAt: String,
)

private data class ConversationMessagesBody(
    val conversationId: String,
    val latestSequence: Long,
    val items: List<ConversationMessageBody>,
)

private data class MarkConversationReadBody(val throughSequence: Long)

private data class ConversationReadBody(
    val conversationId: String,
    val lastReadSequence: Long,
)

private fun ConversationSummaryBody.toModel() = ConversationSummary(
    id = id,
    requestId = requestId,
    title = title,
    createdAt = Instant.parse(createdAt),
    lastMessageAt = Instant.parse(lastMessageAt),
    latestSequence = latestSequence,
    lastReadSequence = lastReadSequence,
    unreadCount = unreadCount,
)

private fun ConversationMessagesBody.toModel() = ConversationMessages(
    conversationId = conversationId,
    latestSequence = latestSequence,
    items = items.map(ConversationMessageBody::toModel),
)

private fun ConversationMessageBody.toModel() = ConversationMessage(
    id = id,
    conversationId = conversationId,
    sequence = sequence,
    authorType = when (authorType) {
        "STORE" -> ConversationAuthorType.Store
        "MAX" -> ConversationAuthorType.Max
        "SYSTEM" -> ConversationAuthorType.System
        else -> throw JsonDataException("Unknown conversation author type")
    },
    text = text,
    imageMediaId = imageMedia?.id,
    audioMediaId = audioMedia?.id,
    createdAt = Instant.parse(createdAt),
)

private fun ConversationReadBody.toModel() = ConversationReadReceipt(
    conversationId = conversationId,
    lastReadSequence = lastReadSequence,
)



private interface ProfileApiService {
    @GET("v1/profile")
    suspend fun getProfile(): ProfileBody

    @POST("v1/profile/deletion-requests")
    suspend fun requestAccountDeletion(): DeletionRequestBody

    @POST("v1/profile/password")
    suspend fun changePassword(@Body body: ChangeProfilePasswordBody)

    @GET("v1/privacy")
    suspend fun getPrivacy(): PrivacySummaryBody

    @GET("v1/support/contact")
    suspend fun getSupportContact(): SupportContactBody
}

private data class ChangeProfilePasswordBody(
    val currentPassword: String,
    val newPassword: String,
)

private data class ProfileBody(
    val userId: String,
    val storeId: String,
    val name: String,
    val storeName: String,
    val phone: String,
)

private data class DeletionRequestBody(
    val requestId: String,
    val requestedAt: String,
    val scheduledFor: String,
)

private data class PrivacySectionBody(
    val title: String,
    val body: String,
)

private data class PrivacySummaryBody(
    val version: String,
    val effectiveAt: String,
    val sections: List<PrivacySectionBody>,
)

private data class SupportContactBody(
    val phone: String,
    val whatsappUrl: String,
)

private fun ProfileBody.toModel() = Profile(
    userId = userId,
    storeId = storeId,
    name = name,
    storeName = storeName,
    phone = phone,
)

private fun DeletionRequestBody.toModel() = DeletionRequest(
    requestId = requestId,
    requestedAt = Instant.parse(requestedAt),
    scheduledFor = Instant.parse(scheduledFor),
)

private fun PrivacySummaryBody.toModel() = PrivacySummary(
    version = version,
    effectiveAt = Instant.parse(effectiveAt),
    sections = sections.map { PrivacySection(it.title, it.body) },
)

private fun SupportContactBody.toModel() = SupportContact(
    phone = phone,
    whatsappUrl = whatsappUrl,
)

private interface NotificationApiService {
    @GET("v1/notifications")
    suspend fun getNotifications(
        @Query("cursor") cursor: String?,
        @Query("limit") limit: Int,
    ): NotificationPageBody

    @POST("v1/notifications/{notificationId}/read")
    suspend fun markRead(@Path("notificationId") notificationId: String)

    @POST("v1/notifications/{notificationId}/read")
    suspend fun markReadAuthenticated(
        @Header("Authorization") authorization: String,
        @Path("notificationId") notificationId: String,
    )

    @PUT("v1/push/installations/{installationId}")
    suspend fun registerPushInstallation(
        @Header("Authorization") authorization: String,
        @Path("installationId") installationId: String,
        @Body body: PushRegistrationBody,
    )

    @DELETE("v1/push/installations/{installationId}")
    suspend fun unregisterPushInstallation(
        @Header("Authorization") authorization: String,
        @Path("installationId") installationId: String,
    )
}

private data class PushRegistrationBody(
    val provider: String,
    val token: String,
    val appVersion: String,
)

private data class NotificationPageBody(
    val items: List<NotificationBody>,
    val nextCursor: String?,
)

private data class NotificationBody(
    val id: String,
    val type: String,
    val title: String,
    val body: String,
    val occurredAt: String,
    val readAt: String?,
    val target: NotificationTargetBody,
)

private data class NotificationTargetBody(
    val type: String,
    val id: String?,
)

private fun NotificationBody.toModel() = MaxNotification(
    id = id,
    type = when (type) {
        "REQUEST_NEEDS_REPLY" -> NotificationType.RequestNeedsReply
        "OUTGOING_REQUEST_UPDATED" -> NotificationType.OutgoingRequestUpdated
        "PART_AVAILABLE" -> NotificationType.PartAvailable
        "PART_UNAVAILABLE" -> NotificationType.PartUnavailable
        "BALANCE_MOVEMENT" -> NotificationType.BalanceMovement
        "BALANCE_UPDATED" -> NotificationType.BalanceUpdated
        else -> throw JsonDataException("Unknown notification type")
    },
    title = title,
    body = body,
    occurredAt = Instant.parse(occurredAt),
    readAt = readAt?.let(Instant::parse),
    target = target.toModel(),
)

private fun NotificationTargetBody.toModel() = when (type) {
    "CONVERSATION" -> NotificationTarget(NotificationTargetType.Conversation, requireTargetId())
    "HOME" -> NotificationTarget(NotificationTargetType.Home)
    "INVOICE" -> NotificationTarget(NotificationTargetType.Invoice, requireTargetId())
    "NONE" -> NotificationTarget(NotificationTargetType.None)
    else -> throw JsonDataException("Unknown notification target type")
}

private fun NotificationTargetBody.requireTargetId(): String =
    id?.takeIf { it.isNotBlank() } ?: throw JsonDataException("Notification target id is required")

private interface InvoiceApiService {
    @GET("v1/invoices")
    suspend fun getInvoices(
        @Query("q") query: String?,
        @Query("cursor") cursor: String?,
        @Query("limit") limit: Int,
    ): InvoicePageBody

    @GET("v1/invoices/{invoiceId}")
    suspend fun getInvoice(@Path("invoiceId") invoiceId: String): InvoiceDetailsBody
}

private data class InvoicePageBody(
    val items: List<InvoiceSummaryBody>,
    val nextCursor: String?,
)

private data class InvoiceSummaryBody(
    val id: String,
    val invoiceNumber: String,
    val type: String,
    val total: MoneyBody,
    val occurredAt: String,
)

private data class InvoiceItemBody(
    val name: String,
    val partNumber: String?,
    val quantity: String,
    val unitAmount: MoneyBody?,
    val lineTotal: MoneyBody?,
)

private data class InvoiceDetailsBody(
    val id: String,
    val invoiceNumber: String,
    val type: String,
    val total: MoneyBody,
    val occurredAt: String,
    val items: List<InvoiceItemBody>,
)

private fun InvoiceSummaryBody.toModel() = InvoiceSummary(
    id = id,
    invoiceNumber = invoiceNumber,
    type = type.toInvoiceType(),
    total = total.toInvoiceMoney(),
    occurredAt = Instant.parse(occurredAt),
)

private fun InvoiceDetailsBody.toModel() = InvoiceDetails(
    id = id,
    invoiceNumber = invoiceNumber,
    type = type.toInvoiceType(),
    total = total.toInvoiceMoney(),
    occurredAt = Instant.parse(occurredAt),
    items = items.map(InvoiceItemBody::toModel),
)

private fun InvoiceItemBody.toModel() = InvoiceItem(
    name = name,
    partNumber = partNumber,
    quantity = quantity,
    unitAmount = unitAmount?.toInvoiceMoney(),
    lineTotal = lineTotal?.toInvoiceMoney(),
)

private fun String.toInvoiceType() = when (this) {
    "SALE" -> InvoiceType.Sale
    "PURCHASE" -> InvoiceType.Purchase
    else -> throw JsonDataException("Unknown invoice type")
}

private fun MoneyBody.toInvoiceMoney(): MoneyAmount {
    if (currency != "SDG") throw JsonDataException("Unsupported invoice currency")
    return MoneyAmount(minorUnits = minorUnits, currency = currency)
}

private interface BalanceApiService {
    @GET("v1/balance")
    suspend fun getBalance(): BalanceSnapshotBody

    @GET("v1/balance/movements")
    suspend fun getBalanceMovements(
        @Query("cursor") cursor: String?,
        @Query("limit") limit: Int,
    ): BalanceMovementPageBody
}

private data class MoneyBody(
    val minorUnits: Long,
    val currency: String,
)

private data class BalanceSnapshotBody(
    val balance: MoneyBody,
    val asOf: String?,
)

private data class BalanceMovementPageBody(
    val items: List<BalanceMovementBody>,
    val nextCursor: String?,
)

private data class BalanceMovementBody(
    val id: String,
    val type: String,
    val amount: MoneyBody,
    val delta: MoneyBody,
    val balanceAfter: MoneyBody,
    val occurredAt: String,
)

private fun BalanceSnapshotBody.toModel() = BalanceSnapshot(
    balance = balance.toModel(),
    asOf = asOf?.let(Instant::parse),
)

private fun BalanceMovementBody.toModel() = BalanceMovement(
    id = id,
    type = when (type) {
        "INCOMING_ORDER" -> BalanceMovementType.IncomingOrder
        "OUTGOING_ORDER" -> BalanceMovementType.OutgoingOrder
        "PAYMENT" -> BalanceMovementType.Payment
        "RECEIPT" -> BalanceMovementType.Receipt
        "CORRECTION" -> BalanceMovementType.Correction
        "RETURN" -> BalanceMovementType.Return
        else -> throw JsonDataException("Unknown balance movement type")
    },
    amount = amount.toModel(),
    delta = delta.toModel(),
    balanceAfter = balanceAfter.toModel(),
    occurredAt = Instant.parse(occurredAt),
)

private fun MoneyBody.toModel(): MoneyAmount {
    if (currency != "SDG") throw JsonDataException("Unsupported balance currency")
    return MoneyAmount(minorUnits = minorUnits, currency = currency)
}

private data class MediaUploadIntentBody(
    val mediaType: String,
    val contentType: String,
    val contentLengthBytes: Long,
)

private data class MediaUploadSlotBody(
    val uploadId: String,
    val uploadUrl: String,
    val expiresAt: String,
)

private data class SubmitRequestBody(
    val text: String?,
    val imageUploadId: String?,
    val audioUploadId: String?,
)

private data class RequestReceiptBody(
    val requestId: String,
    val conversationId: String,
    val clientRequestId: String,
    val acceptedAt: String,
)

private data class OrderPageBody(
    val items: List<OrderBody>,
    val nextCursor: String?,
)

private data class OrderBody(
    val id: String,
    val direction: String,
    val source: String,
    val status: String,
    val content: OrderContentBody,
    val occurredAt: String,
    val invoiceReference: String?,
)

private data class OrderContentBody(
    val text: String?,
    val image: SignedMediaBody?,
    val audio: SignedMediaBody?,
)

private data class SignedMediaBody(
    val url: String,
    val expiresAt: String,
    val contentType: String,
)

private fun OrderBody.toModel(): OrderSummary = OrderSummary(
    id = id,
    direction = when (direction) {
        "INCOMING" -> OrderDirection.Incoming
        "OUTGOING" -> OrderDirection.Outgoing
        else -> throw JsonDataException("Unknown order direction")
    },
    source = when (source) {
        "APP" -> OrderSource.App
        "VERTO" -> OrderSource.Verto
        "MAX_TEAM" -> OrderSource.MaxTeam
        else -> throw JsonDataException("Unknown order source")
    },
    status = when (status) {
        "NEEDS_REPLY" -> OrderStatus.NeedsReply
        "PROVIDED" -> OrderStatus.Provided
        "UNAVAILABLE" -> OrderStatus.Unavailable
        else -> throw JsonDataException("Unknown order status")
    },
    content = OrderContent(
        text = content.text,
        image = content.image?.toModel(),
        audio = content.audio?.toModel(),
    ),
    occurredAt = Instant.parse(occurredAt),
    invoiceReference = invoiceReference,
)

private fun SignedMediaBody.toModel() = SignedMedia(
    url = url,
    expiresAt = Instant.parse(expiresAt),
    contentType = contentType,
)

private interface AuthApiService {
    @POST("v1/auth/registration-codes/validate")
    suspend fun validateRegistrationCode(@Body body: RegistrationCodeBody): RegistrationValidationBody

    @POST("v1/auth/phone-challenges")
    suspend fun createPhoneChallenge(@Body body: PhoneBody): PhoneChallengeBody

    @POST("v1/auth/phone-challenges/{challengeId}/verify")
    suspend fun verifyPhoneChallenge(
        @Path("challengeId") challengeId: String,
        @Body body: OtpBody,
    ): VerifiedPhoneBody

    @POST("v1/auth/phone-verifications/resolve")
    suspend fun resolveVerifiedPhone(@Body body: PhoneVerificationResolutionBody): PhoneAuthResolutionBody

    @POST("v1/auth/accounts")
    suspend fun createAccount(@Body body: AccountCreationBody): SessionBody

    @POST("v1/auth/sessions")
    suspend fun login(@Body body: LoginBody): SessionBody

    @POST("v1/auth/sessions/refresh")
    suspend fun refresh(@Body body: RefreshBody): SessionBody

    @DELETE("v1/auth/sessions/current")
    suspend fun logout(@Header("Authorization") authorization: String)

    @POST("v1/auth/password-reset/challenges")
    suspend fun requestPasswordReset(@Body body: PhoneBody): PhoneChallengeBody

    @POST("v1/auth/password-reset/confirm")
    suspend fun resetPassword(@Body body: ResetPasswordBody)
}

private data class RegistrationCodeBody(
    val code: String,
)

private data class RegistrationValidationBody(
    val validationToken: String,
    val storeDisplayName: String,
    val expiresAt: String,
)

private data class PhoneBody(
    val phone: String,
)

private data class PhoneChallengeBody(
    val challengeId: String,
    val expiresAt: String,
    val resendAvailableAt: String,
    val remainingAttempts: Int,
)

private data class OtpBody(
    val otp: String,
)

private data class VerifiedPhoneBody(
    val verificationToken: String,
    val maskedPhone: String,
    val expiresAt: String,
)

private data class PhoneVerificationResolutionBody(
    val verificationToken: String,
)

private data class PhoneAuthResolutionBody(
    val nextAction: String,
    val session: SessionBody?,
)

private data class AccountCreationBody(
    val name: String,
    val phoneVerificationToken: String,
    val registrationValidationToken: String,
)

private data class LoginBody(
    val phone: String,
    val password: String,
)

private data class RefreshBody(
    val refreshToken: String,
)

private data class ResetPasswordBody(
    val phone: String,
    val resetCode: String,
    val newPassword: String,
)

private data class SessionBody(
    val accessToken: String,
    val refreshToken: String,
    val expiresAt: String,
)

private fun HttpException.toGatewayFailure(): GatewayResult.Failure {
    val code = when (code()) {
        400 -> ApiErrorCode.InvalidRequest
        401 -> ApiErrorCode.Unauthorized
        403 -> ApiErrorCode.Forbidden
        404 -> ApiErrorCode.NotFound
        409 -> ApiErrorCode.Conflict
        429 -> ApiErrorCode.RateLimited
        in 500..599 -> ApiErrorCode.ServiceUnavailable
        else -> ApiErrorCode.Unknown
    }
    return GatewayResult.Failure(
        ApiError(
            code = code,
            message = "تعذر إكمال طلب المصادقة",
            traceId = response()?.headers()?.get("x-trace-id") ?: "unavailable",
            retryable = code == ApiErrorCode.RateLimited || code == ApiErrorCode.ServiceUnavailable,
        ),
    )
}

private fun networkFailure(): GatewayResult.Failure = GatewayResult.Failure(
    ApiError(
        code = ApiErrorCode.ServiceUnavailable,
        message = "تعذر الاتصال بالخدمة",
        traceId = "network-unavailable",
        retryable = true,
    ),
)

private fun malformedResponseFailure(): GatewayResult.Failure = GatewayResult.Failure(
    ApiError(
        code = ApiErrorCode.Unknown,
        message = "استجابة المصادقة غير صالحة",
        traceId = "malformed-response",
        retryable = false,
    ),
)
