package com.maxnetwork.core.network

enum class AuthNetworkOperation {
    RegistrationCode,
    PhoneChallenge,
    VerifyPhone,
    ResolvePhone,
    CreateAccount,
    PasswordResetRequest,
    PasswordResetConfirm,
    Login,
    Refresh,
    Logout,
}

enum class AuthNetworkOutcome {
    Started,
    Succeeded,
    Rejected,
    Failed,
}

data class AuthNetworkEvent(
    val operation: AuthNetworkOperation,
    val outcome: AuthNetworkOutcome,
)

fun interface AuthNetworkEventSink {
    fun record(event: AuthNetworkEvent)

    companion object {
        val None = AuthNetworkEventSink { }
    }
}
