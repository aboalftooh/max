package com.maxnetwork.core.network

interface MaxGateway {
    suspend fun validateRegistrationCode(code: String): GatewayResult<RegistrationCodeValidation>
    suspend fun requestPhoneChallenge(phone: String): GatewayResult<PhoneChallenge>
    suspend fun verifyPhoneChallenge(challengeId: String, otp: String): GatewayResult<VerifiedPhone>
    suspend fun resolveVerifiedPhone(verificationToken: String): GatewayResult<PhoneAuthResolution>
    suspend fun createAccount(command: AccountCreation): GatewayResult<Session>
    suspend fun login(credentials: LoginCredentials): GatewayResult<Session>
    suspend fun refreshSession(refreshToken: String): GatewayResult<Session>
    suspend fun logout(accessToken: String): GatewayResult<Unit>
    suspend fun requestPasswordReset(phone: String): GatewayResult<PhoneChallenge>
    suspend fun resetPassword(command: ResetPasswordCommand): GatewayResult<Unit>

    suspend fun createMediaUploadIntent(intent: MediaUploadIntent): GatewayResult<MediaUploadSlot>
    suspend fun uploadMedia(slot: MediaUploadSlot, payload: MediaUploadPayload): GatewayResult<Unit>
    suspend fun submitRequest(command: SubmitRequestCommand): GatewayResult<RequestReceipt>

    suspend fun getConversations(): GatewayResult<List<ConversationSummary>> = conversationUnavailable()
    suspend fun getConversationMessages(conversationId: String): GatewayResult<ConversationMessages> = conversationUnavailable()
    suspend fun markConversationRead(
        conversationId: String,
        throughSequence: Long,
    ): GatewayResult<ConversationReadReceipt> = conversationUnavailable()

    suspend fun getOrders(
        direction: OrderDirection,
        cursor: String? = null,
        limit: Int = 20,
    ): GatewayResult<CursorPage<OrderSummary>>

    suspend fun getOrder(orderId: String): GatewayResult<OrderSummary>
    suspend fun getInvoices(
        query: String? = null,
        cursor: String? = null,
        limit: Int = 20,
    ): GatewayResult<CursorPage<InvoiceSummary>> = GatewayResult.Failure(
        ApiError(
            code = ApiErrorCode.ServiceUnavailable,
            message = "Invoice read API is unavailable",
            traceId = "invoice-read-unavailable",
            retryable = true,
        ),
    )

    suspend fun getInvoice(invoiceId: String): GatewayResult<InvoiceDetails> = GatewayResult.Failure(
        ApiError(
            code = ApiErrorCode.ServiceUnavailable,
            message = "Invoice read API is unavailable",
            traceId = "invoice-read-unavailable",
            retryable = true,
        ),
    )
    suspend fun getBalance(): GatewayResult<BalanceSnapshot>
    suspend fun getBalanceMovements(cursor: String? = null, limit: Int = 20): GatewayResult<CursorPage<BalanceMovement>>
    suspend fun getProfile(): GatewayResult<Profile>
    suspend fun getSupportContact(): GatewayResult<SupportContact>
    suspend fun getPrivacy(): GatewayResult<PrivacySummary>
    suspend fun requestAccountDeletion(): GatewayResult<DeletionRequest>
    suspend fun changeProfilePassword(command: ChangeProfilePasswordCommand): GatewayResult<Unit> = GatewayResult.Failure(
        ApiError(
            code = ApiErrorCode.ServiceUnavailable,
            message = "Profile password API is unavailable",
            traceId = "profile-password-unavailable",
            retryable = true,
        ),
    )
    suspend fun getNotifications(cursor: String? = null, limit: Int = 20): GatewayResult<CursorPage<MaxNotification>>
    suspend fun markNotificationRead(notificationId: String): GatewayResult<Unit>
    suspend fun markNotificationReadAuthenticated(accessToken: String, notificationId: String): GatewayResult<Unit>
    suspend fun registerPushInstallation(
        accessToken: String,
        installationId: String,
        registration: PushInstallationRegistration,
    ): GatewayResult<Unit>
    suspend fun unregisterPushInstallation(accessToken: String, installationId: String): GatewayResult<Unit>
}


private fun <T> conversationUnavailable(): GatewayResult<T> = GatewayResult.Failure(
    ApiError(
        code = ApiErrorCode.ServiceUnavailable,
        message = "Conversation read API is unavailable",
        traceId = "conversation-read-unavailable",
        retryable = true,
    ),
)
