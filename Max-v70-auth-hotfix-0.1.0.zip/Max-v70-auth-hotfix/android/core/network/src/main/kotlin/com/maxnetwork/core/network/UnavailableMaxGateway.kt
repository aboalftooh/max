package com.maxnetwork.core.network

class UnavailableMaxGateway(
    private val reason: String = "Max backend is not configured",
) : MaxGateway {
    private fun failure() = GatewayResult.Failure(
        ApiError(
            code = ApiErrorCode.ServiceUnavailable,
            message = reason,
            traceId = "local-unavailable",
            retryable = true,
        ),
    )

    override suspend fun validateRegistrationCode(code: String) = failure()
    override suspend fun requestPhoneChallenge(phone: String) = failure()
    override suspend fun verifyPhoneChallenge(challengeId: String, otp: String) = failure()
    override suspend fun resolveVerifiedPhone(verificationToken: String) = failure()
    override suspend fun createAccount(command: AccountCreation) = failure()
    override suspend fun login(credentials: LoginCredentials) = failure()
    override suspend fun refreshSession(refreshToken: String) = failure()
    override suspend fun logout(accessToken: String) = failure()
    override suspend fun requestPasswordReset(phone: String) = failure()
    override suspend fun resetPassword(command: ResetPasswordCommand) = failure()
    override suspend fun createMediaUploadIntent(intent: MediaUploadIntent) = failure()
    override suspend fun uploadMedia(slot: MediaUploadSlot, payload: MediaUploadPayload) = failure()
    override suspend fun submitRequest(command: SubmitRequestCommand) = failure()
    override suspend fun getOrders(direction: OrderDirection, cursor: String?, limit: Int) = failure()
    override suspend fun getOrder(orderId: String) = failure()
    override suspend fun getBalance() = failure()
    override suspend fun getBalanceMovements(cursor: String?, limit: Int) = failure()
    override suspend fun getProfile() = failure()
    override suspend fun getSupportContact() = failure()
    override suspend fun getPrivacy() = failure()
    override suspend fun requestAccountDeletion() = failure()
    override suspend fun getNotifications(cursor: String?, limit: Int) = failure()
    override suspend fun markNotificationRead(notificationId: String) = failure()
    override suspend fun markNotificationReadAuthenticated(accessToken: String, notificationId: String) = failure()
    override suspend fun registerPushInstallation(accessToken: String, installationId: String, registration: PushInstallationRegistration) = failure()
    override suspend fun unregisterPushInstallation(accessToken: String, installationId: String) = failure()
}
