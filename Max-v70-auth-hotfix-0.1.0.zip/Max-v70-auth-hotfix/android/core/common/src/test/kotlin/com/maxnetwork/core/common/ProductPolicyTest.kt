package com.maxnetwork.core.common

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProductPolicyTest {
    @Test
    fun `identity remains frozen`() {
        assertEquals("max", ProductIdentity.DISPLAY_NAME)
        assertEquals("com.maxnetwork.android", ProductIdentity.APPLICATION_ID)
    }

    @Test
    fun `financial writes remain disabled`() {
        assertFalse(V1ProductPolicy.FINANCIAL_WRITES_ALLOWED)
        assertFalse(V1ProductPolicy.OFFLINE_FINANCIAL_WRITES_ALLOWED)
        assertFalse(V1ProductPolicy.INVOICE_DETAILS_VISIBLE)
    }

    @Test
    fun `media policy remains bounded`() {
        assertTrue(V1ProductPolicy.MAX_IMAGE_BYTES < V1ProductPolicy.MAX_TOTAL_ATTACHMENT_BYTES)
        assertEquals(60, V1ProductPolicy.MAX_AUDIO_SECONDS)
    }
}
