package com.maxnetwork.core.common

object V1ProductPolicy {
    const val REGISTRATION_CODE_TTL_HOURS = 72
    const val OTP_LENGTH = 6
    const val OTP_TTL_MINUTES = 5
    const val OTP_RESEND_SECONDS = 60
    const val OTP_MAX_ATTEMPTS = 5
    const val RESET_CODE_TTL_MINUTES = 10
    const val RESET_CODE_MAX_ATTEMPTS = 5

    const val MAX_IMAGE_COUNT = 1
    const val MAX_IMAGE_BYTES = 8L * 1024L * 1024L
    const val MAX_AUDIO_COUNT = 1
    const val MAX_AUDIO_SECONDS = 60
    const val MAX_AUDIO_BYTES = 5L * 1024L * 1024L
    const val MAX_TOTAL_ATTACHMENT_BYTES = 12L * 1024L * 1024L
    const val SIGNED_MEDIA_URL_TTL_MINUTES = 10

    const val ACCOUNT_DELETION_GRACE_DAYS = 30
    const val PENDING_REMINDER_INTERVAL_HOURS = 24
    const val QUIET_HOURS_START = 21
    const val QUIET_HOURS_END = 8

    const val INVOICE_DETAILS_VISIBLE = false
    const val FINANCIAL_WRITES_ALLOWED = false
    const val OFFLINE_FINANCIAL_WRITES_ALLOWED = false
    const val MULTI_USER_SCHEMA_ENABLED = true
}
