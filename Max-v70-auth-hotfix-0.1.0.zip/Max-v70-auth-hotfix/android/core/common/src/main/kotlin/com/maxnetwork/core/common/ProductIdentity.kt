package com.maxnetwork.core.common

object ProductIdentity {
    const val DISPLAY_NAME = "max"
    const val APPLICATION_ID = "com.maxnetwork.android"
}
