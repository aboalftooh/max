package com.maxnetwork.core.model

data class Money(
    val minorUnits: Long,
    val currency: CurrencyCode,
)

enum class CurrencyCode {
    SDG,
}
