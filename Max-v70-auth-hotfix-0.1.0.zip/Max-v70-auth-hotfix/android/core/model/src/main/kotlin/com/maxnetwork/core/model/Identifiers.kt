package com.maxnetwork.core.model

@JvmInline
value class UserId(val value: String)

@JvmInline
value class StoreId(val value: String)

@JvmInline
value class RequestId(val value: String)

@JvmInline
value class NotificationId(val value: String)
