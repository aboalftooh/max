package com.maxnetwork.core.testing

import com.maxnetwork.core.network.AccountCreation
import com.maxnetwork.core.network.ApiError
import com.maxnetwork.core.network.ApiErrorCode
import com.maxnetwork.core.network.BalanceMovement
import com.maxnetwork.core.network.CursorPage
import com.maxnetwork.core.network.ConversationAuthorType
import com.maxnetwork.core.network.ConversationMessage
import com.maxnetwork.core.network.ConversationMessages
import com.maxnetwork.core.network.ConversationReadReceipt
import com.maxnetwork.core.network.ConversationSummary
import com.maxnetwork.core.network.DeletionRequest
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.InvoiceDetails
import com.maxnetwork.core.network.InvoiceItem
import com.maxnetwork.core.network.InvoiceSummary
import com.maxnetwork.core.network.InvoiceType
import com.maxnetwork.core.network.MoneyAmount
import com.maxnetwork.core.network.LoginCredentials
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.MediaUploadIntent
import com.maxnetwork.core.network.MediaUploadPayload
import com.maxnetwork.core.network.MediaUploadSlot
import com.maxnetwork.core.network.OrderDirection
import com.maxnetwork.core.network.OrderSummary
import com.maxnetwork.core.network.PhoneAuthNextAction
import com.maxnetwork.core.network.PhoneAuthResolution
import com.maxnetwork.core.network.PhoneChallenge
import com.maxnetwork.core.network.PushInstallationRegistration
import com.maxnetwork.core.network.RegistrationCodeValidation
import com.maxnetwork.core.network.RequestReceipt
import com.maxnetwork.core.network.ResetPasswordCommand
import com.maxnetwork.core.network.Session
import com.maxnetwork.core.network.SubmitRequestCommand
import com.maxnetwork.core.network.VerifiedPhone
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.UUID

class FakeMaxGateway(
    private val fixtures: FakeFixtures = FakeFixtures.default(),
    private val now: () -> Instant = { Instant.parse("2026-07-28T06:00:00Z") },
) : MaxGateway {
    private val requestReceipts = linkedMapOf<String, RequestReceipt>()
    private val conversations = linkedMapOf<String, ConversationSummary>()
    private val conversationMessages = linkedMapOf<String, List<ConversationMessage>>()
    private val readNotificationIds = linkedSetOf<String>()
    private val pushInstallations = linkedMapOf<String, PushInstallationRegistration>()

    override suspend fun validateRegistrationCode(code: String): GatewayResult<RegistrationCodeValidation> =
        if (code == "MAX-STORE-001") {
            GatewayResult.Success(
                RegistrationCodeValidation(
                    validationToken = "fake-registration-token",
                    storeDisplayName = fixtures.profile.storeName,
                    expiresAt = now().plus(72, ChronoUnit.HOURS),
                ),
            )
        } else {
            failure(ApiErrorCode.InvalidRequest, "كود التسجيل غير صالح")
        }

    override suspend fun requestPhoneChallenge(phone: String): GatewayResult<PhoneChallenge> =
        GatewayResult.Success(
            PhoneChallenge(
                challengeId = "fake-phone-challenge",
                expiresAt = now().plus(5, ChronoUnit.MINUTES),
                resendAvailableAt = now().plus(60, ChronoUnit.SECONDS),
                remainingAttempts = 5,
            ),
        )

    override suspend fun verifyPhoneChallenge(challengeId: String, otp: String): GatewayResult<VerifiedPhone> =
        if (challengeId == "fake-phone-challenge" && otp == "123456") {
            GatewayResult.Success(
                VerifiedPhone(
                    verificationToken = "fake-phone-verification",
                    maskedPhone = "+249******000",
                    expiresAt = now().plus(10, ChronoUnit.MINUTES),
                ),
            )
        } else {
            failure(ApiErrorCode.InvalidRequest, "رمز التحقق غير صحيح")
        }

    override suspend fun resolveVerifiedPhone(verificationToken: String): GatewayResult<PhoneAuthResolution> =
        GatewayResult.Success(
            PhoneAuthResolution(
                nextAction = PhoneAuthNextAction.JoinCode,
                session = null,
            ),
        )

    override suspend fun createAccount(command: AccountCreation): GatewayResult<Session> = session()
    override suspend fun login(credentials: LoginCredentials): GatewayResult<Session> = session()
    override suspend fun refreshSession(refreshToken: String): GatewayResult<Session> =
        if (refreshToken == "fake-refresh-token") session() else failure(ApiErrorCode.Unauthorized, "انتهت الجلسة")
    override suspend fun logout(accessToken: String): GatewayResult<Unit> = GatewayResult.Success(Unit)
    override suspend fun requestPasswordReset(phone: String): GatewayResult<PhoneChallenge> = requestPhoneChallenge(phone)
    override suspend fun resetPassword(command: ResetPasswordCommand): GatewayResult<Unit> = GatewayResult.Success(Unit)

    override suspend fun createMediaUploadIntent(intent: MediaUploadIntent): GatewayResult<MediaUploadSlot> =
        GatewayResult.Success(
            MediaUploadSlot(
                uploadId = "upload-${UUID.nameUUIDFromBytes(intent.contentType.toByteArray())}",
                uploadUrl = "https://fake.invalid/private-upload",
                expiresAt = now().plus(10, ChronoUnit.MINUTES),
            ),
        )

    override suspend fun uploadMedia(slot: MediaUploadSlot, payload: MediaUploadPayload): GatewayResult<Unit> =
        if (slot.uploadId.isNotBlank() && payload.bytes.isNotEmpty()) GatewayResult.Success(Unit)
        else failure(ApiErrorCode.AttachmentRejected, "المرفق غير صالح")

    override suspend fun submitRequest(command: SubmitRequestCommand): GatewayResult<RequestReceipt> = synchronized(requestReceipts) {
        val existing = requestReceipts[command.clientRequestId]
        if (existing != null) {
            GatewayResult.Success(existing)
        } else if (command.text.isNullOrBlank() && command.imageUploadId == null && command.audioUploadId == null) {
            failure(ApiErrorCode.InvalidRequest, "يجب إرفاق نص أو صورة أو صوت")
        } else {
            val requestId = "req-${requestReceipts.size + 1}"
            val conversationId = "conversation-$requestId"
            val receipt = RequestReceipt(
                requestId = requestId,
                conversationId = conversationId,
                clientRequestId = command.clientRequestId,
                acceptedAt = now(),
            )
            val text = command.text?.trim()?.takeIf(String::isNotEmpty)
            val title = text
                ?.lineSequence()
                ?.map(String::trim)
                ?.firstOrNull(String::isNotEmpty)
                ?.take(80)
                ?: "طلب قطعة"
            val message = ConversationMessage(
                id = "request-message-$requestId",
                conversationId = conversationId,
                sequence = 1,
                authorType = ConversationAuthorType.Store,
                text = text,
                imageMediaId = command.imageUploadId,
                audioMediaId = command.audioUploadId,
                createdAt = now(),
            )
            conversations[conversationId] = ConversationSummary(
                id = conversationId,
                requestId = requestId,
                title = title,
                createdAt = now(),
                lastMessageAt = now(),
                latestSequence = 1,
                lastReadSequence = 0,
                unreadCount = 0,
            )
            conversationMessages[conversationId] = listOf(message)
            requestReceipts[command.clientRequestId] = receipt
            GatewayResult.Success(receipt)
        }
    }

    override suspend fun getConversations(): GatewayResult<List<ConversationSummary>> = GatewayResult.Success(
        conversations.values.sortedWith(compareByDescending<ConversationSummary> { it.lastMessageAt }.thenByDescending { it.id }),
    )

    override suspend fun getConversationMessages(conversationId: String): GatewayResult<ConversationMessages> {
        val summary = conversations[conversationId] ?: return failure(ApiErrorCode.NotFound, "المحادثة غير موجودة")
        return GatewayResult.Success(
            ConversationMessages(
                conversationId = conversationId,
                latestSequence = summary.latestSequence,
                items = conversationMessages[conversationId].orEmpty(),
            ),
        )
    }

    override suspend fun markConversationRead(
        conversationId: String,
        throughSequence: Long,
    ): GatewayResult<ConversationReadReceipt> {
        val summary = conversations[conversationId] ?: return failure(ApiErrorCode.NotFound, "المحادثة غير موجودة")
        if (throughSequence !in summary.lastReadSequence..summary.latestSequence) {
            return failure(ApiErrorCode.Conflict, "تسلسل القراءة غير صالح")
        }
        conversations[conversationId] = summary.copy(lastReadSequence = throughSequence, unreadCount = 0)
        return GatewayResult.Success(ConversationReadReceipt(conversationId, throughSequence))
    }

    override suspend fun getOrders(direction: OrderDirection, cursor: String?, limit: Int): GatewayResult<CursorPage<OrderSummary>> {
        val ordered = fixtures.orders
            .filter { it.direction == direction }
            .sortedWith(compareByDescending<OrderSummary> { it.occurredAt }.thenByDescending { it.id })
        val start = cursor?.toIntOrNull()?.coerceIn(0, ordered.size) ?: 0
        val pageSize = limit.coerceIn(1, 50)
        val items = ordered.drop(start).take(pageSize)
        val next = (start + items.size).takeIf { it < ordered.size }?.toString()
        return GatewayResult.Success(CursorPage(items, next))
    }

    override suspend fun getOrder(orderId: String): GatewayResult<OrderSummary> =
        fixtures.orders.firstOrNull { it.id == orderId }
            ?.let { GatewayResult.Success(it) }
            ?: failure(ApiErrorCode.NotFound, "الطلب غير موجود")

    override suspend fun getInvoices(
        query: String?,
        cursor: String?,
        limit: Int,
    ): GatewayResult<CursorPage<InvoiceSummary>> {
        val normalized = query?.trim()?.lowercase().orEmpty()
        val all = fakeInvoices()
            .filter { invoice ->
                normalized.isEmpty() ||
                    invoice.invoiceNumber.lowercase().contains(normalized) ||
                    fakeInvoiceDetails(invoice.id)?.items.orEmpty().any { item ->
                        item.name.lowercase().contains(normalized) ||
                            item.partNumber?.lowercase()?.contains(normalized) == true
                    }
            }
            .sortedWith(compareByDescending<InvoiceSummary> { it.occurredAt }.thenByDescending { it.id })
        val start = cursor?.toIntOrNull()?.coerceIn(0, all.size) ?: 0
        val pageSize = limit.coerceIn(1, 50)
        val items = all.drop(start).take(pageSize)
        val next = (start + items.size).takeIf { it < all.size }?.toString()
        return GatewayResult.Success(CursorPage(items, next))
    }

    override suspend fun getInvoice(invoiceId: String): GatewayResult<InvoiceDetails> =
        fakeInvoiceDetails(invoiceId)?.let { GatewayResult.Success(it) }
            ?: failure(ApiErrorCode.NotFound, "الفاتورة غير موجودة")

    override suspend fun getBalance() = GatewayResult.Success(fixtures.balance)

    override suspend fun getBalanceMovements(cursor: String?, limit: Int): GatewayResult<CursorPage<BalanceMovement>> {
        val start = cursor?.toIntOrNull()?.coerceIn(0, fixtures.movements.size) ?: 0
        val pageSize = limit.coerceIn(1, 50)
        val items = fixtures.movements.drop(start).take(pageSize)
        val next = (start + items.size).takeIf { it < fixtures.movements.size }?.toString()
        return GatewayResult.Success(CursorPage(items, next))
    }

    override suspend fun getProfile() = GatewayResult.Success(fixtures.profile)
    override suspend fun getSupportContact() = GatewayResult.Success(fixtures.supportContact)
    override suspend fun getPrivacy() = GatewayResult.Success(fixtures.privacy)

    override suspend fun requestAccountDeletion(): GatewayResult<DeletionRequest> = GatewayResult.Success(
        DeletionRequest(
            requestId = "delete-req-001",
            requestedAt = now(),
            scheduledFor = now().plus(30, ChronoUnit.DAYS),
        ),
    )

    override suspend fun getNotifications(cursor: String?, limit: Int) = GatewayResult.Success(
        CursorPage(
            fixtures.notifications.take(limit.coerceIn(1, 50)).map { notification ->
                if (notification.id in readNotificationIds && notification.readAt == null) {
                    notification.copy(readAt = now())
                } else {
                    notification
                }
            },
            null,
        ),
    )

    override suspend fun markNotificationRead(notificationId: String): GatewayResult<Unit> {
        readNotificationIds += notificationId
        return GatewayResult.Success(Unit)
    }

    override suspend fun markNotificationReadAuthenticated(
        accessToken: String,
        notificationId: String,
    ): GatewayResult<Unit> = markNotificationRead(notificationId)

    override suspend fun registerPushInstallation(
        accessToken: String,
        installationId: String,
        registration: PushInstallationRegistration,
    ): GatewayResult<Unit> {
        if (accessToken.isBlank() || installationId.isBlank() || registration.token.isBlank()) {
            return failure(ApiErrorCode.InvalidRequest, "بيانات الجهاز غير صالحة")
        }
        pushInstallations[installationId] = registration
        return GatewayResult.Success(Unit)
    }

    override suspend fun unregisterPushInstallation(accessToken: String, installationId: String): GatewayResult<Unit> {
        pushInstallations.remove(installationId)
        return GatewayResult.Success(Unit)
    }

    private fun fakeInvoices(): List<InvoiceSummary> = listOf(
        InvoiceSummary(
            id = "invoice-sale-001",
            invoiceNumber = "INV-1001",
            type = InvoiceType.Sale,
            total = MoneyAmount(125_000),
            occurredAt = now().minus(1, ChronoUnit.DAYS),
        ),
        InvoiceSummary(
            id = "invoice-purchase-001",
            invoiceNumber = "PUR-204",
            type = InvoiceType.Purchase,
            total = MoneyAmount(80_000),
            occurredAt = now().minus(2, ChronoUnit.DAYS),
        ),
    )

    private fun fakeInvoiceDetails(invoiceId: String): InvoiceDetails? {
        val summary = fakeInvoices().firstOrNull { it.id == invoiceId } ?: return null
        val items = when (invoiceId) {
            "invoice-sale-001" -> listOf(
                InvoiceItem(
                    name = "فلتر زيت هايلوكس",
                    partNumber = "90915-YZZD2",
                    quantity = "2",
                    unitAmount = MoneyAmount(62_500),
                    lineTotal = MoneyAmount(125_000),
                ),
            )
            else -> listOf(
                InvoiceItem(
                    name = "زيت محرك",
                    partNumber = "08880-83388",
                    quantity = "4",
                    unitAmount = MoneyAmount(20_000),
                    lineTotal = MoneyAmount(80_000),
                ),
            )
        }
        return InvoiceDetails(
            id = summary.id,
            invoiceNumber = summary.invoiceNumber,
            type = summary.type,
            total = summary.total,
            occurredAt = summary.occurredAt,
            items = items,
        )
    }

    private fun session() = GatewayResult.Success(
        Session(
            accessToken = "fake-access-token",
            refreshToken = "fake-refresh-token",
            expiresAt = now().plus(1, ChronoUnit.HOURS),
        ),
    )

    private fun failure(code: ApiErrorCode, message: String) = GatewayResult.Failure(
        ApiError(
            code = code,
            message = message,
            traceId = "fake-trace",
            retryable = false,
        ),
    )
}
