package com.maxnetwork.core.testing

import com.maxnetwork.core.network.BalanceMovement
import com.maxnetwork.core.network.BalanceMovementType
import com.maxnetwork.core.network.BalanceSnapshot
import com.maxnetwork.core.network.MaxNotification
import com.maxnetwork.core.network.MoneyAmount
import com.maxnetwork.core.network.NotificationType
import com.maxnetwork.core.network.OrderContent
import com.maxnetwork.core.network.OrderDirection
import com.maxnetwork.core.network.OrderStatus
import com.maxnetwork.core.network.OrderSource
import com.maxnetwork.core.network.OrderSummary
import com.maxnetwork.core.network.PrivacySection
import com.maxnetwork.core.network.PrivacySummary
import com.maxnetwork.core.network.Profile
import com.maxnetwork.core.network.SupportContact
import java.time.Instant

data class FakeFixtures(
    val orders: List<OrderSummary>,
    val balance: BalanceSnapshot,
    val movements: List<BalanceMovement>,
    val profile: Profile,
    val supportContact: SupportContact,
    val privacy: PrivacySummary,
    val notifications: List<MaxNotification>,
) {
    companion object {
        fun default(): FakeFixtures {
            val now = Instant.parse("2026-07-28T06:00:00Z")
            return FakeFixtures(
                orders = listOf(
                    OrderSummary(
                        id = "ord_out_001",
                        direction = OrderDirection.Outgoing,
                        source = OrderSource.App,
                        status = OrderStatus.NeedsReply,
                        content = OrderContent("مساعد أمامي كورولا 2015", null, null),
                        occurredAt = Instant.parse("2026-07-28T05:45:00Z"),
                        invoiceReference = null,
                    ),
                    OrderSummary(
                        id = "ord_in_001",
                        direction = OrderDirection.Incoming,
                        source = OrderSource.Verto,
                        status = OrderStatus.Provided,
                        content = OrderContent("طقم بواجي", null, null),
                        occurredAt = Instant.parse("2026-07-27T14:30:00Z"),
                        invoiceReference = "invoice-purchase-001",
                    ),
                    OrderSummary(
                        id = "ord_out_002",
                        direction = OrderDirection.Outgoing,
                        source = OrderSource.MaxTeam,
                        status = OrderStatus.Unavailable,
                        content = OrderContent("طرمبة بنزين", null, null),
                        occurredAt = Instant.parse("2026-07-26T09:15:00Z"),
                        invoiceReference = null,
                    ),
                ),
                balance = BalanceSnapshot(MoneyAmount(185_000, "SDG"), now),
                movements = listOf(
                    BalanceMovement(
                        id = "mov_002",
                        type = BalanceMovementType.IncomingOrder,
                        amount = MoneyAmount(250_000, "SDG"),
                        delta = MoneyAmount(250_000, "SDG"),
                        balanceAfter = MoneyAmount(185_000, "SDG"),
                        occurredAt = Instant.parse("2026-07-27T14:30:00Z"),
                    ),
                    BalanceMovement(
                        id = "mov_001",
                        type = BalanceMovementType.OutgoingOrder,
                        amount = MoneyAmount(65_000, "SDG"),
                        delta = MoneyAmount(-65_000, "SDG"),
                        balanceAfter = MoneyAmount(-65_000, "SDG"),
                        occurredAt = Instant.parse("2026-07-26T11:10:00Z"),
                    ),
                ),
                profile = Profile(
                    userId = "usr_001",
                    storeId = "store_001",
                    name = "محمد أحمد",
                    storeName = "النجمة لقطع الغيار",
                    phone = "+249912000000",
                ),
                supportContact = SupportContact(
                    phone = "+249900000000",
                    whatsappUrl = "https://wa.me/249900000000",
                ),
                privacy = PrivacySummary(
                    version = "1.0",
                    effectiveAt = Instant.parse("2026-07-01T00:00:00Z"),
                    sections = listOf(
                        PrivacySection("البيانات", "يجمع ماكس البيانات اللازمة للتشغيل والمتابعة فقط."),
                        PrivacySection("الخصوصية", "لا يعرض ماكس المخزون أو أسماء المنافسين داخل الطلبات."),
                    ),
                ),
                notifications = listOf(
                    MaxNotification(
                        id = "not_001",
                        type = NotificationType.RequestNeedsReply,
                        title = "طلب يحتاج ردًا",
                        body = "افتح الطلب للاطلاع على المحتوى.",
                        occurredAt = now,
                        readAt = null,
                    ),
                ),
            )
        }
    }
}
