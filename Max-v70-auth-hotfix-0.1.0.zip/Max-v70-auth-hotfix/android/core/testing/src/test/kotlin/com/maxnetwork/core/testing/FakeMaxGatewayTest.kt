package com.maxnetwork.core.testing

import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.core.network.OrderDirection
import com.maxnetwork.core.network.SubmitRequestCommand
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FakeMaxGatewayTest {
    @Test
    fun `request submission is idempotent`() {
        val gateway = FakeMaxGateway()
        val command = SubmitRequestCommand("client-1", "فلتر زيت", null, null)
        val first = runSuspend { gateway.submitRequest(command) }
        val second = runSuspend { gateway.submitRequest(command) }
        assertEquals(first, second)
    }

    @Test
    fun `orders never expose competitor names or inventory`() {
        val gateway = FakeMaxGateway()
        val result = runSuspend { gateway.getOrders(OrderDirection.Outgoing) }
        assertTrue(result is GatewayResult.Success)
        val text = result.toString().lowercase()
        assertTrue("competitor" !in text)
        assertTrue("inventory" !in text)
    }

    private fun <T> runSuspend(block: suspend () -> T): T {
        var outcome: Result<T>? = null
        block.startCoroutine(object : Continuation<T> {
            override val context = EmptyCoroutineContext
            override fun resumeWith(result: Result<T>) {
                outcome = result
            }
        })
        return outcome!!.getOrThrow()
    }
}
