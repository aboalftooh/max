package com.maxnetwork.core.testing

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class ArchitectureBoundaryTest {
    private val androidRoot: File = generateSequence(File(System.getProperty("user.dir"))) { it.parentFile }
        .first { File(it, "settings.gradle.kts").isFile }

    @Test
    fun `features never depend on another feature`() {
        val violations = File(androidRoot, "feature").walkTopDown()
            .filter { it.name == "build.gradle.kts" }
            .filter { Regex("project\\(\\\":feature:").containsMatchIn(it.readText()) }
            .map { it.relativeTo(androidRoot).path }
            .toList()
        assertTrue("Feature-to-feature dependencies: $violations", violations.isEmpty())
    }

    @Test
    fun `domain has no Android database or network imports`() {
        val forbidden = Regex("^import (android\\.|androidx\\.room|retrofit2\\.|okhttp3\\.)", RegexOption.MULTILINE)
        val violations = File(androidRoot, "feature").walkTopDown()
            .filter { it.isFile && it.extension == "kt" && "/domain/" in it.invariantSeparatorsPath }
            .filter { forbidden.containsMatchIn(it.readText()) }
            .map { it.relativeTo(androidRoot).path }
            .toList()
        assertTrue("Domain violations: $violations", violations.isEmpty())
    }

    @Test
    fun `presentation has no data storage or network references`() {
        val forbidden = Regex("(^import .*\\.data\\.|Dao\\b|Retrofit\\b|OkHttpClient\\b|VertoGateway\\b)", RegexOption.MULTILINE)
        val violations = File(androidRoot, "feature").walkTopDown()
            .filter { it.isFile && it.extension == "kt" && "/presentation/" in it.invariantSeparatorsPath }
            .filter { forbidden.containsMatchIn(it.readText()) }
            .map { it.relativeTo(androidRoot).path }
            .toList()
        assertTrue("Presentation violations: $violations", violations.isEmpty())
    }

    @Test
    fun `authentication production code has no body logger or Android log call`() {
        val forbidden = Regex("HttpLoggingInterceptor|\\bLog\\.(v|d|i|w|e|wtf)\\s*\\(")
        val authMain = File(androidRoot, "feature/auth/src/main")
        val violations = authMain.walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .filter { forbidden.containsMatchIn(it.readText()) }
            .map { it.relativeTo(androidRoot).path }
            .toList()
        assertTrue("Authentication logging risks: $violations", violations.isEmpty())
    }
}
