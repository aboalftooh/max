plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ktlint)
    alias(libs.plugins.detekt)
}

val maxApiBaseUrl = providers.gradleProperty("MAX_API_BASE_URL")
    .orElse("https://madkfvggyolmdberzmtb.supabase.co/functions/v1/max-api/")
val firebaseAppId = providers.gradleProperty("MAX_FIREBASE_APP_ID").orElse("")
val firebaseProjectId = providers.gradleProperty("MAX_FIREBASE_PROJECT_ID").orElse("")
val firebaseApiKey = providers.gradleProperty("MAX_FIREBASE_API_KEY").orElse("")
val firebaseSenderId = providers.gradleProperty("MAX_FIREBASE_SENDER_ID").orElse("")

android {
    namespace = "com.maxnetwork.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.maxnetwork.android"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true
        buildConfigField(
            "String",
            "MAX_API_BASE_URL",
            "\"${maxApiBaseUrl.get().replace("\\", "\\\\").replace("\"", "\\\"")}\"",
        )
        buildConfigField("String", "MAX_FIREBASE_APP_ID", "\"${firebaseAppId.get()}\"")
        buildConfigField("String", "MAX_FIREBASE_PROJECT_ID", "\"${firebaseProjectId.get()}\"")
        buildConfigField("String", "MAX_FIREBASE_API_KEY", "\"${firebaseApiKey.get()}\"")
        buildConfigField("String", "MAX_FIREBASE_SENDER_ID", "\"${firebaseSenderId.get()}\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += "-Werror"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }

    lint {
        abortOnError = true
        warningsAsErrors = true
        checkDependencies = true
    }

    testOptions {
        unitTests.isIncludeAndroidResources = true
    }
}

ktlint {
    android.set(true)
    version.set("1.5.0")
}

dependencies {
    implementation(project(":core:common"))
    implementation(project(":core:model"))
    implementation(project(":core:network"))
    implementation(project(":core:designsystem"))
    implementation(project(":feature:auth"))
    implementation(project(":feature:home"))
    implementation(project(":feature:request"))
    implementation(project(":feature:orders"))
    implementation(project(":feature:balance"))
    implementation(project(":feature:profile"))
    implementation(project(":feature:notifications"))
    implementation(project(":feature:invoices"))
    implementation(project(":feature:conversations"))
    implementation(project(":feature:settings"))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.firebase.messaging)
    implementation(libs.androidx.biometric)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)

    testImplementation(libs.junit4)

    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation("androidx.test:core-ktx:1.6.1")
    androidTestImplementation(libs.androidx.test.espresso.core)
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)

    debugImplementation(project(":core:testing"))
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
