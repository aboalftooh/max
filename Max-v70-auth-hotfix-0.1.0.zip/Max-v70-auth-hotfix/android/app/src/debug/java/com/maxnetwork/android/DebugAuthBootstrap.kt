package com.maxnetwork.android

import com.maxnetwork.android.di.MaxAppContainer
import kotlinx.coroutines.runBlocking

/** Test-only fake session bootstrap; this source set is never packaged into release. */
internal fun bootstrapDebugAuthentication(container: MaxAppContainer) {
    runBlocking {
        container.auth.useCases.login(
            phone = "debug-test-phone",
            password = "debug-test-only",
        )
    }
}
