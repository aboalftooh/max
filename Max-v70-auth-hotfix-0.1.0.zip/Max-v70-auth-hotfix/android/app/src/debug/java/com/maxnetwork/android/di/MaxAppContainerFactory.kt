package com.maxnetwork.android.di

import android.content.Context
import com.maxnetwork.core.network.InMemoryBearerTokenStore
import com.maxnetwork.core.testing.FakeFixtures
import com.maxnetwork.core.testing.FakeMaxGateway
import com.maxnetwork.feature.auth.AuthFeatureFactory
import com.maxnetwork.feature.balance.BalanceFeatureFactory
import com.maxnetwork.feature.notifications.NotificationsFeatureFactory
import com.maxnetwork.feature.orders.OrdersFeatureFactory
import com.maxnetwork.feature.profile.ProfileFeatureFactory
import com.maxnetwork.feature.request.RequestFeatureFactory

internal fun createMaxAppContainer(context: Context): MaxAppContainer {
    val bearerTokenStore = InMemoryBearerTokenStore()
    val gateway = FakeMaxGateway(FakeFixtures.default())
    return MaxAppContainer(
        gateway = gateway,
        auth = AuthFeatureFactory.create(
            context = context,
            gateway = gateway,
            onAccessTokenChanged = bearerTokenStore::update,
        ),
        balance = BalanceFeatureFactory.create(gateway = gateway),
        profile = ProfileFeatureFactory.create(gateway = gateway),
        orders = OrdersFeatureFactory.create(gateway = gateway),
        notifications = NotificationsFeatureFactory.create(gateway = gateway),
        request = RequestFeatureFactory.create(context, gateway),
        environmentName = "fake",
    )
}
