package com.maxnetwork.android.session

import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.usecase.ClearPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.ClearRegistrationUseCase
import com.maxnetwork.feature.auth.domain.usecase.LogoutUseCase
import com.maxnetwork.feature.profile.domain.ProfileFailure
import com.maxnetwork.feature.profile.domain.ProfileResult
import com.maxnetwork.feature.profile.domain.usecase.ClearLocalProfileUseCase
import com.maxnetwork.feature.profile.domain.usecase.RequestAccountDeletionUseCase
import com.maxnetwork.feature.request.domain.usecase.DeleteRequestDraftUseCase

class DefaultSessionOperations(
    private val logout: LogoutUseCase,
    private val clearRegistration: ClearRegistrationUseCase,
    private val clearPasswordReset: ClearPasswordResetUseCase,
    private val clearProfile: ClearLocalProfileUseCase,
    private val requestDeletion: RequestAccountDeletionUseCase,
    private val deleteRequestDraft: DeleteRequestDraftUseCase,
    private val unregisterPush: suspend () -> Unit = {},
) : SessionOperations {
    override suspend fun revokeAndClearAuthSession(): Boolean {
        runCatching { unregisterPush() }
        return when (val result = logout()) {
            is AuthResult.Success -> result.value.remoteRevocationCompleted
            is AuthResult.Failure -> false
        }
    }

    override suspend fun clearTransientAuthenticationData() {
        clearRegistration()
        clearPasswordReset()
    }

    override fun clearProfileData() {
        clearProfile()
    }

    override suspend fun clearRequestDraft() {
        deleteRequestDraft()
    }

    override suspend fun submitDeletionRequest(): DeletionSubmission = when (val result = requestDeletion()) {
        is ProfileResult.Success -> DeletionSubmission.Accepted(
            TrackableDeletionReceipt(
                requestId = result.value.requestId,
                requestedAt = result.value.requestedAt,
                scheduledFor = result.value.scheduledFor,
            ),
        )
        is ProfileResult.Failure -> DeletionSubmission.Failed(result.reason.toSessionFailure())
    }
}

private fun ProfileFailure.toSessionFailure(): SessionFailure = when (this) {
    ProfileFailure.Unauthorized -> SessionFailure.Unauthorized
    ProfileFailure.Offline -> SessionFailure.Offline
    ProfileFailure.Unavailable, ProfileFailure.InvalidData -> SessionFailure.Unavailable
}
