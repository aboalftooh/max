package com.maxnetwork.android.session

import java.time.Instant

data class TrackableDeletionReceipt(
    val requestId: String,
    val requestedAt: Instant,
    val scheduledFor: Instant,
)

enum class SessionFailure {
    Offline,
    Unauthorized,
    Unavailable,
}

sealed interface DeletionSubmission {
    data class Accepted(val receipt: TrackableDeletionReceipt) : DeletionSubmission
    data class Failed(val reason: SessionFailure) : DeletionSubmission
}

data class LogoutOutcome(
    val localDataCleared: Boolean,
    val remoteRevocationCompleted: Boolean,
)

interface SessionOperations {
    suspend fun revokeAndClearAuthSession(): Boolean
    suspend fun clearTransientAuthenticationData()
    fun clearProfileData()
    suspend fun clearRequestDraft()
    suspend fun submitDeletionRequest(): DeletionSubmission
}

class SessionCoordinator(
    private val operations: SessionOperations,
) {
    suspend fun logout(): LogoutOutcome {
        val remoteRevoked = try {
            operations.revokeAndClearAuthSession()
        } finally {
            operations.clearTransientAuthenticationData()
            operations.clearProfileData()
            operations.clearRequestDraft()
        }
        return LogoutOutcome(
            localDataCleared = true,
            remoteRevocationCompleted = remoteRevoked,
        )
    }

    suspend fun deleteAccount(): DeletionSubmission = when (val submission = operations.submitDeletionRequest()) {
        is DeletionSubmission.Failed -> submission
        is DeletionSubmission.Accepted -> {
            logout()
            submission
        }
    }
}
