package com.maxnetwork.android.security

import android.content.Context

class AppLockStore(context: Context) {
    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = preferences.getBoolean(KEY_ENABLED, false)
        set(value) {
            preferences.edit().putBoolean(KEY_ENABLED, value).apply()
        }

    var lastBackgroundAtEpochMillis: Long?
        get() = preferences.getLong(KEY_LAST_BACKGROUND_AT, NO_TIME).takeUnless { it == NO_TIME }
        set(value) {
            val editor = preferences.edit()
            if (value == null) editor.remove(KEY_LAST_BACKGROUND_AT) else editor.putLong(KEY_LAST_BACKGROUND_AT, value)
            editor.apply()
        }

    private companion object {
        const val PREFERENCES_NAME = "max_app_lock"
        const val KEY_ENABLED = "enabled"
        const val KEY_LAST_BACKGROUND_AT = "last_background_at_epoch_ms"
        const val NO_TIME = Long.MIN_VALUE
    }
}
