package com.maxnetwork.android.di

import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.feature.auth.AuthFeatureDependencies
import com.maxnetwork.feature.balance.BalanceFeatureDependencies
import com.maxnetwork.feature.invoices.InvoicesFeatureDependencies
import com.maxnetwork.feature.invoices.InvoicesFeatureFactory
import com.maxnetwork.feature.conversations.ConversationsFeatureDependencies
import com.maxnetwork.feature.conversations.ConversationsFeatureFactory
import com.maxnetwork.feature.notifications.NotificationFeatureDependencies
import com.maxnetwork.feature.orders.OrdersFeatureDependencies
import com.maxnetwork.feature.profile.ProfileFeatureDependencies
import com.maxnetwork.feature.request.RequestFeatureDependencies

data class MaxAppContainer(
    val gateway: MaxGateway,
    val auth: AuthFeatureDependencies,
    val balance: BalanceFeatureDependencies,
    val profile: ProfileFeatureDependencies,
    val orders: OrdersFeatureDependencies,
    val notifications: NotificationFeatureDependencies,
    val request: RequestFeatureDependencies,
    val environmentName: String,
) {
    val invoices: InvoicesFeatureDependencies by lazy { InvoicesFeatureFactory.create(gateway) }
    val conversations: ConversationsFeatureDependencies by lazy { ConversationsFeatureFactory.create(gateway) }
}
