package com.maxnetwork.android

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.fragment.app.FragmentActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.maxnetwork.android.push.PushLaunch
import com.maxnetwork.android.security.AppLockController
import com.maxnetwork.android.security.AppLockGate
import com.maxnetwork.android.security.AppLockStore
import com.maxnetwork.android.push.PushRegistrationCoordinator
import com.maxnetwork.android.push.toPushLaunch
import com.maxnetwork.android.session.DefaultSessionOperations
import com.maxnetwork.android.session.SessionCoordinator
import com.maxnetwork.android.session.SessionViewModel
import com.maxnetwork.android.session.TrackableDeletionReceipt
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.presentation.AuthViewModel
import com.maxnetwork.feature.balance.presentation.BalanceViewModel
import com.maxnetwork.feature.profile.domain.SupportChannel
import com.maxnetwork.feature.profile.domain.usecase.ChangeProfilePasswordUseCase
import com.maxnetwork.feature.profile.presentation.ProfileViewModel
import com.maxnetwork.feature.request.presentation.RequestViewModel
import com.maxnetwork.feature.settings.presentation.SettingsUiState
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    private var pendingPushLaunch: PushLaunch? by mutableStateOf(null)
    private val pushRegistration by lazy { PushRegistrationCoordinator(this) }
    private val appLockController by lazy { AppLockController(this, AppLockStore(this)) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingPushLaunch = intent.toPushLaunch()

        val authViewModel = createAuthViewModel()
        val balanceViewModel = createBalanceViewModel()
        val profileViewModel = createProfileViewModel()
        val sessionViewModel = createSessionViewModel()
        val requestViewModel = createRequestViewModel()
        setContent {
            val authState by authViewModel.authState.collectAsStateWithLifecycle()
            val appLockState by appLockController.state.collectAsStateWithLifecycle()
            MaxTheme {
                AppLockGate(
                    authenticated = authState is AuthState.Authenticated,
                    state = appLockState,
                    onUnlock = appLockController::requestUnlock,
                ) {
                    MaxAppRoute(
                        authViewModel = authViewModel,
                        balanceViewModel = balanceViewModel,
                        profileViewModel = profileViewModel,
                        sessionViewModel = sessionViewModel,
                        requestViewModel = requestViewModel,
                        settingsUiState = SettingsUiState(
                            appLockEnabled = appLockState.enabled,
                            appLockAvailable = appLockState.available,
                            appLockBusy = appLockState.authenticating,
                            appLockUnavailableMessage = appLockState.unavailableMessage,
                        ),
                        onAppLockChanged = appLockController::requestEnabled,
                        pushLaunch = pendingPushLaunch,
                        onPushLaunchConsumed = ::consumePushLaunch,
                        onAuthenticated = ::handleAuthenticatedSession,
                        onOpenSupport = ::openSupportChannel,
                        onDeletionAccepted = ::showDeletionReceipt,
                        onSupportUnavailable = {
                            Toast.makeText(this, "قناة التواصل غير متاحة حاليًا", Toast.LENGTH_SHORT).show()
                        },
                        onAuthSupport = {
                            authViewModel.requestContactSupport()
                            Toast.makeText(
                                this,
                                getString(R.string.support_contact_not_configured),
                                Toast.LENGTH_SHORT,
                            ).show()
                        },
                    )
                }
            }
        }
    }

    private fun createAuthViewModel(): AuthViewModel {
        val authUseCases = (application as MaxApplication).appContainer.auth.useCases
        val factory = viewModelFactory {
            initializer {
                AuthViewModel(
                    observeAuthState = authUseCases.observeState,
                    restoreSessionUseCase = authUseCases.restoreSession,
                    loginUseCase = authUseCases.login,
                    logoutUseCase = authUseCases.logout,
                    validateRegistrationCodeUseCase = authUseCases.validateRegistrationCode,
                    requestPhoneChallengeUseCase = authUseCases.requestPhoneChallenge,
                    resendPhoneChallengeUseCase = authUseCases.resendPhoneChallenge,
                    verifyPhoneOtpUseCase = authUseCases.verifyPhoneOtp,
                    createAccountUseCase = authUseCases.createAccount,
                    clearRegistrationUseCase = authUseCases.clearRegistration,
                    requestPasswordResetUseCase = authUseCases.requestPasswordReset,
                    resendPasswordResetUseCase = authUseCases.resendPasswordReset,
                    confirmPasswordResetUseCase = authUseCases.confirmPasswordReset,
                    clearPasswordResetUseCase = authUseCases.clearPasswordReset,
                )
            }
        }
        return ViewModelProvider(this, factory)[AuthViewModel::class.java]
    }

    private fun createBalanceViewModel(): BalanceViewModel {
        val useCases = (application as MaxApplication).appContainer.balance.useCases
        val factory = viewModelFactory {
            initializer {
                BalanceViewModel(
                    loadBalance = useCases.loadBalance,
                    loadMovementsPage = useCases.loadMovementsPage,
                )
            }
        }
        return ViewModelProvider(this, factory)[BalanceViewModel::class.java]
    }

    private fun createRequestViewModel(): RequestViewModel {
        val useCases = (application as MaxApplication).appContainer.request.useCases
        val factory = viewModelFactory {
            initializer {
                RequestViewModel(
                    loadDraft = useCases.load,
                    saveDraft = useCases.save,
                    observeOutbox = useCases.observeOutbox,
                    enqueueRequest = useCases.enqueue,
                    acknowledgeAccepted = useCases.acknowledgeAccepted,
                    deleteDraft = useCases.delete,
                    scheduler = (application as MaxApplication).appContainer.request.outboxScheduler,
                )
            }
        }
        return ViewModelProvider(this, factory)[RequestViewModel::class.java]
    }

    private fun createProfileViewModel(): ProfileViewModel {
        val useCases = (application as MaxApplication).appContainer.profile.useCases
        val factory = viewModelFactory {
            initializer {
                val container = (application as MaxApplication).appContainer
                ProfileViewModel(
                    loadProfile = useCases.load,
                    clearLocalProfile = useCases.clearLocal,
                    changePassword = ChangeProfilePasswordUseCase(container.profile.repository),
                )
            }
        }
        return ViewModelProvider(this, factory)[ProfileViewModel::class.java]
    }

    private fun createSessionViewModel(): SessionViewModel {
        val container = (application as MaxApplication).appContainer
        val operations = DefaultSessionOperations(
            logout = container.auth.useCases.logout,
            clearRegistration = container.auth.useCases.clearRegistration,
            clearPasswordReset = container.auth.useCases.clearPasswordReset,
            clearProfile = container.profile.useCases.clearLocal,
            requestDeletion = container.profile.useCases.requestDeletion,
            deleteRequestDraft = container.request.useCases.delete,
            unregisterPush = {
                pushRegistration.unregister()
                Unit
            },
        )
        val factory = viewModelFactory {
            initializer { SessionViewModel(SessionCoordinator(operations)) }
        }
        return ViewModelProvider(this, factory)[SessionViewModel::class.java]
    }

    override fun onStart() {
        super.onStart()
        appLockController.onForegrounded()
    }

    override fun onStop() {
        appLockController.onBackgrounded()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingPushLaunch = intent.toPushLaunch()
    }

    private fun consumePushLaunch() {
        val consumed = pendingPushLaunch ?: return
        pendingPushLaunch = null
        lifecycleScope.launch {
            pushRegistration.markRead(consumed.notificationId)
        }
    }

    private fun handleAuthenticatedSession() {
        requestNotificationPermissionOnce()
        if (FirebaseApp.getApps(this).isEmpty()) return
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            lifecycleScope.launch { pushRegistration.sync(token) }
        }
    }

    private fun requestNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            return
        }
        val preferences = getSharedPreferences(PUSH_PERMISSION_PREFERENCES, MODE_PRIVATE)
        if (preferences.getBoolean(PUSH_PERMISSION_REQUESTED, false)) return
        preferences.edit().putBoolean(PUSH_PERMISSION_REQUESTED, true).apply()
        requestPermissions(
            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
            NOTIFICATION_PERMISSION_REQUEST_CODE,
        )
    }

    private fun showDeletionReceipt(receipt: TrackableDeletionReceipt) {
        Toast.makeText(
            this,
            "تم تسجيل طلب الحذف: ${receipt.requestId}",
            Toast.LENGTH_LONG,
        ).show()
    }

    private fun openSupportChannel(channel: SupportChannel) {
        val uri = when (channel) {
            is SupportChannel.WhatsApp -> Uri.parse(channel.httpsUrl)
            is SupportChannel.Phone -> Uri.parse("tel:${channel.number}")
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "لا يوجد تطبيق مناسب لفتح قناة التواصل", Toast.LENGTH_SHORT).show()
        }
    }

    private companion object {
        const val PUSH_PERMISSION_PREFERENCES = "max_push_permission"
        const val PUSH_PERMISSION_REQUESTED = "requested_once"
        const val NOTIFICATION_PERMISSION_REQUEST_CODE = 1001
    }
}
