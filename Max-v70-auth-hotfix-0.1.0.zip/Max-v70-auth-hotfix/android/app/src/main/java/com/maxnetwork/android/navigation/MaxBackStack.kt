package com.maxnetwork.android.navigation

class MaxBackStack private constructor(
    val entries: List<MaxDestination>,
) {
    val current: MaxDestination
        get() = entries.last()

    val canGoBack: Boolean
        get() = entries.size > 1

    fun navigate(destination: MaxDestination): MaxBackStack {
        if (destination == current) return this
        return MaxBackStack(entries + destination)
    }

    fun replace(destination: MaxDestination): MaxBackStack = MaxBackStack(listOf(destination))

    fun back(): MaxBackStack = if (canGoBack) {
        MaxBackStack(entries.dropLast(1))
    } else {
        this
    }

    fun resolveAuthentication(authenticated: Boolean): MaxBackStack = when {
        authenticated && !current.requiresAuthentication -> authenticatedRoot()
        !authenticated && current.requiresAuthentication -> signedOutRoot()
        else -> this
    }

    companion object {
        fun signedOutRoot() = MaxBackStack(listOf(MaxDestination.Login))
        fun authenticatedRoot() = MaxBackStack(listOf(MaxDestination.Home))
        fun from(destination: MaxDestination) = MaxBackStack(listOf(destination))
    }
}
