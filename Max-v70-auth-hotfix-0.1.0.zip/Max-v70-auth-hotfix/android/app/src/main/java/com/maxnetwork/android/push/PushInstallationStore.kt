package com.maxnetwork.android.push

import android.content.Context
import com.maxnetwork.feature.notifications.domain.PushInstallationId
import java.util.UUID

class PushInstallationStore(context: Context) {
    private val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)

    fun getOrCreate(): PushInstallationId {
        preferences.getString(KEY_INSTALLATION_ID, null)?.let { stored ->
            runCatching { PushInstallationId(stored) }.getOrNull()?.let { return it }
        }
        val created = PushInstallationId("install_${UUID.randomUUID().toString().replace("-", "")}")
        preferences.edit().putString(KEY_INSTALLATION_ID, created.value).apply()
        return created
    }

    private companion object {
        const val PREFERENCES = "max_push_installation"
        const val KEY_INSTALLATION_ID = "installation_id"
    }
}
