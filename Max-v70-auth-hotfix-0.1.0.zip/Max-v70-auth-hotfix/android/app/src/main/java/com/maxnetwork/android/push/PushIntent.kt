package com.maxnetwork.android.push

import android.content.Intent
import com.maxnetwork.feature.notifications.domain.PushNavigationTarget

data class PushLaunch(
    val notificationId: String,
    val target: PushNavigationTarget,
)

fun Intent.toPushLaunch(): PushLaunch? {
    val notificationId = getStringExtra(EXTRA_NOTIFICATION_ID)
        ?.takeIf { it.matches(Regex("^[A-Za-z0-9_-]{1,128}$")) }
        ?: return null
    val target = runCatching {
        PushNavigationTarget.valueOf(requireNotNull(getStringExtra(EXTRA_TARGET)))
    }.getOrNull() ?: return null
    return PushLaunch(notificationId, target)
}

const val EXTRA_NOTIFICATION_ID = "com.maxnetwork.android.push.NOTIFICATION_ID"
const val EXTRA_TARGET = "com.maxnetwork.android.push.TARGET"
