package com.maxnetwork.android.navigation

import java.net.URLDecoder
import java.net.URLEncoder

sealed interface MaxDestination {
    val route: String
    val requiresAuthentication: Boolean

    data object Login : MaxDestination {
        override val route = "login"
        override val requiresAuthentication = false
    }

    data object RegistrationCode : MaxDestination {
        override val route = "registration/code"
        override val requiresAuthentication = false
    }

    data object ConfirmPhone : MaxDestination {
        override val route = "registration/phone"
        override val requiresAuthentication = false
    }

    data object Otp : MaxDestination {
        override val route = "registration/otp"
        override val requiresAuthentication = false
    }

    data object CreateAccount : MaxDestination {
        override val route = "registration/account"
        override val requiresAuthentication = false
    }

    data object ForgotPassword : MaxDestination {
        override val route = "password/forgot"
        override val requiresAuthentication = false
    }

    data object ResetPassword : MaxDestination {
        override val route = "password/reset"
        override val requiresAuthentication = false
    }

    data object Home : MaxDestination {
        override val route = "home"
        override val requiresAuthentication = true
    }

    data object Conversations : MaxDestination {
        override val route = "conversations"
        override val requiresAuthentication = true
    }

    data object Invoices : MaxDestination {
        override val route = "invoices"
        override val requiresAuthentication = true
    }

    data object Settings : MaxDestination {
        override val route = "settings"
        override val requiresAuthentication = true
    }

    data object RequestPart : MaxDestination {
        override val route = "request"
        override val requiresAuthentication = true
    }

    data object Notifications : MaxDestination {
        override val route = "notifications"
        override val requiresAuthentication = true
    }

    data class ConversationThread(val conversationId: String) : MaxDestination {
        init {
            require(conversationId.isNotBlank())
        }

        override val route: String = "$THREAD_PREFIX${URLEncoder.encode(conversationId, Charsets.UTF_8.name())}"
        override val requiresAuthentication = true
    }

    data class InvoiceDetails(val invoiceId: String) : MaxDestination {
        init {
            require(invoiceId.isNotBlank())
        }

        override val route: String = "$INVOICE_DETAILS_PREFIX${URLEncoder.encode(invoiceId, Charsets.UTF_8.name())}"
        override val requiresAuthentication = true
    }

    data object Profile : MaxDestination {
        override val route = "profile"
        override val requiresAuthentication = true
    }

    data object Privacy : MaxDestination {
        override val route = "profile/privacy"
        override val requiresAuthentication = true
    }

    /** Legacy push target kept only for binary/source compatibility; active navigation normalizes it to Home. */
    data object IncomingOrders : MaxDestination {
        override val route = "orders/incoming"
        override val requiresAuthentication = true
    }

    /** Legacy push target kept only for binary/source compatibility; active navigation normalizes it to Home. */
    data object OutgoingOrders : MaxDestination {
        override val route = "orders/outgoing"
        override val requiresAuthentication = true
    }

    /** Legacy push target kept only for binary/source compatibility; active navigation normalizes it to Home. */
    data object Balance : MaxDestination {
        override val route = "balance"
        override val requiresAuthentication = true
    }

    companion object {
        const val THREAD_PREFIX = "conversations/thread/"
        const val INVOICE_DETAILS_PREFIX = "invoices/details/"
    }
}

private const val LEGACY_WELCOME_ROUTE = "welcome"

object MaxNavigationGraph {
    val destinations: Set<MaxDestination> = setOf(
        MaxDestination.Login,
        MaxDestination.RegistrationCode,
        MaxDestination.Otp,
        MaxDestination.CreateAccount,
        MaxDestination.Home,
        MaxDestination.Conversations,
        MaxDestination.Invoices,
        MaxDestination.Settings,
        MaxDestination.RequestPart,
        MaxDestination.Notifications,
        MaxDestination.Profile,
        MaxDestination.Privacy,
    )

    val authenticatedRoots: List<MaxDestination> = listOf(
        MaxDestination.Home,
        MaxDestination.Conversations,
        MaxDestination.Invoices,
        MaxDestination.Settings,
    )

    // v43-v51 compatibility metadata only. MaxTab/MaxTabBackStacks own active v52 navigation.
    val homeDestinations: Set<MaxDestination> = setOf(
        MaxDestination.RequestPart,
        MaxDestination.IncomingOrders,
        MaxDestination.OutgoingOrders,
        MaxDestination.Balance,
        MaxDestination.Profile,
    )

    fun fromRoute(route: String): MaxDestination {
        if (route.startsWith(MaxDestination.THREAD_PREFIX)) {
            val encodedId = route.removePrefix(MaxDestination.THREAD_PREFIX)
            return MaxDestination.ConversationThread(URLDecoder.decode(encodedId, Charsets.UTF_8.name()))
        }
        if (route.startsWith(MaxDestination.INVOICE_DETAILS_PREFIX)) {
            val encodedId = route.removePrefix(MaxDestination.INVOICE_DETAILS_PREFIX)
            return MaxDestination.InvoiceDetails(URLDecoder.decode(encodedId, Charsets.UTF_8.name()))
        }
        return when (route) {
            LEGACY_WELCOME_ROUTE -> MaxDestination.Login
            MaxDestination.IncomingOrders.route,
            MaxDestination.OutgoingOrders.route,
            MaxDestination.Balance.route,
            LEGACY_REQUEST_SUCCESS_ROUTE,
            -> MaxDestination.Home
            else -> destinations.firstOrNull { it.route == route }
                ?: error("Unknown route: $route")
        }
    }

    init {
        require(destinations.map { it.route }.distinct().size == destinations.size) {
            "Navigation routes must be unique"
        }
    }

    private const val LEGACY_REQUEST_SUCCESS_ROUTE = "request/success"
}
