package com.maxnetwork.android.navigation

enum class MaxTab(
    val key: String,
    val label: String,
    val root: MaxDestination,
) {
    Home("home", "الرئيسية", MaxDestination.Home),
    Conversations("conversations", "المحادثات", MaxDestination.Conversations),
    Invoices("invoices", "الفواتير", MaxDestination.Invoices),
    Settings("settings", "الإعدادات", MaxDestination.Settings),
    ;

    companion object {
        val ordered: List<MaxTab> = listOf(Home, Conversations, Invoices, Settings)

        fun fromKey(key: String): MaxTab? = ordered.firstOrNull { it.key == key }

        fun fromRoot(destination: MaxDestination): MaxTab? = ordered.firstOrNull { it.root == destination }

        fun ownerOf(destination: MaxDestination): MaxTab = when (destination) {
            MaxDestination.Home,
            MaxDestination.RequestPart,
            MaxDestination.Notifications,
            MaxDestination.IncomingOrders,
            MaxDestination.OutgoingOrders,
            MaxDestination.Balance,
            -> Home

            MaxDestination.Conversations,
            is MaxDestination.ConversationThread,
            -> Conversations

            MaxDestination.Invoices,
            is MaxDestination.InvoiceDetails,
            -> Invoices

            MaxDestination.Settings,
            MaxDestination.Profile,
            MaxDestination.Privacy,
            -> Settings

            else -> Home
        }
    }
}
