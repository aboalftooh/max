package com.maxnetwork.android.navigation

class MaxTabBackStacks private constructor(
    val selectedTab: MaxTab,
    private val stacks: Map<MaxTab, MaxBackStack>,
) {
    val currentStack: MaxBackStack
        get() = requireNotNull(stacks[selectedTab])

    val current: MaxDestination
        get() = currentStack.current

    val canGoBack: Boolean
        get() = currentStack.canGoBack || selectedTab != MaxTab.Home

    fun selectTab(tab: MaxTab): MaxTabBackStacks = copyWith(selectedTab = tab)

    fun navigate(destination: MaxDestination): MaxTabBackStacks {
        val normalized = destination.activeDestination()
        MaxTab.fromRoot(normalized)?.let { return selectTab(it) }

        val owner = MaxTab.ownerOf(normalized)
        val base = if (owner == selectedTab) {
            currentStack
        } else {
            MaxBackStack.from(owner.root)
        }
        return copyWith(
            selectedTab = owner,
            stacks = stacks + (owner to base.navigate(normalized)),
        )
    }

    fun back(): MaxTabBackStacks = when {
        currentStack.canGoBack -> copyWith(stacks = stacks + (selectedTab to currentStack.back()))
        selectedTab != MaxTab.Home -> selectTab(MaxTab.Home)
        else -> this
    }

    fun saveState(): List<String> = buildList {
        add(selectedTab.key)
        MaxTab.ordered.forEach { tab ->
            stacks.getValue(tab).entries.forEach { destination ->
                add("${tab.key}$STATE_SEPARATOR${destination.route}")
            }
        }
    }

    private fun copyWith(
        selectedTab: MaxTab = this.selectedTab,
        stacks: Map<MaxTab, MaxBackStack> = this.stacks,
    ) = MaxTabBackStacks(selectedTab, stacks)

    private fun MaxDestination.activeDestination(): MaxDestination = when (this) {
        MaxDestination.IncomingOrders,
        MaxDestination.OutgoingOrders,
        MaxDestination.Balance,
        -> MaxDestination.Home
        else -> this
    }

    companion object {
        private const val STATE_SEPARATOR = "|"

        fun authenticatedRoot(): MaxTabBackStacks = MaxTabBackStacks(
            selectedTab = MaxTab.Home,
            stacks = MaxTab.ordered.associateWith { MaxBackStack.from(it.root) },
        )

        fun restoreState(state: List<String>): MaxTabBackStacks {
            val selected = state.firstOrNull()?.let(MaxTab::fromKey) ?: MaxTab.Home
            val restored = MaxTab.ordered.associateWith { tab ->
                val routes = state.drop(1)
                    .mapNotNull { encoded ->
                        val separator = encoded.indexOf(STATE_SEPARATOR)
                        if (separator <= 0) return@mapNotNull null
                        val key = encoded.substring(0, separator)
                        if (key != tab.key) return@mapNotNull null
                        runCatching { MaxNavigationGraph.fromRoute(encoded.substring(separator + 1)) }.getOrNull()
                    }
                    .map { destination ->
                        when (destination) {
                            MaxDestination.IncomingOrders,
                            MaxDestination.OutgoingOrders,
                            MaxDestination.Balance,
                            -> MaxDestination.Home
                            else -> destination
                        }
                    }
                    .filter { MaxTab.ownerOf(it) == tab || MaxTab.fromRoot(it) == tab }
                routes.fold(null as MaxBackStack?) { stack, destination ->
                    stack?.navigate(destination) ?: MaxBackStack.from(destination)
                } ?: MaxBackStack.from(tab.root)
            }
            val selectedStack = restored.getValue(selected)
            val normalized = if (selectedStack.entries.firstOrNull() == selected.root) {
                restored
            } else {
                restored + (selected to MaxBackStack.from(selected.root))
            }
            return MaxTabBackStacks(selected, normalized)
        }
    }
}
