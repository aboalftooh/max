package com.maxnetwork.android.security

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import com.maxnetwork.core.designsystem.component.MaxBannerTone
import com.maxnetwork.core.designsystem.component.MaxBrandMark
import com.maxnetwork.core.designsystem.component.MaxInlineBanner
import com.maxnetwork.core.designsystem.component.MaxPrimaryButton
import com.maxnetwork.core.designsystem.component.MaxScaffold
import com.maxnetwork.core.designsystem.component.MaxText
import com.maxnetwork.core.designsystem.theme.MaxSpacing

@Composable
fun AppLockGate(
    authenticated: Boolean,
    state: AppLockState,
    onUnlock: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    if (!authenticated || !state.enabled || !state.locked) {
        content()
        return
    }

    MaxScaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("app_lock_gate"),
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .padding(MaxSpacing.lg),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(MaxSpacing.md, Alignment.CenterVertically),
        ) {
            MaxBrandMark(modifier = Modifier.testTag("app_lock_brand"))
            MaxText(
                text = "max مقفل",
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center,
            )
            MaxText(
                text = "استخدم بصمة الجهاز أو رمز قفل الشاشة للوصول إلى المحتوى المحمي.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            if (!state.available) {
                MaxInlineBanner(
                    message = state.unavailableMessage ?: "مصادقة الجهاز غير متاحة حاليًا.",
                    tone = MaxBannerTone.Error,
                    modifier = Modifier.testTag("app_lock_error"),
                )
            } else if (state.authenticating) {
                MaxInlineBanner(
                    message = "جارٍ التحقق من الهوية…",
                    modifier = Modifier.testTag("app_lock_authenticating"),
                )
            }
            MaxPrimaryButton(
                text = "فتح التطبيق",
                onClick = onUnlock,
                enabled = state.available,
                loading = state.authenticating,
                testTag = "app_lock_unlock",
            )
        }
    }
}
