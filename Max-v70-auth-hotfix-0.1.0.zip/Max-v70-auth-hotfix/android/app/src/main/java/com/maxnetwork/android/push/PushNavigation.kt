package com.maxnetwork.android.push

import com.maxnetwork.android.navigation.MaxDestination
import com.maxnetwork.feature.notifications.domain.NotificationTarget
import com.maxnetwork.feature.notifications.domain.PushNavigationTarget

fun PushNavigationTarget.toMaxDestination(): MaxDestination = when (this) {
    PushNavigationTarget.Home,
    PushNavigationTarget.Balance,
    -> MaxDestination.Home
    PushNavigationTarget.Notifications,
    PushNavigationTarget.IncomingOrders,
    PushNavigationTarget.OutgoingOrders,
    -> MaxDestination.Notifications
}

fun NotificationTarget.toMaxDestinationOrNull(): MaxDestination? = when (this) {
    is NotificationTarget.Conversation -> MaxDestination.ConversationThread(conversationId)
    NotificationTarget.Home -> MaxDestination.Home
    is NotificationTarget.Invoice -> MaxDestination.InvoiceDetails(invoiceId)
    NotificationTarget.None -> null
}
