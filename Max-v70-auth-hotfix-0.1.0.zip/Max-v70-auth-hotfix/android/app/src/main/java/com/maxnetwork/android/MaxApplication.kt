package com.maxnetwork.android

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.maxnetwork.android.di.MaxAppContainer
import com.maxnetwork.android.di.createMaxAppContainer
import com.maxnetwork.android.push.AndroidPushNotifier

class MaxApplication : Application() {
    lateinit var appContainer: MaxAppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        initializeFirebaseIfConfigured()
        appContainer = createMaxAppContainer(this)
        bootstrapDebugAuthentication(appContainer)
        AndroidPushNotifier(this).ensureChannel()
    }

    private fun initializeFirebaseIfConfigured() {
        if (FirebaseApp.getApps(this).isNotEmpty()) return
        val values = listOf(
            BuildConfig.MAX_FIREBASE_APP_ID,
            BuildConfig.MAX_FIREBASE_PROJECT_ID,
            BuildConfig.MAX_FIREBASE_API_KEY,
            BuildConfig.MAX_FIREBASE_SENDER_ID,
        )
        if (values.any(String::isBlank)) return
        val options = FirebaseOptions.Builder()
            .setApplicationId(BuildConfig.MAX_FIREBASE_APP_ID)
            .setProjectId(BuildConfig.MAX_FIREBASE_PROJECT_ID)
            .setApiKey(BuildConfig.MAX_FIREBASE_API_KEY)
            .setGcmSenderId(BuildConfig.MAX_FIREBASE_SENDER_ID)
            .build()
        FirebaseApp.initializeApp(this, options)
    }
}
