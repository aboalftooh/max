package com.maxnetwork.android.security

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

const val APP_LOCK_BACKGROUND_THRESHOLD_MILLIS: Long = 120_000L

internal const val APP_LOCK_AUTHENTICATORS: Int =
    BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL

data class AppLockState(
    val enabled: Boolean,
    val available: Boolean,
    val locked: Boolean,
    val authenticating: Boolean = false,
    val unavailableMessage: String? = null,
)

class AppLockController(
    private val activity: FragmentActivity,
    private val store: AppLockStore,
    private val nowMillis: () -> Long = System::currentTimeMillis,
) {
    private val availability = resolveAvailability(activity)
    private val mutableState = MutableStateFlow(
        AppLockState(
            enabled = store.enabled,
            available = availability.available,
            locked = store.enabled,
            unavailableMessage = availability.message,
        ),
    )
    val state: StateFlow<AppLockState> = mutableState.asStateFlow()

    fun onBackgrounded() {
        if (store.enabled) store.lastBackgroundAtEpochMillis = nowMillis()
    }

    fun onForegrounded() {
        if (!store.enabled) return
        val backgroundAt = store.lastBackgroundAtEpochMillis ?: return
        val elapsed = (nowMillis() - backgroundAt).coerceAtLeast(0L)
        if (elapsed >= APP_LOCK_BACKGROUND_THRESHOLD_MILLIS) {
            mutableState.value = mutableState.value.copy(locked = true)
        }
    }

    fun requestEnabled(enabled: Boolean) {
        if (!enabled) {
            store.enabled = false
            store.lastBackgroundAtEpochMillis = null
            mutableState.value = mutableState.value.copy(enabled = false, locked = false, authenticating = false)
            return
        }
        if (store.enabled || !mutableState.value.available || mutableState.value.authenticating) return
        authenticate(
            title = "تفعيل قفل التطبيق",
            subtitle = "أكد هويتك باستخدام قفل الجهاز",
            onSuccess = {
                store.enabled = true
                store.lastBackgroundAtEpochMillis = null
                mutableState.value = mutableState.value.copy(enabled = true, locked = false, authenticating = false)
            },
        )
    }

    fun requestUnlock() {
        if (!store.enabled || !mutableState.value.locked || mutableState.value.authenticating) return
        authenticate(
            title = "فتح max",
            subtitle = "استخدم قفل الجهاز للمتابعة",
            onSuccess = {
                store.lastBackgroundAtEpochMillis = null
                mutableState.value = mutableState.value.copy(locked = false, authenticating = false)
            },
        )
    }

    private fun authenticate(
        title: String,
        subtitle: String,
        onSuccess: () -> Unit,
    ) {
        mutableState.value = mutableState.value.copy(authenticating = true)
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    mutableState.value = mutableState.value.copy(authenticating = false)
                }

            },
        )
        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            builder.setAllowedAuthenticators(APP_LOCK_AUTHENTICATORS)
        } else {
            @Suppress("DEPRECATION")
            builder.setDeviceCredentialAllowed(true)
        }
        prompt.authenticate(builder.build())
    }

    private data class Availability(val available: Boolean, val message: String?)

    private fun resolveAvailability(context: Context): Availability {
        val keyguardManager = context.getSystemService(KeyguardManager::class.java)
        if (keyguardManager?.isDeviceSecure != true) {
            return Availability(false, "فعّل قفل شاشة آمنًا على الجهاز أولًا")
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return Availability(true, null)
        }
        return when (BiometricManager.from(context).canAuthenticate(APP_LOCK_AUTHENTICATORS)) {
            BiometricManager.BIOMETRIC_SUCCESS -> Availability(true, null)
            else -> Availability(false, "تعذر استخدام مصادقة النظام على هذا الجهاز")
        }
    }
}
