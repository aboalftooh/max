package com.maxnetwork.android.push

import android.content.Context
import com.maxnetwork.android.BuildConfig
import com.maxnetwork.android.MaxApplication
import com.maxnetwork.core.network.GatewayResult
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.notifications.domain.PushRegistration
import com.maxnetwork.feature.notifications.domain.PushRegistrationResult
import com.maxnetwork.feature.notifications.domain.PushToken

class PushRegistrationCoordinator(
    context: Context,
) {
    private val application = context.applicationContext as MaxApplication
    private val installationStore = PushInstallationStore(application)

    suspend fun sync(rawToken: String): PushRegistrationResult? {
        val token = runCatching { PushToken(rawToken) }.getOrNull() ?: return null
        val accessToken = when (val result = application.appContainer.auth.useCases.getValidAccessToken()) {
            is AuthResult.Success -> result.value
            is AuthResult.Failure -> return null
        }
        return application.appContainer.notifications.useCases.registerPush(
            accessToken = accessToken,
            registration = PushRegistration(
                installationId = installationStore.getOrCreate(),
                token = token,
                appVersion = BuildConfig.VERSION_NAME,
            ),
        )
    }

    suspend fun markRead(notificationId: String): Boolean {
        val accessToken = when (val result = application.appContainer.auth.useCases.getValidAccessToken()) {
            is AuthResult.Success -> result.value
            is AuthResult.Failure -> return false
        }
        return application.appContainer.gateway.markNotificationReadAuthenticated(
            accessToken = accessToken,
            notificationId = notificationId,
        ) is GatewayResult.Success
    }

    suspend fun unregister(): PushRegistrationResult? {
        val accessToken = when (val result = application.appContainer.auth.useCases.getValidAccessToken()) {
            is AuthResult.Success -> result.value
            is AuthResult.Failure -> return null
        }
        return application.appContainer.notifications.useCases.unregisterPush(
            accessToken = accessToken,
            installationId = installationStore.getOrCreate(),
        )
    }
}
