package com.maxnetwork.android

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.maxnetwork.android.navigation.MaxBackStack
import com.maxnetwork.android.navigation.MaxDestination
import com.maxnetwork.android.navigation.MaxNavigationGraph
import com.maxnetwork.android.navigation.MaxTab
import com.maxnetwork.android.navigation.MaxTabBackStacks
import com.maxnetwork.android.push.PushLaunch
import com.maxnetwork.android.push.toMaxDestination
import com.maxnetwork.android.push.toMaxDestinationOrNull
import com.maxnetwork.android.session.SessionUiEvent
import com.maxnetwork.android.session.SessionViewModel
import com.maxnetwork.android.session.TrackableDeletionReceipt
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.presentation.AuthUiEvent
import com.maxnetwork.feature.auth.presentation.AuthViewModel
import com.maxnetwork.feature.auth.presentation.ConfirmPhoneScreen
import com.maxnetwork.feature.auth.presentation.ConfirmPhoneScreenActions
import com.maxnetwork.feature.auth.presentation.ConfirmPhoneUiState
import com.maxnetwork.feature.auth.presentation.CreateAccountScreen
import com.maxnetwork.feature.auth.presentation.CreateAccountScreenActions
import com.maxnetwork.feature.auth.presentation.CreateAccountUiState
import com.maxnetwork.feature.auth.presentation.ForgotPasswordScreen
import com.maxnetwork.feature.auth.presentation.ForgotPasswordScreenActions
import com.maxnetwork.feature.auth.presentation.ForgotPasswordUiState
import com.maxnetwork.feature.auth.presentation.LoginScreen
import com.maxnetwork.feature.auth.presentation.LoginScreenActions
import com.maxnetwork.feature.auth.presentation.LoginUiState
import com.maxnetwork.feature.auth.presentation.OtpScreen
import com.maxnetwork.feature.auth.presentation.OtpScreenActions
import com.maxnetwork.feature.auth.presentation.OtpUiState
import com.maxnetwork.feature.auth.presentation.RegistrationCodeScreen
import com.maxnetwork.feature.auth.presentation.RegistrationCodeScreenActions
import com.maxnetwork.feature.auth.presentation.RegistrationCodeUiState
import com.maxnetwork.feature.auth.presentation.ResetPasswordScreen
import com.maxnetwork.feature.auth.presentation.ResetPasswordScreenActions
import com.maxnetwork.feature.auth.presentation.ResetPasswordUiState
import com.maxnetwork.feature.balance.presentation.BalanceUiState
import com.maxnetwork.feature.balance.presentation.BalanceViewModel
import com.maxnetwork.feature.balance.presentation.balanceStatusLabel
import com.maxnetwork.feature.balance.presentation.movementDirectionLabel
import com.maxnetwork.feature.balance.presentation.toBalanceDate
import com.maxnetwork.feature.balance.presentation.toBalanceTime
import com.maxnetwork.feature.balance.presentation.toSdgText
import com.maxnetwork.feature.conversations.domain.ConversationId
import com.maxnetwork.feature.conversations.presentation.ConversationThreadScreen
import com.maxnetwork.feature.conversations.presentation.ConversationsScreen
import com.maxnetwork.feature.conversations.presentation.ConversationsUiState
import com.maxnetwork.feature.conversations.presentation.ConversationsViewModel
import com.maxnetwork.feature.home.presentation.HomeActions
import com.maxnetwork.feature.home.presentation.HomeFinancialTone
import com.maxnetwork.feature.home.presentation.HomeMovementUi
import com.maxnetwork.feature.home.presentation.HomeScreen
import com.maxnetwork.feature.home.presentation.HomeUiState
import com.maxnetwork.feature.home.presentation.StoreDisplayName
import com.maxnetwork.feature.invoices.domain.InvoiceId
import com.maxnetwork.feature.invoices.presentation.InvoiceDetailsScreen
import com.maxnetwork.feature.invoices.presentation.InvoicesScreen
import com.maxnetwork.feature.invoices.presentation.InvoicesUiState
import com.maxnetwork.feature.invoices.presentation.InvoicesViewModel
import com.maxnetwork.feature.notifications.domain.NotificationItem
import com.maxnetwork.feature.notifications.domain.NotificationTarget
import com.maxnetwork.feature.notifications.presentation.NotificationsScreen
import com.maxnetwork.feature.notifications.presentation.NotificationsUiState
import com.maxnetwork.feature.notifications.presentation.NotificationsViewModel
import com.maxnetwork.feature.profile.domain.SupportChannel
import com.maxnetwork.feature.profile.presentation.PrivacyScreen
import com.maxnetwork.feature.profile.presentation.ProfileActions
import com.maxnetwork.feature.profile.presentation.ProfileScreen
import com.maxnetwork.feature.profile.presentation.ProfileUiEvent
import com.maxnetwork.feature.profile.presentation.ProfileUiState
import com.maxnetwork.feature.profile.presentation.ProfileViewModel
import com.maxnetwork.feature.request.media.ImageImportFailure
import com.maxnetwork.feature.request.media.RequestAudioFailure
import com.maxnetwork.feature.request.presentation.RequestPartActions
import com.maxnetwork.feature.request.presentation.RequestPartScreen
import com.maxnetwork.feature.request.presentation.RequestPartUiState
import com.maxnetwork.feature.request.presentation.RequestUiEvent
import com.maxnetwork.feature.request.presentation.RequestViewModel
import com.maxnetwork.feature.settings.presentation.SettingsActions
import com.maxnetwork.feature.settings.presentation.SettingsScreen
import com.maxnetwork.feature.settings.presentation.SettingsUiState
import com.maxnetwork.core.designsystem.MaxIcons
import com.maxnetwork.core.designsystem.component.MaxBottomNavigation
import com.maxnetwork.core.designsystem.component.MaxBottomNavigationItem
import com.maxnetwork.core.designsystem.component.MaxBottomNavigationPrimaryAction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.launch

@Composable
fun MaxAppRoute(
    authViewModel: AuthViewModel,
    balanceViewModel: BalanceViewModel,
    profileViewModel: ProfileViewModel,
    sessionViewModel: SessionViewModel,
    requestViewModel: RequestViewModel,
    settingsUiState: SettingsUiState = SettingsUiState(),
    onAppLockChanged: (Boolean) -> Unit = {},
    pushLaunch: PushLaunch? = null,
    onPushLaunchConsumed: () -> Unit = {},
    onAuthenticated: () -> Unit = {},
    onOpenSupport: (SupportChannel) -> Unit,
    onDeletionAccepted: (TrackableDeletionReceipt) -> Unit,
    onSupportUnavailable: () -> Unit,
    onAuthSupport: () -> Unit,
) {
    val authState by authViewModel.authState.collectAsStateWithLifecycle()
    val balanceUiState by balanceViewModel.state.collectAsStateWithLifecycle()
    val loginUiState by authViewModel.loginUiState.collectAsStateWithLifecycle()
    val registrationCodeUiState by authViewModel.registrationCodeUiState.collectAsStateWithLifecycle()
    val confirmPhoneUiState by authViewModel.confirmPhoneUiState.collectAsStateWithLifecycle()
    val otpUiState by authViewModel.otpUiState.collectAsStateWithLifecycle()
    val createAccountUiState by authViewModel.createAccountUiState.collectAsStateWithLifecycle()
    val forgotPasswordUiState by authViewModel.forgotPasswordUiState.collectAsStateWithLifecycle()
    val resetPasswordUiState by authViewModel.resetPasswordUiState.collectAsStateWithLifecycle()
    val profileUiState by profileViewModel.state.collectAsStateWithLifecycle()
    val requestUiState by requestViewModel.state.collectAsStateWithLifecycle()
    val localContext = LocalContext.current
    val maxApplication = localContext.applicationContext as MaxApplication
    val conversationsViewModel = remember(localContext) {
        val owner = requireNotNull(localContext as? ViewModelStoreOwner) { "Activity must own conversation ViewModel" }
        val useCases = maxApplication.appContainer.conversations.useCases
        val factory = viewModelFactory {
            initializer {
                ConversationsViewModel(
                    loadList = useCases.loadList,
                    loadThread = useCases.loadThread,
                    markRead = useCases.markRead,
                )
            }
        }
        ViewModelProvider(owner, factory)["max-conversations", ConversationsViewModel::class.java]
    }
    val conversationsUiState by conversationsViewModel.state.collectAsStateWithLifecycle()
    val owner = requireNotNull(localContext as? ViewModelStoreOwner) { "Activity must own feature ViewModels" }
    val invoicesViewModel = remember(localContext) {
        val useCases = maxApplication.appContainer.invoices.useCases
        val factory = viewModelFactory {
            initializer {
                InvoicesViewModel(
                    loadPage = useCases.loadPage,
                    loadInvoiceDetails = useCases.loadDetails,
                )
            }
        }
        ViewModelProvider(owner, factory)["max-invoices", InvoicesViewModel::class.java]
    }
    val invoicesUiState by invoicesViewModel.state.collectAsStateWithLifecycle()
    val notificationsViewModel = remember(maxApplication) {
        val useCases = maxApplication.appContainer.notifications.useCases
        NotificationsViewModel(
            loadPage = useCases.loadPage,
            markRead = useCases.markRead,
        )
    }
    val notificationsUiState = notificationsViewModel.state
    val coroutineScope = rememberCoroutineScope()
    val authenticated = authState is AuthState.Authenticated

    LaunchedEffect(authenticated) {
        if (authenticated) {
            profileViewModel.load()
            balanceViewModel.refresh()
            conversationsViewModel.start()
            notificationsViewModel.start()
            onAuthenticated()
        } else {
            profileViewModel.clear()
            balanceViewModel.clear()
            conversationsViewModel.clear()
            invoicesViewModel.clear()
            notificationsViewModel.clear()
        }
    }
    LaunchedEffect(profileViewModel.events) {
        profileViewModel.events.collect { event ->
            when (event) {
                is ProfileUiEvent.OpenSupport -> onOpenSupport(event.channel)
                ProfileUiEvent.SupportUnavailable -> onSupportUnavailable()
            }
        }
    }
    LaunchedEffect(sessionViewModel.events) {
        sessionViewModel.events.collect { event ->
            authViewModel.clearSensitiveUiState()
            when (event) {
                is SessionUiEvent.DeletionAccepted -> onDeletionAccepted(event.receipt)
                SessionUiEvent.LoggedOut -> Unit
            }
        }
    }

    val notificationNavigationEvents = remember { kotlinx.coroutines.flow.MutableSharedFlow<NotificationTarget>() }

    MaxApp(
        authState = authState,
        loginUiState = loginUiState,
        balanceUiState = balanceUiState,
        registrationCodeUiState = registrationCodeUiState,
        confirmPhoneUiState = confirmPhoneUiState,
        otpUiState = otpUiState,
        createAccountUiState = createAccountUiState,
        forgotPasswordUiState = forgotPasswordUiState,
        resetPasswordUiState = resetPasswordUiState,
        profileUiState = profileUiState,
        settingsUiState = settingsUiState,
        requestUiState = requestUiState,
        conversationsUiState = conversationsUiState,
        invoicesUiState = invoicesUiState,
        notificationsUiState = notificationsUiState,
        requestImageManager = (androidx.compose.ui.platform.LocalContext.current.applicationContext as MaxApplication)
            .appContainer.request.imageManager,
        requestAudioControllerFactory = (androidx.compose.ui.platform.LocalContext.current.applicationContext as MaxApplication)
            .appContainer.request.audioControllerFactory,
        events = authViewModel.events,
        requestEvents = requestViewModel.events,
        notificationNavigationEvents = notificationNavigationEvents,
        pushLaunch = pushLaunch,
        onPushLaunchConsumed = onPushLaunchConsumed,
        actions = MaxAppActions(
            onPhoneChanged = authViewModel::onPhoneChanged,
            onSubmitLogin = authViewModel::submitLogin,
            onRegistrationCodeChanged = authViewModel::onRegistrationCodeChanged,
            onSubmitRegistrationCode = authViewModel::submitRegistrationCode,
            onRegistrationPhoneChanged = authViewModel::onRegistrationPhoneChanged,
            onSubmitRegistrationPhone = authViewModel::submitRegistrationPhone,
            onOtpChanged = authViewModel::onOtpChanged,
            onSubmitOtp = authViewModel::submitOtp,
            onResendOtp = authViewModel::resendOtp,
            onAccountNameChanged = authViewModel::onAccountNameChanged,
            onStoreNameChanged = authViewModel::onStoreNameChanged,
            onAccountPasswordChanged = authViewModel::onAccountPasswordChanged,
            onAccountPasswordConfirmationChanged = authViewModel::onAccountPasswordConfirmationChanged,
            onToggleAccountPasswordVisibility = authViewModel::toggleAccountPasswordVisibility,
            onSubmitCreateAccount = authViewModel::submitCreateAccount,
            onForgotPasswordPhoneChanged = authViewModel::onForgotPasswordPhoneChanged,
            onSubmitPasswordResetRequest = authViewModel::submitPasswordResetRequest,
            onResetCodeChanged = authViewModel::onResetCodeChanged,
            onResetNewPasswordChanged = authViewModel::onResetNewPasswordChanged,
            onResetPasswordConfirmationChanged = authViewModel::onResetPasswordConfirmationChanged,
            onToggleResetPasswordVisibility = authViewModel::toggleResetPasswordVisibility,
            onSubmitPasswordReset = authViewModel::submitPasswordReset,
            onResendPasswordReset = authViewModel::resendPasswordResetCode,
            onClearPasswordReset = authViewModel::clearPasswordReset,
            onClearRegistration = authViewModel::clearRegistration,
            onContactSupport = onAuthSupport,
            onRequestTextChanged = requestViewModel::onTextChanged,
            onRequestImageChanged = { requestViewModel.onImageChanged(it) },
            onRequestAudioChanged = { requestViewModel.onAudioChanged(it) },
            onRequestImageFailure = { requestViewModel.markSubmissionFailed(it.toUserMessage()) },
            onRequestAudioFailure = { requestViewModel.markSubmissionFailed(it.toUserMessage()) },
            onRequestSubmit = requestViewModel::submit,
            onRequestRetry = requestViewModel::retry,
            onAcceptedRequestConsumed = requestViewModel::consumeAcceptedRequest,
            onConversationsStart = conversationsViewModel::start,
            onConversationsRetry = conversationsViewModel::refreshList,
            onConversationOpen = { conversationsViewModel.openConversation(ConversationId(it)) },
            onConversationRetry = conversationsViewModel::retryThread,
            onNotificationsRetry = { coroutineScope.launch { notificationsViewModel.refresh() } },
            onNotificationsLoadMore = { coroutineScope.launch { notificationsViewModel.loadMore() } },
            onNotificationOpen = { item ->
                coroutineScope.launch {
                    notificationsViewModel.markReadAndResolve(item)?.let { target ->
                        notificationNavigationEvents.emit(target)
                    }
                }
            },
            onInvoicesStart = invoicesViewModel::start,
            onInvoiceSearchTextChanged = invoicesViewModel::onSearchTextChanged,
            onInvoiceSearch = invoicesViewModel::submitSearch,
            onInvoicesRetry = invoicesViewModel::retry,
            onInvoicesLoadMore = invoicesViewModel::loadMore,
            onInvoiceOpen = { invoicesViewModel.loadDetails(InvoiceId(it)) },
            onInvoiceRetry = { invoicesViewModel.retryDetails(InvoiceId(it)) },
            onProfileRetry = profileViewModel::retry,
            onProfileContact = profileViewModel::openSupport,
            onShowPasswordChange = profileViewModel::showPasswordChange,
            onCurrentPasswordChanged = profileViewModel::onCurrentPasswordChanged,
            onNewProfilePasswordChanged = profileViewModel::onNewPasswordChanged,
            onProfilePasswordConfirmationChanged = profileViewModel::onPasswordConfirmationChanged,
            onSubmitProfilePasswordChange = profileViewModel::submitPasswordChange,
            onDismissProfilePasswordChange = profileViewModel::dismissPasswordChange,
            onAppLockChanged = onAppLockChanged,
            onLogout = {
                authViewModel.clearSensitiveUiState()
                sessionViewModel.logout()
            },
        ),
    )
}

data class MaxAppActions(
    val onPhoneChanged: (String) -> Unit,
    val onSubmitLogin: () -> Unit,
    val onRegistrationCodeChanged: (String) -> Unit = {},
    val onSubmitRegistrationCode: () -> Unit = {},
    val onRegistrationPhoneChanged: (String) -> Unit = {},
    val onSubmitRegistrationPhone: () -> Unit = {},
    val onOtpChanged: (String) -> Unit = {},
    val onSubmitOtp: () -> Unit = {},
    val onResendOtp: () -> Unit = {},
    val onAccountNameChanged: (String) -> Unit = {},
    val onStoreNameChanged: (String) -> Unit = {},
    val onAccountPasswordChanged: (String) -> Unit = {},
    val onAccountPasswordConfirmationChanged: (String) -> Unit = {},
    val onToggleAccountPasswordVisibility: () -> Unit = {},
    val onSubmitCreateAccount: () -> Unit = {},
    val onForgotPasswordPhoneChanged: (String) -> Unit = {},
    val onSubmitPasswordResetRequest: () -> Unit = {},
    val onResetCodeChanged: (String) -> Unit = {},
    val onResetNewPasswordChanged: (String) -> Unit = {},
    val onResetPasswordConfirmationChanged: (String) -> Unit = {},
    val onToggleResetPasswordVisibility: () -> Unit = {},
    val onSubmitPasswordReset: () -> Unit = {},
    val onResendPasswordReset: () -> Unit = {},
    val onClearPasswordReset: () -> Unit = {},
    val onClearRegistration: () -> Unit = {},
    val onContactSupport: () -> Unit = {},
    val onRequestTextChanged: (String) -> Unit = {},
    val onRequestImageChanged: suspend (com.maxnetwork.feature.request.domain.RequestAttachmentRef?) -> Unit = {},
    val onRequestAudioChanged: suspend (com.maxnetwork.feature.request.domain.RequestAttachmentRef?) -> Unit = {},
    val onRequestImageFailure: (ImageImportFailure) -> Unit = {},
    val onRequestAudioFailure: (RequestAudioFailure) -> Unit = {},
    val onRequestSubmit: () -> Unit = {},
    val onRequestRetry: () -> Unit = {},
    val onAcceptedRequestConsumed: () -> Unit = {},
    val onConversationsStart: () -> Unit = {},
    val onConversationsRetry: () -> Unit = {},
    val onConversationOpen: (String) -> Unit = {},
    val onConversationRetry: () -> Unit = {},
    val onNotificationsRetry: () -> Unit = {},
    val onNotificationsLoadMore: () -> Unit = {},
    val onNotificationOpen: (NotificationItem) -> Unit = {},
    val onInvoicesStart: () -> Unit = {},
    val onInvoiceSearchTextChanged: (String) -> Unit = {},
    val onInvoiceSearch: () -> Unit = {},
    val onInvoicesRetry: () -> Unit = {},
    val onInvoicesLoadMore: () -> Unit = {},
    val onInvoiceOpen: (String) -> Unit = {},
    val onInvoiceRetry: (String) -> Unit = {},
    val onProfileRetry: () -> Unit = {},
    val onProfileContact: () -> Unit = {},
    val onShowPasswordChange: () -> Unit = {},
    val onCurrentPasswordChanged: (String) -> Unit = {},
    val onNewProfilePasswordChanged: (String) -> Unit = {},
    val onProfilePasswordConfirmationChanged: (String) -> Unit = {},
    val onSubmitProfilePasswordChange: () -> Unit = {},
    val onDismissProfilePasswordChange: () -> Unit = {},
    val onAppLockChanged: (Boolean) -> Unit = {},
    val onLogout: () -> Unit = {},
)

private val BackStackSaver = Saver<MaxBackStack, List<String>>(
    save = { stack -> stack.entries.map { it.route } },
    restore = { routes ->
        routes.map(MaxNavigationGraph::fromRoute)
            .fold(null as MaxBackStack?) { stack, destination ->
                stack?.navigate(destination) ?: MaxBackStack.from(destination)
            }
    },
)

private val TabBackStacksSaver = Saver<MaxTabBackStacks, List<String>>(
    save = { stacks -> stacks.saveState() },
    restore = { state -> MaxTabBackStacks.restoreState(state) },
)

@Composable
@Suppress("LongParameterList")
fun MaxApp(
    authState: AuthState,
    loginUiState: LoginUiState,
    balanceUiState: BalanceUiState = BalanceUiState(),
    registrationCodeUiState: RegistrationCodeUiState = RegistrationCodeUiState(),
    confirmPhoneUiState: ConfirmPhoneUiState = ConfirmPhoneUiState(),
    otpUiState: OtpUiState = OtpUiState(),
    createAccountUiState: CreateAccountUiState = CreateAccountUiState(),
    forgotPasswordUiState: ForgotPasswordUiState = ForgotPasswordUiState(),
    resetPasswordUiState: ResetPasswordUiState = ResetPasswordUiState(),
    profileUiState: ProfileUiState = ProfileUiState(),
    settingsUiState: SettingsUiState = SettingsUiState(),
    requestUiState: RequestPartUiState = RequestPartUiState(),
    conversationsUiState: ConversationsUiState = ConversationsUiState(),
    invoicesUiState: InvoicesUiState = InvoicesUiState(),
    notificationsUiState: NotificationsUiState = NotificationsUiState(),
    requestImageManager: com.maxnetwork.feature.request.media.RequestImageManager? = null,
    requestAudioControllerFactory: com.maxnetwork.feature.request.media.RequestAudioControllerFactory? = null,
    events: Flow<AuthUiEvent> = emptyFlow(),
    requestEvents: Flow<RequestUiEvent> = emptyFlow(),
    notificationNavigationEvents: Flow<NotificationTarget> = emptyFlow(),
    pushLaunch: PushLaunch? = null,
    onPushLaunchConsumed: () -> Unit = {},
    actions: MaxAppActions,
    modifier: Modifier = Modifier,
) {
    val authenticated = authState is AuthState.Authenticated
    var signedOutBackStack by rememberSaveable(stateSaver = BackStackSaver) {
        mutableStateOf(MaxBackStack.signedOutRoot())
    }
    var tabBackStacks by rememberSaveable(stateSaver = TabBackStacksSaver) {
        mutableStateOf(MaxTabBackStacks.authenticatedRoot())
    }

    LaunchedEffect(authenticated) {
        if (!authenticated) signedOutBackStack = MaxBackStack.signedOutRoot()
    }

    LaunchedEffect(authenticated, pushLaunch, notificationsUiState.loaded, notificationsUiState.items) {
        if (authenticated && pushLaunch != null && notificationsUiState.loaded) {
            val typedTarget = notificationsUiState.items
                .firstOrNull { it.id.value == pushLaunch.notificationId }
                ?.target
                ?.toMaxDestinationOrNull()
            val destination = typedTarget ?: pushLaunch.target.toMaxDestination()
            tabBackStacks = MaxTabBackStacks.authenticatedRoot().navigate(destination)
            onPushLaunchConsumed()
        }
    }
    LaunchedEffect(events) {
        events.collect { event ->
            when (event) {
                AuthUiEvent.Authenticated -> tabBackStacks = MaxTabBackStacks.authenticatedRoot()
                AuthUiEvent.RegistrationCodeAccepted -> signedOutBackStack = signedOutBackStack.navigate(MaxDestination.CreateAccount)
                AuthUiEvent.PhoneChallengeSent -> signedOutBackStack = signedOutBackStack.navigate(MaxDestination.Otp)
                AuthUiEvent.OtpVerified,
                AuthUiEvent.NewUserOtpVerified -> signedOutBackStack = signedOutBackStack.navigate(MaxDestination.RegistrationCode)
                AuthUiEvent.PasswordResetCodeSent -> signedOutBackStack = signedOutBackStack.navigate(MaxDestination.ResetPassword)
                AuthUiEvent.PasswordResetCompleted -> signedOutBackStack = MaxBackStack.from(MaxDestination.Login)
                AuthUiEvent.ContactSupportRequested -> Unit
            }
        }
    }
    LaunchedEffect(requestEvents) {
        requestEvents.collect { event ->
            when (event) {
                is RequestUiEvent.Accepted -> {
                    actions.onAcceptedRequestConsumed()
                    tabBackStacks = tabBackStacks.navigate(MaxDestination.ConversationThread(event.conversationId))
                }
            }
        }
    }
    LaunchedEffect(notificationNavigationEvents) {
        notificationNavigationEvents.collect { target ->
            when (val destination = target.toMaxDestinationOrNull()) {
                null -> Unit
                else -> tabBackStacks = tabBackStacks.navigate(destination)
            }
        }
    }

    val activeBackStack = if (authenticated) tabBackStacks.currentStack else signedOutBackStack
    BackHandler(enabled = activeBackStack.canGoBack) {
        if (authenticated) {
            tabBackStacks = tabBackStacks.back()
        } else {
            signedOutBackStack = signedOutBackStack.back()
        }
    }

    MaxAppContent(
        destination = activeBackStack.current,
        authenticated = authenticated,
        selectedTab = tabBackStacks.selectedTab,
        loginUiState = loginUiState,
        balanceUiState = balanceUiState,
        registrationCodeUiState = registrationCodeUiState,
        confirmPhoneUiState = confirmPhoneUiState,
        otpUiState = otpUiState,
        createAccountUiState = createAccountUiState,
        forgotPasswordUiState = forgotPasswordUiState,
        resetPasswordUiState = resetPasswordUiState,
        profileUiState = profileUiState,
        settingsUiState = settingsUiState,
        requestUiState = requestUiState,
        conversationsUiState = conversationsUiState,
        invoicesUiState = invoicesUiState,
        notificationsUiState = notificationsUiState,
        requestImageManager = requestImageManager,
        requestAudioControllerFactory = requestAudioControllerFactory,
        actions = actions,
        navigate = { destination ->
            if (authenticated) {
                tabBackStacks = tabBackStacks.navigate(destination)
            } else {
                signedOutBackStack = signedOutBackStack.navigate(destination)
            }
        },
        back = {
            if (authenticated) {
                tabBackStacks = tabBackStacks.back()
            } else {
                signedOutBackStack = signedOutBackStack.back()
            }
        },
        onTabSelected = { tabBackStacks = tabBackStacks.selectTab(it) },
        modifier = modifier,
    )
}

@Composable
@Suppress("LongMethod", "LongParameterList")
private fun MaxAppContent(
    destination: MaxDestination,
    authenticated: Boolean,
    selectedTab: MaxTab,
    loginUiState: LoginUiState,
    balanceUiState: BalanceUiState,
    registrationCodeUiState: RegistrationCodeUiState,
    confirmPhoneUiState: ConfirmPhoneUiState,
    otpUiState: OtpUiState,
    createAccountUiState: CreateAccountUiState,
    forgotPasswordUiState: ForgotPasswordUiState,
    resetPasswordUiState: ResetPasswordUiState,
    profileUiState: ProfileUiState,
    settingsUiState: SettingsUiState,
    requestUiState: RequestPartUiState,
    conversationsUiState: ConversationsUiState,
    invoicesUiState: InvoicesUiState,
    notificationsUiState: NotificationsUiState,
    requestImageManager: com.maxnetwork.feature.request.media.RequestImageManager?,
    requestAudioControllerFactory: com.maxnetwork.feature.request.media.RequestAudioControllerFactory?,
    actions: MaxAppActions,
    navigate: (MaxDestination) -> Unit,
    back: () -> Unit,
    onTabSelected: (MaxTab) -> Unit,
    modifier: Modifier,
) {
    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("max_app_root"),
        color = MaterialTheme.colorScheme.background,
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.weight(1f)) {
                when (destination) {
            MaxDestination.Login -> LoginScreen(
                state = loginUiState,
                actions = LoginScreenActions(
                    onPhoneChanged = actions.onPhoneChanged,
                    onSubmit = actions.onSubmitLogin,
                ),
            )

            MaxDestination.RegistrationCode -> RegistrationCodeScreen(
                state = registrationCodeUiState,
                actions = RegistrationCodeScreenActions(
                    onCodeChanged = actions.onRegistrationCodeChanged,
                    onSubmit = actions.onSubmitRegistrationCode,
                    onContactMax = actions.onContactSupport,
                    onBack = {
                        actions.onClearRegistration()
                        back()
                    },
                ),
            )

            MaxDestination.ConfirmPhone -> ConfirmPhoneScreen(
                state = confirmPhoneUiState,
                actions = ConfirmPhoneScreenActions(
                    onPhoneChanged = actions.onRegistrationPhoneChanged,
                    onSubmit = actions.onSubmitRegistrationPhone,
                    onContactMax = actions.onContactSupport,
                    onBack = {
                        actions.onClearRegistration()
                        back()
                    },
                ),
            )

            MaxDestination.Otp -> OtpScreen(
                state = otpUiState,
                actions = OtpScreenActions(
                    onOtpChanged = actions.onOtpChanged,
                    onSubmit = actions.onSubmitOtp,
                    onResend = actions.onResendOtp,
                    onBack = {
                        actions.onClearRegistration()
                        back()
                    },
                ),
            )

            MaxDestination.CreateAccount -> CreateAccountScreen(
                state = createAccountUiState,
                actions = CreateAccountScreenActions(
                    onNameChanged = actions.onAccountNameChanged,
                    onStoreNameChanged = actions.onStoreNameChanged,
                    onPasswordChanged = actions.onAccountPasswordChanged,
                    onPasswordConfirmationChanged = actions.onAccountPasswordConfirmationChanged,
                    onTogglePasswordVisibility = actions.onToggleAccountPasswordVisibility,
                    onSubmit = actions.onSubmitCreateAccount,
                    onBack = {
                        actions.onClearRegistration()
                        back()
                    },
                ),
            )

            MaxDestination.ForgotPassword -> ForgotPasswordScreen(
                state = forgotPasswordUiState,
                actions = ForgotPasswordScreenActions(
                    onPhoneChanged = actions.onForgotPasswordPhoneChanged,
                    onSubmit = actions.onSubmitPasswordResetRequest,
                    onBack = {
                        actions.onClearPasswordReset()
                        back()
                    },
                ),
            )

            MaxDestination.ResetPassword -> ResetPasswordScreen(
                state = resetPasswordUiState,
                actions = ResetPasswordScreenActions(
                    onCodeChanged = actions.onResetCodeChanged,
                    onNewPasswordChanged = actions.onResetNewPasswordChanged,
                    onConfirmationChanged = actions.onResetPasswordConfirmationChanged,
                    onTogglePasswordVisibility = actions.onToggleResetPasswordVisibility,
                    onSubmit = actions.onSubmitPasswordReset,
                    onResend = actions.onResendPasswordReset,
                    onBack = {
                        actions.onClearPasswordReset()
                        back()
                    },
                ),
            )

            MaxDestination.Home -> HomeScreen(
                state = balanceUiState.toHomeUiState(
                    storeName = profileUiState.snapshot?.profile?.storeName?.let(::StoreDisplayName),
                    unreadNotifications = notificationsUiState.unreadCount,
                ),
                actions = HomeActions(
                    onRequestPart = { navigate(MaxDestination.RequestPart) },
                    onNotifications = { navigate(MaxDestination.Notifications) },
                ),
            )

            MaxDestination.RequestPart -> RequestPartScreen(
                state = requestUiState,
                imageManager = requestImageManager,
                audioControllerFactory = requestAudioControllerFactory,
                actions = RequestPartActions(
                    onTextChanged = actions.onRequestTextChanged,
                    onImageChanged = actions.onRequestImageChanged,
                    onAudioChanged = actions.onRequestAudioChanged,
                    onImageFailure = actions.onRequestImageFailure,
                    onAudioFailure = actions.onRequestAudioFailure,
                    onSubmit = actions.onRequestSubmit,
                    onRetry = actions.onRequestRetry,
                    onBack = back,
                ),
            )
            MaxDestination.Conversations -> {
                LaunchedEffect(Unit) { actions.onConversationsStart() }
                ConversationsScreen(
                    state = conversationsUiState.list,
                    onOpenConversation = { navigate(MaxDestination.ConversationThread(it.value)) },
                    onRetry = actions.onConversationsRetry,
                    onBack = back,
                )
            }
            MaxDestination.Invoices -> {
                LaunchedEffect(Unit) { actions.onInvoicesStart() }
                InvoicesScreen(
                    state = invoicesUiState,
                    onSearchTextChanged = actions.onInvoiceSearchTextChanged,
                    onSearch = actions.onInvoiceSearch,
                    onInvoiceClick = { navigate(MaxDestination.InvoiceDetails(it.value)) },
                    onRetry = actions.onInvoicesRetry,
                    onLoadMore = actions.onInvoicesLoadMore,
                    onBack = back,
                )
            }
            MaxDestination.Notifications -> NotificationsScreen(
                state = notificationsUiState,
                onNotificationClick = actions.onNotificationOpen,
                onRetry = actions.onNotificationsRetry,
                onLoadMore = actions.onNotificationsLoadMore,
                onBack = back,
            )
            is MaxDestination.ConversationThread -> {
                LaunchedEffect(destination.conversationId) {
                    actions.onConversationOpen(destination.conversationId)
                }
                ConversationThreadScreen(
                    state = conversationsUiState.thread,
                    onBack = back,
                    onRetry = actions.onConversationRetry,
                )
            }
            MaxDestination.IncomingOrders,
            MaxDestination.OutgoingOrders,
            MaxDestination.Balance,
            -> error("Legacy root destinations must be normalized to Home before rendering")
            is MaxDestination.InvoiceDetails -> {
                LaunchedEffect(destination.invoiceId) { actions.onInvoiceOpen(destination.invoiceId) }
                InvoiceDetailsScreen(
                    state = invoicesUiState,
                    onBack = back,
                    onRetry = { actions.onInvoiceRetry(destination.invoiceId) },
                )
            }
            MaxDestination.Settings -> SettingsScreen(
                state = settingsUiState,
                actions = SettingsActions(
                    onBack = back,
                    onProfile = { navigate(MaxDestination.Profile) },
                    onAppLockChanged = actions.onAppLockChanged,
                    onPrivacy = { navigate(MaxDestination.Privacy) },
                    onSupport = actions.onProfileContact,
                    onLogout = actions.onLogout,
                ),
            )
            MaxDestination.Profile -> ProfileScreen(
                state = profileUiState,
                actions = ProfileActions(
                    onBack = back,
                    onRetry = actions.onProfileRetry,
                    onChangePassword = actions.onShowPasswordChange,
                    onCurrentPasswordChanged = actions.onCurrentPasswordChanged,
                    onNewPasswordChanged = actions.onNewProfilePasswordChanged,
                    onPasswordConfirmationChanged = actions.onProfilePasswordConfirmationChanged,
                    onSubmitPasswordChange = actions.onSubmitProfilePasswordChange,
                    onDismissPasswordChange = actions.onDismissProfilePasswordChange,
                ),
            )
            MaxDestination.Privacy -> PrivacyScreen(onBack = back)
                }
            }

            if (authenticated && MaxTab.fromRoot(destination) != null) {
                MaxBottomNavigation(
                    items = listOf(
                        MaxBottomNavigationItem(MaxTab.Home.key, MaxTab.Home.label, MaxIcons.Home),
                        MaxBottomNavigationItem(
                            MaxTab.Conversations.key,
                            MaxTab.Conversations.label,
                            MaxIcons.Conversations,
                        ),
                        MaxBottomNavigationItem(MaxTab.Invoices.key, MaxTab.Invoices.label, MaxIcons.Invoices),
                        MaxBottomNavigationItem(MaxTab.Settings.key, MaxTab.Settings.label, MaxIcons.Settings),
                    ),
                    selectedKey = selectedTab.key,
                    onSelected = { key -> MaxTab.fromKey(key)?.let(onTabSelected) },
                    primaryAction = MaxBottomNavigationPrimaryAction(
                        icon = MaxIcons.Add,
                        contentDescription = "طلب جديد",
                    ),
                    onPrimaryAction = { navigate(MaxDestination.RequestPart) },
                )
            }
        }
    }
}

private fun BalanceUiState.toHomeUiState(
    storeName: StoreDisplayName?,
    unreadNotifications: Int,
): HomeUiState {
    val currentBalance = balance
    val tone = currentBalance?.minorUnits.toHomeFinancialTone()
    return HomeUiState(
        storeName = storeName,
        balanceAmount = currentBalance?.toSdgText(),
        balanceStatus = currentBalance?.balanceStatusLabel() ?: "الرصيد",
        balanceTone = tone,
        movements = movements.map { movement ->
            HomeMovementUi(
                id = movement.id.value,
                label = movement.delta.movementDirectionLabel(),
                amount = movement.amount.toSdgText(includeSign = false),
                date = movement.occurredAt.toBalanceDate(),
                time = movement.occurredAt.toBalanceTime(),
                tone = movement.delta.minorUnits.toHomeFinancialTone(),
            )
        },
        unreadNotifications = unreadNotifications,
        balanceLoading = initialLoading,
        balanceErrorMessage = errorMessage,
    )
}

private fun Long?.toHomeFinancialTone(): HomeFinancialTone = when {
    this == null || this == 0L -> HomeFinancialTone.Neutral
    this > 0L -> HomeFinancialTone.Positive
    else -> HomeFinancialTone.Negative
}

private fun ImageImportFailure.toUserMessage(): String = when (this) {
    ImageImportFailure.Cancelled -> "لم يتم اختيار صورة."
    ImageImportFailure.PermissionLost -> "تعذر الوصول إلى الصورة. اخترها مرة أخرى."
    ImageImportFailure.NotEnoughSpace -> "لا توجد مساحة كافية لحفظ الصورة."
    ImageImportFailure.UnsupportedImage -> "صيغة الصورة غير مدعومة."
    ImageImportFailure.TooLarge -> "حجم الصورة أكبر من المسموح."
    ImageImportFailure.ReadFailed -> "تعذر قراءة الصورة."
    ImageImportFailure.WriteFailed -> "تعذر حفظ الصورة."
}

private fun RequestAudioFailure.toUserMessage(): String = when (this) {
    RequestAudioFailure.PermissionDenied -> "اسمح بالميكروفون لتسجيل رسالة صوتية."
    RequestAudioFailure.RecorderUnavailable -> "تعذر بدء التسجيل."
    RequestAudioFailure.RecordingTooShort -> "التسجيل قصير جدًا."
    RequestAudioFailure.RecordingTooLong -> "تجاوز التسجيل 60 ثانية."
    RequestAudioFailure.FileTooLarge -> "حجم التسجيل أكبر من المسموح."
    RequestAudioFailure.FileMissing -> "ملف التسجيل غير موجود."
    RequestAudioFailure.PlaybackUnavailable -> "تعذر تشغيل التسجيل."
    RequestAudioFailure.Interrupted -> "توقف التسجيل بسبب مقاطعة."
}
