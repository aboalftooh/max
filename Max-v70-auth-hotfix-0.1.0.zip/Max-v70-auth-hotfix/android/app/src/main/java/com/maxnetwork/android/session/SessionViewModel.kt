package com.maxnetwork.android.session

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

enum class DeletionConfirmationStep {
    None,
    First,
    Final,
}

data class SessionUiState(
    val deletionStep: DeletionConfirmationStep = DeletionConfirmationStep.None,
    val deleting: Boolean = false,
    val deletionError: SessionFailure? = null,
    val loggingOut: Boolean = false,
)

sealed interface SessionUiEvent {
    data class DeletionAccepted(val receipt: TrackableDeletionReceipt) : SessionUiEvent
    data object LoggedOut : SessionUiEvent
}

class SessionViewModel(
    private val coordinator: SessionCoordinator,
) : ViewModel() {
    private val mutableState = MutableStateFlow(SessionUiState())
    val state: StateFlow<SessionUiState> = mutableState.asStateFlow()

    private val eventChannel = Channel<SessionUiEvent>(capacity = Channel.BUFFERED)
    val events = eventChannel.receiveAsFlow()

    fun beginDeletion() {
        if (mutableState.value.deleting) return
        mutableState.value = SessionUiState(deletionStep = DeletionConfirmationStep.First)
    }

    fun continueDeletion() {
        if (mutableState.value.deletionStep != DeletionConfirmationStep.First) return
        mutableState.value = SessionUiState(deletionStep = DeletionConfirmationStep.Final)
    }

    fun cancelDeletion() {
        if (mutableState.value.deleting) return
        mutableState.value = SessionUiState()
    }

    fun confirmDeletion() {
        val current = mutableState.value
        if (current.deletionStep != DeletionConfirmationStep.Final || current.deleting) return
        mutableState.value = current.copy(deleting = true, deletionError = null)
        viewModelScope.launch {
            when (val result = coordinator.deleteAccount()) {
                is DeletionSubmission.Accepted -> {
                    mutableState.value = SessionUiState()
                    eventChannel.send(SessionUiEvent.DeletionAccepted(result.receipt))
                }
                is DeletionSubmission.Failed -> {
                    mutableState.value = SessionUiState(
                        deletionStep = DeletionConfirmationStep.Final,
                        deletionError = result.reason,
                    )
                }
            }
        }
    }

    fun logout() {
        if (mutableState.value.loggingOut) return
        mutableState.value = mutableState.value.copy(loggingOut = true)
        viewModelScope.launch {
            coordinator.logout()
            mutableState.value = SessionUiState()
            eventChannel.send(SessionUiEvent.LoggedOut)
        }
    }
}
