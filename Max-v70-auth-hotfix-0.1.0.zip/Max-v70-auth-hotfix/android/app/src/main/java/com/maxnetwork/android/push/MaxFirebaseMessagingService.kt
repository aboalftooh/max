package com.maxnetwork.android.push

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.maxnetwork.feature.notifications.domain.PushMessageParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MaxFirebaseMessagingService : FirebaseMessagingService() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        serviceScope.launch {
            PushRegistrationCoordinator(applicationContext).sync(token)
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val parsed = PushMessageParser.parse(message.data) ?: return
        AndroidPushNotifier(applicationContext).show(parsed)
    }
}
