package com.maxnetwork.android

import java.nio.file.Files
import java.nio.file.Path
import kotlin.io.path.isDirectory
import kotlin.io.path.name
import kotlin.io.path.readText
import org.junit.Assert.assertTrue
import org.junit.Test

class BrandIdentityStaticChecksTest {
    @Test
    fun `production UI uses Tajawal and the new visible product name`() {
        val androidRoot = findAndroidRoot()
        val productionRoots = buildList {
            add(androidRoot.resolve("app/src/main"))
            add(androidRoot.resolve("core/common/src/main"))
            add(androidRoot.resolve("core/designsystem/src/main"))
            Files.list(androidRoot.resolve("feature")).use { features ->
                features
                    .filter { it.isDirectory() }
                    .map { it.resolve("src/main") }
                    .filter { Files.exists(it) }
                    .forEach { add(it) }
            }
        }

        val violations = mutableListOf<String>()
        productionRoots.forEach { root ->
            Files.walk(root).use { paths ->
                paths
                    .filter { Files.isRegularFile(it) }
                    .filter { it.name.endsWith(".kt") || it.name.endsWith(".java") || it.name.endsWith(".xml") }
                    .forEach { path ->
                        val relative = androidRoot.relativize(path).toString()
                        val text = path.readText()
                        if ("ماكس" in text) {
                            violations += "$relative: old Arabic product name"
                        }
                        if (UPPERCASE_VISIBLE_BRAND.containsMatchIn(text)) {
                            violations += "$relative: old uppercase product name in a string literal"
                        }
                        if ("FontFamily.SansSerif" in text) {
                            violations += "$relative: FontFamily.SansSerif"
                        }
                        if (text.contains("Cairo", ignoreCase = true) || text.contains("Alyamama", ignoreCase = true)) {
                            violations += "$relative: forbidden font family reference"
                        }
                    }
            }
        }

        val forbiddenAssets = productionRoots.flatMap { root ->
            Files.walk(root).use { paths ->
                paths
                    .filter { Files.isRegularFile(it) }
                    .map { androidRoot.relativize(it).toString() }
                    .filter { path ->
                        path.contains("cairo", ignoreCase = true) || path.contains("alyamama", ignoreCase = true)
                    }
                    .toList()
            }
        }
        violations += forbiddenAssets.map { "$it: forbidden font asset" }

        assertTrue(
            "Brand identity violations:\n${violations.joinToString("\n")}",
            violations.isEmpty(),
        )
    }

    private fun findAndroidRoot(): Path {
        var current = Path.of(System.getProperty("user.dir")).toAbsolutePath().normalize()
        while (current.parent != null) {
            if (Files.exists(current.resolve("settings.gradle.kts")) && Files.isDirectory(current.resolve("app"))) {
                return current
            }
            current = current.parent
        }
        error("Unable to locate Android project root from ${System.getProperty("user.dir")}")
    }

    private companion object {
        val UPPERCASE_VISIBLE_BRAND = Regex("\\\"(?:[^\\\"\\\\]|\\\\.)*MAX(?:[^\\\"\\\\]|\\\\.)*\\\"")
    }
}
