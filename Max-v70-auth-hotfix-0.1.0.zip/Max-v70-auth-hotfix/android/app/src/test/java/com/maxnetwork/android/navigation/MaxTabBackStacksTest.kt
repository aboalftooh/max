package com.maxnetwork.android.navigation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MaxTabBackStacksTest {
    @Test
    fun switchingTabsPreservesEachTabsBackStack() {
        var stacks = MaxTabBackStacks.authenticatedRoot()
            .navigate(MaxDestination.Profile)

        assertEquals(MaxTab.Settings, stacks.selectedTab)
        assertEquals(MaxDestination.Profile, stacks.current)
        assertTrue(stacks.canGoBack)

        stacks = stacks.selectTab(MaxTab.Home)
        assertEquals(MaxDestination.Home, stacks.current)
        assertFalse(stacks.canGoBack)

        stacks = stacks.selectTab(MaxTab.Settings)
        assertEquals(MaxDestination.Profile, stacks.current)
        assertTrue(stacks.canGoBack)
    }

    @Test
    fun backOnlyPopsTheSelectedTabsStack() {
        var stacks = MaxTabBackStacks.authenticatedRoot()
            .navigate(MaxDestination.Profile)
            .selectTab(MaxTab.Home)
            .navigate(MaxDestination.Notifications)

        assertEquals(MaxTab.Home, stacks.selectedTab)
        assertEquals(MaxDestination.Notifications, stacks.current)

        stacks = stacks.back()
        assertEquals(MaxDestination.Home, stacks.current)
        assertFalse(stacks.canGoBack)

        stacks = stacks.selectTab(MaxTab.Settings)
        assertEquals(MaxDestination.Profile, stacks.current)
        assertTrue(stacks.canGoBack)
    }

    @Test
    fun backFromSecondaryTabRootReturnsToHomeRoot() {
        var stacks = MaxTabBackStacks.authenticatedRoot()
            .selectTab(MaxTab.Invoices)

        assertEquals(MaxDestination.Invoices, stacks.current)
        assertTrue(stacks.canGoBack)

        stacks = stacks.back()

        assertEquals(MaxTab.Home, stacks.selectedTab)
        assertEquals(MaxDestination.Home, stacks.current)
        assertFalse(stacks.canGoBack)
    }

    @Test
    fun savedStateRestoresSelectedTabAndNestedStacks() {
        val before = MaxTabBackStacks.authenticatedRoot()
            .navigate(MaxDestination.Profile)
            .selectTab(MaxTab.Home)
            .navigate(MaxDestination.Notifications)
            .selectTab(MaxTab.Settings)

        val restored = MaxTabBackStacks.restoreState(before.saveState())

        assertEquals(MaxTab.Settings, restored.selectedTab)
        assertEquals(MaxDestination.Profile, restored.current)
        assertTrue(restored.canGoBack)

        val home = restored.selectTab(MaxTab.Home)
        assertEquals(MaxDestination.Notifications, home.current)
        assertTrue(home.canGoBack)
    }
}
