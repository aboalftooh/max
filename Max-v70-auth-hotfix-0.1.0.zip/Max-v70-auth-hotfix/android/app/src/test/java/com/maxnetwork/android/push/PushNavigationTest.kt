package com.maxnetwork.android.push

import com.maxnetwork.android.navigation.MaxDestination
import com.maxnetwork.feature.notifications.domain.PushNavigationTarget

private var checks = 0

private fun expect(condition: Boolean, name: String) {
    check(condition) { "Failed: $name" }
    checks += 1
}

fun main() {
    expect(
        PushNavigationTarget.IncomingOrders.toMaxDestination() == MaxDestination.IncomingOrders,
        "incoming target",
    )
    expect(
        PushNavigationTarget.OutgoingOrders.toMaxDestination() == MaxDestination.OutgoingOrders,
        "outgoing target",
    )
    expect(
        PushNavigationTarget.Balance.toMaxDestination() == MaxDestination.Balance,
        "balance target",
    )
    println("PushNavigationTest: $checks/$checks checks passed")
}
