package com.maxnetwork.android

import com.maxnetwork.core.common.ProductIdentity
import org.junit.Assert.assertEquals
import org.junit.Test

class ProductIdentityTest {
    @Test
    fun `product identity remains frozen`() {
        assertEquals("max", ProductIdentity.DISPLAY_NAME)
        assertEquals("com.maxnetwork.android", ProductIdentity.APPLICATION_ID)
    }

    @Test
    fun `generated application id matches frozen identity`() {
        assertEquals(ProductIdentity.APPLICATION_ID, BuildConfig.APPLICATION_ID)
    }
}
