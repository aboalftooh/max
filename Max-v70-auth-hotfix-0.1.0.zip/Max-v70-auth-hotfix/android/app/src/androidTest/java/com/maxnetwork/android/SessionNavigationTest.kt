package com.maxnetwork.android

import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.presentation.LoginUiState
import java.time.Instant
import org.junit.Rule
import org.junit.Test

class SessionNavigationTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun logoutFromSettingsRemovesAuthenticatedTabsAndAllowsFreshLoginFlow() {
        val auth = mutableStateOf<AuthState>(AuthState.Authenticated(Instant.parse("2026-07-28T14:00:00Z")))
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                MaxApp(
                    authState = auth.value,
                    loginUiState = LoginUiState(),
                    actions = MaxAppActions(
                        onPhoneChanged = {},
                        onSubmitLogin = {},
                        onLogout = { auth.value = AuthState.SignedOut() },
                    ),
                )
            }
        }

        composeRule.onNodeWithTag("bottom_tab_settings").performClick()
        composeRule.onNodeWithTag("settings_logout").performClick()
        composeRule.onNodeWithTag("login_screen").assertIsDisplayed()
        composeRule.onAllNodesWithTag("bottom_bar").assertCountEquals(0)
        composeRule.onAllNodesWithTag("settings_screen").assertCountEquals(0)
    }
}
