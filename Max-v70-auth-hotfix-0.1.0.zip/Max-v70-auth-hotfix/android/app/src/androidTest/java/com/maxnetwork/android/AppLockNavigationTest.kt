package com.maxnetwork.android

import androidx.activity.ComponentActivity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.assertDoesNotExist
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import com.maxnetwork.android.security.AppLockGate
import com.maxnetwork.android.security.AppLockState
import org.junit.Rule
import org.junit.Test

class AppLockNavigationTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<ComponentActivity>()

    @Test
    fun lockedAuthenticatedContentIsHidden() {
        composeRule.setContent {
            AppLockGate(
                authenticated = true,
                state = AppLockState(enabled = true, available = true, locked = true),
                onUnlock = {},
            ) {
                androidx.compose.material3.Text("protected", modifier = androidx.compose.ui.Modifier.testTag("protected_content"))
            }
        }
        composeRule.onNodeWithTag("app_lock_gate").assertIsDisplayed()
        composeRule.onNodeWithTag("protected_content").assertDoesNotExist()
    }

    @Test
    fun authenticatingAndUnavailableStatesAreExplicit() {
        composeRule.setContent {
            AppLockGate(
                authenticated = true,
                state = AppLockState(
                    enabled = true,
                    available = false,
                    locked = true,
                    unavailableMessage = "مصادقة الجهاز غير متاحة للاختبار",
                ),
                onUnlock = {},
            ) {
                androidx.compose.material3.Text("protected")
            }
        }
        composeRule.onNodeWithTag("app_lock_error").assertIsDisplayed()
        composeRule.onNodeWithTag("app_lock_unlock").assertIsNotEnabled()
    }

    @Test
    fun signedOutContentIsNeverBlocked() {
        composeRule.setContent {
            AppLockGate(
                authenticated = false,
                state = AppLockState(enabled = true, available = true, locked = true),
                onUnlock = {},
            ) {
                androidx.compose.material3.Text("signed-out", modifier = androidx.compose.ui.Modifier.testTag("signed_out_content"))
            }
        }
        composeRule.onNodeWithTag("app_lock_gate").assertDoesNotExist()
        composeRule.onNodeWithTag("signed_out_content").assertIsDisplayed()
    }
}
