package com.maxnetwork.android

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.maxnetwork.feature.auth.domain.AuthState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AuthBootstrapSmokeTest {
    @Test
    fun applicationRestoresSingleAuthenticationState() = runBlocking {
        val application = androidx.test.core.app.ApplicationProvider.getApplicationContext<MaxApplication>()
        application.appContainer.auth.useCases.restoreSession()

        assertFalse(application.appContainer.auth.repository.authState.value is AuthState.Initializing)
    }
}
