package com.maxnetwork.android

import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import com.maxnetwork.core.designsystem.theme.MaxTheme
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.presentation.LoginUiState
import java.time.Instant
import org.junit.Rule
import org.junit.Test

class MaxAppNavigationTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun authenticatedRootsExposeExactlyTheLockedFourTabs() {
        setAuthenticatedContent()

        composeRule.onNodeWithTag("home_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_tab_home").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_tab_conversations").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_tab_invoices").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_tab_settings").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_primary_action").assertIsDisplayed()
        composeRule.onAllNodesWithTag("bottom_bar").assertCountEquals(1)

        composeRule.onNodeWithTag("bottom_tab_conversations").performClick()
        composeRule.onNodeWithTag("conversations_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_bar").assertIsDisplayed()

        composeRule.onNodeWithTag("bottom_tab_invoices").performClick()
        composeRule.onNodeWithTag("invoices_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_bar").assertIsDisplayed()

        composeRule.onNodeWithTag("bottom_tab_settings").performClick()
        composeRule.onNodeWithTag("settings_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_bar").assertIsDisplayed()

        composeRule.onNodeWithTag("bottom_tab_home").performClick()
        composeRule.onNodeWithTag("home_screen").assertIsDisplayed()
    }

    @Test
    fun nestedAuthenticatedContentHidesBottomBarAndBackReturnsToRoot() {
        setAuthenticatedContent()

        composeRule.onNodeWithTag("bottom_primary_action").performClick()
        composeRule.onNodeWithTag("request_part_screen").assertIsDisplayed()
        composeRule.onAllNodesWithTag("bottom_bar").assertCountEquals(0)
        composeRule.onAllNodesWithTag("bottom_primary_action").assertCountEquals(0)
        composeRule.onNodeWithTag("max_top_bar_back").performClick()
        composeRule.onNodeWithTag("home_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_bar").assertIsDisplayed()

        composeRule.onNodeWithTag("bottom_tab_settings").performClick()
        composeRule.onNodeWithTag("settings_profile").performClick()
        composeRule.onNodeWithTag("profile_screen").assertIsDisplayed()
        composeRule.onAllNodesWithTag("bottom_bar").assertCountEquals(0)
        composeRule.onNodeWithTag("max_top_bar_back").performClick()
        composeRule.onNodeWithTag("settings_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_bar").assertIsDisplayed()
    }

    @Test
    fun rootBackActionIsFunctionalAndReturnsSecondaryTabToHome() {
        setAuthenticatedContent()

        composeRule.onNodeWithTag("bottom_tab_settings").performClick()
        composeRule.onNodeWithTag("settings_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("max_top_bar_back").performClick()

        composeRule.onNodeWithTag("home_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("bottom_bar").assertIsDisplayed()
    }

    @Test
    fun signedOutAuthenticationGraphNeverShowsBottomBar() {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                MaxApp(
                    authState = AuthState.SignedOut(),
                    loginUiState = LoginUiState(),
                    actions = emptyActions(),
                )
            }
        }

        composeRule.onAllNodesWithTag("bottom_bar").assertCountEquals(0)
        composeRule.onNodeWithTag("login_screen").assertIsDisplayed()
    }

    private fun setAuthenticatedContent() {
        composeRule.setContent {
            MaxTheme(motionEnabled = false) {
                MaxApp(
                    authState = AuthState.Authenticated(Instant.parse("2026-07-28T14:00:00Z")),
                    loginUiState = LoginUiState(),
                    actions = emptyActions(),
                )
            }
        }
    }

    private fun emptyActions() = MaxAppActions(
        onPhoneChanged = {},
        onSubmitLogin = {},
    )
}
