package com.maxnetwork.android

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import org.junit.Rule
import org.junit.Test

class MainActivitySmokeTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun appLaunchesIntoAuthenticationFlowWithFrozenIdentity() {
        composeRule.onNodeWithTag("max_app_root").assertIsDisplayed()
        composeRule.onNodeWithText("max").assertIsDisplayed()
        composeRule.onNodeWithText("تسجيل الدخول").assertIsDisplayed()
        composeRule.onNodeWithText("التسجيل").assertIsDisplayed()
    }
}
