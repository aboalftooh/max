package com.maxnetwork.android

import com.maxnetwork.android.di.MaxAppContainer

/** Release keeps the normal server-owned authentication bootstrap. */
internal fun bootstrapDebugAuthentication(container: MaxAppContainer) = Unit
