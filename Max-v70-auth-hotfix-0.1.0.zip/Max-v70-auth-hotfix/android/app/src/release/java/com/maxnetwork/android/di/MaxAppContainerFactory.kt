package com.maxnetwork.android.di

import android.content.Context
import com.maxnetwork.android.BuildConfig
import com.maxnetwork.core.network.InMemoryBearerTokenStore
import com.maxnetwork.core.network.MaxGateway
import com.maxnetwork.core.network.RetrofitMaxGateway
import com.maxnetwork.core.network.UnavailableMaxGateway
import com.maxnetwork.feature.auth.AuthFeatureFactory
import com.maxnetwork.feature.balance.BalanceFeatureFactory
import com.maxnetwork.feature.notifications.NotificationsFeatureFactory
import com.maxnetwork.feature.orders.OrdersFeatureFactory
import com.maxnetwork.feature.profile.ProfileFeatureFactory
import com.maxnetwork.feature.request.RequestFeatureFactory

internal fun createMaxAppContainer(context: Context): MaxAppContainer {
    val bearerTokenStore = InMemoryBearerTokenStore()
    val gateway: MaxGateway = if (BuildConfig.MAX_API_BASE_URL.isBlank()) {
        UnavailableMaxGateway()
    } else {
        RetrofitMaxGateway.create(
            baseUrl = BuildConfig.MAX_API_BASE_URL,
            bearerTokenStore = bearerTokenStore,
        )
    }
    return MaxAppContainer(
        gateway = gateway,
        auth = AuthFeatureFactory.create(
            context = context,
            gateway = gateway,
            onAccessTokenChanged = bearerTokenStore::update,
        ),
        balance = BalanceFeatureFactory.create(gateway = gateway),
        profile = ProfileFeatureFactory.create(gateway = gateway),
        orders = OrdersFeatureFactory.create(gateway = gateway),
        notifications = NotificationsFeatureFactory.create(gateway = gateway),
        request = RequestFeatureFactory.create(context, gateway),
        environmentName = if (BuildConfig.MAX_API_BASE_URL.isBlank()) "unconfigured" else "production",
    )
}
