# v01 has no custom shrinking rules.
