# Verto Integration Boundary

فيرتو يرسل أحداثًا مستقرة إلى Max Backend/BFF. كل حدث يملك `eventId` و`idempotencyKey`. التصحيح والمرتجع أحداث مستقلة تشير إلى الحدث الأصلي، ولا تعيدان كتابة التاريخ.

- Sale → طلب صادر وحركة حمراء.
- Purchase → طلب وارد وحركة خضراء.
- Payment/Receipt → حركة رصيد فقط.
- Correction → حركة append-only تستخدم مبلغًا موقّعًا غير صفري.
- Return → حركة append-only بمبلغ موجب تعكس اتجاه فاتورة البيع أو الشراء الأصلية.

## Financial projection through v29

- `SALE_RECORDED` → `OUTGOING/PROVIDED` + `OUTGOING_ORDER`.
- `PURCHASE_RECORDED` → `INCOMING/PROVIDED` + `INCOMING_ORDER`.
- `PAYMENT_RECORDED` → `PAYMENT` balance movement only.
- `RECEIPT_RECORDED` → `RECEIPT` balance movement only.
- `CORRECTION_RECORDED` → signed `CORRECTION` movement; `causationEventId` is mandatory.
- `RETURN_RECORDED` → `RETURN` movement against an original invoice; cumulative returns cannot exceed it.
- The adapter acknowledges only applied or exact duplicate events.
- A rejected event blocks cursor advancement so no event can be skipped.
- Store-scoped keys enforce tenant ownership of sources and causes.
