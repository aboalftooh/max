# Max Contracts

- `api/openapi.yaml`: العقد الوحيد بين Android وMax API/BFF.
- `verto/verto-events.schema.json`: أحداث فيرتو الداخلة إلى Backend، وليست عقد Android.
- `fixtures/`: بيانات ثابتة لاختبارات العقود والـFake.

## قواعد ثابتة

- لا كتابة مالية عبر Max API.
- لا اتصال Android بجداول فيرتو.
- لا أسماء منافسين ولا مخزون في استجابات الطلبات.
- العملة `SDG` والمبالغ بوحدات صحيحة `minorUnits` دون Float.
- كل توقيت RFC 3339 بصيغة `date-time`.
- pagination عبر cursor وحد أقصى 50.
