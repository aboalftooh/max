#!/usr/bin/env python3
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
checks = 0


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def expect(condition: bool, name: str) -> None:
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {name}")
    checks += 1


api = read("backend/src/main/kotlin/com/maxnetwork/backend/balance/api/BalanceApi.kt")
service = read("backend/src/main/kotlin/com/maxnetwork/backend/balance/application/BalanceQueryService.kt")
cursor = read("backend/src/main/kotlin/com/maxnetwork/backend/balance/infrastructure/HmacBalanceCursorCodec.kt")
ports = read("backend/src/main/kotlin/com/maxnetwork/backend/balance/ports/FinancialLedgerPorts.kt")
sql = read("backend/src/main/resources/db/migration/V007__balance_read_api.sql")
openapi = read("contracts/api/openapi.yaml")
network = read("android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt")
domain = read("android/feature/balance/src/main/java/com/maxnetwork/feature/balance/domain/BalanceReadModel.kt")
data = read("android/feature/balance/src/main/java/com/maxnetwork/feature/balance/data/NetworkBalanceReadRepository.kt")
fixture = json.loads(read("contracts/fixtures/balance.json"))

expect("fun getBalance(accessToken: String)" in api, "authenticated-snapshot-endpoint")
expect("fun listMovements(" in api and "accessToken: String" in api, "authenticated-movements-endpoint")
expect("auth.authenticate(accessToken)" in api, "server-session-authentication")
expect("StoreId(result.value.storeId)" in api, "tenant-from-session")
expect("sourceReference" not in api and "sourceEventId" not in api, "no-internal-reference-response")
expect("signedDeltaMinorUnits" in api and "delta = MoneyResponse" in api, "signed-delta-response")
expect("limit !in MIN_LIMIT..MAX_LIMIT" in service, "limit-validation")
expect("limit + 1" in service, "next-page-probe")
expect("visible.last().sequence" in service, "sequence-keyset-cursor")
expect("listMovementsBefore" in ports and "sortedByDescending" in ports, "newest-first-reader")
expect("HmacSHA256" in cursor and "MessageDigest.isEqual" in cursor, "signed-cursor")
expect("cursorStore == storeId.value" in cursor, "tenant-bound-cursor")
expect("MIN_SECRET_BYTES = 32" in cursor, "cursor-secret-strength")
expect("security invoker" in sql.lower(), "sql-security-invoker")
expect("current_setting('app.store_id'" in sql, "sql-tenant-context")
expect("order by movement.sequence_no desc" in sql.lower(), "sql-newest-first")
expect("revoke all on function" in sql.lower(), "sql-no-public-execute")
expect("@GET(\"v1/balance\")" in network, "android-snapshot-client")
expect("@GET(\"v1/balance/movements\")" in network, "android-movements-client")
expect("delta: MoneyAmount" in read("android/core/network/src/main/kotlin/com/maxnetwork/core/network/ApiModels.kt"), "android-delta-model")
expect("val asOf: Instant?" in read("android/core/network/src/main/kotlin/com/maxnetwork/core/network/ApiModels.kt"), "empty-balance-null-asof")
expect("interface BalanceReadRepository" in read("android/feature/balance/src/main/java/com/maxnetwork/feature/balance/domain/BalanceReadRepository.kt"), "balance-repository")
expect("class NetworkBalanceReadRepository" in data, "network-repository")
expect("BalanceMovementKind.entries.size" not in domain, "domain-no-test-code")
expect(not re.search(r'^import (android\.|androidx\.|retrofit2\.|okhttp3\.)', domain, re.M), "domain-platform-free")
expect(all("delta" in movement for movement in fixture["movements"]), "fixture-signed-deltas")
expect("post:" not in openapi.split("  /v1/balance:", 1)[1].split("  /v1/profile:", 1)[0].lower(), "no-financial-write-route")
expect("type: [string, 'null']" in openapi.split("BalanceSnapshot:", 1)[1].split("BalanceMovementType:", 1)[0], "openapi-empty-asof")
expect('enum: [INCOMING_ORDER, OUTGOING_ORDER, PAYMENT, RECEIPT, CORRECTION, RETURN]' in openapi, "six-api-types")
expect('project(":feature:' not in read("android/feature/balance/build.gradle.kts"), "no-feature-dependency")

print(f"BalanceReadContractCheck: {checks}/{checks} checks passed")
