#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/order-read-upload-api.jar"
mkdir -p "$ROOT/verification-artifacts"
mapfile -t SOURCES < <(find "$ROOT/backend/src/main/kotlin" -name '*.kt' | sort)
kotlinc "${SOURCES[@]}" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/request/read/OrderReadAndUploadApiTest.kt" \
  -Werror -include-runtime -d "$OUT"
java -jar "$OUT"
