package com.maxnetwork.feature.request.presentation

import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.domain.RequestContent

private var checks = 0

private fun verify(condition: Boolean, message: String) {
    check(condition) { message }
    checks += 1
}

fun main() {
    val reducer = RequestComposerReducer()
    verify(reducer.state.phase == RequestComposerPhase.Loading, "initial phase")
    verify(!reducer.state.canSubmit, "loading cannot submit")

    reducer.dispatch(RequestComposerAction.DraftLoaded(null))
    verify(reducer.state.phase == RequestComposerPhase.Draft, "draft loaded")
    verify(!reducer.state.canSubmit, "empty draft cannot submit")

    val textTransition = reducer.dispatch(RequestComposerAction.TextChanged("  فلتر زيت  "))
    verify(textTransition.command is RequestComposerCommand.Persist, "text persists")
    verify(reducer.state.canSubmit, "text enables submit")

    val submit = reducer.dispatch(RequestComposerAction.SubmitClicked)
    verify(submit.command is RequestComposerCommand.Submit, "submit command")
    val submitted = (submit.command as RequestComposerCommand.Submit).content
    verify(submitted.text == "فلتر زيت", "submitted text normalized")
    verify(reducer.state.phase == RequestComposerPhase.Uploading, "uploading phase")
    verify(!reducer.state.canSubmit, "double submit blocked while uploading")

    reducer.dispatch(RequestComposerAction.SubmissionFailed("تعذر الإرسال"))
    verify(reducer.state.phase == RequestComposerPhase.Failed, "failure visible")
    verify(reducer.state.message == "تعذر الإرسال", "failure message retained")
    verify(reducer.state.canSubmit, "valid failed draft can retry")

    val retry = reducer.dispatch(RequestComposerAction.RetryClicked)
    verify(retry.command is RequestComposerCommand.Submit, "retry resubmits")

    reducer.dispatch(RequestComposerAction.SubmissionAccepted)
    verify(reducer.state.phase == RequestComposerPhase.Accepted, "accepted waits for success consumption")

    val image = RequestAttachmentRef(
        id = LocalAttachmentId("image-1"),
        kind = RequestAttachmentKind.Image,
        mimeType = "image/jpeg",
        byteSize = 1_024,
    )
    val imageTransition = reducer.dispatch(RequestComposerAction.ImageChanged(image))
    verify(imageTransition.command is RequestComposerCommand.Persist, "image persists")
    verify(reducer.state.content.image == image, "image retained")

    val audio = RequestAttachmentRef(
        id = LocalAttachmentId("audio-1"),
        kind = RequestAttachmentKind.Audio,
        mimeType = "audio/mp4",
        byteSize = 2_048,
        durationSeconds = 10,
    )
    reducer.dispatch(RequestComposerAction.AudioChanged(audio))
    verify(reducer.state.content.audio == audio, "audio retained")

    val blank = RequestComposerReducer(RequestPartUiState(content = RequestContent(), phase = RequestComposerPhase.Draft))
    blank.dispatch(RequestComposerAction.SubmitClicked)
    verify(blank.state.phase == RequestComposerPhase.Failed, "blank submit fails")
    verify(blank.state.message?.isNotBlank() == true, "blank error visible")

    val longText = "x".repeat(2_001)
    val oversized = RequestComposerReducer(RequestPartUiState(content = RequestContent(longText), phase = RequestComposerPhase.Draft))
    oversized.dispatch(RequestComposerAction.SubmitClicked)
    verify(oversized.state.phase == RequestComposerPhase.Failed, "long text fails")

    println("RequestComposerHarness: $checks/$checks checks passed")
}
