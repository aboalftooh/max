import com.maxnetwork.feature.request.domain.DraftSaveResult
import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.domain.RequestContent
import com.maxnetwork.feature.request.domain.RequestDraft
import com.maxnetwork.feature.request.domain.RequestDraftId
import com.maxnetwork.feature.request.domain.RequestDraftPolicy
import com.maxnetwork.feature.request.domain.RequestValidationError
import com.maxnetwork.feature.request.domain.RequestValidationResult
import java.time.Instant

fun main() {
    var passed = 0
    fun verify(condition: Boolean, label: String) {
        check(condition) { label }
        passed += 1
        println("PASS $label")
    }

    val image = RequestAttachmentRef(LocalAttachmentId("image"), RequestAttachmentKind.Image, "image/jpeg", 1024)
    val audio = RequestAttachmentRef(LocalAttachmentId("audio"), RequestAttachmentKind.Audio, "audio/mp4", 2048, 12)
    verify(RequestDraftPolicy.validate(RequestContent(text = "فلتر")) == RequestValidationResult.Valid, "text content")
    verify(RequestDraftPolicy.validate(RequestContent(image = image)) == RequestValidationResult.Valid, "image content")
    verify(RequestDraftPolicy.validate(RequestContent(audio = audio)) == RequestValidationResult.Valid, "audio content")
    verify(
        RequestDraftPolicy.validate(RequestContent()) == RequestValidationResult.Invalid(RequestValidationError.EmptyContent),
        "empty content rejected",
    )
    verify(
        RequestDraftPolicy.validate(RequestContent(text = "x".repeat(2001))) ==
            RequestValidationResult.Invalid(RequestValidationError.TextTooLong),
        "long text rejected",
    )
    verify(
        RequestDraftPolicy.validate(RequestContent(image = image.copy(byteSize = RequestDraftPolicy.MAX_IMAGE_BYTES + 1))) ==
            RequestValidationResult.Invalid(RequestValidationError.ImageTooLarge),
        "large image rejected",
    )
    verify(
        RequestDraftPolicy.validate(RequestContent(audio = audio.copy(durationSeconds = 61))) ==
            RequestValidationResult.Invalid(RequestValidationError.AudioTooLong),
        "long audio rejected",
    )
    val draft = RequestDraft(RequestDraftId("active"), RequestContent(text = " بواجي "), updatedAt = Instant.EPOCH)
    verify(draft.content.hasAnyContent(), "draft has content")
    verify(draft.content.normalized().text == "بواجي", "text normalized")
    verify(!DraftSaveResult(draft).financialMovementCreated, "no financial movement")
    println("RESULT $passed/$passed")
}
