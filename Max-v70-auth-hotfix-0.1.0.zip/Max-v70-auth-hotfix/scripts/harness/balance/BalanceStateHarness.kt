package com.maxnetwork.feature.balance.presentation

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.feature.balance.domain.BalanceCursor
import com.maxnetwork.feature.balance.domain.BalanceMovement
import com.maxnetwork.feature.balance.domain.BalanceMovementId
import com.maxnetwork.feature.balance.domain.BalanceMovementKind
import com.maxnetwork.feature.balance.domain.BalanceMovementPage
import com.maxnetwork.feature.balance.domain.BalanceReadFailure
import com.maxnetwork.feature.balance.domain.BalanceSnapshot
import java.time.Instant

private var passed = 0
private fun expect(name: String, condition: Boolean) {
    check(condition) { name }
    passed++
    println("PASS: $name")
}

private fun money(value: Long) = Money(value, CurrencyCode.SDG)
private fun movement(id: String, delta: Long, kind: BalanceMovementKind = BalanceMovementKind.Correction) =
    BalanceMovement(
        BalanceMovementId(id),
        kind,
        money(kotlin.math.abs(delta)),
        money(delta),
        money(delta),
        Instant.ofEpochSecond(id.toLong()),
    )

fun main() {
    val reducer = BalanceStateReducer()
    expect("initial has no tenant data", !reducer.state.hasContent && reducer.state.movements.isEmpty())
    reducer.refreshing()
    expect("refresh loading", reducer.state.initialLoading)
    reducer.balanceLoaded(BalanceSnapshot(money(185_000), Instant.EPOCH))
    expect("balance loaded", reducer.state.balance?.minorUnits == 185_000L)
    reducer.pageLoaded(
        BalanceMovementPage(
            listOf(movement("4", 50_000), movement("3", -25_000)),
            BalanceCursor("next"),
        ),
        append = false,
    )
    expect("first page loaded", reducer.state.movements.map { it.id.value } == listOf("4", "3"))
    expect("cursor enables pagination", reducer.state.canLoadMore)
    reducer.loadingMore()
    expect("pagination loading", reducer.state.loadingMore)
    reducer.pageLoaded(
        BalanceMovementPage(
            listOf(movement("3", -25_000), movement("2", 10_000), movement("1", -5_000)),
            null,
        ),
        append = true,
    )
    expect("overlap removed", reducer.state.movements.size == 4)
    expect("server order preserved", reducer.state.movements.map { it.id.value } == listOf("4", "3", "2", "1"))
    expect("pagination ends", !reducer.state.canLoadMore)
    reducer.failed(BalanceReadFailure.Offline)
    expect("offline explicit", reducer.state.offline)
    expect("offline retains balance", reducer.state.balance?.minorUnits == 185_000L)
    expect("offline retains movements", reducer.state.movements.size == 4)
    reducer.balanceLoaded(BalanceSnapshot(money(-65_000), Instant.EPOCH))
    expect("negative balance represented", reducer.state.balance?.minorUnits == -65_000L)
    expect("signed money label", money(-65_000).toSdgText().contains("ج.س"))
    expect("absolute movement amount", money(-65_000).toSdgText(includeSign = false).contains("ج.س"))
    expect("incoming label", BalanceMovementKind.IncomingOrder.displayName() == "طلب وارد")
    expect("outgoing label", BalanceMovementKind.OutgoingOrder.displayName() == "طلب صادر")
    expect("payment label", BalanceMovementKind.Payment.displayName() == "دفعة")
    expect("receipt label", BalanceMovementKind.Receipt.displayName() == "استلام")
    expect("correction label", BalanceMovementKind.Correction.displayName() == "تصحيح")
    expect("return label", BalanceMovementKind.Return.displayName() == "مرتجع")
    reducer.clear()
    expect("clear removes balance", reducer.state.balance == null)
    expect("clear removes movements", reducer.state.movements.isEmpty())
    expect("clear removes cursor", reducer.state.nextCursor == null)
    println("Balance state harness passed: $passed/$passed")
}
