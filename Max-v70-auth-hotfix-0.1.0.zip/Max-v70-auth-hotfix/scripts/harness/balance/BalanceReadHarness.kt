package com.maxnetwork.harness.balance

import com.maxnetwork.core.model.CurrencyCode
import com.maxnetwork.core.model.Money
import com.maxnetwork.feature.balance.domain.BalanceCursor
import com.maxnetwork.feature.balance.domain.BalanceMovement
import com.maxnetwork.feature.balance.domain.BalanceMovementId
import com.maxnetwork.feature.balance.domain.BalanceMovementKind
import com.maxnetwork.feature.balance.domain.BalanceMovementPage
import com.maxnetwork.feature.balance.domain.BalanceMovementQuery
import com.maxnetwork.feature.balance.domain.BalanceReadRepository
import com.maxnetwork.feature.balance.domain.BalanceReadResult
import com.maxnetwork.feature.balance.domain.BalanceSnapshot
import com.maxnetwork.feature.balance.domain.LoadBalanceMovementsPageUseCase
import com.maxnetwork.feature.balance.domain.LoadBalanceUseCase
import java.time.Instant
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private var checks = 0
private fun verify(value: Boolean, message: String) {
    check(value) { message }
    checks += 1
}

private class FakeRepository : BalanceReadRepository {
    var requestedQuery: BalanceMovementQuery? = null
    val snapshot = BalanceSnapshot(Money(125_000, CurrencyCode.SDG), Instant.parse("2026-07-30T08:00:00Z"))
    val movement = BalanceMovement(
        id = BalanceMovementId("mov-1"),
        kind = BalanceMovementKind.Correction,
        amount = Money(5_000, CurrencyCode.SDG),
        delta = Money(-5_000, CurrencyCode.SDG),
        balanceAfter = Money(125_000, CurrencyCode.SDG),
        occurredAt = Instant.parse("2026-07-30T07:30:00Z"),
    )

    override suspend fun getBalance(): BalanceReadResult<BalanceSnapshot> = BalanceReadResult.Success(snapshot)

    override suspend fun getMovements(query: BalanceMovementQuery): BalanceReadResult<BalanceMovementPage> {
        requestedQuery = query
        return BalanceReadResult.Success(BalanceMovementPage(listOf(movement), BalanceCursor("next")))
    }
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var outcome: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(result: Result<T>) {
            outcome = result
        }
    })
    return requireNotNull(outcome).getOrThrow()
}

fun main() {
    val repository = FakeRepository()
    val snapshot = runSuspend { LoadBalanceUseCase(repository)() }
    verify(snapshot is BalanceReadResult.Success, "snapshot use case")
    verify((snapshot as BalanceReadResult.Success).value.balance.minorUnits == 125_000L, "snapshot amount")

    val query = BalanceMovementQuery(BalanceCursor("cursor"), 20)
    val page = runSuspend { LoadBalanceMovementsPageUseCase(repository)(query) }
    verify(page is BalanceReadResult.Success, "movement use case")
    val value = (page as BalanceReadResult.Success).value
    verify(value.items.single().delta.minorUnits == -5_000L, "signed delta retained")
    verify(value.items.single().amount.minorUnits == 5_000L, "absolute amount retained")
    verify(value.nextCursor?.value == "next", "next cursor retained")
    verify(repository.requestedQuery == query, "query forwarded unchanged")

    verify(runCatching { BalanceMovementQuery(limit = 0) }.isFailure, "zero limit rejected")
    verify(runCatching { BalanceMovementQuery(limit = 51) }.isFailure, "oversized limit rejected")
    verify(runCatching { BalanceCursor(" ") }.isFailure, "blank cursor rejected")
    verify(runCatching { BalanceMovementId("") }.isFailure, "blank id rejected")
    verify(
        runCatching {
            repository.movement.copy(delta = Money(Long.MIN_VALUE, CurrencyCode.SDG))
        }.isFailure,
        "minimum long delta rejected",
    )
    verify(
        runCatching {
            repository.movement.copy(delta = Money(-4_000, CurrencyCode.SDG))
        }.isFailure,
        "delta must match amount",
    )
    verify(
        BalanceSnapshot(Money(0, CurrencyCode.SDG), null).asOf == null,
        "empty snapshot supports null as-of",
    )
    verify(BalanceMovementKind.entries.size == 6, "six movement kinds")

    println("BalanceReadHarness: $checks/$checks checks passed")
}
