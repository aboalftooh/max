package okhttp3

import java.io.Closeable

class MediaType private constructor() {
    companion object {
        fun String.toMediaType(): MediaType = MediaType()
    }
}

class RequestBody private constructor() {
    companion object {
        fun ByteArray.toRequestBody(contentType: MediaType): RequestBody {
            @Suppress("UNUSED_VARIABLE")
            val ignored = contentType
            return RequestBody()
        }
    }
}

class HttpUrl(val encodedPath: String = "/")

class Request private constructor(
    val url: HttpUrl,
    private val headers: Map<String, String>,
) {
    fun header(name: String): String? = headers[name]

    fun newBuilder(): Builder = Builder()
        .url(url)
        .apply { headers.forEach(::header) }

    class Builder {
        private var url: HttpUrl = HttpUrl()
        private val headers = linkedMapOf<String, String>()

        fun url(value: String): Builder {
            url = HttpUrl(value.substringAfter("://", value).substringAfter('/', "").let { "/$it" })
            return this
        }

        fun url(value: HttpUrl): Builder {
            url = value
            return this
        }

        fun put(body: RequestBody): Builder {
            @Suppress("UNUSED_VARIABLE")
            val ignored = body
            return this
        }

        fun header(name: String, value: String): Builder {
            headers[name] = value
            return this
        }

        fun build(): Request = Request(url, headers.toMap())
    }
}

class Response(
    val isSuccessful: Boolean = true,
    val code: Int = 200,
    private val headers: Map<String, String> = emptyMap(),
) : Closeable {
    fun header(name: String): String? = headers[name]
    override fun close() = Unit
}

fun interface Interceptor {
    fun intercept(chain: Chain): Response
}

interface Chain {
    fun request(): Request
    fun proceed(request: Request): Response
}

fun interface Call {
    fun execute(): Response
}

class OkHttpClient private constructor(
    private val interceptors: List<Interceptor>,
) {
    class Builder {
        private val interceptors = mutableListOf<Interceptor>()

        fun addInterceptor(interceptor: Interceptor): Builder {
            interceptors += interceptor
            return this
        }

        fun build(): OkHttpClient = OkHttpClient(interceptors.toList())
    }

    fun newCall(request: Request): Call = Call {
        @Suppress("UNUSED_VARIABLE")
        val ignored = request
        Response()
    }
}
