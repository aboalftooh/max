package retrofit2.http

@Target(AnnotationTarget.VALUE_PARAMETER)
annotation class Body

@Target(AnnotationTarget.FUNCTION)
annotation class DELETE(val value: String = "")

@Target(AnnotationTarget.FUNCTION)
annotation class GET(val value: String = "")

@Target(AnnotationTarget.VALUE_PARAMETER)
annotation class Header(val value: String)

@Target(AnnotationTarget.FUNCTION)
annotation class POST(val value: String = "")

@Target(AnnotationTarget.FUNCTION)
annotation class PUT(val value: String = "")

@Target(AnnotationTarget.VALUE_PARAMETER)
annotation class Path(val value: String)

@Target(AnnotationTarget.VALUE_PARAMETER)
annotation class Query(val value: String)
