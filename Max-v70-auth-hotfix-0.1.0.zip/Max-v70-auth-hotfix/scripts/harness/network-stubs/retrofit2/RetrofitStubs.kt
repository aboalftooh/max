package retrofit2

import okhttp3.OkHttpClient

class Headers internal constructor(
    private val values: Map<String, String> = emptyMap(),
) {
    operator fun get(name: String): String? = values[name]
}

class Response<T>(private val responseHeaders: Headers = Headers()) {
    fun headers(): Headers = responseHeaders
}

open class HttpException(
    private val statusCode: Int,
    private val httpResponse: Response<*>? = null,
) : RuntimeException() {
    fun code(): Int = statusCode
    fun response(): Response<*>? = httpResponse
}

class Retrofit private constructor() {
    class Builder {
        fun baseUrl(url: String): Builder {
            @Suppress("UNUSED_VARIABLE")
            val ignored = url
            return this
        }

        fun client(client: OkHttpClient): Builder {
            @Suppress("UNUSED_VARIABLE")
            val ignored = client
            return this
        }

        fun addConverterFactory(factory: Any): Builder {
            @Suppress("UNUSED_VARIABLE")
            val ignored = factory
            return this
        }

        fun build(): Retrofit = Retrofit()
    }

    fun <T> create(service: Class<T>): T = throw UnsupportedOperationException(service.name)
}
