package retrofit2.converter.moshi

import com.squareup.moshi.Moshi

class MoshiConverterFactory private constructor() {
    companion object {
        fun create(moshi: Moshi): MoshiConverterFactory {
            @Suppress("UNUSED_VARIABLE")
            val ignored = moshi
            return MoshiConverterFactory()
        }
    }
}
