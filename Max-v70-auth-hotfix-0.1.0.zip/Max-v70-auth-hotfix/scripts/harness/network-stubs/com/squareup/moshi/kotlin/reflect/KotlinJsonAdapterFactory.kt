package com.squareup.moshi.kotlin.reflect

class KotlinJsonAdapterFactory
