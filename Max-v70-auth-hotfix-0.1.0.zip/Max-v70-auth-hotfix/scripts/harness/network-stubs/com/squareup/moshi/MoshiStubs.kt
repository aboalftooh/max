package com.squareup.moshi

class JsonDataException(message: String) : RuntimeException(message)

class Moshi private constructor() {
    class Builder {
        fun add(adapter: Any): Builder {
            @Suppress("UNUSED_VARIABLE")
            val ignored = adapter
            return this
        }
        fun build(): Moshi = Moshi()
    }
}
