import com.maxnetwork.android.session.DeletionSubmission
import com.maxnetwork.android.session.SessionCoordinator
import com.maxnetwork.android.session.SessionFailure
import com.maxnetwork.android.session.SessionOperations
import com.maxnetwork.android.session.TrackableDeletionReceipt
import java.time.Instant
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private fun <T> runSuspend(block: suspend () -> T): T {
    var outcome: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(result: Result<T>) { outcome = result }
    })
    return outcome!!.getOrThrow()
}

private class FakeOperations(
    var deletion: DeletionSubmission,
    var remoteRevoked: Boolean = true,
) : SessionOperations {
    var revokeCalls = 0
    var clearAuthCalls = 0
    var clearProfileCalls = 0
    var deletionCalls = 0
    var clearRequestDraftCalls = 0

    override suspend fun revokeAndClearAuthSession(): Boolean {
        revokeCalls += 1
        return remoteRevoked
    }

    override suspend fun clearTransientAuthenticationData() { clearAuthCalls += 1 }
    override fun clearProfileData() { clearProfileCalls += 1 }
    override suspend fun clearRequestDraft() { clearRequestDraftCalls += 1 }
    override suspend fun submitDeletionRequest(): DeletionSubmission {
        deletionCalls += 1
        return deletion
    }
}

fun main() {
    var checks = 0
    fun verify(value: Boolean, message: String) {
        checks += 1
        check(value) { message }
    }
    val receipt = TrackableDeletionReceipt(
        requestId = "delete-req-001",
        requestedAt = Instant.parse("2026-07-28T10:00:00Z"),
        scheduledFor = Instant.parse("2026-08-27T10:00:00Z"),
    )

    val logoutOps = FakeOperations(DeletionSubmission.Accepted(receipt), remoteRevoked = false)
    val logout = runSuspend { SessionCoordinator(logoutOps).logout() }
    verify(logout.localDataCleared, "logout always reports local clear")
    verify(!logout.remoteRevocationCompleted, "remote failure remains explicit")
    verify(logoutOps.revokeCalls == 1, "session revocation attempted once")
    verify(logoutOps.clearAuthCalls == 1, "transient authentication data cleared")
    verify(logoutOps.clearProfileCalls == 1, "profile cache cleared")
    verify(logoutOps.clearRequestDraftCalls == 1, "request draft cleared")

    val acceptedOps = FakeOperations(DeletionSubmission.Accepted(receipt))
    val accepted = runSuspend { SessionCoordinator(acceptedOps).deleteAccount() }
    verify(accepted is DeletionSubmission.Accepted, "accepted deletion remains trackable")
    verify((accepted as DeletionSubmission.Accepted).receipt.requestId == "delete-req-001", "receipt id preserved")
    verify(acceptedOps.deletionCalls == 1, "deletion submitted once")
    verify(acceptedOps.revokeCalls == 1, "accepted deletion clears session")
    verify(acceptedOps.clearAuthCalls == 1 && acceptedOps.clearProfileCalls == 1, "accepted deletion clears device data")
    verify(acceptedOps.clearRequestDraftCalls == 1, "accepted deletion clears request draft")

    val failedOps = FakeOperations(DeletionSubmission.Failed(SessionFailure.Offline))
    val failed = runSuspend { SessionCoordinator(failedOps).deleteAccount() }
    verify(failed is DeletionSubmission.Failed, "network failure is explicit")
    verify(failedOps.revokeCalls == 0 && failedOps.clearAuthCalls == 0 && failedOps.clearProfileCalls == 0, "failed deletion does not silently log out or erase state")
    verify(failedOps.clearRequestDraftCalls == 0, "failed deletion keeps request draft")

    println("session-coordinator-harness: $checks/$checks passed")
}
