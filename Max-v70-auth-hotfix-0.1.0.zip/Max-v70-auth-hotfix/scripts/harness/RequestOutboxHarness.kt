package com.maxnetwork.feature.request.data.outbox

import com.maxnetwork.core.network.*
import com.maxnetwork.feature.request.domain.*
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

private var checks = 0
private fun verify(value: Boolean, message: String) { check(value) { message }; checks++ }

private class MemoryOutboxRepository(
    private val now: Instant = Instant.parse("2026-07-28T10:00:00Z"),
) : RequestOutboxRepository {
    private val items = linkedMapOf<String, RequestOutboxItem>()
    private val uploadIds = mutableMapOf<Pair<String, RequestAttachmentKind>, String>()
    private val bytes = mutableMapOf<Pair<String, RequestAttachmentKind>, ByteArray>()
    private val latest = MutableStateFlow<RequestOutboxItem?>(null)
    val states = mutableListOf<RequestOutboxState>()

    override fun observeLatest(): Flow<RequestOutboxItem?> = latest

    override suspend fun enqueue(draftId: RequestDraftId, content: RequestContent): OutboxEnqueueResult {
        val key = RequestIdempotencyKey("request:${draftId.value}")
        val existing = items[key.value]
        if (existing != null) return OutboxEnqueueResult(existing, created = false)
        val item = RequestOutboxItem(
            key = key,
            draftId = draftId,
            content = content,
            state = RequestOutboxState.Pending,
            attemptCount = 0,
            lastError = null,
            serverRequestId = null,
            acceptedAt = null,
            createdAt = now,
            updatedAt = now,
        )
        items[key.value] = item
        content.image?.let { bytes[key.value to RequestAttachmentKind.Image] = byteArrayOf(1, 2, 3) }
        content.audio?.let { bytes[key.value to RequestAttachmentKind.Audio] = byteArrayOf(4, 5, 6) }
        latest.value = item
        states += item.state
        return OutboxEnqueueResult(item, created = true)
    }

    override suspend fun loadNextProcessable(): RequestOutboxItem? = items.values.firstOrNull { !it.isTerminal }

    override suspend fun updateState(key: RequestIdempotencyKey, state: RequestOutboxState, error: String?) {
        val current = requireNotNull(items[key.value])
        val next = current.copy(
            state = state,
            attemptCount = current.attemptCount + if (state == RequestOutboxState.RetryableFailure) 1 else 0,
            lastError = error,
            updatedAt = now.plus(states.size.toLong(), ChronoUnit.SECONDS),
        )
        items[key.value] = next
        latest.value = next
        states += state
    }

    override suspend fun saveUploadId(key: RequestIdempotencyKey, kind: RequestAttachmentKind, uploadId: String) {
        uploadIds[key.value to kind] = uploadId
    }

    override suspend fun uploadId(key: RequestIdempotencyKey, kind: RequestAttachmentKind): String? =
        uploadIds[key.value to kind]

    override suspend fun attachmentBytes(key: RequestIdempotencyKey, kind: RequestAttachmentKind): ByteArray? =
        bytes[key.value to kind]

    override suspend fun acknowledge(key: RequestIdempotencyKey) {
        val current = requireNotNull(items[key.value])
        val next = current.copy(state = RequestOutboxState.Acknowledged)
        items[key.value] = next
        latest.value = next
        states += RequestOutboxState.Acknowledged
    }

    override suspend fun markAccepted(key: RequestIdempotencyKey, requestId: String, acceptedAt: Instant) {
        val current = requireNotNull(items[key.value])
        val accepted = current.copy(
            state = RequestOutboxState.Accepted,
            serverRequestId = requestId,
            acceptedAt = acceptedAt,
            lastError = null,
            updatedAt = acceptedAt,
        )
        items[key.value] = accepted
        latest.value = accepted
        states += RequestOutboxState.Accepted
    }

    fun latestItem(): RequestOutboxItem = requireNotNull(latest.value)
}

private class RecordingGateway : MaxGateway {
    var mediaIntentCalls = 0
    var uploadCalls = 0
    var submitCalls = 0
    var failNextSubmit = false
    private val receipts = linkedMapOf<String, RequestReceipt>()

    override suspend fun createMediaUploadIntent(intent: MediaUploadIntent): GatewayResult<MediaUploadSlot> {
        mediaIntentCalls++
        return GatewayResult.Success(
            MediaUploadSlot("upload-$mediaIntentCalls", "https://upload.invalid/$mediaIntentCalls", Instant.parse("2026-07-28T10:10:00Z")),
        )
    }

    override suspend fun uploadMedia(slot: MediaUploadSlot, payload: MediaUploadPayload): GatewayResult<Unit> {
        uploadCalls++
        verify(payload.bytes.isNotEmpty(), "uploaded bytes are present")
        return GatewayResult.Success(Unit)
    }

    override suspend fun submitRequest(command: SubmitRequestCommand): GatewayResult<RequestReceipt> {
        submitCalls++
        if (failNextSubmit) {
            failNextSubmit = false
            return GatewayResult.Failure(
                ApiError(ApiErrorCode.ServiceUnavailable, "offline", "trace", retryable = true),
            )
        }
        val receipt = receipts.getOrPut(command.clientRequestId) {
            RequestReceipt("req-${receipts.size + 1}", command.clientRequestId, Instant.parse("2026-07-28T10:05:00Z"))
        }
        return GatewayResult.Success(receipt)
    }

    private fun <T> unused(): GatewayResult<T> = error("unused")
    override suspend fun validateRegistrationCode(code: String) = unused<RegistrationCodeValidation>()
    override suspend fun requestPhoneChallenge(phone: String) = unused<PhoneChallenge>()
    override suspend fun verifyPhoneChallenge(challengeId: String, otp: String) = unused<VerifiedPhone>()
    override suspend fun createAccount(command: AccountCreation) = unused<Session>()
    override suspend fun login(credentials: LoginCredentials) = unused<Session>()
    override suspend fun refreshSession(refreshToken: String) = unused<Session>()
    override suspend fun logout(accessToken: String) = unused<Unit>()
    override suspend fun requestPasswordReset(phone: String) = unused<PhoneChallenge>()
    override suspend fun resetPassword(command: ResetPasswordCommand) = unused<Unit>()
    override suspend fun getOrders(direction: OrderDirection, cursor: String?, limit: Int) = unused<CursorPage<OrderSummary>>()
    override suspend fun getOrder(orderId: String) = unused<OrderSummary>()
    override suspend fun getBalance() = unused<BalanceSnapshot>()
    override suspend fun getBalanceMovements(cursor: String?, limit: Int) = unused<CursorPage<BalanceMovement>>()
    override suspend fun getProfile() = unused<Profile>()
    override suspend fun getSupportContact() = unused<SupportContact>()
    override suspend fun getPrivacy() = unused<PrivacySummary>()
    override suspend fun requestAccountDeletion() = unused<DeletionRequest>()
    override suspend fun getNotifications(cursor: String?, limit: Int) = unused<CursorPage<MaxNotification>>()
    override suspend fun markNotificationRead(notificationId: String) = unused<Unit>()
    override suspend fun markNotificationReadAuthenticated(accessToken: String, notificationId: String) = unused<Unit>()
    override suspend fun registerPushInstallation(
        accessToken: String,
        installationId: String,
        registration: PushInstallationRegistration,
    ) = unused<Unit>()
    override suspend fun unregisterPushInstallation(accessToken: String, installationId: String) = unused<Unit>()
}

private fun image() = RequestAttachmentRef(
    LocalAttachmentId("img"), RequestAttachmentKind.Image, "image/jpeg", 3,
)
private fun audio() = RequestAttachmentRef(
    LocalAttachmentId("aud"), RequestAttachmentKind.Audio, "audio/mp4", 3, 8,
)

fun main() {
    runSuspend {
        val repository = MemoryOutboxRepository()
        val first = repository.enqueue(RequestDraftId("draft-1"), RequestContent(text = "فلتر زيت"))
        val duplicate = repository.enqueue(RequestDraftId("draft-1"), RequestContent(text = "مختلف"))
        verify(first.created, "first enqueue creates")
        verify(!duplicate.created, "duplicate enqueue reuses item")
        verify(first.item.key == duplicate.item.key, "idempotency key stable")
        verify(!first.financialMovementCreated, "enqueue has no financial movement")

        val gateway = RecordingGateway()
        val result = RequestOutboxProcessor(repository, gateway).processNext()
        verify(result is RequestProcessResult.Accepted, "text request accepted")
        verify(gateway.mediaIntentCalls == 0, "text request skips media intents")
        verify(gateway.uploadCalls == 0, "text request skips uploads")
        verify(gateway.submitCalls == 1, "text request submitted once")
        verify(repository.latestItem().state == RequestOutboxState.Accepted, "accepted persisted")
        verify(repository.loadNextProcessable() == null, "accepted not processed twice")

        val mediaRepo = MemoryOutboxRepository()
        mediaRepo.enqueue(RequestDraftId("draft-2"), RequestContent(image = image(), audio = audio()))
        val mediaGateway = RecordingGateway()
        val mediaResult = RequestOutboxProcessor(mediaRepo, mediaGateway).processNext()
        verify(mediaResult is RequestProcessResult.Accepted, "media request accepted")
        verify(mediaGateway.mediaIntentCalls == 2, "two media intents")
        verify(mediaGateway.uploadCalls == 2, "two media uploads")
        verify(mediaGateway.submitCalls == 1, "submit after uploads once")
        verify(mediaRepo.states.indexOf(RequestOutboxState.UploadingImage) < mediaRepo.states.indexOf(RequestOutboxState.UploadingAudio), "image precedes audio")
        verify(mediaRepo.states.indexOf(RequestOutboxState.UploadingAudio) < mediaRepo.states.indexOf(RequestOutboxState.Submitting), "uploads precede submit")

        val retryRepo = MemoryOutboxRepository()
        retryRepo.enqueue(RequestDraftId("draft-3"), RequestContent(text = "طرمبة بنزين"))
        val retryGateway = RecordingGateway().apply { failNextSubmit = true }
        val processor = RequestOutboxProcessor(retryRepo, retryGateway)
        val retry = processor.processNext()
        verify(retry is RequestProcessResult.Retry, "retryable error requests retry")
        verify(retryRepo.latestItem().state == RequestOutboxState.RetryableFailure, "retry state persisted")
        verify(retryRepo.latestItem().attemptCount == 1, "attempt counted")
        val accepted = processor.processNext()
        verify(accepted is RequestProcessResult.Accepted, "retry later accepted")
        verify(retryGateway.submitCalls == 2, "one failed and one successful submit")
        verify(retryRepo.latestItem().serverRequestId == "req-1", "single server request identity")
    }
    println("RequestOutboxHarness: $checks/$checks checks passed")
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var outcome: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(result: Result<T>) { outcome = result }
    })
    return outcome!!.getOrThrow()
}
