import com.maxnetwork.feature.request.domain.LocalAttachmentId
import com.maxnetwork.feature.request.domain.RequestAttachmentKind
import com.maxnetwork.feature.request.domain.RequestAttachmentRef
import com.maxnetwork.feature.request.media.AudioCaptureResult
import com.maxnetwork.feature.request.media.AudioCaptureTarget
import com.maxnetwork.feature.request.media.AudioFileStore
import com.maxnetwork.feature.request.media.AudioFinalizeResult
import com.maxnetwork.feature.request.media.AudioPlayerEngine
import com.maxnetwork.feature.request.media.AudioRecorderEngine
import com.maxnetwork.feature.request.media.RequestAudioController
import com.maxnetwork.feature.request.media.RequestAudioFailure
import com.maxnetwork.feature.request.media.RequestAudioState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import java.io.File

private class FakeRecorder : AudioRecorderEngine {
    override var isRecording=false
    var interrupted: (() -> Unit)?=null
    override fun start(target: AudioCaptureTarget, onInterrupted: () -> Unit) {
        target.file.writeBytes(byteArrayOf(1,2,3,4)); isRecording=true; interrupted=onInterrupted
    }
    override fun stop(){ isRecording=false }
    override fun cancel(){ isRecording=false }
}
private class FakePlayer : AudioPlayerEngine {
    override var isPlaying=false
    override fun play(file: File,onCompleted:()->Unit){ isPlaying=true }
    override fun stop(){ isPlaying=false }
}
private class FakeStore(private val dir: File): AudioFileStore {
    var deleted=false
    override fun createCaptureTarget(): AudioCaptureTarget = AudioCaptureTarget(LocalAttachmentId("voice"), File(dir,"voice.m4a"))
    override fun finalizeCapture(target: AudioCaptureTarget,durationSeconds:Int): AudioFinalizeResult = AudioFinalizeResult.Success(
        RequestAttachmentRef(target.id,RequestAttachmentKind.Audio,"audio/mp4",target.file.length(),durationSeconds)
    )
    override fun resolve(attachment: RequestAttachmentRef): File? = File(dir,"voice.m4a").takeIf(File::exists)
    override fun delete(attachment: RequestAttachmentRef){ deleted=true; resolve(attachment)?.delete() }
    override fun discard(target: AudioCaptureTarget){ target.file.delete() }
}
fun main()=runBlocking {
    var passed=0
    fun verify(v:Boolean,label:String){ check(v){label};passed++;println("PASS $label") }
    val dir=java.nio.file.Files.createTempDirectory("max-audio-").toFile()
    val recorder=FakeRecorder();val player=FakePlayer();val store=FakeStore(dir)
    var now=0L
    val controller=RequestAudioController(recorder,player,store,CoroutineScope(Dispatchers.Unconfined)){now}
    verify(controller.state.value is RequestAudioState.Idle,"starts idle")
    verify(controller.start()==null,"starts recording")
    verify(recorder.isRecording,"microphone active while recording")
    verify(controller.state.value is RequestAudioState.Recording,"visible recording state")
    now=5_000L
    val result=controller.stop()
    verify(result is AudioCaptureResult.Success,"stop produces attachment")
    verify(!recorder.isRecording,"microphone released after stop")
    val attachment=(result as AudioCaptureResult.Success).attachment
    verify(attachment.durationSeconds==5,"duration recorded")
    controller.play(attachment)
    verify(player.isPlaying,"playback starts")
    controller.stopPlayback()
    verify(!player.isPlaying,"playback stops")
    controller.restore(attachment)
    controller.delete(attachment)
    verify(store.deleted,"recording deleted")
    controller.reportPermissionDenied()
    verify((controller.state.value as RequestAudioState.Failed).reason==RequestAudioFailure.PermissionDenied,"permission denial explicit")
    now=0L;controller.start();controller.onHostStopped()
    verify(!recorder.isRecording,"host stop releases microphone")
    now=0L;controller.start();controller.close()
    verify(!recorder.isRecording,"close releases microphone")
    dir.deleteRecursively()
    println("RESULT $passed/$passed")
}
