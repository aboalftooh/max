import com.maxnetwork.android.navigation.MaxBackStack
import com.maxnetwork.android.navigation.MaxDestination
import com.maxnetwork.android.navigation.MaxNavigationGraph

fun main() {
    var checks = 0
    fun checkThat(value: Boolean, message: String) {
        checks += 1
        check(value) { message }
    }

    checkThat(MaxNavigationGraph.destinations.size == 12, "all destinations are registered")
    checkThat(MaxNavigationGraph.destinations.map { it.route }.distinct().size == 12, "routes are unique")
    checkThat(MaxNavigationGraph.homeDestinations.size == 5, "home exposes five actions")
    checkThat(MaxNavigationGraph.homeDestinations.all { it.requiresAuthentication }, "home actions require auth")

    var stack = MaxBackStack.authenticatedRoot()
    stack = stack.navigate(MaxDestination.Balance)
    checkThat(stack.entries == listOf(MaxDestination.Home, MaxDestination.Balance), "one-tap destination is pushed")
    stack = stack.back()
    checkThat(stack.entries == listOf(MaxDestination.Home), "back returns to home")
    stack = stack.navigate(MaxDestination.Home)
    checkThat(stack.entries.count { it == MaxDestination.Home } == 1, "home is never duplicated")
    stack = stack.navigate(MaxDestination.Profile).resolveAuthentication(authenticated = false)
    checkThat(stack.current == MaxDestination.Login, "signed out users cannot remain in protected graph")

    val signedOut = MaxBackStack.signedOutRoot()
    checkThat(signedOut.current == MaxDestination.Login, "signed-out root is phone entry")
    checkThat(signedOut.resolveAuthentication(authenticated = true).entries == listOf(MaxDestination.Home), "authentication resets root")

    println("navigation-harness: $checks/$checks passed")
}
