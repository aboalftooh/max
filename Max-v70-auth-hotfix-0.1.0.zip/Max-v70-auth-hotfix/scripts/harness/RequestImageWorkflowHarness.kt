private enum class Outcome { Success, Cancelled, PermissionLost, NoSpace }

private data class ImageState(val existingId: String?, val pending: Boolean = false)

private fun apply(state: ImageState, outcome: Outcome, importedId: String? = null): ImageState = when (outcome) {
    Outcome.Success -> ImageState(existingId = requireNotNull(importedId), pending = false)
    Outcome.Cancelled, Outcome.PermissionLost, Outcome.NoSpace -> state.copy(pending = false)
}

fun main() {
    var passed = 0
    fun verify(value: Boolean, label: String) { check(value) { label }; passed++; println("PASS $label") }
    val original = ImageState("old", pending = true)
    verify(apply(original, Outcome.Cancelled).existingId == "old", "cancel keeps existing image")
    verify(apply(original, Outcome.PermissionLost).existingId == "old", "permission loss keeps existing image")
    verify(apply(original, Outcome.NoSpace).existingId == "old", "no space keeps existing image")
    verify(apply(original, Outcome.Success, "new").existingId == "new", "successful import replaces image")
    verify(!apply(original, Outcome.Success, "new").pending, "pending state cleared")
    println("RESULT $passed/$passed")
}
