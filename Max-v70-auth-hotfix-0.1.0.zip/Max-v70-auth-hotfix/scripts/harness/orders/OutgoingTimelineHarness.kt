package com.maxnetwork.feature.orders.domain

import java.time.Instant

private var passed = 0
private fun expect(name: String, condition: Boolean) { check(condition) { name }; passed++; println("PASS: $name") }
private fun remote(id: String, time: String) = OrderReadModel(
    OrderId(id), OrderDirection.Outgoing, OrderSource.App, OrderContent("طلب $id", null, null),
    OrderVisualStatus.NeedsReply, Instant.parse(time), null,
)
fun main() {
    val pending = PendingOutgoingOrder(
        "client-1", null, "فلتر هواء", Instant.parse("2026-07-28T10:00:00Z"),
        OrderSynchronization.WaitingForNetwork,
    )
    val offline = OutgoingTimelineMerger.merge(emptyList(), pending)
    expect("offline item visible", offline.single() is OutgoingTimelineItem.Pending)
    expect("offline state separate", (offline.single() as OutgoingTimelineItem.Pending).submission.synchronization == OrderSynchronization.WaitingForNetwork)
    expect("pending has no money", PendingOutgoingOrder::class.java.declaredFields.none { it.name.contains("amount", true) || it.name.contains("balance", true) })
    val retry = pending.copy(synchronization = OrderSynchronization.RetryableFailure)
    expect("retry remains visible", OutgoingTimelineMerger.merge(emptyList(), retry).single() is OutgoingTimelineItem.Pending)
    val accepted = pending.copy(serverRequestId = "server-1", synchronization = OrderSynchronization.AcceptedWaitingForReadModel)
    expect("accepted waits for read model", OutgoingTimelineMerger.merge(emptyList(), accepted).single() is OutgoingTimelineItem.Pending)
    val synchronized = OutgoingTimelineMerger.merge(listOf(remote("server-1", "2026-07-28T10:01:00Z")), accepted)
    expect("server item replaces pending", synchronized.single() is OutgoingTimelineItem.Synchronized)
    val sorted = OutgoingTimelineMerger.merge(listOf(remote("old", "2026-07-27T10:00:00Z"), remote("new", "2026-07-28T10:00:00Z")), null)
    expect("remote newest first", (sorted.first() as OutgoingTimelineItem.Synchronized).order.id.value == "new")
    val incoming = remote("incoming", "2026-07-29T10:00:00Z").copy(direction = OrderDirection.Incoming)
    expect("incoming filtered", OutgoingTimelineMerger.merge(listOf(incoming), null).isEmpty())
    expect("business statuses unchanged", remote("x", "2026-07-28T10:00:00Z").status == OrderVisualStatus.NeedsReply)
    expect("accepted requires server id", runCatching { pending.copy(synchronization = OrderSynchronization.AcceptedWaitingForReadModel) }.isFailure)
    println("Outgoing timeline harness passed: $passed/$passed")
}
