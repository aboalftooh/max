package com.maxnetwork.feature.orders.harness

import com.maxnetwork.feature.orders.domain.*
import java.time.Instant
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.coroutines.*

private var passed = 0
private fun checkThat(name: String, condition: Boolean) {
    check(condition) { name }
    passed++
    println("PASS: $name")
}

private fun order(id: String, direction: OrderDirection, time: String, status: OrderVisualStatus = OrderVisualStatus.NeedsReply, invoice: String? = null) =
    OrderReadModel(OrderId(id), direction, OrderSource.App, OrderContent(id, null, null), status,
        Instant.parse(time), invoice?.let(::InvoiceReference))

private fun <T> runSuspend(block: suspend () -> T): T {
    val latch = CountDownLatch(1)
    var outcome: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context: CoroutineContext = EmptyCoroutineContext
        override fun resumeWith(result: Result<T>) { outcome = result; latch.countDown() }
    })
    check(latch.await(5, TimeUnit.SECONDS))
    return outcome!!.getOrThrow()
}

fun main() {
    checkThat("directions are explicit", OrderDirection.entries.size == 2)
    checkThat("sources are explicit", OrderSource.entries.size == 3)
    checkThat("visual statuses are exact", OrderVisualStatus.entries.map { it.name } == listOf("NeedsReply", "Provided", "Unavailable"))
    checkThat("text preview", OrderContent("  فلتر زيت  ", null, null).preview == "فلتر زيت")
    checkThat("image preview", OrderContent(null, OrderMedia("https://media.invalid/a", Instant.MAX, "image/jpeg"), null).preview == "صورة مرفقة")
    checkThat("audio preview", OrderContent(null, null, OrderMedia("https://media.invalid/a", Instant.MAX, "audio/mp4")).preview == "رسالة صوتية")
    checkThat("combined media preview", OrderContent(null, OrderMedia("https://media.invalid/a", Instant.MAX, "image/jpeg"), OrderMedia("https://media.invalid/b", Instant.MAX, "audio/mp4")).preview == "صورة ورسالة صوتية")
    checkThat("limit lower bound", runCatching { OrderQuery(OrderDirection.Incoming, limit = 0) }.isFailure)
    checkThat("limit upper bound", runCatching { OrderQuery(OrderDirection.Incoming, limit = 51) }.isFailure)
    checkThat("empty cursor rejected", runCatching { OrderCursor("") }.isFailure)
    checkThat("empty order content rejected", runCatching { OrderContent(null, null, null) }.isFailure)
    checkThat("insecure media rejected", runCatching { OrderMedia("http://media.invalid/a", Instant.MAX, "image/jpeg") }.isFailure)
    checkThat("unavailable invoice rejected", runCatching { order("x", OrderDirection.Incoming, "2026-07-28T00:00:00Z", OrderVisualStatus.Unavailable, "inv") }.isFailure)

    val old = order("old", OrderDirection.Incoming, "2026-07-27T00:00:00Z")
    val newest = order("new", OrderDirection.Incoming, "2026-07-28T00:00:00Z")
    val outgoing = order("out", OrderDirection.Outgoing, "2026-07-29T00:00:00Z")
    val repository = object : OrderReadRepository {
        override suspend fun getOrders(query: OrderQuery) = OrderReadResult.Success(OrderPage(listOf(old, newest, newest, outgoing), OrderCursor("2")))
        override suspend fun getOrder(id: OrderId) = if (id.value == newest.id.value) OrderReadResult.Success(newest) else OrderReadResult.Failure(OrderReadFailure.NotFound)
    }
    val page = runSuspend { LoadOrdersPageUseCase(repository)(OrderQuery(OrderDirection.Incoming)) } as OrderReadResult.Success
    checkThat("direction filter", page.value.items.all { it.direction == OrderDirection.Incoming })
    checkThat("deduplication", page.value.items.size == 2)
    checkThat("newest first", page.value.items.map { it.id.value } == listOf("new", "old"))
    checkThat("cursor retained", page.value.nextCursor?.value == "2")
    checkThat("single order load", runSuspend { LoadOrderUseCase(repository)(OrderId("new")) } is OrderReadResult.Success)
    checkThat("not found retained", runSuspend { LoadOrderUseCase(repository)(OrderId("none")) } is OrderReadResult.Failure)

    val fieldNames = OrderReadModel::class.java.declaredFields.map { it.name.lowercase() }
    checkThat("no competitor field", fieldNames.none { "competitor" in it || "store" in it })
    checkThat("no inventory field", fieldNames.none { "inventory" in it || "stock" in it })
    checkThat("no financial movement field", fieldNames.none { "amount" in it || "balance" in it || "movement" in it })
    println("Order read harness passed: $passed/$passed")
}
