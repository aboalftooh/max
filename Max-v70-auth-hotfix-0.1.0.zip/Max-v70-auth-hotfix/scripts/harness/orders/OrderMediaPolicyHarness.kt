import com.maxnetwork.feature.orders.domain.OrderMedia
import com.maxnetwork.feature.orders.domain.OrderMediaAccessPolicy
import com.maxnetwork.feature.orders.domain.OrderMediaAvailability
import com.maxnetwork.feature.orders.domain.OrderMediaKind
import java.time.Instant

private var passed = 0
private fun checkThat(name: String, condition: Boolean) {
    check(condition) { name }
    passed += 1
    println("PASS: $name")
}

fun main() {
    val now = Instant.parse("2026-07-28T18:00:00Z")
    val image = OrderMedia("https://media.max.test/i", now.plusSeconds(120), "image/jpeg")
    val audio = OrderMedia("https://media.max.test/a", now.plusSeconds(120), "audio/mp4")

    checkThat("fresh image accepted", OrderMediaAccessPolicy.evaluate(image, OrderMediaKind.Image, now) == OrderMediaAvailability.Available)
    checkThat("fresh audio accepted", OrderMediaAccessPolicy.evaluate(audio, OrderMediaKind.Audio, now) == OrderMediaAvailability.Available)
    checkThat("expired media rejected", OrderMediaAccessPolicy.evaluate(image.copy(expiresAt = now), OrderMediaKind.Image, now) == OrderMediaAvailability.Expired)
    checkThat("near-expiry media refreshes early", OrderMediaAccessPolicy.evaluate(image.copy(expiresAt = now.plusSeconds(10)), OrderMediaKind.Image, now) == OrderMediaAvailability.Expired)
    checkThat("outside refresh leeway remains available", OrderMediaAccessPolicy.evaluate(image.copy(expiresAt = now.plusSeconds(16)), OrderMediaKind.Image, now) == OrderMediaAvailability.Available)
    checkThat("wrong image type rejected", OrderMediaAccessPolicy.evaluate(audio, OrderMediaKind.Image, now) == OrderMediaAvailability.Unsupported)
    checkThat("wrong audio type rejected", OrderMediaAccessPolicy.evaluate(image, OrderMediaKind.Audio, now) == OrderMediaAvailability.Unsupported)
    checkThat("content type matching is case insensitive", OrderMediaAccessPolicy.evaluate(image.copy(contentType = "IMAGE/WEBP"), OrderMediaKind.Image, now) == OrderMediaAvailability.Available)
    checkThat("http links are forbidden", runCatching { OrderMedia("http://media.max.test/i", now.plusSeconds(60), "image/jpeg") }.isFailure)
    checkThat("blank content type is forbidden", runCatching { OrderMedia("https://media.max.test/i", now.plusSeconds(60), "") }.isFailure)

    println("order media policy checks passed: $passed/$passed")
}
