import com.maxnetwork.backend.request.domain.RequestPrincipal
import com.maxnetwork.backend.request.domain.StoreId
import com.maxnetwork.backend.request.domain.UserId
import com.maxnetwork.backend.request.media.HmacPrivateMediaUrlIssuer
import com.maxnetwork.backend.request.media.MediaAccessClock
import com.maxnetwork.backend.request.media.MediaAccessFailure
import com.maxnetwork.backend.request.media.MediaAccessResult
import com.maxnetwork.backend.request.media.OrderMediaAccessService
import com.maxnetwork.backend.request.media.OrderMediaAuthorizer
import com.maxnetwork.backend.request.media.PrivateMediaCatalog
import com.maxnetwork.backend.request.media.PrivateMediaId
import com.maxnetwork.backend.request.media.PrivateOrderMedia
import java.net.URI
import java.time.Duration
import java.time.Instant

private var passed = 0
private fun checkThat(name: String, condition: Boolean) {
    check(condition) { name }
    passed += 1
    println("PASS: $name")
}

fun main() {
    val now = Instant.parse("2026-07-28T18:00:00Z")
    val principal = RequestPrincipal(StoreId("store-a"), UserId("user-a"))
    val mediaId = PrivateMediaId("med_7f0c2a9d")
    val media = PrivateOrderMedia(mediaId, "order-secret-42", "image/jpeg")
    val catalog = PrivateMediaCatalog { id -> if (id == mediaId) media else null }
    val authorizer = OrderMediaAuthorizer { current, orderId -> current.storeId == principal.storeId && orderId == media.orderId }
    val issuer = HmacPrivateMediaUrlIssuer("https://media.max.test", ByteArray(32) { (it + 1).toByte() })
    val service = OrderMediaAccessService(catalog, authorizer, issuer, MediaAccessClock { now })

    val result = service.issue(principal, mediaId)
    checkThat("authorized media link issued", result is MediaAccessResult.Success)
    val link = (result as MediaAccessResult.Success).link
    checkThat("link uses HTTPS", link.url.startsWith("https://"))
    checkThat("link expires in five minutes", link.expiresAt == now.plus(Duration.ofMinutes(5)))
    checkThat("link does not expose store", "store-a" !in link.url)
    checkThat("link does not expose order", "order-secret-42" !in link.url)
    checkThat("content type preserved", link.contentType == "image/jpeg")

    val uri = URI(link.url)
    val query = uri.rawQuery.split('&').associate { part -> part.substringBefore('=') to part.substringAfter('=') }
    val expires = query.getValue("expires").toLong()
    val signature = query.getValue("signature")
    checkThat("signature valid before expiry", issuer.verify(mediaId, expires, signature, now.plusSeconds(299)))
    checkThat("signature invalid at expiry", !issuer.verify(mediaId, expires, signature, now.plusSeconds(300)))
    checkThat("tampered signature rejected", !issuer.verify(mediaId, expires, signature + "x", now))

    val denied = service.issue(RequestPrincipal(StoreId("store-b"), UserId("user-b")), mediaId)
    checkThat("unauthorized store denied", denied == MediaAccessResult.Failure(MediaAccessFailure.Forbidden))
    val missing = service.issue(principal, PrivateMediaId("missing"))
    checkThat("missing media hidden", missing == MediaAccessResult.Failure(MediaAccessFailure.NotFound))
    checkThat("long-lived TTL forbidden", runCatching {
        OrderMediaAccessService(catalog, authorizer, issuer, MediaAccessClock { now }, Duration.ofMinutes(11))
    }.isFailure)
    checkThat("weak signing secret forbidden", runCatching {
        HmacPrivateMediaUrlIssuer("https://media.max.test", ByteArray(8))
    }.isFailure)

    println("private media access checks passed: $passed/$passed")
}
