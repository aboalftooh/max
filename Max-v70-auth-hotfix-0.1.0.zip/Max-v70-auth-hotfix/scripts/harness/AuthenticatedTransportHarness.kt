package com.maxnetwork.harness

import com.maxnetwork.core.network.InMemoryBearerTokenStore
import com.maxnetwork.core.network.isProtectedMaxApiPath

fun main() {
    var passed = 0
    fun verify(condition: Boolean, message: String) {
        check(condition) { message }
        passed += 1
    }

    val store = InMemoryBearerTokenStore()
    verify(store.current() == null, "token starts empty")
    store.update("first")
    verify(store.current() == "first", "token stored in memory")
    store.update("rotated")
    verify(store.current() == "rotated", "token rotates")
    store.update("")
    verify(store.current() == null, "blank token clears")
    store.update("secret")
    store.update(null)
    verify(store.current() == null, "logout clears token")

    listOf(
        "/v1/requests",
        "/v1/orders",
        "/v1/balance",
        "/v1/profile",
        "/v1/profile/deletion-requests",
        "/v1/notifications",
        "/v1/push/installations/device",
        "/v1/media/upload-intents",
    ).forEach { path -> verify(isProtectedMaxApiPath(path), "$path is protected") }

    listOf(
        "/v1/auth/sessions",
        "/v1/auth/phone-challenges",
        "/health",
        "https://storage.example/upload",
    ).forEach { path -> verify(!isProtectedMaxApiPath(path), "$path is public or external") }

    println("AUTHENTICATED_TRANSPORT_TESTS_PASSED=$passed")
}
