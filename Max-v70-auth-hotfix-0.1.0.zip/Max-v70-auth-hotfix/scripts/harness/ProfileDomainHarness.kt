import com.maxnetwork.feature.profile.domain.MaxSupportContact
import com.maxnetwork.feature.profile.domain.SupportChannel

fun main() {
    var checks = 0
    fun verify(value: Boolean, message: String) {
        checks += 1
        check(value) { message }
    }

    val whatsapp = MaxSupportContact("+249912000001", "https://wa.me/249912000001").preferredChannel()
    verify(whatsapp is SupportChannel.WhatsApp, "approved WhatsApp HTTPS URL is accepted")

    val fallback = MaxSupportContact("+249912000001", "http://wa.me/unsafe").preferredChannel()
    verify(fallback is SupportChannel.Phone, "unsafe URL falls back to declared phone")

    val invalid = MaxSupportContact("not-a-phone", "javascript:alert(1)").preferredChannel()
    verify(invalid == null, "unsafe channels are rejected")

    val phone = MaxSupportContact("249 912 000 001", "").preferredChannel()
    verify(phone is SupportChannel.Phone, "spaced phone is accepted after validation")

    println("profile-domain-harness: $checks/$checks passed")
}
