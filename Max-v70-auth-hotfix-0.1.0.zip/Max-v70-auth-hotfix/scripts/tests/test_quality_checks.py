from __future__ import annotations
import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


architecture = load('architecture_check', ROOT / 'scripts' / 'architecture-check.py')
secrets = load('secret_scan', ROOT / 'scripts' / 'secret-scan.py')


class QualityCheckTests(unittest.TestCase):
    def test_architecture_checker_detects_feature_dependency(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            build = root / 'feature' / 'auth' / 'build.gradle.kts'
            build.parent.mkdir(parents=True)
            build.write_text('implementation(project(":feature:home"))', encoding='utf-8')
            self.assertTrue(architecture.violations(root))

    def test_secret_scanner_detects_private_key(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / 'sample.kt'
            source.write_text('-----BEGIN ' + 'PRIVATE KEY-----', encoding='utf-8')
            self.assertTrue(secrets.scan(root))

    def test_current_android_tree_has_no_architecture_violation(self):
        self.assertEqual([], architecture.violations(ROOT / 'android'))


if __name__ == '__main__':
    unittest.main()
