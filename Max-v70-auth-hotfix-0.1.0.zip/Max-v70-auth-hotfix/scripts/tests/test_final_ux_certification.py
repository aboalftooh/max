import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]


class FinalUxCertificationTests(unittest.TestCase):
    def test_static_final_certification(self):
        script = ROOT / "scripts" / "final-ux-certification-check.py"
        spec = importlib.util.spec_from_file_location("final_ux_certification_check", script)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        self.assertGreaterEqual(len(module.checks()), 7)


if __name__ == "__main__":
    unittest.main()
