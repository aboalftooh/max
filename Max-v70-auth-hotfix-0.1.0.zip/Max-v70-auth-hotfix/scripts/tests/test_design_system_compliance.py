from __future__ import annotations

import subprocess
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "check_design_system_compliance"


class DesignSystemComplianceTest(unittest.TestCase):
    def make_root(self, source: str, allowlisted: bool) -> tuple[tempfile.TemporaryDirectory[str], Path]:
        temp = tempfile.TemporaryDirectory()
        root = Path(temp.name)
        ui = root / "android/feature/demo/src/main/java/DemoScreen.kt"
        ui.parent.mkdir(parents=True)
        ui.write_text(source, encoding="utf-8")
        allowlist = root / "allowlist.txt"
        allowlist.write_text(
            "android/feature/demo/src/main/java/DemoScreen.kt\n" if allowlisted else "",
            encoding="utf-8",
        )
        self.addCleanup(temp.cleanup)
        return temp, root

    def run_guard(self, root: Path) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [str(SCRIPT), "--root", str(root), "--allowlist", "allowlist.txt"],
            check=False,
            capture_output=True,
            text=True,
        )

    def test_allowlisted_legacy_violation_passes(self) -> None:
        _, root = self.make_root('@Composable fun Demo() { Box(Modifier.padding(12.dp)) }', True)
        result = self.run_guard(root)
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_non_allowlisted_violation_fails(self) -> None:
        _, root = self.make_root('@Composable fun Demo() { Box(Modifier.padding(12.dp)) }', False)
        result = self.run_guard(root)
        self.assertNotEqual(0, result.returncode)
        self.assertIn("dp-literal", result.stdout)

    def test_non_allowlisted_max_components_pass(self) -> None:
        _, root = self.make_root('@Composable fun Demo() { MaxPrimaryButton("OK", {}) }', False)
        result = self.run_guard(root)
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
