from __future__ import annotations
import importlib.util
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('contract_check', ROOT / 'scripts' / 'contract-check.py')
contract_check = importlib.util.module_from_spec(spec)
assert spec.loader
spec.loader.exec_module(contract_check)


class ContractTests(unittest.TestCase):
    def test_all_contract_invariants(self):
        passed = contract_check.checks()
        self.assertGreaterEqual(len(passed), 11)


if __name__ == '__main__':
    unittest.main()
