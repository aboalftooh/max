from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


class BackendAuthStructureTest(unittest.TestCase):
    def test_all_authentication_security_checks_pass(self) -> None:
        script = Path(__file__).resolve().parents[1] / "backend-auth-check.py"
        spec = importlib.util.spec_from_file_location("backend_auth_check", script)
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        failed = [name for name, passed in module.run_checks() if not passed]
        self.assertEqual([], failed)


if __name__ == "__main__":
    unittest.main()
