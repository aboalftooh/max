#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks: list[str] = []


def expect(condition: bool, name: str) -> None:
    if not condition:
        raise AssertionError(name)
    checks.append(name)


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


service = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/application/VertoInvoiceProjectionService.kt")
models = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/domain/InvoiceProjectionModels.kt")
ledger_models = read("backend/src/main/kotlin/com/maxnetwork/backend/balance/domain/FinancialLedgerModels.kt")
store = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/infrastructure/InMemoryInvoiceProjectionStore.kt")
synchronizer = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/application/VertoInvoiceSynchronizer.kt")
ports = read("backend/src/main/kotlin/com/maxnetwork/backend/request/ports/RequestPorts.kt")
sql_v3 = read("backend/src/main/resources/db/migration/V003__verto_invoice_order_projection.sql")
sql_v4 = read("backend/src/main/resources/db/migration/V004__invoice_financial_ledger.sql")
openapi = read("contracts/api/openapi.yaml")

expect("VertoEventType.SaleRecorded -> InvoiceOrderDirection.Outgoing" in service, "sale-to-outgoing")
expect("VertoEventType.PurchaseRecorded -> InvoiceOrderDirection.Incoming" in service, "purchase-to-incoming")
expect("UnsupportedEvent" in service and "PaymentRecorded" not in service, "later-events-not-projected")
expect('event.payload.currency != "SDG"' in service, "sdg-only")
expect("amountMinorUnits <= 0" in service and "InvalidAmount" in service, "positive-invoice-amount")
expect("InvoiceProjectionFailureKind.InvalidEvent" in service, "malformed-event-rejected")
expect('MessageDigest.getInstance("SHA-256")' in service, "cryptographic-payload-fingerprint")
expect("findByRequestId" in service and "request.storeId != storeId" in service, "same-store-request-link")
expect("findEventById" in service and "findEventByIdempotencyKey" in service, "event-idempotency-lookup")
expect("FinancialMovementDraft" in service and "direction.toMovementType()" in service, "invoice-to-ledger-draft")
expect("IncomingOrder" in service and "OutgoingOrder" in service, "direction-to-movement-type")
expect("ProcessedInvoiceEvent" in service and "movementId = movement.movementId" in service, "event-links-movement")
expect("projections.commit(receipt, order, movement)" in service, "atomic-unit-of-work-call")
expect("BalanceOverflow" in service, "balance-overflow-rejected")
expect("data class Applied" in models and "val movement:" in models, "result-returns-movement")
expect("signedDeltaMinorUnits" in ledger_models and "balanceAfterMinorUnits" in ledger_models, "ledger-financial-fields")
expect("require(amountMinorUnits > 0)" in ledger_models, "ledger-positive-amount")
expect("@Synchronized" in store and "CommitResult.Duplicate" in store, "atomic-in-memory-projection")
expect("Math.addExact" in store and "Math.incrementExact" in store, "overflow-safe-ledger")
expect("movementsByEventId" in store and "balancesByStore" in store, "ledger-indexes-and-balance")
expect("isConsistent(event, order, movement)" in store, "cross-record-consistency")
expect("data class FinancialReferenceKey" in store, "collision-safe-financial-reference-key")
expect("acknowledgedIds += event.eventId" in synchronizer and "Rejected -> rejected" in synchronizer, "acknowledge-only-safe-events")
expect("cursorAdvanced = rejected == 0" in synchronizer and "else afterCursor" in synchronizer, "cursor-does-not-skip-rejected-event")
expect("fun findByRequestId(requestId: String)" in ports, "request-id-lookup-port")
expect("idempotency_key text not null unique" in sql_v3, "database-idempotency-key")
expect("unique (store_id, source_reference)" in sql_v3, "invoice-reference-unique-per-store")
expect("foreign key (request_id, store_id)" in sql_v3, "database-same-store-request-link")
expect("foreign key (image_upload_id, store_id)" in sql_v3 and "foreign key (audio_upload_id, store_id)" in sql_v3, "database-same-store-media-link")
expect("foreign key (source_event_id, store_id)" in sql_v3, "database-same-store-event-link")
expect("create table if not exists max_finance.financial_movement" in sql_v4, "database-financial-ledger")
expect("create table if not exists max_finance.store_balance" in sql_v4, "database-balance-snapshot")
expect("unique (source_event_id)" in sql_v4, "database-one-movement-per-event")
expect("unique (store_id, sequence_no)" in sql_v4, "database-store-sequence")
expect("PURCHASE_RECORDED' then 'INCOMING_ORDER'" in sql_v4, "database-purchase-incoming")
expect("SALE_RECORDED' then 'OUTGOING_ORDER'" in sql_v4, "database-sale-outgoing")
expect("for update" in sql_v4.lower(), "database-balance-row-lock")
expect("after insert on max_integration.verto_invoice_event" in sql_v4, "database-same-transaction-trigger")
expect("constraint trigger" in sql_v4 and "deferrable initially deferred" in sql_v4, "database-event-requires-order-at-commit")
expect("financial ledger is append-only" in sql_v4, "database-append-only-guard")
expect("enable row level security" in sql_v4 and "tenant_isolation" in sql_v4, "ledger-tenant-rls")
order_table = sql_v3.split("create table if not exists max_request.order_read_model", 1)[1]
expect(all(token not in order_table.split("create index", 1)[0] for token in ("amount_minor_units", "balance_after", "payment_id")), "order-read-model-no-finance")
expect("invoiceReference" in openapi and "Internal Verto reference only" in openapi, "openapi-internal-invoice-reference")
expect("BalanceMovement" in openapi and "balanceAfter" in openapi, "openapi-read-only-ledger-shape")
for forbidden in ("competitorName", "competitorInventory", "stockQuantity"):
    expect(forbidden not in service + models + ledger_models + openapi, f"no-{forbidden}")

print(f"Verto invoice and ledger checks passed: {len(checks)}/{len(checks)}")
for check in checks:
    print(f"- {check}")
