#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import yaml
from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[1]
OPENAPI = ROOT / 'contracts' / 'api' / 'openapi.yaml'
VERTO_SCHEMA = ROOT / 'contracts' / 'verto' / 'verto-events.schema.json'
FIXTURES = ROOT / 'contracts' / 'fixtures'

REQUIRED_PATHS = {
    '/v1/auth/registration-codes/validate',
    '/v1/auth/phone-challenges',
    '/v1/auth/sessions',
    '/v1/auth/sessions/refresh',
    '/v1/requests',
    '/v1/orders',
    '/v1/balance',
    '/v1/balance/movements',
    '/v1/profile',
    '/v1/notifications',
}
MUTATING = {'post', 'put', 'patch', 'delete'}


def load_openapi() -> dict:
    return yaml.safe_load(OPENAPI.read_text(encoding='utf-8'))


def checks() -> list[str]:
    api = load_openapi()
    passed: list[str] = []
    assert api['openapi'].startswith('3.1')
    passed.append('openapi-3.1')
    assert REQUIRED_PATHS <= set(api['paths'])
    passed.append('required-paths')

    for path, operations in api['paths'].items():
        if path.startswith('/v1/balance'):
            assert not (set(operations) & MUTATING), f'financial mutation exposed at {path}'
    passed.append('no-financial-mutations')

    schemas = api['components']['schemas']
    order_text = json.dumps(
        {'Order': schemas['Order'], 'OrderContent': schemas['OrderContent']},
        ensure_ascii=False,
    ).lower()
    for forbidden in ('competitor', 'inventory', 'stock', 'invoiceitems', 'competitorname'):
        assert forbidden not in order_text, f'forbidden order field: {forbidden}'
    passed.append('order-privacy')

    assert schemas['Money']['properties']['currency']['enum'] == ['SDG']
    assert schemas['Money']['properties']['minorUnits']['type'] == 'integer'
    passed.append('money-sdg-integer')

    assert api['components']['parameters']['Limit']['schema']['maximum'] == 50
    for page in ('OrderPage', 'BalanceMovementPage', 'NotificationPage'):
        assert 'nextCursor' in schemas[page]['properties']
    passed.append('cursor-pagination')

    request_post = api['paths']['/v1/requests']['post']
    refs = [parameter.get('$ref', '') for parameter in request_post['parameters']]
    assert '#/components/parameters/IdempotencyKey' in refs
    assert 'never creates a financial movement' in request_post['description']
    passed.append('request-idempotency-no-ledger-write')

    for schema_name, schema in schemas.items():
        for prop_name, prop in schema.get('properties', {}).items():
            if prop_name.endswith('At') and isinstance(prop, dict) and '$ref' not in prop:
                assert prop.get('format') == 'date-time', f'{schema_name}.{prop_name} lacks date-time'
    passed.append('rfc3339-time-fields')

    verto_schema = json.loads(VERTO_SCHEMA.read_text(encoding='utf-8'))
    required = set(verto_schema['required'])
    assert {'eventId', 'idempotencyKey', 'eventType', 'occurredAt', 'payload'} <= required
    enum = verto_schema['properties']['eventType']['enum']
    assert 'CORRECTION_RECORDED' in enum and 'RETURN_RECORDED' in enum
    passed.append('verto-event-envelope')

    validator = Draft202012Validator(verto_schema, format_checker=FormatChecker())
    events = json.loads((FIXTURES / 'verto-events.json').read_text(encoding='utf-8'))
    errors = [error.message for event in events for error in validator.iter_errors(event)]
    assert not errors, errors
    passed.append('verto-fixtures-valid')

    orders = json.loads((FIXTURES / 'orders.json').read_text(encoding='utf-8'))
    fixture_text = json.dumps(orders, ensure_ascii=False).lower()
    assert 'competitor' not in fixture_text and 'inventory' not in fixture_text
    assert [item['occurredAt'] for item in orders['items']] == sorted(
        [item['occurredAt'] for item in orders['items']], reverse=True
    )
    passed.append('order-fixtures-private-newest-first')

    android_sources = '\n'.join(
        p.read_text(encoding='utf-8', errors='ignore')
        for p in (ROOT / 'android').rglob('*.kt')
    )
    assert 'interface VertoGateway' not in android_sources
    backend_source = ROOT / 'backend' / 'src' / 'main' / 'kotlin' / 'com' / 'maxnetwork' / 'backend' / 'integration' / 'verto' / 'VertoGateway.kt'
    assert backend_source.is_file()
    passed.append('verto-boundary-backend-only')
    return passed


def main() -> int:
    passed = checks()
    print(f'Contract checks passed: {len(passed)}/{len(passed)}')
    for item in passed:
        print(f'- {item}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
