#!/usr/bin/env python3
from pathlib import Path

root=Path(__file__).resolve().parents[1]
manifest=(root/'android/feature/request/src/main/AndroidManifest.xml').read_text()
engine=(root/'android/feature/request/src/main/java/com/maxnetwork/feature/request/media/AndroidAudioEngines.kt').read_text()
controller=(root/'android/feature/request/src/main/java/com/maxnetwork/feature/request/media/RequestAudioController.kt').read_text()
ui=(root/'android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestAudioAttachmentSection.kt').read_text()
checks={
 'record_audio_permission_declared':'android.permission.RECORD_AUDIO' in manifest,
 'permission_requested_on_action':'RequestPermission' in ui and 'request_audio_start' in ui,
 'permission_explained':'request_audio_permission_explanation' in ui,
 'aac_encoder':'AudioEncoder.AAC' in engine,
 'm4a_private_file':'audioRoot' in controller and '.m4a' in controller,
 'duration_limit_engine':'setMaxDuration(60_000)' in engine,
 'duration_limit_policy':'MAX_AUDIO_DURATION_SECONDS' in controller,
 'file_limit_engine':'setMaxFileSize(5L * 1024L * 1024L)' in engine,
 'file_limit_policy':'MAX_AUDIO_BYTES' in controller,
 'recording_indicator':'request_audio_recording_indicator' in ui,
 'stop_action':'request_audio_stop' in ui,
 'play_action':'request_audio_play' in ui,
 'delete_action':'request_audio_delete' in ui,
 'audio_focus_interruption':'AUDIOFOCUS_LOSS_TRANSIENT' in engine,
 'host_stop':'Lifecycle.Event.ON_STOP' in ui and 'onHostStopped' in controller,
 'dispose_closes':'onDispose' in ui and 'controller.close()' in ui,
 'no_storage_permission':'READ_EXTERNAL_STORAGE' not in manifest and 'WRITE_EXTERNAL_STORAGE' not in manifest,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(f"{'PASS' if v else 'FAIL'} {k}")
if failed: raise SystemExit('Failed: '+', '.join(failed))
print(f"RESULT {len(checks)}/{len(checks)}")
