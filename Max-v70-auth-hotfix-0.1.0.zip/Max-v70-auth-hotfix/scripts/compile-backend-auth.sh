#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT

mapfile -d '' SOURCES < <(find \
  "$ROOT/backend/src/main/kotlin" \
  "$ROOT/backend/src/test/kotlin" \
  -name '*.kt' -print0 | sort -z)

kotlinc "${SOURCES[@]}" \
  -Werror \
  -jvm-target 17 \
  -include-runtime \
  -d "$OUT/auth-security-tests.jar"

java -cp "$OUT/auth-security-tests.jar" com.maxnetwork.backend.auth.AuthSecurityTestKt
