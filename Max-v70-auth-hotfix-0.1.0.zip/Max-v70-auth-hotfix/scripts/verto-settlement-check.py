#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = 0

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def expect(condition: bool, name: str) -> None:
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {name}")
    checks += 1

models = read("backend/src/main/kotlin/com/maxnetwork/backend/balance/domain/FinancialLedgerModels.kt")
service = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/settlement/application/VertoSettlementProjectionService.kt")
store = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/infrastructure/InMemoryInvoiceProjectionStore.kt")
sync = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/application/VertoFinancialSynchronizer.kt")
sql = read("backend/src/main/resources/db/migration/V005__verto_payments_receipts_ledger.sql")
module = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/VertoInvoiceModule.kt")

expect("Payment" in models and "Receipt" in models, "movement-types")
expect("FinancialMovementType.Payment" in models and "-> -amountMinorUnits" in models, "payment-negative")
expect("FinancialMovementType.Receipt" in models and "-> amountMinorUnits" in models, "receipt-positive")
expect("event.payload.requestId != null" in service, "settlement-no-order-link")
expect("findSettlementEventById" in service and "findSettlementEventByIdempotencyKey" in service, "idempotency-precheck")
expect("movementIdsByReference.containsKey" in store, "reference-uniqueness-in-commit")
expect("commitSettlement" in store and "@Synchronized" in store, "atomic-in-memory-settlement")
expect("invoiceEventsById.containsKey" in store and "settlementEventsById.containsKey" in store, "cross-type-event-conflict")
expect("movementIdsByReference" in store, "shared-reference-index")
expect("VertoEventType.PaymentRecorded" in sync and "VertoEventType.ReceiptRecorded" in sync, "unified-sync-settlements")
expect("VertoEventType.CorrectionRecorded" in sync and "adjustmentProjector.project" in sync, "adjustments-dispatched-separately")
expect("VertoFinancialSynchronizer" in module and "VertoSettlementProjectionService" in module, "module-wiring")
expect("verto_financial_event" in sql, "shared-financial-inbox")
expect("PAYMENT_RECORDED" in sql and "RECEIPT_RECORDED" in sql, "sql-settlement-types")
expect("when 'PAYMENT_RECORDED' then -new.amount_minor_units" in sql, "sql-payment-negative")
expect("when 'RECEIPT_RECORDED' then new.amount_minor_units" in sql, "sql-receipt-positive")
expect("for update" in sql.lower(), "sql-balance-row-lock")
expect("financial_movement_source_financial_event_fk" in sql, "sql-composite-source-fk")
expect("enable row level security" in sql.lower(), "sql-rls")
expect("append_only" in sql and "before update or delete" in sql.lower(), "sql-append-only")
expect("deferrable initially deferred" in sql.lower(), "sql-deferred-projection-check")
expect("request_id is null" in sql.lower(), "sql-settlement-no-request")
expect("Android" not in service and "android" not in service, "backend-only-service")

print(f"VertoSettlementCheck: {checks}/{checks} checks passed")
