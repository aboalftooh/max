#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/verification-artifacts/request-image-workflow.jar"
kotlinc "$ROOT/scripts/harness/RequestImageWorkflowHarness.kt" -Werror -include-runtime -d "$OUT"
java -jar "$OUT"
