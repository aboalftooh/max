#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
orders = ROOT / 'android/feature/orders/src/main/java/com/maxnetwork/feature/orders'
presentation = orders / 'presentation'
destination = (ROOT/'android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt').read_text()
push = (ROOT/'android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/PushModels.kt').read_text()
checks = [
    ('orders-presentation-removed', not presentation.exists() or not any(presentation.glob('*.kt'))),
    ('incoming-screen-removed', not (presentation/'OrdersScreen.kt').exists()),
    ('incoming-legacy-route-kept', 'data object IncomingOrders : MaxDestination' in destination),
    ('incoming-route-normalized-home', 'MaxDestination.IncomingOrders.route' in destination and '-> MaxDestination.Home' in destination),
    ('incoming-push-contract-kept', 'PushNavigationTarget.IncomingOrders' in push),
]
failed=[n for n,ok in checks if not ok]
if failed:
    print('incoming orders removal checks failed:')
    for n in failed: print('-',n)
    raise SystemExit(1)
print(f'incoming orders removal checks passed: {len(checks)}/{len(checks)}')
for n,_ in checks: print('-',n)
