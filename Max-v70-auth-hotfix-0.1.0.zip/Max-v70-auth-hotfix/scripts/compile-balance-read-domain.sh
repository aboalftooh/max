#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/balance-read-domain-v30"
rm -rf "$OUT"
mkdir -p "$OUT"
kotlinc \
  "$ROOT/android/core/model/src/main/kotlin/com/maxnetwork/core/model/Money.kt" \
  "$ROOT/android/feature/balance/src/main/java/com/maxnetwork/feature/balance/domain/BalanceReadModel.kt" \
  "$ROOT/android/feature/balance/src/main/java/com/maxnetwork/feature/balance/domain/BalanceReadRepository.kt" \
  "$ROOT/android/feature/balance/src/main/java/com/maxnetwork/feature/balance/domain/BalanceReadUseCases.kt" \
  "$ROOT/scripts/harness/balance/BalanceReadHarness.kt" \
  -Werror -include-runtime -d "$OUT/balance-read-domain.jar"
java -jar "$OUT/balance-read-domain.jar"
