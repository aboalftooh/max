#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks: list[str] = []


def require(condition: bool, name: str) -> None:
    if not condition:
        raise AssertionError(name)
    checks.append(name)


identifiers = (ROOT / "android/core/model/src/main/kotlin/com/maxnetwork/core/model/Identifiers.kt").read_text()
require("@JvmInline value class" not in identifiers, "ktlint-inline-annotation-fixed")
require(identifiers.count("@JvmInline\nvalue class") == 4, "identifier-annotations-on-own-line")

detekt = (ROOT / "config/detekt/detekt.yml").read_text()
forbidden = detekt.split("ForbiddenComment:", 1)[1].split("complexity:", 1)[0]
require("comments:" in forbidden, "detekt-forbidden-comment-comments-schema")
require("values:" not in forbidden, "detekt-invalid-values-removed")

requirements = (ROOT / "requirements-quality.txt").read_text()
require("jsonschema==" in requirements, "jsonschema-pinned")
require("PyYAML==" in requirements, "pyyaml-pinned")
workflow = (ROOT / ".github/workflows/android-quality.yml").read_text()
require("pip install" in workflow and "requirements-quality.txt" in workflow, "ci-installs-python-quality-dependencies")

network_build = (ROOT / "android/core/network/build.gradle.kts").read_text()
require("implementation(libs.kotlinx.coroutines.core)" in network_build, "retrofit-suspend-runtime-present")

auth_build = (ROOT / "android/feature/auth/build.gradle.kts").read_text()
require("implementation(libs.androidx.compose.foundation)" in auth_build, "auth-foundation-dependency-present")

notification_build = (ROOT / "android/feature/notifications/build.gradle.kts").read_text()
require('testImplementation(project(":core:testing"))' in notification_build, "notification-test-fixtures-dependency-present")

image_manager = (
    ROOT
    / "android/feature/request/src/main/java/com/maxnetwork/feature/request/media/AndroidRequestImageManager.kt"
).read_text()
require("BitmapFactory.decodeFile(file.absolutePath)" in image_manager, "bitmap-file-path-type-fixed")
require("let(BitmapFactory::decodeFile)" not in image_manager, "invalid-bitmap-function-reference-removed")

verify = (ROOT / "scripts/verify.sh").read_text()
require("v40-release-repair-check" in verify, "v40-gate-wired")
require("skip_gate ui-smoke" in verify and " false" in verify, "optional-ui-smoke-does-not-block-local-verify")

print(f"V40 release repair checks passed: {len(checks)}/{len(checks)}")
for check in checks:
    print(f"- {check}")
