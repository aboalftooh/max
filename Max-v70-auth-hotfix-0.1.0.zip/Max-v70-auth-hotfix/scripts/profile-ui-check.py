#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
profile = (root / "android/feature/profile/src/main/java/com/maxnetwork/feature/profile/presentation/ProfileScreen.kt").read_text()
privacy = (root / "android/feature/profile/src/main/java/com/maxnetwork/feature/profile/presentation/PrivacyScreen.kt").read_text()
app = (root / "android/app/src/main/java/com/maxnetwork/android/MaxApp.kt").read_text()
main = (root / "android/app/src/main/java/com/maxnetwork/android/MainActivity.kt").read_text()
checks = []

def require(value: bool, name: str) -> None:
    checks.append(name)
    if not value:
        raise SystemExit(f"FAIL: {name}")

ordered = ["profile_name", "profile_store_name", "profile_phone", "profile_contact_max", "profile_privacy", "profile_logout", "profile_delete_account"]
positions = [profile.find(token) for token in ordered]
require(all(position >= 0 for position in positions), "approved profile items exist")
require(positions == sorted(positions), "approved profile order is exact")
for forbidden in ["المدينة", "حالة الحساب", "إعدادات الإشعارات", "الشروط", "اسم المسؤول"]:
    require(forbidden not in profile, f"removed item absent: {forbidden}")
for required in ["البيانات التي نجمعها", "لا يعرض ماكس مخزون", "لا تظهر أسماء المحلات المنافسة", "فيرتو هو مصدر", "نستخدم البيانات", "يمكن طلب حذف الحساب"]:
    require(required in privacy, f"privacy topic exists: {required}")
require('MaxDestination.Privacy' in app, "privacy destination is wired")
require('home_full_header' not in profile and 'home_full_header' not in privacy, "no full header outside home")
require('Uri.parse("tel:${channel.number}")' in main, "phone channel is explicit")
require('SupportChannel.WhatsApp' in main and 'Intent.ACTION_VIEW' in main, "safe external support intent")
require('city' not in profile.lower(), "city field is not modeled in UI")
require('competitor' not in profile.lower(), "competitor identity is not modeled")

print(f"profile-ui-check: {len(checks)}/{len(checks)} passed")
