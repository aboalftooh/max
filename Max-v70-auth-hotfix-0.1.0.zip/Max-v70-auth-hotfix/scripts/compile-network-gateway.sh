#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT_DIR/verification-artifacts/network-gateway"
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"

mapfile -t STUBS < <(find "$ROOT_DIR/scripts/harness/network-stubs" -type f -name '*.kt' | sort)
SOURCES=(
  "$ROOT_DIR/android/core/network/src/main/kotlin/com/maxnetwork/core/network/ApiModels.kt"
  "$ROOT_DIR/android/core/network/src/main/kotlin/com/maxnetwork/core/network/MaxGateway.kt"
  "$ROOT_DIR/android/core/network/src/main/kotlin/com/maxnetwork/core/network/AuthNetworkEvents.kt"
  "$ROOT_DIR/android/core/network/src/main/kotlin/com/maxnetwork/core/network/BearerTokenStore.kt"
  "$ROOT_DIR/android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt"
)

kotlinc -Werror "${STUBS[@]}" "${SOURCES[@]}" -d "$OUT_DIR/network-gateway.jar"
echo "NETWORK_GATEWAY_COMPILE_PASSED=5"
