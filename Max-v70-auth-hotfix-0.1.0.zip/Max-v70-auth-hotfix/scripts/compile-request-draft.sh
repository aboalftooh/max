#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/verification-artifacts/request-draft-harness.jar"
mkdir -p "$(dirname "$OUT")"
kotlinc \
  "$ROOT/android/feature/request/src/main/java/com/maxnetwork/feature/request/domain/RequestModels.kt" \
  "$ROOT/scripts/harness/RequestDraftHarness.kt" \
  -Werror -include-runtime -d "$OUT"
java -jar "$OUT"
