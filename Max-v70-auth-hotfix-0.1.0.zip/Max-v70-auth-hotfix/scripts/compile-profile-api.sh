#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/profile-api-v35"
rm -rf "$OUT"
mkdir -p "$OUT"
mapfile -d '' SOURCES < <(find "$ROOT/backend/src/main/kotlin" -name '*.kt' -print0)
kotlinc "${SOURCES[@]}" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/profile/ProfileApiTest.kt" \
  -Werror -d "$OUT"
kotlin -classpath "$OUT" com.maxnetwork.backend.profile.ProfileApiTestKt
