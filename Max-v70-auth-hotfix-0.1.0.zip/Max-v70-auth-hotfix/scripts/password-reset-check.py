#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def read(path): return (ROOT/path).read_text(encoding='utf-8')
def tree(path): return '\n'.join(p.read_text(encoding='utf-8') for p in sorted((ROOT/path).rglob('*.kt')))

presentation = tree('android/feature/auth/src/main/java/com/maxnetwork/feature/auth/presentation')
data = tree('android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data')
domain = tree('android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain')
app = read('android/app/src/main/java/com/maxnetwork/android/MaxApp.kt')
network = read('android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt')
backend = tree('backend/src/main/kotlin/com/maxnetwork/backend/auth')
backend_tests = tree('backend/src/test/kotlin/com/maxnetwork/backend/auth')
strings = read('android/feature/auth/src/main/res/values/strings.xml')
checks = [
    ('forgot-password-screen', 'fun ForgotPasswordScreen' in presentation),
    ('phone-only-request', 'forgot_password_phone' in presentation and 'send_reset_code' in strings),
    ('reset-password-screen', 'fun ResetPasswordScreen' in presentation),
    ('reset-fields', all(x in presentation for x in ['reset_password_code','reset_password_new','reset_password_confirmation'])),
    ('temporary-reset-session', 'PasswordResetSessionStore' in data and 'StoredPasswordResetSession' in data),
    ('no-sensitive-route-arguments', all(x not in app for x in ['resetCode =', 'resetPhone =', 'newPassword ='])),
    ('generic-request-message', 'إن كان الرقم مسجلًا' in strings),
    ('no-account-enumeration-copy', all(x not in strings for x in ['الرقم غير مسجل','الحساب غير موجود'])),
    ('request-endpoint', 'v1/auth/password-reset/challenges' in network),
    ('confirm-endpoint', 'v1/auth/password-reset/confirm' in network),
    ('network-event-metadata', 'PasswordResetRequest' in network and 'PasswordResetConfirm' in network),
    ('old-local-session-cleared', 'authSessionStore.clear(SignOutReason.SessionExpired)' in data),
    ('server-revokes-sessions', 'session' in backend.lower() and 'resetPassword' in backend),
    ('server-enumeration-test', 'resetRequestEnumerationResistance' in backend_tests),
    ('server-session-invalidation-test', 'passwordResetFlow' in backend_tests),
    ('navigation-complete', all(x in app for x in ['AuthUiEvent.PasswordResetCodeSent', 'MaxDestination.ResetPassword', 'AuthUiEvent.PasswordResetCompleted', 'MaxDestination.Login'])),
    ('no-auth-placeholders', 'password_reset_placeholder' not in app and 'otp_placeholder' not in app),
    ('no-prefilled-auth-data', 'ForgotPasswordUiState(phone =' not in presentation and 'ResetPasswordUiState(resetCode =' not in presentation),
]
failed=[name for name, ok in checks if not ok]
if failed:
    print('v12 checks failed:')
    for name in failed: print(f'- {name}')
    raise SystemExit(1)
print(f'v12 checks passed: {len(checks)}/{len(checks)}')
for name,_ in checks: print(f'- {name}')
