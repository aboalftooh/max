#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/request-composer-harness.jar"
kotlinc \
  "$ROOT/android/feature/request/src/main/java/com/maxnetwork/feature/request/domain/RequestModels.kt" \
  "$ROOT/android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestComposerState.kt" \
  "$ROOT/scripts/harness/RequestComposerHarness.kt" \
  -include-runtime -d "$OUT"
java -jar "$OUT"
