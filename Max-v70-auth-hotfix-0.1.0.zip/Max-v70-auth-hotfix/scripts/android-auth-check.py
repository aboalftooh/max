#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUTH = ROOT / "android/feature/auth"
AUTH_MAIN = AUTH / "src/main/java/com/maxnetwork/feature/auth"
AUTH_TEST = AUTH / "src/test/java/com/maxnetwork/feature/auth"
AUTH_ANDROID_TEST = AUTH / "src/androidTest/java/com/maxnetwork/feature/auth"
NETWORK_MAIN = ROOT / "android/core/network/src/main/kotlin/com/maxnetwork/core/network"
NETWORK_TEST = ROOT / "android/core/network/src/test/kotlin/com/maxnetwork/core/network"
APP_TEST = ROOT / "android/app/src/androidTest/java/com/maxnetwork/android"
OPENAPI = (ROOT / "contracts/api/openapi.yaml").read_text(encoding="utf-8")


def text(root: Path) -> str:
    return "\n".join(path.read_text(encoding="utf-8") for path in sorted(root.rglob("*.kt")))


def run_checks() -> list[tuple[str, bool]]:
    auth_main = text(AUTH_MAIN)
    domain = text(AUTH_MAIN / "domain")
    presentation = text(AUTH_MAIN / "presentation")
    tests = text(AUTH_TEST)
    android_tests = text(AUTH_ANDROID_TEST)
    network = text(NETWORK_MAIN)
    network_tests = text(NETWORK_TEST)
    app_tests = text(APP_TEST)

    return [
        ("auth-repository-contract", "interface AuthRepository" in domain),
        ("single-stateflow", "val authState: StateFlow<AuthState>" in domain and "AuthSessionStore" in auth_main),
        ("domain-platform-free", not re.search(r"^import (android\.|retrofit2\.|okhttp3\.)", domain, re.MULTILINE)),
        ("presentation-data-free", ".data." not in presentation and "Retrofit" not in presentation),
        ("keystore-aes-gcm", all(token in auth_main for token in ["AndroidKeyStore", "AES/GCM/NoPadding", "GCMParameterSpec"])),
        ("no-plaintext-auth-logging", "HttpLoggingInterceptor" not in auth_main + network and not re.search(r"\bLog\.(v|d|i|w|e|wtf)\s*\(", auth_main + network)),
        ("refresh-mutex", "private val sessionMutex = Mutex()" in auth_main),
        ("refresh-skew", "Duration.ofSeconds(30)" in auth_main),
        ("max-gateway-is-network-boundary", "class RetrofitMaxGateway" in network and "Retrofit" not in auth_main),
        ("https-only-production", 'baseUrl.startsWith("https://")' in network),
        ("contract-login-path", 'POST("v1/auth/sessions")' in network and "/v1/auth/sessions:" in OPENAPI),
        ("contract-refresh-path", 'POST("v1/auth/sessions/refresh")' in network and "/v1/auth/sessions/refresh:" in OPENAPI),
        ("contract-logout-path", 'DELETE("v1/auth/sessions/current")' in network and "/v1/auth/sessions/current:" in OPENAPI),
        ("expiry-refresh-network-tests", all(token in tests for token in ["expired session", "network failure", "unauthorized refresh"])),
        ("concurrent-refresh-test", "concurrent token requests perform only one refresh" in tests),
        ("mock-server-tests", "MockWebServer" in network_tests and "DISCONNECT_AT_START" in network_tests),
        ("encrypted-storage-tests", "preferencesNeverContainPlaintextTokens" in android_tests),
        ("app-auth-smoke", "applicationRestoresSingleAuthenticationState" in app_tests),
    ]


def main() -> int:
    checks = run_checks()
    failed = [name for name, ok in checks if not ok]
    if failed:
        print("Android authentication checks failed:")
        for name in failed:
            print(f"- {name}")
        return 1
    print(f"Android authentication checks passed: {len(checks)}/{len(checks)}")
    for name, _ in checks:
        print(f"- {name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
