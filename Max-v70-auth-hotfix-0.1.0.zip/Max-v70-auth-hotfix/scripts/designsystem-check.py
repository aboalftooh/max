#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
DS = ROOT / 'android' / 'core' / 'designsystem' / 'src' / 'main'
required = [
    'MaxTheme', 'MaxSpacing', 'MaxShapes', 'MaxPrimaryButton', 'MaxTextField',
    'MaxStatusCard', 'MaxTopBar', 'MaxStateScreen', 'MaxErrorMessage',
    'LocalMaxMotionEnabled', 'LayoutDirection.Rtl',
    'MaxText', 'MaxIcon', 'MaxDivider', 'MaxSwitch', 'MaxBadge', 'MaxStatusPill', 'MaxIconContainer',
    'MaxSecondaryButton', 'MaxTertiaryButton', 'MaxDestructiveButton', 'MaxIconButton',
    'MaxSearchField', 'MaxOtpField', 'MaxScaffold', 'MaxSectionHeader', 'MaxListContainer',
    'MaxListRow', 'MaxBottomActionBar', 'MaxLoadingState', 'MaxEmptyState', 'MaxErrorState',
    'MaxOfflineState', 'MaxSuccessState', 'MaxInlineBanner', 'MaxDialog', 'MaxConfirmationDialog',
    'MaxDashboardPattern', 'MaxSearchableListPattern', 'MaxDetailsPattern', 'MaxFormPattern',
    'MaxSettingsPattern', 'MaxChatPattern',
]
text = '\n'.join(p.read_text(encoding='utf-8') for p in DS.rglob('*.kt'))
missing = [token for token in required if token not in text]
if missing:
    raise SystemExit('Missing design-system tokens/components: ' + ', '.join(missing))
if 'minimumTouchTarget = 48.dp' not in text:
    raise SystemExit('48dp touch target is not centralized')
scanner = ROOT / 'scripts' / 'check_design_system_compliance'
if not scanner.exists():
    raise SystemExit('Missing design compliance scanner')
result = subprocess.run([str(scanner)], cwd=ROOT, check=False)
if result.returncode != 0:
    raise SystemExit('Design compliance scanner failed')
print(f'Design-system checks passed: {len(required) + 2}/{len(required) + 2}')
