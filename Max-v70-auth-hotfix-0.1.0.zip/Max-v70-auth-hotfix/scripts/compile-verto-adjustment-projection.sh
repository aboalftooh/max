#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/verto-financial-v29"
rm -rf "$OUT"
mkdir -p "$OUT"
mapfile -d '' SOURCES < <(find "$ROOT/backend/src/main/kotlin" -name '*.kt' -print0)
kotlinc "${SOURCES[@]}" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/integration/verto/invoice/VertoInvoiceProjectionTest.kt" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/integration/verto/settlement/VertoSettlementProjectionTest.kt" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/integration/verto/adjustment/VertoAdjustmentProjectionTest.kt" \
  -Werror -d "$OUT"
kotlin -classpath "$OUT" com.maxnetwork.backend.integration.verto.invoice.VertoInvoiceProjectionTestKt
kotlin -classpath "$OUT" com.maxnetwork.backend.integration.verto.settlement.VertoSettlementProjectionTestKt
kotlin -classpath "$OUT" com.maxnetwork.backend.integration.verto.adjustment.VertoAdjustmentProjectionTestKt
