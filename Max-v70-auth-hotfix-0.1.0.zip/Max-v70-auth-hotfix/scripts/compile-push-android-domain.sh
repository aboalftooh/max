#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/push-android-domain-v33"
rm -rf "$OUT"
mkdir -p "$OUT"
kotlinc \
  "$ROOT/android/core/model/src/main/kotlin/com/maxnetwork/core/model/Identifiers.kt" \
  "$ROOT/android/core/network/src/main/kotlin/com/maxnetwork/core/network/ApiModels.kt" \
  "$ROOT/android/core/network/src/main/kotlin/com/maxnetwork/core/network/MaxGateway.kt" \
  "$ROOT/android/core/testing/src/main/kotlin/com/maxnetwork/core/testing/FakeFixtures.kt" \
  "$ROOT/android/core/testing/src/main/kotlin/com/maxnetwork/core/testing/FakeMaxGateway.kt" \
  "$ROOT/android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/NotificationReadModel.kt" \
  "$ROOT/android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/PushModels.kt" \
  "$ROOT/android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/PushRegistrationRepository.kt" \
  "$ROOT/android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/data/NetworkPushRegistrationRepository.kt" \
  "$ROOT/android/feature/notifications/src/test/java/com/maxnetwork/feature/notifications/data/PushRegistrationTest.kt" \
  -Werror -d "$OUT"
kotlin -classpath "$OUT" com.maxnetwork.feature.notifications.data.PushRegistrationTestKt
