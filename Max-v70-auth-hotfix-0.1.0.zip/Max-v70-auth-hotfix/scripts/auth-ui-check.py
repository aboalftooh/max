#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUTH_PRESENTATION = ROOT / "android/feature/auth/src/main/java/com/maxnetwork/feature/auth/presentation"
APP_MAIN = ROOT / "android/app/src/main/java/com/maxnetwork/android"
AUTH_ANDROID_TEST = ROOT / "android/feature/auth/src/androidTest/java/com/maxnetwork/feature/auth/presentation"
APP_ANDROID_TEST = ROOT / "android/app/src/androidTest/java/com/maxnetwork/android"
AUTH_UNIT_TEST = ROOT / "android/feature/auth/src/test/java/com/maxnetwork/feature/auth/presentation"


def read_tree(root: Path) -> str:
    if root.is_file():
        return root.read_text(encoding="utf-8")
    return "\n".join(path.read_text(encoding="utf-8") for path in sorted(root.rglob("*.kt")))


def main() -> int:
    presentation = read_tree(AUTH_PRESENTATION)
    app = read_tree(APP_MAIN)
    compose_tests = read_tree(AUTH_ANDROID_TEST) + read_tree(APP_ANDROID_TEST)
    unit_tests = read_tree(AUTH_UNIT_TEST)
    ui_sources = presentation + app

    checks = [
        ("login-screen", "fun LoginScreen" in presentation),
        ("phone-only-login", "login_phone" in presentation and "login_password" not in presentation),
        ("direct-phone-root", "fun signedOutRoot() = MaxBackStack(listOf(MaxDestination.Login))" in app),
        ("no-login-password-copy", "أدخل رقم الهاتف وكلمة المرور" not in presentation),
        ("otp-screen", all(token in presentation for token in ["otp_screen", "otp_input", "otp_submit"])),
        ("join-code-after-new-otp", "NewUserOtpVerified" in presentation and "MaxDestination.RegistrationCode" in app),
        ("existing-user-to-dashboard", "PhoneAuthenticationResult.ExistingUser" in presentation and "AuthUiEvent.Authenticated" in presentation),
        ("registration-code-screen", all(token in presentation for token in ["registration_code_screen", "registration_code_input"])),
        ("registration-data-screen", "create_account_screen" in presentation and "create_account_name" in presentation),
        ("registration-no-password", "create_account_password" not in presentation and "create_account_store" not in presentation),
        ("loading-state", "isLoading" in presentation and "loading = state.isLoading" in presentation),
        ("offline-state", "LoginErrorKind.Offline" in presentation),
        ("temporary-lock-state", "TemporarilyLocked" in presentation),
        ("successful-auth-to-home", "MaxDestination.Home" in app and "AuthState.Authenticated" in app),
        ("no-bottom-navigation", "NavigationBar(" not in ui_sources and "BottomAppBar(" not in ui_sources),
        ("compose-screen-tests", "class AuthScreensTest" in compose_tests),
        ("navigation-tests", "class MaxAppNavigationTest" in compose_tests),
        ("viewmodel-state-tests", "class AuthViewModelTest" in unit_tests),
    ]

    failed = [name for name, passed in checks if not passed]
    if failed:
        print("Authentication UI checks failed:")
        for name in failed:
            print(f"- {name}")
        return 1

    print(f"Authentication UI checks passed: {len(checks)}/{len(checks)}")
    for name, _ in checks:
        print(f"- {name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
