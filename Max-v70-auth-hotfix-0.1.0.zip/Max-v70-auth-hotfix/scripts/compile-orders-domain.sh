#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/orders-domain"
rm -rf "$OUT"
mkdir -p "$OUT"
kotlinc \
  "$ROOT/android/feature/orders/src/main/java/com/maxnetwork/feature/orders/domain/OrderReadModel.kt" \
  "$ROOT/android/feature/orders/src/main/java/com/maxnetwork/feature/orders/domain/OrderReadRepository.kt" \
  "$ROOT/android/feature/orders/src/main/java/com/maxnetwork/feature/orders/domain/OrderReadUseCases.kt" \
  "$ROOT/scripts/harness/orders/OrderReadHarness.kt" \
  -Werror -include-runtime -d "$OUT/orders-domain.jar"
java -jar "$OUT/orders-domain.jar"
