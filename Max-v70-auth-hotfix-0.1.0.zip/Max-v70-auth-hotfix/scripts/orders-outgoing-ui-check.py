#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
orders = ROOT / 'android/feature/orders/src/main/java/com/maxnetwork/feature/orders'
presentation = orders / 'presentation'
domain='\n'.join(p.read_text() for p in (orders/'domain').rglob('*.kt'))
destination=(ROOT/'android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt').read_text()
app=(ROOT/'android/app/src/main/java/com/maxnetwork/android/MaxApp.kt').read_text()
main=(ROOT/'android/app/src/main/java/com/maxnetwork/android/MainActivity.kt').read_text()
checks=[
    ('orders-presentation-removed', not presentation.exists() or not any(presentation.glob('*.kt'))),
    ('outgoing-screen-removed', not (presentation/'OrdersScreen.kt').exists()),
    ('orders-viewmodel-removed', 'OrdersViewModel' not in app and 'OrdersViewModel' not in main),
    ('outgoing-legacy-route-kept', 'data object OutgoingOrders : MaxDestination' in destination),
    ('outgoing-route-normalized-home', 'MaxDestination.OutgoingOrders.route' in destination and '-> MaxDestination.Home' in destination),
    ('sync-domain-kept', 'enum class OrderSynchronization' in domain),
    ('no-money-in-order-domain', all(x.lower() not in domain.lower() for x in ['MoneyAmount','balanceAfter','financialMovement'])),
]
failed=[n for n,ok in checks if not ok]
if failed:
    print('outgoing orders removal checks failed:')
    for n in failed: print('-',n)
    raise SystemExit(1)
print(f'outgoing orders removal checks passed: {len(checks)}/{len(checks)}')
for n,_ in checks: print('-',n)
