#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/session-coordinator-harness.jar"
mkdir -p "$(dirname "$OUT")"
kotlinc \
  "$ROOT/android/app/src/main/java/com/maxnetwork/android/session/SessionCoordinator.kt" \
  "$ROOT/scripts/harness/SessionCoordinatorHarness.kt" \
  -Werror -include-runtime -d "$OUT"
java -jar "$OUT"
