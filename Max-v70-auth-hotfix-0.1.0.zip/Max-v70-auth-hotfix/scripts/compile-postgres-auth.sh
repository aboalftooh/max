#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/max-postgres-auth-v38"
rm -rf "$OUT"
mkdir -p "$OUT"

mapfile -t MAIN_SOURCES < <(find "$ROOT/backend/src/main/kotlin" -name '*.kt' -print | sort)
kotlinc -Werror "${MAIN_SOURCES[@]}" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/auth/postgres/PostgresAuthStoreTest.kt" \
  -d "$OUT"

kotlin -classpath "$OUT" com.maxnetwork.backend.auth.postgres.PostgresAuthStoreTestKt
