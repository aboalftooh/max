#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/max-postgres-request-v39"
rm -rf "$OUT"
mkdir -p "$OUT"

mapfile -t MAIN_SOURCES < <(find "$ROOT/backend/src/main/kotlin" -name '*.kt' -print | sort)
kotlinc -Werror "${MAIN_SOURCES[@]}" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/request/postgres/PostgresRequestStoreTest.kt" \
  -d "$OUT"

kotlin -classpath "$OUT" com.maxnetwork.backend.request.postgres.PostgresRequestStoreTestKt
