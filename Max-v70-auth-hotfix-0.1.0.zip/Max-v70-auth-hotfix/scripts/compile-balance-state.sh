#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/balance-state-v31"
rm -rf "$OUT" && mkdir -p "$OUT"
kotlinc \
  "$ROOT/android/core/model/src/main/kotlin/com/maxnetwork/core/model/Money.kt" \
  "$ROOT/android/feature/balance/src/main/java/com/maxnetwork/feature/balance/domain/BalanceReadModel.kt" \
  "$ROOT/android/feature/balance/src/main/java/com/maxnetwork/feature/balance/presentation/BalanceUiState.kt" \
  "$ROOT/android/feature/balance/src/main/java/com/maxnetwork/feature/balance/presentation/BalanceFormatting.kt" \
  "$ROOT/scripts/harness/balance/BalanceStateHarness.kt" \
  -Werror -include-runtime -d "$OUT/balance-state.jar"
java -jar "$OUT/balance-state.jar"
