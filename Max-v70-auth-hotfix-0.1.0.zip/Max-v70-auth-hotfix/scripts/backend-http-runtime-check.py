#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = 0


def verify(condition: bool, message: str) -> None:
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {message}")
    checks += 1


def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

router = text("backend/src/main/kotlin/com/maxnetwork/backend/http/MaxHttpRouter.kt")
server = text("backend/src/main/kotlin/com/maxnetwork/backend/http/JdkMaxHttpServer.kt")
config = text("backend/src/main/kotlin/com/maxnetwork/backend/http/BackendRuntimeConfig.kt")
order_api = text("backend/src/main/kotlin/com/maxnetwork/backend/request/read/api/OrderReadApi.kt")
order_service = text("backend/src/main/kotlin/com/maxnetwork/backend/request/read/application/OrderReadService.kt")
order_cursor = text("backend/src/main/kotlin/com/maxnetwork/backend/request/read/infrastructure/OrderReadInfrastructure.kt")
upload_api = text("backend/src/main/kotlin/com/maxnetwork/backend/request/upload/api/MediaUploadApi.kt")
upload_service = text("backend/src/main/kotlin/com/maxnetwork/backend/request/upload/application/MediaUploadService.kt")
openapi = text("contracts/api/openapi.yaml")

paths = (
    "/v1/auth/registration-codes/validate",
    "/v1/auth/phone-challenges",
    "/v1/auth/accounts",
    "/v1/auth/sessions",
    "/v1/auth/password-reset/challenges",
    "/v1/media/upload-intents",
    "/v1/requests",
    "/v1/orders",
    "/v1/balance",
    "/v1/profile",
    "/v1/privacy",
    "/v1/support/contact",
    "/v1/notifications",
    "/v1/push/installations/{installationId}",
)
for path in paths:
    verify(path in openapi, f"OpenAPI path exists: {path}")

for fragment in (
    'listOf("v1", "media", "upload-intents")',
    'listOf("v1", "requests")',
    'listOf("v1", "orders")',
    'listOf("v1", "balance")',
    'listOf("v1", "profile")',
    'listOf("v1", "notifications")',
    'listOf("v1", "push", "installations")',
):
    verify(fragment in router, f"router handles protected path: {fragment}")

verify("requireBearer" in router, "HTTP boundary extracts bearer token")
verify('startsWith("Bearer ", ignoreCase = false)' in router, "bearer scheme is strict")
verify("tenantId" not in router and 'query["storeId"]' not in router and 'query["userId"]' not in router, "router accepts no tenant selector")
verify("Duplicate JSON key" in text("backend/src/main/kotlin/com/maxnetwork/backend/http/Json.kt"), "duplicate JSON keys rejected")
verify("requireOnly" in router, "unknown JSON fields rejected")
verify("MAX_HTTP_BODY_BYTES" in router and "64 * 1024" in router, "request body limit exists")
verify('"Cache-Control" to "no-store"' in router, "responses disable caching")
verify('"X-Content-Type-Options" to "nosniff"' in router, "responses disable MIME sniffing")
verify("HttpLoggingInterceptor" not in router and "println(" not in router, "HTTP router does not log bodies")
verify('listOf("health", "live")' in router and 'listOf("health", "ready")' in router, "health routes exist")
verify("readiness()" in router, "readiness is injected and fail-closed")

verify("Executors.newFixedThreadPool" in server, "server worker pool is bounded")
verify("MAX_HTTP_BODY_BYTES" in server, "transport enforces body limit")
verify("server.stop" in server and "awaitTermination" in server, "server shuts down gracefully")
verify("parseQuery" in server and "Duplicate or empty query parameter" in server, "duplicate query parameters rejected")

verify("MAX_RUNTIME_MODE" in config, "runtime mode required")
verify('uri.scheme == "https"' in config, "production public URL requires HTTPS")
for secret in (
    "MAX_AUTH_PEPPER_B64",
    "MAX_CURSOR_SECRET_B64",
    "MAX_MEDIA_SIGNING_SECRET_B64",
    "MAX_PUSH_TOKEN_SECRET_B64",
):
    verify(secret in config, f"runtime secret required: {secret}")
verify("decoded.size >= MIN_SECRET_BYTES" in config, "runtime secrets have minimum entropy")

verify("auth.authenticate(accessToken)" in order_api, "order API derives tenant from session")
verify("HmacOrderCursorCodec" in order_cursor and "storeId.value" in order_cursor and "direction.name" in order_cursor, "order cursor is store/direction bound")
verify("sortedWith(compareByDescending" in order_service, "orders are newest-first")
verify("media.issue(principal, orderId" in order_service, "private media is reauthorized per order")
verify("auth.authenticate(accessToken)" in upload_api, "upload API derives tenant from session")
verify("MAX_IMAGE_BYTES" in upload_service and "MAX_AUDIO_BYTES" in upload_service, "upload size limits enforced")
verify("IMAGE_TYPES" in upload_service and "AUDIO_TYPES" in upload_service, "upload MIME allowlists enforced")
verify("Duration.ofMinutes(5)" in upload_service and "Duration.ofMinutes(10)" in upload_service, "upload slots are short lived")

print(f"BACKEND_HTTP_RUNTIME_CHECKS_PASSED={checks}")
