#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/profile-domain-harness.jar"
mkdir -p "$(dirname "$OUT")"
kotlinc \
  "$ROOT/android/feature/profile/src/main/java/com/maxnetwork/feature/profile/domain/ProfileModels.kt" \
  "$ROOT/scripts/harness/ProfileDomainHarness.kt" \
  -Werror -include-runtime -d "$OUT"
java -jar "$OUT"
