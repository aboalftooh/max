#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/authenticated-transport-v34"
rm -rf "$OUT"
mkdir -p "$OUT"
kotlinc \
  "$ROOT/android/core/network/src/main/kotlin/com/maxnetwork/core/network/BearerTokenStore.kt" \
  "$ROOT/scripts/harness/AuthenticatedTransportHarness.kt" \
  -Werror -d "$OUT"
kotlin -classpath "$OUT" com.maxnetwork.harness.AuthenticatedTransportHarnessKt
