#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
checks = []

def expect(condition: bool, name: str) -> None:
    if not condition:
        raise AssertionError(name)
    checks.append(name)

def text(path: str) -> str:
    return (ROOT / path).read_text(encoding='utf-8')

api = text('backend/src/main/kotlin/com/maxnetwork/backend/request/api/RequestApi.kt')
service = text('backend/src/main/kotlin/com/maxnetwork/backend/request/application/RequestService.kt')
models = text('backend/src/main/kotlin/com/maxnetwork/backend/request/domain/RequestModels.kt')
openapi = text('contracts/api/openapi.yaml')
retrofit = text('android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt')
success_path = ROOT / 'android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestSuccessScreen.kt'
vm = text('android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestViewModel.kt')
app = text('android/app/src/main/java/com/maxnetwork/android/MaxApp.kt')
destination = text('android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt')
sql = text('backend/src/main/resources/db/migration/V002__request_schema.sql')

expect('POST /v1/requests' in api, 'request-endpoint-declared')
expect('RequestSource.App' in api, 'app-source-server-controlled')
expect("('APP', 'VERTO', 'MAX_TEAM')" in sql, 'all-approved-sources-persistable')
expect('unique (store_id, client_request_id)' in sql, 'database-idempotency-constraint')
expect('enable row level security' in sql and 'tenant_isolation' in sql, 'request-database-tenant-isolation')
expect('ownerStoreId != storeId' in service, 'attachment-store-ownership')
expect('upload.kind != expectedKind' in service, 'attachment-kind-validation')
expect('UploadState.Completed' in service, 'attachment-upload-completion')
expect('insertIfAbsent' in service and 'notifications.publish' in service, 'idempotent-persist-and-notify')
expect('financialMovementCreated: Boolean = false' in models and 'require(!financialMovementCreated)' in models, 'no-financial-effect')
expect('/v1/requests:' in openapi and "'201':" in openapi and "'200':" in openapi, 'openapi-created-and-duplicate')
expect("@POST(\"v1/media/upload-intents\")" in retrofit, 'media-path-matches-contract')
expect("@Header(\"Idempotency-Key\")" in retrofit, 'android-idempotency-header')
expect(not success_path.exists(), 'dead-request-success-screen-removed')
expect('RequestOutboxState.Accepted' in vm and 'RequestUiEvent.Accepted' in vm, 'success-event-from-accepted-outbox')
expect('RequestOutboxState.Pending' in vm and 'RequestUiEvent.Accepted' not in vm.split('RequestOutboxState.Pending', 1)[1].split('RequestOutboxState.Accepted', 1)[0], 'no-success-before-accepted')
expect('MaxDestination.ConversationThread(event.conversationId)' in app, 'accepted-request-navigates-to-conversation')
expect('data object RequestSuccess' not in destination, 'typed-success-destination-removed')
expect('LEGACY_REQUEST_SUCCESS_ROUTE = "request/success"' in destination and '-> MaxDestination.Home' in destination, 'legacy-success-route-normalized-home')

print(f'Request acceptance checks passed: {len(checks)}/{len(checks)}')
for item in checks:
    print(f'- {item}')
