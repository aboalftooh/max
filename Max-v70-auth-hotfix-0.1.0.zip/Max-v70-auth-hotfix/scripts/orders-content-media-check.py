#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
orders = root/'android/feature/orders/src/main/java/com/maxnetwork/feature/orders'
presentation = orders/'presentation'
domain = '\n'.join(p.read_text() for p in (orders/'domain').rglob('*.kt'))
backend = (root/'backend/src/main/kotlin/com/maxnetwork/backend/request/media/OrderMediaAccess.kt').read_text()
openapi = (root/'contracts/api/openapi.yaml').read_text()
checks = [
    ('dead-content-panel-removed', not (presentation/'OrderContentPanel.kt').exists()),
    ('dead-fullscreen-image-removed', not presentation.exists() or 'ZoomablePrivateImage' not in '\n'.join(p.read_text() for p in presentation.glob('*.kt'))),
    ('expiry-policy-kept', 'OrderMediaAccessPolicy' in domain and 'refreshLeeway' in domain),
    ('short-lived-server-links', 'Duration.ofMinutes(5)' in backend and 'ttl <= Duration.ofMinutes(10)' in backend),
    ('authorization-before-signing', 'authorizer.canRead' in backend),
    ('hmac-signing', 'HmacSHA256' in backend),
    ('https-only', 'require(endpoint.startsWith("https://"))' in backend),
    ('openapi-private-media', 'authorization-scoped media link' in openapi and 'expires within 10 minutes' in openapi),
]
failed = [name for name, ok in checks if not ok]
if failed:
    print('order media compatibility checks failed:')
    for name in failed: print('-', name)
    raise SystemExit(1)
print(f'order media compatibility checks passed: {len(checks)}/{len(checks)}')
for name, _ in checks: print('-', name)
