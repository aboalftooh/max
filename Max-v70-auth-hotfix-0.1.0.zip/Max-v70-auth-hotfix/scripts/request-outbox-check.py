#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
worker = (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/data/outbox/RequestOutboxWorker.kt").read_text()
processor = (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/data/outbox/RequestOutboxProcessor.kt").read_text()
entity = (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/data/local/RequestOutboxEntity.kt").read_text()
dao = (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/data/local/RequestOutboxDao.kt").read_text()
screen = (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestPartScreen.kt").read_text()
checks = {
    "network constrained worker": "NetworkType.CONNECTED" in worker,
    "unique worker": "enqueueUniqueWork" in worker and "ExistingWorkPolicy.KEEP" in worker,
    "idempotency primary key": "@PrimaryKey val idempotencyKey" in entity,
    "draft uniqueness": 'Index(value = ["draftId"], unique = true)' in entity,
    "insert ignores duplicates": "OnConflictStrategy.IGNORE" in dao,
    "uploads precede request": processor.index("uploadIfRequired") < processor.index("gateway.submitRequest"),
    "upload resume ids": "repository.uploadId" in processor and "saveUploadId" in processor,
    "retryable state": "RequestOutboxState.RetryableFailure" in processor,
    "permanent state": "RequestOutboxState.PermanentFailure" in processor,
    "pending visible": 'testTag("request_pending_state")' in screen,
    "no success before server": "markAccepted" in processor and "GatewayResult.Success" in processor,
    "no financial path": all(word not in processor.lower() for word in ["balance", "payment", "invoice", "financialmovement"]),
}
failed = [k for k,v in checks.items() if not v]
for k,v in checks.items(): print(f"{'PASS' if v else 'FAIL'}: {k}")
if failed: raise SystemExit("failed: " + ", ".join(failed))
print(f"request-outbox-check: {len(checks)}/{len(checks)} checks passed")
