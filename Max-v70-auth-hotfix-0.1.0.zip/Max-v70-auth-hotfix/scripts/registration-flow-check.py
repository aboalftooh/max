#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUTH = ROOT / "android/feature/auth/src/main/java/com/maxnetwork/feature/auth"
APP = ROOT / "android/app/src/main/java/com/maxnetwork/android/MaxApp.kt"
BACKSTACK = ROOT / "android/app/src/main/java/com/maxnetwork/android/navigation/MaxBackStack.kt"
NETWORK = ROOT / "android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt"
BACKEND = ROOT / "backend/src/main/kotlin/com/maxnetwork/backend/auth/application/AuthService.kt"
BACKEND_TEST = ROOT / "backend/src/test/kotlin/com/maxnetwork/backend/auth/AuthSecurityTest.kt"

def read(path: Path) -> str:
    if path.is_file():
        return path.read_text(encoding="utf-8")
    return "\n".join(p.read_text(encoding="utf-8") for p in sorted(path.rglob("*.kt")))

def main() -> int:
    auth = read(AUTH)
    app = read(APP)
    backstack = read(BACKSTACK)
    network = read(NETWORK)
    backend = read(BACKEND)
    backend_test = read(BACKEND_TEST)
    checks = [
        ("direct-phone-root", "MaxDestination.Login" in backstack and "signedOutRoot" in backstack),
        ("phone-first", "requestPhoneChallengeUseCase(snapshot.phone)" in auth),
        ("single-otp-step", "fun OtpScreen" in auth and "otp_input" in auth),
        ("server-resolves-current-new", "resolveVerifiedPhone" in backend and "VerifiedPhoneResolution.ExistingUser" in backend and "VerifiedPhoneResolution.NewUser" in backend),
        ("current-user-dashboard", "PhoneAuthenticationResult.ExistingUser" in auth and "AuthUiEvent.Authenticated" in app),
        ("new-user-join-code", "NewUserOtpVerified" in app and "MaxDestination.RegistrationCode" in app),
        ("code-after-verified-phone", "StoredRegistrationSession.PhoneVerified" in auth and "ReadyToCreateAccount" in auth),
        ("registration-data", "create_account_name" in auth and "create_account_password" not in auth),
        ("no-route-secrets", "validationToken =" not in app and "challengeId =" not in app),
        ("phone-endpoint", 'POST("v1/auth/phone-challenges")' in network),
        ("resolve-endpoint", 'POST("v1/auth/phone-verifications/resolve")' in network),
        ("registration-endpoint", 'POST("v1/auth/registration-codes/validate")' in network),
        ("used-code-test", "registration code is single-use under concurrency" in backend_test),
    ]
    failed = [name for name, ok in checks if not ok]
    if failed:
        print("Registration flow checks failed:")
        for name in failed: print(f"- {name}")
        return 1
    print(f"Registration flow checks passed: {len(checks)}/{len(checks)}")
    for name, _ in checks: print(f"- {name}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
