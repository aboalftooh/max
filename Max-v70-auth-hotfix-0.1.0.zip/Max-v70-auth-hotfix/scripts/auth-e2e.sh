#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
"$ROOT/scripts/compile-backend-auth.sh"
"$ROOT/scripts/compile-auth-flow.sh"
"$ROOT/scripts/compile-password-reset-flow.sh"
echo "Authentication executable acceptance: 31/31 passed"
