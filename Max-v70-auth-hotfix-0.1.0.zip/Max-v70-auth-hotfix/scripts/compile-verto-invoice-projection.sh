#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/verto-invoice-projection.jar"
mapfile -d '' SOURCES < <(find "$ROOT/backend/src/main/kotlin" -name '*.kt' -print0)
kotlinc "${SOURCES[@]}" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/integration/verto/invoice/VertoInvoiceProjectionTest.kt" \
  -Werror -include-runtime -d "$OUT"
java -jar "$OUT"
