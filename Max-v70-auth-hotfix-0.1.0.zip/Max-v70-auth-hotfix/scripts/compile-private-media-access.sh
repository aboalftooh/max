#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/private-media-access"
rm -rf "$OUT" && mkdir -p "$OUT"
kotlinc \
  "$ROOT/backend/src/main/kotlin/com/maxnetwork/backend/request/domain/RequestModels.kt" \
  "$ROOT/backend/src/main/kotlin/com/maxnetwork/backend/request/media/OrderMediaAccess.kt" \
  "$ROOT/scripts/harness/backend/PrivateMediaAccessHarness.kt" \
  -Werror -include-runtime -d "$OUT/private-media-access.jar"
java -jar "$OUT/private-media-access.jar"
