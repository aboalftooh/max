#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
checks = []

def require(condition: bool, message: str) -> None:
    checks.append((condition, message))
    if not condition:
        raise SystemExit(f"FAIL: {message}")

home = (root / "android/feature/home/src/main/java/com/maxnetwork/feature/home/presentation/HomeScreen.kt").read_text()
app = (root / "android/app/src/main/java/com/maxnetwork/android/MaxApp.kt").read_text()
dest = (root / "android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt").read_text()
nav = (root / "android/app/src/main/java/com/maxnetwork/android/navigation/MaxBackStack.kt").read_text()
test = (root / "android/app/src/androidTest/java/com/maxnetwork/android/MaxAppNavigationTest.kt").read_text()

for tag in ["home_action_request", "home_action_incoming", "home_action_outgoing", "home_action_balance", "home_action_profile"]:
    require(tag in home, f"home action exists: {tag}")
require("home_full_header" in home, "full header belongs to home")
require("bottom_bar" not in app.lower(), "no bottom bar implementation")
require("sealed interface MaxDestination" in dest, "typed destination model")
require("data class MaxBackStack" in nav, "central back stack")
require("destination == MaxDestination.Home" in nav, "home reset prevents duplication")
require("fullHeaderExistsOnlyOnHome" in test, "UI test enforces header rule")
require("authenticatedHomeProvidesOneTapAccess" in test, "UI test covers one-tap destinations")
require("MaxDestination.Profile ->" in app, "profile route exists")
require("HomeUiState(" in app, "home state is explicitly provided")

print(f"home-navigation-check: {len(checks)}/{len(checks)} passed")
