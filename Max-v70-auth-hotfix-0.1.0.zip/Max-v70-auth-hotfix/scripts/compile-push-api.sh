#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/push-api-v33"
rm -rf "$OUT"
mkdir -p "$OUT"
mapfile -d '' SOURCES < <(find "$ROOT/backend/src/main/kotlin" -name '*.kt' -print0)
kotlinc "${SOURCES[@]}" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/notification/PushApiTest.kt" \
  -Werror -d "$OUT"
kotlin -classpath "$OUT" com.maxnetwork.backend.notification.PushApiTestKt
