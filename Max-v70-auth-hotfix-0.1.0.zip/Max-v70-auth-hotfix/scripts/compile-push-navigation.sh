#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/push-navigation-v33"
rm -rf "$OUT"
mkdir -p "$OUT"
kotlinc \
  "$ROOT/android/core/model/src/main/kotlin/com/maxnetwork/core/model/Identifiers.kt" \
  "$ROOT/android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt" \
  "$ROOT/android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/NotificationReadModel.kt" \
  "$ROOT/android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/PushModels.kt" \
  "$ROOT/android/app/src/main/java/com/maxnetwork/android/push/PushNavigation.kt" \
  "$ROOT/android/app/src/test/java/com/maxnetwork/android/push/PushNavigationTest.kt" \
  -Werror -d "$OUT"
kotlin -classpath "$OUT" com.maxnetwork.android.push.PushNavigationTestKt
