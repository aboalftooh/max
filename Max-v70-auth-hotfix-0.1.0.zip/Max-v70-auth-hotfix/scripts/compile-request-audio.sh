#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COROUTINES="/root/.sdkman/candidates/kotlin/current/lib/kotlinx-coroutines-core-jvm.jar"
OUT="$ROOT/verification-artifacts/request-audio-harness.jar"
kotlinc \
  "$ROOT/android/feature/request/src/main/java/com/maxnetwork/feature/request/domain/RequestModels.kt" \
  "$ROOT/android/feature/request/src/main/java/com/maxnetwork/feature/request/media/RequestAudioController.kt" \
  "$ROOT/scripts/harness/RequestAudioControllerHarness.kt" \
  -classpath "$COROUTINES" -Werror -include-runtime -d "$OUT"
java -cp "$OUT:$COROUTINES" RequestAudioControllerHarnessKt
