#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/request-backend-harness.jar"
kotlinc \
  "$ROOT/backend/src/main/kotlin/com/maxnetwork/backend/request/domain/RequestModels.kt" \
  "$ROOT/backend/src/main/kotlin/com/maxnetwork/backend/request/ports/RequestPorts.kt" \
  "$ROOT/backend/src/main/kotlin/com/maxnetwork/backend/request/application/RequestService.kt" \
  "$ROOT/backend/src/main/kotlin/com/maxnetwork/backend/request/infrastructure/InMemoryRequestInfrastructure.kt" \
  "$ROOT/backend/src/main/kotlin/com/maxnetwork/backend/request/api/RequestApi.kt" \
  "$ROOT/backend/src/main/kotlin/com/maxnetwork/backend/request/RequestModule.kt" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/request/RequestEndpointTest.kt" \
  -include-runtime -d "$OUT"
java -jar "$OUT"
