#!/usr/bin/env bash
set -uo pipefail
export PYTHONDONTWRITEBYTECODE=1

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ARTIFACTS="$ROOT/verification-artifacts"
GATES="$ARTIFACTS/gates.ndjson"
mkdir -p "$ARTIFACTS"
: > "$GATES"
status=0

record() {
  local name="$1" result="$2" detail="$3"
  python3 - "$GATES" "$name" "$result" "$detail" <<'PY'
import json, sys
path, name, status, detail = sys.argv[1:]
with open(path, 'a', encoding='utf-8') as fh:
    fh.write(json.dumps({'name': name, 'status': status, 'detail': detail}, ensure_ascii=False) + '\n')
PY
}

run_gate() {
  local name="$1"
  shift
  local log="$ARTIFACTS/${name}.log"
  echo "== $name =="
  if "$@" >"$log" 2>&1; then
    echo "PASS: $name"
    record "$name" passed "$log"
  else
    echo "FAIL: $name"
    record "$name" failed "$log"
    status=1
  fi
}

skip_gate() {
  local name="$1" reason="$2" required="${3:-true}"
  echo "SKIP: $name — $reason"
  record "$name" skipped "$reason"
  if [[ "$required" == "true" ]]; then
    status=1
  fi
}

run_gate repository-check "$ROOT/scripts/repository-check.sh"
run_gate shell-syntax bash -n "$ROOT/scripts/repository-check.sh" "$ROOT/scripts/verify.sh" "$ROOT/scripts/deliver.sh" "$ROOT/scripts/compile-backend-auth.sh" "$ROOT/scripts/compile-verto-adjustment-projection.sh" "$ROOT/scripts/compile-balance-read-api.sh" "$ROOT/scripts/compile-balance-read-domain.sh" "$ROOT/scripts/compile-balance-state.sh" "$ROOT/scripts/compile-notification-api.sh" "$ROOT/scripts/compile-notification-domain.sh" "$ROOT/scripts/compile-push-delivery.sh" "$ROOT/scripts/compile-push-api.sh" "$ROOT/scripts/compile-fcm-push.sh" "$ROOT/scripts/compile-push-android-domain.sh" "$ROOT/scripts/compile-push-navigation.sh" "$ROOT/scripts/compile-authenticated-transport.sh" "$ROOT/scripts/compile-profile-api.sh" "$ROOT/scripts/compile-network-gateway.sh" "$ROOT/scripts/compile-postgres-auth.sh" "$ROOT/scripts/compile-postgres-request.sh"
run_gate python-checks python3 -m unittest discover -s "$ROOT/scripts/tests" -p 'test_*.py'
run_gate contract-check "$ROOT/scripts/contract-check.py"
run_gate backend-auth-check "$ROOT/scripts/backend-auth-check.py"
run_gate android-auth-check "$ROOT/scripts/android-auth-check.py"
run_gate auth-ui-check "$ROOT/scripts/auth-ui-check.py"
run_gate v40-release-repair-check "$ROOT/scripts/v40-release-repair-check.py"
if command -v kotlinc >/dev/null 2>&1; then
  run_gate backend-auth-tests "$ROOT/scripts/compile-backend-auth.sh"
elif command -v gradle >/dev/null 2>&1; then
  run_gate backend-auth-tests bash -lc "cd '$ROOT/backend' && gradle check --stacktrace"
else
  skip_gate backend-auth-tests 'Kotlin compiler or Gradle is required'
fi
run_gate designsystem-check "$ROOT/scripts/designsystem-check.py"
run_gate dead-ui-removal-check "$ROOT/scripts/dead-ui-removal-check.py"
run_gate final-ux-certification-check "$ROOT/scripts/final-ux-certification-check.py"
run_gate verto-adjustment-check "$ROOT/scripts/verto-adjustment-check.py"
run_gate balance-read-contract-check "$ROOT/scripts/balance-read-contract-check.py"
run_gate balance-ui-check "$ROOT/scripts/balance-ui-check.py"
run_gate notification-contract-check "$ROOT/scripts/notification-contract-check.py"
run_gate push-delivery-check "$ROOT/scripts/push-delivery-check.py"
run_gate protected-release-path-check "$ROOT/scripts/protected-release-path-check.py"
run_gate backend-http-runtime-check "$ROOT/scripts/backend-http-runtime-check.py"
run_gate postgres-auth-check "$ROOT/scripts/postgres-auth-check.py"
run_gate postgres-request-check "$ROOT/scripts/postgres-request-check.py"
if command -v kotlinc >/dev/null 2>&1; then
  run_gate verto-adjustment-tests "$ROOT/scripts/compile-verto-adjustment-projection.sh"
  run_gate balance-read-api-tests "$ROOT/scripts/compile-balance-read-api.sh"
  run_gate balance-read-domain-tests "$ROOT/scripts/compile-balance-read-domain.sh"
  run_gate balance-state-tests "$ROOT/scripts/compile-balance-state.sh"
  run_gate notification-api-tests "$ROOT/scripts/compile-notification-api.sh"
  run_gate notification-domain-tests "$ROOT/scripts/compile-notification-domain.sh"
  run_gate push-delivery-tests "$ROOT/scripts/compile-push-delivery.sh"
  run_gate push-api-tests "$ROOT/scripts/compile-push-api.sh"
  run_gate fcm-push-tests "$ROOT/scripts/compile-fcm-push.sh"
  run_gate order-read-upload-api-tests "$ROOT/scripts/compile-order-read-upload-api.sh"
  run_gate backend-http-runtime-tests "$ROOT/scripts/compile-backend-http-runtime.sh"
  run_gate postgres-auth-tests "$ROOT/scripts/compile-postgres-auth.sh"
  run_gate postgres-request-tests "$ROOT/scripts/compile-postgres-request.sh"
  run_gate push-android-domain-tests "$ROOT/scripts/compile-push-android-domain.sh"
  run_gate push-navigation-tests "$ROOT/scripts/compile-push-navigation.sh" "$ROOT/scripts/compile-authenticated-transport.sh" "$ROOT/scripts/compile-profile-api.sh" "$ROOT/scripts/compile-network-gateway.sh" "$ROOT/scripts/compile-postgres-auth.sh"
fi

cd "$ROOT/android"
run_gate formatting ./gradlew ktlintCheck --stacktrace
run_gate detekt ./gradlew detekt --stacktrace
run_gate unit-tests ./gradlew test testDebugUnitTest --stacktrace
run_gate android-lint ./gradlew lintDebug --stacktrace
run_gate debug-build ./gradlew :app:assembleDebug --stacktrace

if [[ "${RUN_CONNECTED_TESTS:-0}" == "1" ]]; then
  run_gate ui-smoke ./gradlew :app:connectedDebugAndroidTest --stacktrace
else
  skip_gate ui-smoke 'set RUN_CONNECTED_TESTS=1 with a device or emulator' false
fi

python3 "$ROOT/scripts/quality-summary.py" --gates "$GATES" --out "$ARTIFACTS/summary.json" >/dev/null 2>&1 || true
exit "$status"
