#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
screen = (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestPartScreen.kt").read_text()
app = (root / "android/app/src/main/java/com/maxnetwork/android/MaxApp.kt").read_text()
state = (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestComposerState.kt").read_text()

checks = {
    "screen title": 'title = "اطلب قطعة"' in screen,
    "text input": 'testTag("request_text_input")' in screen,
    "gallery wired": "RequestImageAttachmentSection" in screen,
    "camera available": 'testTag("request_take_photo")' in (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestImageAttachmentSection.kt").read_text(),
    "microphone wired": "RequestAudioAttachmentSection" in screen,
    "send button": 'testTag = "request_submit"' in screen,
    "back action": "onBack = actions.onBack" in screen,
    "single hoisted state": "data class RequestPartUiState" in state,
    "no technical required fields": all(word not in screen for word in ["partNumber", "vehicleId", "competitorId", "inventory"]),
    "no full header": "home_full_header" not in screen,
    "rtl inherited": "MaxTheme" in (root / "android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/theme/Theme.kt").read_text(),
    "one hand bottom action": ".weight(1f)" in screen and 'text = if (state.phase' in screen,
    "failure state": "RequestComposerPhase.Failed" in screen,
    "uploading state": "RequestComposerPhase.Uploading" in screen,
    "submit blocked without valid content": "val canSubmit" in state and "RequestDraftPolicy.validate" in state,
    "app route wired": "MaxDestination.RequestPart -> RequestPartScreen" in app,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
if failed:
    raise SystemExit("failed: " + ", ".join(failed))
print(f"request-ui-check: {len(checks)}/{len(checks)} checks passed")
