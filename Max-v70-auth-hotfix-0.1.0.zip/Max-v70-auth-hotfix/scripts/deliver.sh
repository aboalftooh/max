#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="${1:-v08}"
OUT="${2:-$ROOT/../max-${VERSION}-full.zip}"

cd "$ROOT"
if [[ ! -f "modified-files-${VERSION}.txt" ]]; then
  find . -type f \
    ! -path './.git/*' \
    ! -path './android/.gradle/*' \
    ! -path '*/build/*' \
    ! -path './verification-artifacts/*' \
    ! -path '*/__pycache__/*' \
    -print | sort > "modified-files-${VERSION}.txt"
fi

rm -f "$OUT"
zip -qr "$OUT" . \
  -x '.git/*' 'android/.gradle/*' '*/build/*' 'verification-artifacts/*' '*/__pycache__/*' '*.pyc' '*.apk' '*.aab'

echo "$OUT"
