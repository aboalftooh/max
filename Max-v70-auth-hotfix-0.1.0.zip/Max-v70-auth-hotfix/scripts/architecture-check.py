#!/usr/bin/env python3
from __future__ import annotations
import argparse
import re
import tempfile
from pathlib import Path

FEATURE_DEP = re.compile(r'project\(\s*["\']:\s*feature:', re.IGNORECASE)
DOMAIN_IMPORT = re.compile(r'^import (android\.|androidx\.room|retrofit2\.|okhttp3\.)', re.MULTILINE)
PRESENTATION_REF = re.compile(r'(\b(Dao|Retrofit|OkHttpClient|VertoGateway)\b|^import .*\.data\.)', re.MULTILINE)
VERTO_DB = re.compile(r'(verto[_-]?db|from\s*\(\s*["\'][a-z_]+["\']\s*\))', re.IGNORECASE)
AUTH_LOGGING = re.compile(r'(HttpLoggingInterceptor|\bLog\.(?:v|d|i|w|e|wtf)\s*\()')


def violations(android_root: Path) -> list[str]:
    found: list[str] = []
    for build in (android_root / 'feature').glob('*/build.gradle.kts'):
        if FEATURE_DEP.search(build.read_text(encoding='utf-8')):
            found.append(f'feature dependency: {build.relative_to(android_root)}')
    for source in (android_root / 'feature').glob('*/src/main/**/*.kt'):
        text = source.read_text(encoding='utf-8')
        parts = source.parts
        if 'domain' in parts and DOMAIN_IMPORT.search(text):
            found.append(f'domain platform import: {source.relative_to(android_root)}')
        if 'presentation' in parts and PRESENTATION_REF.search(text):
            found.append(f'presentation infrastructure reference: {source.relative_to(android_root)}')
    for source in android_root.glob('**/*.kt'):
        text = source.read_text(encoding='utf-8')
        if VERTO_DB.search(text):
            found.append(f'direct Verto database coupling: {source.relative_to(android_root)}')
        if '/feature/auth/' in source.as_posix() and '/src/main/' in source.as_posix() and AUTH_LOGGING.search(text):
            found.append(f'authentication secret logging risk: {source.relative_to(android_root)}')
    return found


def self_test() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        build = root / 'feature' / 'auth' / 'build.gradle.kts'
        build.parent.mkdir(parents=True)
        build.write_text('implementation(project(":feature:home"))', encoding='utf-8')
        assert violations(root), 'checker failed to detect injected violation'


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('android_root', nargs='?', default='android')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
    found = violations(Path(args.android_root))
    if found:
        print('\n'.join(found))
        return 1
    print('Architecture checks passed')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
