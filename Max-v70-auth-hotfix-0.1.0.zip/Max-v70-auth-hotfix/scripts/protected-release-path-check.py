#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = 0


def verify(condition: bool, message: str) -> None:
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {message}")
    checks += 1


def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

bearer = text("android/core/network/src/main/kotlin/com/maxnetwork/core/network/BearerTokenStore.kt")
retrofit = text("android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt")
session = text("android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/DefaultAuthSessionStore.kt")
auth_factory = text("android/feature/auth/src/main/java/com/maxnetwork/feature/auth/AuthFeatureFactory.kt")
release_factory = text("android/app/src/release/java/com/maxnetwork/android/di/MaxAppContainerFactory.kt")
profile_service = text("backend/src/main/kotlin/com/maxnetwork/backend/profile/application/ProfileService.kt")
profile_api = text("backend/src/main/kotlin/com/maxnetwork/backend/profile/api/ProfileApi.kt")
auth_service = text("backend/src/main/kotlin/com/maxnetwork/backend/auth/application/AuthService.kt")
migration = text("backend/src/main/resources/db/migration/V010__profile_account_deletion.sql")
openapi = text("contracts/api/openapi.yaml")

for path in (
    "/v1/media/",
    "/v1/requests",
    "/v1/orders",
    "/v1/balance",
    "/v1/profile",
    "/v1/notifications",
    "/v1/push/",
):
    verify(path in bearer, f"protected prefix declared: {path}")
verify("/v1/auth/" not in bearer, "authentication endpoints are not bearer-intercepted")
verify("AtomicReference" in bearer, "token bridge is thread safe")
verify("token?.takeIf(String::isNotBlank)" in bearer, "blank token is rejected")

verify("addInterceptor" in retrofit, "Retrofit installs protected API interceptor")
verify('header("Authorization", "Bearer $token")' in retrofit, "bearer header is attached")
verify("isProtectedMaxApiPath" in retrofit, "only protected Max paths receive bearer")
verify("val apiClient" in retrofit and "val uploadClient" in retrofit, "signed upload client is isolated")
verify(".client(apiClient)" in retrofit, "Retrofit uses authenticated API client")
verify("uploadClient = uploadClient" in retrofit, "signed uploads use isolated client")
verify("HttpLoggingInterceptor" not in retrofit, "no sensitive HTTP logging")
verify("profileService.getProfile" in retrofit, "release profile endpoint implemented")
verify("profileService.requestAccountDeletion" in retrofit, "release deletion endpoint implemented")
verify("profileService.getSupportContact" in retrofit, "release support endpoint implemented")
verify("profileService.getPrivacy" in retrofit, "release privacy endpoint implemented")

verify("onAccessTokenChanged(restored?.accessToken)" in session, "restored token enters bridge")
verify("onAccessTokenChanged(session.accessToken)" in session, "new token enters bridge")
verify("onAccessTokenChanged(null)" in session, "logout clears bridge")
verify("onAccessTokenChanged: (String?) -> Unit" in auth_factory, "auth exposes token-change boundary")
verify("bearerTokenStore = InMemoryBearerTokenStore()" in release_factory, "release creates one token bridge")
verify("onAccessTokenChanged = bearerTokenStore::update" in release_factory, "auth and network share bridge")

verify("auth.getCurrentAccount(accessToken)" in profile_service, "profile derives user from session")
verify("auth.requestAccountDeletion(accessToken)" in profile_service, "deletion derives user from session")
verify("storeId" not in profile_api.split("fun getProfile", 1)[1].split("fun requestAccountDeletion", 1)[0], "profile API accepts no tenant selector")
verify("PrivacySection(" in profile_service and profile_service.count("PrivacySection(") == 6, "privacy has six fixed sections")
verify("https://wa.me/" in text("backend/src/main/kotlin/com/maxnetwork/backend/profile/domain/ProfileModels.kt"), "WhatsApp domain is allowlisted")
verify("https://api.whatsapp.com/" in text("backend/src/main/kotlin/com/maxnetwork/backend/profile/domain/ProfileModels.kt"), "alternate WhatsApp domain is allowlisted")

verify("updateUser(user.copy(status = UserStatus.Disabled))" in auth_service, "deletion disables identity immediately")
verify("sessionsForUser(user.id)" in auth_service and "revokedAt = now" in auth_service, "deletion revokes sessions")
verify("accountDeletionGracePeriod" in auth_service, "deletion schedule comes from server policy")
verify("insertAccountDeletion(request)" in auth_service, "deletion request is trackable")

verify("enable row level security" in migration, "deletion rows use RLS")
verify("account_deletion_tenant_isolation" in migration, "deletion rows are tenant scoped")
verify("account_deletion_one_active_per_user_idx" in migration, "one active deletion per user")
verify("account_deletion_identity_immutable" in migration, "deletion identity is immutable")
verify("account_deletion_no_delete" in migration, "deletion audit rows cannot be deleted")
verify("revoke all" in migration, "public access revoked")
verify("max_balance" not in migration and "ledger" not in migration.lower(), "deletion migration never rewrites finance")

for endpoint in (
    "/v1/profile:",
    "/v1/profile/deletion-requests:",
    "/v1/privacy:",
    "/v1/support/contact:",
):
    verify(endpoint in openapi, f"OpenAPI contains {endpoint}")

print(f"PROTECTED_RELEASE_PATH_CHECKS_PASSED={checks}")
