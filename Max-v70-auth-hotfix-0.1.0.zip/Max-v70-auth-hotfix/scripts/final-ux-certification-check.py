#!/usr/bin/env python3
"""Static final certification guard for SESSION-66.

This gate proves repository-enforceable migration invariants. Device-only UX,
TalkBack and responsive execution remain a separate required connected-test gate.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REACHABLE = (
    "LoginScreen", "RegistrationCodeScreen", "ConfirmPhoneScreen",
    "OtpScreen", "CreateAccountScreen", "ForgotPasswordScreen", "ResetPasswordScreen",
    "HomeScreen", "RequestPartScreen", "ConversationsScreen", "ConversationThreadScreen",
    "InvoicesScreen", "InvoiceDetailsScreen", "NotificationsScreen", "SettingsScreen",
    "ProfileScreen", "PrivacyScreen",
)
DEAD = ("WelcomeScreen", "BalanceScreen", "IncomingOrdersScreen", "OutgoingOrdersScreen", "RequestSuccessScreen")


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def assert_true(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def production_ui_files() -> list[Path]:
    roots = [ROOT / "android/app/src/main", *sorted((ROOT / "android/feature").glob("*/src/main"))]
    files: list[Path] = []
    for source_root in roots:
        if not source_root.exists():
            continue
        for path in source_root.rglob("*.kt"):
            if "@Composable" in path.read_text(encoding="utf-8"):
                files.append(path)
    return sorted(files)


def checks() -> list[str]:
    passed: list[str] = []
    ledger = read("docs/designsystem/MIGRATION-LEDGER.md")
    table_rows = [line for line in ledger.splitlines() if line.startswith("| SCR-")]
    reachable_rows = [line for line in table_rows if any(name in line for name in REACHABLE)]
    dead_rows = [line for line in table_rows if any(name in line for name in DEAD)]
    assert_true(len(reachable_rows) == 17, f"reachable ledger rows={len(reachable_rows)}, expected 17")
    assert_true(all("`MIGRATED`" in row for row in reachable_rows), "not all reachable screens are MIGRATED")
    assert_true(len(dead_rows) == 5, f"dead ledger rows={len(dead_rows)}, expected 5")
    assert_true(all("`REMOVED`" in row for row in dead_rows), "not all dead screens are REMOVED")
    assert_true(not any("`Legacy`" in row or "`Mixed`" in row for row in table_rows), "Legacy/Mixed row remains")
    passed.append("migration ledger 17/17 migrated + 5/5 removed + 0 Legacy/Mixed")

    allowlist = [
        line.strip() for line in read("docs/designsystem/DESIGN-COMPLIANCE-ALLOWLIST.txt").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    assert_true(not allowlist, f"compliance allowlist is not empty: {allowlist}")
    completed = subprocess.run(
        [str(ROOT / "scripts/check_design_system_compliance")], cwd=ROOT,
        check=False, capture_output=True, text=True,
    )
    assert_true(completed.returncode == 0, completed.stdout + completed.stderr)
    ui_files = production_ui_files()
    assert_true(len(ui_files) == 19, f"production Compose UI count={len(ui_files)}, expected 19")
    passed.append("19/19 production Compose UI enforced; allowlist empty; 0 design violations")

    manifest = read("android/app/src/main/AndroidManifest.xml")
    strings = read("android/app/src/main/res/values/strings.xml")
    themes = read("android/app/src/main/res/values/themes.xml") + read("android/app/src/main/res/values-night/themes.xml")
    colors = read("android/app/src/main/res/values/colors.xml")
    assert_true('<string name="app_name">max</string>' in strings, "visible app name is not max")
    assert_true('android:icon="@mipmap/ic_launcher"' in manifest, "launcher icon binding missing")
    assert_true('android:roundIcon="@mipmap/ic_launcher_round"' in manifest, "round launcher icon binding missing")
    assert_true('android:supportsRtl="true"' in manifest, "supportsRtl missing")
    assert_true(themes.count('<item name="android:fontFamily">@font/tajawal</item>') == 2, "native themes do not both use Tajawal")
    assert_true(themes.count('<item name="android:colorAccent">@color/max_primary</item>') == 2, "native accent is not centralized MAX green")
    assert_true("max_purple" not in colors + themes, "legacy purple accent remains")
    passed.append("identity = max + launcher icon + Tajawal + green native accent")

    font_dir = ROOT / "android/core/designsystem/src/main/res/font"
    expected_fonts = {
        "tajawal_regular.ttf", "tajawal_medium.ttf", "tajawal_bold.ttf", "tajawal_extrabold.ttf",
        "tajawal_light.ttf", "tajawal_extralight.ttf", "tajawal_black.ttf", "tajawal.xml",
    }
    found_fonts = {p.name for p in font_dir.iterdir() if p.is_file()}
    assert_true(expected_fonts <= found_fonts, f"missing Tajawal assets: {sorted(expected_fonts - found_fonts)}")
    legacy_assets = [p for p in (ROOT / "android").rglob("*") if p.is_file() and re.search(r"cairo|alyamama", p.name, re.I)]
    assert_true(not legacy_assets, f"legacy font assets remain: {legacy_assets}")
    theme = read("android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/theme/Theme.kt")
    typography = read("android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/theme/Type.kt")
    assert_true("LayoutDirection.Rtl" in theme, "MaxTheme does not force RTL")
    assert_true("TajawalFamily" in typography, "Tajawal is not the canonical Compose family")
    passed.append("RTL/Tajawal foundations centralized")

    dims = read("android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/theme/Dimens.kt")
    buttons = read("android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/component/MaxPrimaryButton.kt")
    icon_button = read("android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/component/MaxIconButton.kt")
    primitives = read("android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/component/MaxPrimitives.kt")
    structure = read("android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/component/MaxStructure.kt")
    assert_true("minimumTouchTarget = 48.dp" in dims, "48dp token missing")
    assert_true("heightIn(min = MaxSizes.minimumTouchTarget)" in buttons, "button minimum touch target missing")
    assert_true(".size(MaxSizes.minimumTouchTarget)" in icon_button, "icon-button minimum touch target missing")
    assert_true("minWidth = MaxSizes.minimumTouchTarget" in primitives and "minHeight = MaxSizes.minimumTouchTarget" in primitives, "switch minimum touch target missing")
    assert_true("MaxSizes.listRowMinHeight" in structure, "list-row minimum target missing")
    passed.append("shared interactive primitives enforce >=48dp targets")

    nav = read("android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/component/MaxBottomNavigation.kt")
    state_screen = read("android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/component/MaxStateScreen.kt")
    assert_true("contentDescription" in nav, "bottom navigation action description missing")
    assert_true("MaxText" in state_screen, "state surfaces must expose textual status")
    assert_true("LocalMaxMotionEnabled" in theme, "reduced-motion foundation missing")
    passed.append("semantic labels + text status + reduced-motion foundations present")

    test_sources = "\n".join(
        p.read_text(encoding="utf-8")
        for p in sorted((ROOT / "android").rglob("src/androidTest/**/*.kt"))
    )
    missing_screen_tests = [name for name in REACHABLE if name not in test_sources]
    assert_true(not missing_screen_tests, f"reachable screens missing instrumentation source coverage: {missing_screen_tests}")
    assert_true("fontScale = 2f" in test_sources or "fontScale = 2.0f" in test_sources, "fontScale 2.0 instrumentation source missing")
    assert_true("LayoutDirection.Rtl" in test_sources, "explicit RTL instrumentation source missing")
    passed.append("17 reachable screen symbols covered by androidTest source; RTL/fontScale 2.0 cases present")

    return passed


def main() -> int:
    try:
        passed = checks()
    except AssertionError as exc:
        print(f"FAIL: {exc}")
        return 1
    for item in passed:
        print(f"PASS: {item}")
    print("STATIC_FINAL_CERTIFICATION=PASS")
    print("DEVICE_FINAL_CERTIFICATION=REQUIRED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
