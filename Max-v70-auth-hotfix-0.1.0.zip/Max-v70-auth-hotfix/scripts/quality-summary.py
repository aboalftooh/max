#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--gates', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    gates_path = Path(args.gates)
    gates = []
    if gates_path.exists():
        for line in gates_path.read_text(encoding='utf-8').splitlines():
            if line.strip():
                gates.append(json.loads(line))
    passed = sum(1 for item in gates if item['status'] == 'passed')
    failed = sum(1 for item in gates if item['status'] == 'failed')
    skipped = sum(1 for item in gates if item['status'] == 'skipped')
    payload = {
        'schemaVersion': 1,
        'overall': 'passed' if failed == 0 and skipped == 0 else 'failed',
        'passed': passed,
        'failed': failed,
        'skipped': skipped,
        'gates': gates,
    }
    Path(args.out).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(payload, ensure_ascii=False))
    return 0 if payload['overall'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
