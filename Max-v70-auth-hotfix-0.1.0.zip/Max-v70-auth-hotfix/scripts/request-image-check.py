#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
manifest = (root / "android/feature/request/src/main/AndroidManifest.xml").read_text()
manager = (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/media/AndroidRequestImageManager.kt").read_text()
ui = (root / "android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestImageAttachmentSection.kt").read_text()
paths = root / "android/feature/request/src/main/res/xml/request_file_paths.xml"
ET.parse(paths)
checks = {
    "photo_picker": "PickVisualMedia" in ui,
    "safe_camera_contract": "TakePicture" in ui,
    "file_provider": "FileProvider.getUriForFile" in manager,
    "private_cache_path": "request-camera" in manager and paths.exists(),
    "no_storage_permission": "READ_EXTERNAL_STORAGE" not in manifest and "WRITE_EXTERNAL_STORAGE" not in manifest,
    "no_camera_permission": "android.permission.CAMERA" not in manifest,
    "jpeg_reencode": "Bitmap.CompressFormat.JPEG" in manager,
    "exif_read_for_orientation": "ExifInterface" in manager,
    "gps_not_copied": "TAG_GPS" not in manager,
    "image_size_limit": "MAX_IMAGE_BYTES" in manager,
    "space_guard": "StatFs" in manager,
    "permission_failure": "PermissionLost" in manager,
    "cancelled_picker": "ImageImportFailure.Cancelled" in ui,
    "preview": "request_image_preview" in ui,
    "delete": "request_remove_image" in ui,
    "replace": '"استبدال"' in ui,
    "rotation_state": "rememberSaveable" in ui,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(f"{'PASS' if v else 'FAIL'} {k}")
if failed: raise SystemExit("Failed: "+", ".join(failed))
print(f"RESULT {len(checks)}/{len(checks)}")
