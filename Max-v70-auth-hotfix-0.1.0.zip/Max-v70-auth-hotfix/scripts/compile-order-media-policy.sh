#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/order-media-policy"
rm -rf "$OUT" && mkdir -p "$OUT"
kotlinc \
  "$ROOT/android/feature/orders/src/main/java/com/maxnetwork/feature/orders/domain/OrderReadModel.kt" \
  "$ROOT/android/feature/orders/src/main/java/com/maxnetwork/feature/orders/domain/OrderMediaAccess.kt" \
  "$ROOT/scripts/harness/orders/OrderMediaPolicyHarness.kt" \
  -Werror -include-runtime -d "$OUT/order-media-policy.jar"
java -jar "$OUT/order-media-policy.jar"
