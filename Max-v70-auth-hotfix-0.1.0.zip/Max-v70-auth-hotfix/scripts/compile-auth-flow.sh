#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
COROUTINES_JAR="${KOTLIN_HOME:-/root/.sdkman/candidates/kotlin/current}/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$OUT/harness"

cat > "$OUT/harness/Main.kt" <<'KOTLIN'
package harness

import com.maxnetwork.feature.auth.data.AuthRemoteDataSource
import com.maxnetwork.feature.auth.data.AuthSessionStore
import com.maxnetwork.feature.auth.data.DefaultRegistrationRepository
import com.maxnetwork.feature.auth.data.RegistrationSessionStore
import com.maxnetwork.feature.auth.data.RemoteAccountCreation
import com.maxnetwork.feature.auth.data.RemoteAuthFailure
import com.maxnetwork.feature.auth.data.RemoteAuthResult
import com.maxnetwork.feature.auth.data.RemotePhoneAuthentication
import com.maxnetwork.feature.auth.data.RemotePhoneChallenge
import com.maxnetwork.feature.auth.data.RemoteRegistrationValidation
import com.maxnetwork.feature.auth.data.RemoteSession
import com.maxnetwork.feature.auth.data.RemoteVerifiedPhone
import com.maxnetwork.feature.auth.data.StoredAuthSession
import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.NewAccount
import com.maxnetwork.feature.auth.domain.PhoneAuthenticationResult
import com.maxnetwork.feature.auth.domain.SignOutReason
import com.maxnetwork.feature.auth.domain.usecase.RequestPhoneChallengeUseCase
import java.time.Instant
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking

private class FakeSessionStore : AuthSessionStore {
    override val state = MutableStateFlow<AuthState>(AuthState.SignedOut())
    var stored: StoredAuthSession? = null
    var saves = 0
    override suspend fun restore(): StoredAuthSession? = stored
    override suspend fun current(): StoredAuthSession? = stored
    override suspend fun save(session: StoredAuthSession) {
        stored = session
        saves += 1
        state.value = AuthState.Authenticated(session.expiresAt)
    }
    override suspend fun markAuthenticated(expiresAt: Instant) { state.value = AuthState.Authenticated(expiresAt) }
    override suspend fun markRefreshing(previousExpiry: Instant?) = Unit
    override suspend fun markUnavailable(retryable: Boolean) = Unit
    override suspend fun clear(reason: SignOutReason) {
        stored = null
        state.value = AuthState.SignedOut(reason)
    }
}

private class FakeRemote : AuthRemoteDataSource {
    var existingUser = false
    var validCode = true
    var lastPhone: String? = null
    var createCalls = 0
    var lastAccount: RemoteAccountCreation? = null

    override suspend fun validateRegistrationCode(code: String) = if (validCode) {
        RemoteAuthResult.Success(
            RemoteRegistrationValidation("reg-token", Instant.parse("2026-08-29T09:30:00Z")),
        )
    } else RemoteAuthResult.Failure(RemoteAuthFailure.InvalidRequest, false)

    override suspend fun requestPhoneChallenge(phone: String): RemoteAuthResult<RemotePhoneChallenge> {
        lastPhone = phone
        return RemoteAuthResult.Success(
            RemotePhoneChallenge(
                challengeId = "challenge-1",
                expiresAt = Instant.parse("2026-08-29T09:05:00Z"),
                resendAvailableAt = Instant.parse("2026-08-29T09:00:00Z"),
                remainingAttempts = 5,
            ),
        )
    }

    override suspend fun verifyPhoneChallenge(challengeId: String, otp: String): RemoteAuthResult<RemoteVerifiedPhone> =
        if (challengeId == "challenge-1" && otp == "123456") {
            RemoteAuthResult.Success(
                RemoteVerifiedPhone(
                    verificationToken = "phone-proof",
                    maskedPhone = "+249***287",
                    expiresAt = Instant.parse("2026-08-29T09:15:00Z"),
                ),
            )
        } else RemoteAuthResult.Failure(RemoteAuthFailure.InvalidRequest, false)

    override suspend fun resolveVerifiedPhone(verificationToken: String): RemoteAuthResult<RemotePhoneAuthentication> =
        if (verificationToken != "phone-proof") {
            RemoteAuthResult.Failure(RemoteAuthFailure.InvalidRequest, false)
        } else if (existingUser) {
            RemoteAuthResult.Success(
                RemotePhoneAuthentication.ExistingUser(
                    RemoteSession("access-existing", "refresh-existing", Instant.parse("2026-08-29T10:00:00Z")),
                ),
            )
        } else RemoteAuthResult.Success(RemotePhoneAuthentication.NewUser)

    override suspend fun createAccount(command: RemoteAccountCreation): RemoteAuthResult<RemoteSession> {
        createCalls += 1
        lastAccount = command
        return RemoteAuthResult.Success(
            RemoteSession("access-new", "refresh-new", Instant.parse("2026-08-29T10:00:00Z")),
        )
    }

    override suspend fun requestPasswordReset(phone: String) = requestPhoneChallenge(phone)
    override suspend fun resetPassword(phone: String, resetCode: String, newPassword: String) = RemoteAuthResult.Success(Unit)
    override suspend fun login(phone: String, password: String) = RemoteAuthResult.Failure(RemoteAuthFailure.InvalidCredentials, false)
    override suspend fun refresh(refreshToken: String) = RemoteAuthResult.Failure(RemoteAuthFailure.Unauthorized, false)
    override suspend fun logout(accessToken: String) = RemoteAuthResult.Success(Unit)
}

fun main() = runBlocking {
    var passed = 0
    fun pass(name: String) { passed += 1; println("PASS: $name") }

    val remote = FakeRemote()
    val sessions = FakeSessionStore()
    val registration = DefaultRegistrationRepository(remote, RegistrationSessionStore(), sessions)
    val requestOtp = RequestPhoneChallengeUseCase(registration)

    check(requestOtp("0909212287") is AuthResult.Success)
    check(remote.lastPhone == "+249909212287")
    pass("local Sudan phone normalizes before OTP")

    check(registration.validateRegistrationCode("MAX-001") == AuthResult.Failure(AuthFailure.InvalidRequest))
    pass("join code cannot run before verified phone")

    check(registration.verifyPhoneOtp("000000") == AuthResult.Failure(AuthFailure.InvalidRequest))
    pass("wrong OTP is rejected")

    val newUser = registration.verifyPhoneOtp("123456")
    check(newUser is AuthResult.Success && newUser.value is PhoneAuthenticationResult.NewUser)
    pass("server resolution sends new user to join-code flow")

    check(registration.validateRegistrationCode("MAX-001") is AuthResult.Success)
    pass("join code is accepted only after new-user OTP")

    check(registration.createAccount(NewAccount(name = "محمد")) is AuthResult.Success)
    check(sessions.saves == 1)
    check(remote.lastAccount?.phoneVerificationToken == "phone-proof")
    pass("name-only registration creates linked account and session")

    val existingRemote = FakeRemote().apply { existingUser = true }
    val existingSessions = FakeSessionStore()
    val existingRegistration = DefaultRegistrationRepository(existingRemote, RegistrationSessionStore(), existingSessions)
    check(RequestPhoneChallengeUseCase(existingRegistration)("0909212287") is AuthResult.Success)
    val existing = existingRegistration.verifyPhoneOtp("123456")
    check(existing is AuthResult.Success && existing.value is PhoneAuthenticationResult.ExistingUser)
    check(existingSessions.saves == 1)
    pass("existing user goes directly to authenticated session")

    check(passed == 7)
    println("Android OTP-first auth flow harness: $passed/7 passed")
}
KOTLIN

SOURCES=(
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/AuthModels.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/AuthRepository.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/RegistrationModels.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/RegistrationRepository.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/usecase/RegistrationUseCases.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/AuthRemoteDataSource.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/AuthSessionStore.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/RegistrationSessionStore.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/RemoteAuthFailureMapping.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/DefaultRegistrationRepository.kt"
  "$OUT/harness/Main.kt"
)

kotlinc "${SOURCES[@]}" \
  -cp "$COROUTINES_JAR" \
  -Werror \
  -jvm-target 17 \
  -include-runtime \
  -d "$OUT/auth-flow-tests.jar"

java -cp "$OUT/auth-flow-tests.jar:$COROUTINES_JAR" harness.MainKt
