#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
COROUTINES_JAR="${KOTLIN_HOME:-/root/.sdkman/candidates/kotlin/current}/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$OUT/harness"
cat > "$OUT/harness/Main.kt" <<'KOTLIN'
package harness

import com.maxnetwork.feature.auth.data.AuthRemoteDataSource
import com.maxnetwork.feature.auth.data.AuthSessionStore
import com.maxnetwork.feature.auth.data.DefaultPasswordResetRepository
import com.maxnetwork.feature.auth.data.PasswordResetSessionStore
import com.maxnetwork.feature.auth.data.RemoteAccountCreation
import com.maxnetwork.feature.auth.data.RemoteAuthFailure
import com.maxnetwork.feature.auth.data.RemoteAuthResult
import com.maxnetwork.feature.auth.data.RemotePhoneChallenge
import com.maxnetwork.feature.auth.data.RemoteRegistrationValidation
import com.maxnetwork.feature.auth.data.RemoteSession
import com.maxnetwork.feature.auth.data.RemoteVerifiedPhone
import com.maxnetwork.feature.auth.data.StoredAuthSession
import com.maxnetwork.feature.auth.domain.AuthFailure
import com.maxnetwork.feature.auth.domain.AuthResult
import com.maxnetwork.feature.auth.domain.AuthState
import com.maxnetwork.feature.auth.domain.PasswordResetConfirmation
import com.maxnetwork.feature.auth.domain.SignOutReason
import com.maxnetwork.feature.auth.domain.usecase.ConfirmPasswordResetUseCase
import com.maxnetwork.feature.auth.domain.usecase.RequestPasswordResetUseCase
import java.time.Instant
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking

private class FakeSessionStore : AuthSessionStore {
    override val state = MutableStateFlow<AuthState>(AuthState.Authenticated(Instant.parse("2026-07-28T14:00:00Z")))
    var currentValue: StoredAuthSession? = StoredAuthSession("access-old", "refresh-old", Instant.parse("2026-07-28T14:00:00Z"))
    var clearReason: SignOutReason? = null
    override suspend fun restore() = currentValue
    override suspend fun current() = currentValue
    override suspend fun save(session: StoredAuthSession) { currentValue = session }
    override suspend fun markAuthenticated(expiresAt: Instant) { state.value = AuthState.Authenticated(expiresAt) }
    override suspend fun markRefreshing(previousExpiry: Instant?) { state.value = AuthState.Refreshing(previousExpiry) }
    override suspend fun markUnavailable(retryable: Boolean) { state.value = AuthState.TemporarilyUnavailable(retryable) }
    override suspend fun clear(reason: SignOutReason) {
        currentValue = null
        clearReason = reason
        state.value = AuthState.SignedOut(reason)
    }
}

private class FakeRemote : AuthRemoteDataSource {
    var requestCalls = 0
    var resetCalls = 0
    var knownAccount = true
    var lastPhone = ""
    var lastCode = ""

    override suspend fun requestPasswordReset(phone: String): RemoteAuthResult<RemotePhoneChallenge> {
        requestCalls += 1
        lastPhone = phone
        // Same result for known and unknown phones: no account enumeration.
        return RemoteAuthResult.Success(
            RemotePhoneChallenge(
                challengeId = "generic-reset",
                expiresAt = Instant.parse("2026-07-28T13:10:00Z"),
                resendAvailableAt = Instant.parse("2026-07-28T13:01:00Z"),
                remainingAttempts = 5,
            ),
        )
    }

    override suspend fun resetPassword(phone: String, resetCode: String, newPassword: String): RemoteAuthResult<Unit> {
        resetCalls += 1
        lastPhone = phone
        lastCode = resetCode
        return if (knownAccount && resetCode == "246810" && newPassword.length >= 10) {
            RemoteAuthResult.Success(Unit)
        } else {
            RemoteAuthResult.Failure(RemoteAuthFailure.InvalidRequest, false)
        }
    }

    override suspend fun validateRegistrationCode(code: String): RemoteAuthResult<RemoteRegistrationValidation> =
        RemoteAuthResult.Failure(RemoteAuthFailure.InvalidRequest, false)
    override suspend fun requestPhoneChallenge(phone: String): RemoteAuthResult<RemotePhoneChallenge> =
        RemoteAuthResult.Failure(RemoteAuthFailure.InvalidRequest, false)
    override suspend fun verifyPhoneChallenge(challengeId: String, otp: String): RemoteAuthResult<RemoteVerifiedPhone> =
        RemoteAuthResult.Failure(RemoteAuthFailure.InvalidRequest, false)
    override suspend fun createAccount(command: RemoteAccountCreation): RemoteAuthResult<RemoteSession> =
        RemoteAuthResult.Failure(RemoteAuthFailure.InvalidRequest, false)
    override suspend fun login(phone: String, password: String): RemoteAuthResult<RemoteSession> =
        RemoteAuthResult.Failure(RemoteAuthFailure.InvalidCredentials, false)
    override suspend fun refresh(refreshToken: String): RemoteAuthResult<RemoteSession> =
        RemoteAuthResult.Failure(RemoteAuthFailure.Unauthorized, false)
    override suspend fun logout(accessToken: String): RemoteAuthResult<Unit> = RemoteAuthResult.Success(Unit)
}

fun main() = runBlocking {
    var passed = 0
    fun pass(name: String) { passed += 1; println("PASS: $name") }

    val remote = FakeRemote()
    val sessionStore = FakeSessionStore()
    val resetStore = PasswordResetSessionStore()
    val repository = DefaultPasswordResetRepository(remote, resetStore, sessionStore)
    val request = RequestPasswordResetUseCase(repository)
    val confirm = ConfirmPasswordResetUseCase(repository)

    check(request("0912000000") == AuthResult.Failure(AuthFailure.InvalidRequest))
    check(remote.requestCalls == 0)
    pass("invalid phone is rejected locally")

    check(request("+249912000000") is AuthResult.Success)
    check(remote.requestCalls == 1)
    pass("reset challenge is requested through the repository")

    remote.knownAccount = false
    check(request("+249912999999") is AuthResult.Success)
    pass("request response does not reveal whether the phone exists")

    check(confirm("12", "new-password-12", "new-password-12") == AuthResult.Failure(AuthFailure.InvalidRequest))
    check(remote.resetCalls == 0)
    pass("invalid code is rejected before network")

    check(confirm("246810", "short", "short") == AuthResult.Failure(AuthFailure.InvalidRequest))
    pass("weak password is rejected before network")

    remote.knownAccount = true
    check(confirm("246810", "new-password-12", "different-pass") == AuthResult.Failure(AuthFailure.InvalidRequest))
    pass("password confirmation mismatch is rejected")

    check(confirm("246810", "new-password-12", "new-password-12") is AuthResult.Success)
    check(remote.lastPhone == "+249912999999")
    check(sessionStore.currentValue == null)
    check(sessionStore.clearReason == SignOutReason.SessionExpired)
    pass("successful reset clears local authentication session")

    check(repository.resetPassword(PasswordResetConfirmation("246810", "new-password-12")) == AuthResult.Failure(AuthFailure.InvalidRequest))
    check(remote.resetCalls == 1)
    pass("used reset session cannot be replayed")

    check(passed == 8)
    println("Android password reset flow harness: $passed/8 passed")
}
KOTLIN

SOURCES=(
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/AuthModels.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/PasswordResetModels.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/PasswordResetRepository.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/usecase/PasswordResetUseCases.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/AuthRemoteDataSource.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/AuthSessionStore.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/PasswordResetSessionStore.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/RemoteAuthFailureMapping.kt"
  "$ROOT/android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/DefaultPasswordResetRepository.kt"
  "$OUT/harness/Main.kt"
)

kotlinc "${SOURCES[@]}" -cp "$COROUTINES_JAR" -Werror -jvm-target 17 -include-runtime -d "$OUT/reset-flow.jar"
java -cp "$OUT/reset-flow.jar:$COROUTINES_JAR" harness.MainKt
