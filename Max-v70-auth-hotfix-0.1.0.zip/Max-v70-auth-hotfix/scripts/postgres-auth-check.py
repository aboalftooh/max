#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
store = (ROOT / "backend/src/main/kotlin/com/maxnetwork/backend/auth/infrastructure/postgres/PostgresAuthStore.kt").read_text()
connection = (ROOT / "backend/src/main/kotlin/com/maxnetwork/backend/auth/infrastructure/postgres/PostgresConnection.kt").read_text()
runtime = (ROOT / "backend/src/main/kotlin/com/maxnetwork/backend/auth/infrastructure/postgres/PostgresAuthRuntime.kt").read_text()
migration = (ROOT / "backend/src/main/resources/db/migration/V001__auth_schema.sql").read_text()
delete_migration = (ROOT / "backend/src/main/resources/db/migration/V010__profile_account_deletion.sql").read_text()
build = (ROOT / "backend/build.gradle.kts").read_text()

checks = []
def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)
    checks.append(message)

require("class PostgresAuthStore" in store and ": AuthStore" in store, "Postgres implements AuthStore")
require("connection.autoCommit = false" in store, "transactions disable autocommit")
require("connection.commit()" in store, "successful transactions commit")
require("connection.rollback()" in store, "failed transactions roll back")
require("set local row_security = off" in store, "cross-tenant auth fails closed under RLS")
require("statement_timeout" in store and "lock_timeout" in store, "database operations are bounded")
require(store.count(" for update") >= 15, "mutable reads lock rows")
require("PreparedStatement" in store and "prepareStatement" in store, "prepared statements are used")
require("createStatement" in store and store.count("createStatement") == 1, "raw statements are limited to transaction guards")
require("password_hash" in store and "passwordHash" in store, "password hashes map without plaintext fields")
require("access_token_digest" in store and "refresh_token_digest" in store, "session digests are persisted")
require("account_deletion_request" in store, "account deletion is durable")
require("storeId = getString(\"store_id\")" in store, "tenant ownership maps from database")
require("Expected one row" in store and "executeUpdate() == 1" in store, "writes enforce cardinality")
require("org.postgresql:postgresql:" in build, "PostgreSQL runtime driver is declared")
require("MAX_DB_PASSWORD" in connection and "<redacted>" in connection, "database secret is required and redacted")
require("sslmode=verify-full" in connection and "sslmode=verify-ca" in connection, "production verifies PostgreSQL TLS")
require("connectTimeout" in connection and "socketTimeout" in connection, "driver network waits are bounded")
require("to_regclass('max_auth.store')" in connection, "readiness checks auth schema")
require("PostgresAuthSchemaProbe" in runtime, "runtime exposes database readiness")
require("createAuthComponents" in runtime, "durable store uses shared auth composition")
require("InMemory" not in runtime, "production runtime does not fall back to memory")

required_tables = {
    "store",
    "app_user",
    "registration_code",
    "registration_validation_grant",
    "phone_challenge",
    "phone_verification_grant",
    "password_reset_challenge",
    "auth_session",
}
for table in sorted(required_tables):
    require(f"max_auth.{table}" in store, f"adapter covers {table}")
    require(re.search(rf"create table if not exists max_auth\.{table}\b", migration) is not None, f"migration defines {table}")
require("max_auth.account_deletion_request" in store, "adapter covers deletion table")
require("create table if not exists max_auth.account_deletion_request" in delete_migration, "migration defines deletion table")

for method in [
    "insertStore", "findStore", "updateStore", "insertUser", "updateUser", "findUserByPhone",
    "findUserForStore", "insertRegistrationCode", "updateRegistrationCode",
    "findRegistrationCodeByDigest", "findRegistrationCode", "insertRegistrationValidation",
    "updateRegistrationValidation", "findRegistrationValidationByDigest", "registrationValidationsForCode",
    "insertPhoneChallenge", "updatePhoneChallenge", "findPhoneChallenge", "phoneChallenges",
    "insertPhoneVerification", "updatePhoneVerification", "findPhoneVerificationByDigest",
    "phoneVerifications", "insertPasswordReset", "updatePasswordReset", "passwordResets",
    "insertSession", "updateSession", "findSessionByAccessDigest", "findSessionByRefreshDigest",
    "sessionsForUser", "insertAccountDeletion", "accountDeletionForUser",
]:
    require(f"override fun {method}" in store, f"AuthTransaction method implemented: {method}")

require("println(" not in store and "print(" not in store, "adapter does not log secrets")
require("System.getenv" not in store, "store does not read environment directly")
require("password=<redacted>" in connection, "config diagnostics redact password")
print(f"postgres-auth-check: {len(checks)}/{len(checks)} checks passed")
