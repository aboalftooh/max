#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
screen = ROOT / 'android/feature/balance/src/main/java/com/maxnetwork/feature/balance/presentation/BalanceScreen.kt'
presentation = '\n'.join(
    p.read_text(encoding='utf-8')
    for p in (ROOT / 'android/feature/balance/src/main/java/com/maxnetwork/feature/balance/presentation').glob('*.kt')
)
app = (ROOT / 'android/app/src/main/java/com/maxnetwork/android/MaxApp.kt').read_text(encoding='utf-8')
main = (ROOT / 'android/app/src/main/java/com/maxnetwork/android/MainActivity.kt').read_text(encoding='utf-8')
destination = (ROOT / 'android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt').read_text(encoding='utf-8')
factory = (ROOT / 'android/feature/balance/src/main/java/com/maxnetwork/feature/balance/BalanceFeatureFactory.kt').read_text(encoding='utf-8')

checks = [
    ('dead-balance-screen-removed', not screen.exists() and 'fun BalanceScreen' not in presentation),
    ('no-balance-composable-remains', '@Composable' not in presentation),
    ('balance-viewmodel-kept', 'BalanceViewModel' in main and 'balanceViewModel' in app),
    ('balance-home-projection-kept', 'BalanceUiState.toHomeUiState' in app and 'balanceAmount = currentBalance?.toSdgText()' in app),
    ('balance-movements-home-projection-kept', 'movements = movements.map' in app and 'movementDirectionLabel()' in app),
    ('balance-domain-factory-kept', 'BalanceFeatureFactory' in factory and 'loadBalance' in factory),
    ('legacy-route-kept', 'data object Balance : MaxDestination' in destination and 'override val route = "balance"' in destination),
    ('legacy-route-normalized-home', 'MaxDestination.Balance.route' in destination and '-> MaxDestination.Home' in destination),
    ('no-balance-render-branch', 'BalanceScreen(' not in app),
    ('logout-clears-balance-state', 'balanceViewModel.clear()' in app),
]
failed = [name for name, ok in checks if not ok]
if failed:
    print('balance compatibility checks failed:')
    for name in failed:
        print('-', name)
    raise SystemExit(1)
print(f'balance compatibility checks passed: {len(checks)}/{len(checks)}')
for name, _ in checks:
    print('-', name)
