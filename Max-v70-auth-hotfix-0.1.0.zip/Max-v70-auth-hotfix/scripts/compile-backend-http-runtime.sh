#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/backend-http-runtime.jar"
mkdir -p "$ROOT/verification-artifacts"
mapfile -t SOURCES < <(find "$ROOT/backend/src/main/kotlin" -name '*.kt' | sort)
kotlinc "${SOURCES[@]}" \
  "$ROOT/backend/src/test/kotlin/com/maxnetwork/backend/http/BackendHttpRuntimeTest.kt" \
  -Werror -include-runtime -d "$OUT"
java --add-modules jdk.httpserver -jar "$OUT"
