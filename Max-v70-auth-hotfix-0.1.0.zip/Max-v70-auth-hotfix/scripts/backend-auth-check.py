#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUTH_ROOT = ROOT / "backend/src/main/kotlin/com/maxnetwork/backend/auth"
SQL = ROOT / "backend/src/main/resources/db/migration/V001__auth_schema.sql"
OPENAPI = ROOT / "contracts/api/openapi.yaml"


def run_checks() -> list[tuple[str, bool]]:
    production = "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted(AUTH_ROOT.rglob("*.kt"))
    )
    sql = SQL.read_text(encoding="utf-8")
    openapi = OPENAPI.read_text(encoding="utf-8")
    service = (AUTH_ROOT / "application/AuthService.kt").read_text(encoding="utf-8")
    api = (AUTH_ROOT / "api/AuthApi.kt").read_text(encoding="utf-8")
    security = (AUTH_ROOT / "infrastructure/security/JvmSecurity.kt").read_text(encoding="utf-8")
    memory = (AUTH_ROOT / "infrastructure/memory/InMemoryAuthStore.kt").read_text(encoding="utf-8")

    raw_secret_columns = re.compile(
        r"\b(password|otp|registration_code|reset_code|access_token|refresh_token)\s+text\b",
        re.IGNORECASE,
    )
    logging_calls = re.compile(r"\b(println|print|System\.out|System\.err|logger\.)")
    sensitive_schema_count = openapi.count("x-sensitive: true")

    return [
        ("auth-layered-structure", all((AUTH_ROOT / part).is_dir() for part in ["domain", "application", "ports", "api", "infrastructure"])),
        ("postgres-auth-schema", SQL.is_file() and "create schema if not exists max_auth" in sql),
        ("no-raw-secret-columns", raw_secret_columns.search(sql) is None),
        ("password-pbkdf2", "PBKDF2WithHmacSHA256" in security and "210_000" in security),
        ("purpose-separated-hmac", "HmacSHA256" in security and "mac.update(purpose.toByteArray" in security and "mac.update(0)" in security),
        ("pepper-injected", "pepper: ByteArray" in security and "AUTH_TOKEN_PEPPER" not in production),
        ("registration-one-transaction", "fun createAccount" in service and "return store.transaction" in service),
        ("registration-code-consumed", "updateRegistrationCode(registrationCode.copy(usedAt = now))" in service),
        ("grants-consumed", "updateRegistrationValidation(registrationGrant.copy(consumedAt = now))" in service and "updatePhoneVerification(phoneGrant.copy(consumedAt = now))" in service),
        ("concurrency-lock", "synchronized(lock)" in memory),
        ("tenant-scoped-read", "findUserForStore(principal.storeId, requestedUserId)" in service),
        ("postgres-rls", sql.count("enable row level security") >= 5 and "current_setting('app.store_id', true)" in sql),
        ("old-challenges-invalidated", "updatePhoneChallenge(it.copy(invalidatedAt = now))" in service and "updatePasswordReset(it.copy(invalidatedAt = now))" in service),
        ("attempt-limits", "remainingAttempts = remaining" in service and "remaining == 0" in service),
        ("generic-api-errors", "submitted" not in api.lower() and "تعذر إكمال الطلب" in api and "بيانات الدخول غير صحيحة" in api),
        ("no-production-secret-logging", logging_calls.search(production) is None),
        ("openapi-sensitive-fields", sensitive_schema_count >= 12),
        ("openapi-auth-routes", all(path in openapi for path in [
            "/v1/auth/registration-codes/validate:",
            "/v1/auth/phone-challenges:",
            "/v1/auth/accounts:",
            "/v1/auth/sessions:",
            "/v1/auth/sessions/refresh:",
            "/v1/auth/password-reset/confirm:",
        ])),
    ]


def main() -> int:
    checks = run_checks()
    failures = [name for name, passed in checks if not passed]
    if failures:
        print("Backend authentication checks failed:")
        for name in failures:
            print(f"- {name}")
        return 1
    print(f"Backend authentication checks passed: {len(checks)}/{len(checks)}")
    for name, _ in checks:
        print(f"- {name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
