#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/outgoing-timeline"
rm -rf "$OUT" && mkdir -p "$OUT"
kotlinc \
  "$ROOT/android/feature/orders/src/main/java/com/maxnetwork/feature/orders/domain/OrderReadModel.kt" \
  "$ROOT/android/feature/orders/src/main/java/com/maxnetwork/feature/orders/domain/OutgoingOrderSync.kt" \
  "$ROOT/scripts/harness/orders/OutgoingTimelineHarness.kt" \
  -Werror -include-runtime -d "$OUT/outgoing-timeline.jar"
java -jar "$OUT/outgoing-timeline.jar"
