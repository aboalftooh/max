#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

required=(
  "AGENTS.md"
  "android/settings.gradle.kts"
  "android/app/build.gradle.kts"
  "android/app/src/main/AndroidManifest.xml"
  "docs/product-config.md"
  "docs/product-policies.md"
  "docs/active-architecture.md"
  "docs/dependency-rules.md"
  "docs/quality-gates.md"
  "docs/glossary.md"
  "docs/source-of-truth/max_product_source_of_truth_v1.md"
  "contracts/api/openapi.yaml"
  "contracts/verto/verto-events.schema.json"
  "backend/build.gradle.kts"
  "backend/src/main/resources/db/migration/V001__auth_schema.sql"
  "docs/auth-security.md"
)

for file in "${required[@]}"; do
  [[ -f "$file" ]] || { echo "Missing required file: $file"; exit 1; }
done

python3 "$ROOT/scripts/secret-scan.py" "$ROOT"
python3 "$ROOT/scripts/architecture-check.py" "$ROOT/android"

if find . -type f \
  \( -name '*.pyc' -o -path '*/__pycache__/*' \) \
  -print -quit | grep -q .; then
  echo "Generated Python cache found in repository"
  exit 1
fi

if find android backend contracts docs scripts -type f \
  \( -name '*.log' -o -name '*.apk' -o -name '*.aab' -o -name '*.jks' -o -name '*.keystore' \) \
  -print -quit | grep -q .; then
  echo "Generated or credential file found inside source directories"
  exit 1
fi

if grep -RInE --include='*.kt' --include='*.kts' --include='*.java' \
  '(^|[^A-Za-z])(TODO|FIXME)(:|\b)' android backend 2>/dev/null; then
  echo "Critical TODO/FIXME marker found in production source"
  exit 1
fi

echo "Repository checks passed"
