#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
def text(path): return (ROOT / path).read_text(encoding='utf-8')
def tree(path): return '\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/path).rglob('*.kt'))

presentation = tree('android/feature/auth/src/main/java/com/maxnetwork/feature/auth/presentation')
data = tree('android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data')
domain = tree('android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain')
app = text('android/app/src/main/java/com/maxnetwork/android/MaxApp.kt')
network = text('android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt')
checks = [
 ('otp-screen', 'fun OtpScreen' in presentation),
 ('single-logical-otp', 'MaxOtpField' in presentation and 'otp_input' in presentation),
 ('otp-paste-normalization', 'filter(Char::isDigit).take(OTP_LENGTH)' in presentation),
 ('otp-accessibility', 'max_auth_otp_accessibility' in presentation),
 ('resend-countdown', 'resendSecondsRemaining' in presentation and 'resendPhoneChallenge' in domain),
 ('otp-attempt-limit', 'remainingAttempts' in presentation and 'remainingAttempts' in data),
 ('account-screen', 'fun CreateAccountScreen' in presentation),
 ('account-name-only', 'create_account_name' in presentation and 'create_account_password' not in presentation and 'create_account_store_name' not in presentation),
 ('account-screen-no-phone', 'max_auth_phone' not in text('android/feature/auth/src/main/java/com/maxnetwork/feature/auth/presentation/CreateAccountScreen.kt')),
 ('verified-session-required', 'StoredRegistrationSession.PhoneVerified' in data),
 ('atomic-session-transition', 'authSessionStore.save(session)' in data and 'registrationStore.clear()' in data),
 ('registration-endpoints', all(x in network for x in ['phone-challenges/{challengeId}/verify','v1/auth/accounts'])),
 ('new-user-navigation', 'AuthUiEvent.NewUserOtpVerified' in app and 'MaxDestination.RegistrationCode' in app),
 ('accepted-code-navigation', 'AuthUiEvent.RegistrationCodeAccepted' in app and 'MaxDestination.CreateAccount' in app),
 ('no-route-secrets', all(x not in app for x in ['validationToken =', 'challengeId =', 'phoneVerificationToken ='])),
]
failed=[n for n,p in checks if not p]
if failed:
 print('registration otp/account checks failed:')
 for n in failed: print(f'- {n}')
 raise SystemExit(1)
print(f'registration otp/account checks passed: {len(checks)}/{len(checks)}')
for n,_ in checks: print(f'- {n}')
