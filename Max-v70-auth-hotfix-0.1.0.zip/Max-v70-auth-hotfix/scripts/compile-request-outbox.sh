#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/request-outbox-harness.jar"
COROUTINES="$(dirname "$(which kotlinc)")/../lib/kotlinx-coroutines-core-jvm.jar"
kotlinc \
  -classpath "$COROUTINES" \
  "$ROOT/android/core/network/src/main/kotlin/com/maxnetwork/core/network/ApiModels.kt" \
  "$ROOT/android/core/network/src/main/kotlin/com/maxnetwork/core/network/MaxGateway.kt" \
  "$ROOT/android/feature/request/src/main/java/com/maxnetwork/feature/request/domain/RequestModels.kt" \
  "$ROOT/android/feature/request/src/main/java/com/maxnetwork/feature/request/domain/RequestOutbox.kt" \
  "$ROOT/android/feature/request/src/main/java/com/maxnetwork/feature/request/data/outbox/RequestOutboxProcessor.kt" \
  "$ROOT/scripts/harness/RequestOutboxHarness.kt" \
  -include-runtime -d "$OUT"
java -cp "$OUT:$COROUTINES" com.maxnetwork.feature.request.data.outbox.RequestOutboxHarnessKt
