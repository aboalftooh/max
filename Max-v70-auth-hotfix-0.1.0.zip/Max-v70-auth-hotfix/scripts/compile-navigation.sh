#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/verification-artifacts/navigation-harness.jar"
mkdir -p "$(dirname "$OUT")"
kotlinc \
  "$ROOT/android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt" \
  "$ROOT/android/app/src/main/java/com/maxnetwork/android/navigation/MaxBackStack.kt" \
  "$ROOT/scripts/harness/NavigationHarness.kt" \
  -Werror -include-runtime -d "$OUT"
java -jar "$OUT"
