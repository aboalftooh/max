#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
removed = [
    'android/feature/balance/src/main/java/com/maxnetwork/feature/balance/presentation/BalanceScreen.kt',
    'android/feature/orders/src/main/java/com/maxnetwork/feature/orders/presentation/OrdersScreen.kt',
    'android/feature/orders/src/main/java/com/maxnetwork/feature/orders/presentation/OrderContentPanel.kt',
    'android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestSuccessScreen.kt',
]
for rel in removed:
    if (ROOT/rel).exists():
        raise SystemExit(f'dead UI still exists: {rel}')

orders_presentation = ROOT/'android/feature/orders/src/main/java/com/maxnetwork/feature/orders/presentation'
if orders_presentation.exists() and any(orders_presentation.glob('*.kt')):
    raise SystemExit('orphan orders presentation Kotlin remains')

allowlist = ROOT/'docs/designsystem/DESIGN-COMPLIANCE-ALLOWLIST.txt'
if allowlist.read_text(encoding='utf-8').strip():
    raise SystemExit('design compliance allowlist must be empty after SESSION-65')

symbols = ('BalanceScreen', 'IncomingOrdersScreen', 'OutgoingOrdersScreen', 'RequestSuccessScreen', 'OrderContentPanel', 'ZoomablePrivateImage', 'OrdersViewModel', 'OrdersUiState')
production_roots = [ROOT/'android/app/src/main', *sorted((ROOT/'android/feature').glob('*/src/main'))]
for source_root in production_roots:
    if not source_root.exists():
        continue
    for path in source_root.rglob('*.kt'):
        text = path.read_text(encoding='utf-8')
        for symbol in symbols:
            if re.search(rf'\b{re.escape(symbol)}\b', text):
                raise SystemExit(f'dead presentation symbol remains in production: {path.relative_to(ROOT)} -> {symbol}')

nav = (ROOT/'android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt').read_text(encoding='utf-8')
for token in ('MaxDestination.IncomingOrders.route', 'MaxDestination.OutgoingOrders.route', 'MaxDestination.Balance.route', 'LEGACY_REQUEST_SUCCESS_ROUTE'):
    if token not in nav:
        raise SystemExit(f'backward-compatible route normalization removed: {token}')
if '-> MaxDestination.Home' not in nav:
    raise SystemExit('legacy route normalization to Home missing')

print('SESSION-65 dead UI removal checks passed: 4/4 screens removed; orders presentation empty; compatibility routes preserved')
