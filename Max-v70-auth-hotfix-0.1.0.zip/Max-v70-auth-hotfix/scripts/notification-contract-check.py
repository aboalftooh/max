#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
checks = 0


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def expect(condition: bool, name: str) -> None:
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {name}")
    checks += 1


api = read("backend/src/main/kotlin/com/maxnetwork/backend/notification/api/NotificationApi.kt")
service = read("backend/src/main/kotlin/com/maxnetwork/backend/notification/application/NotificationService.kt")
store = read("backend/src/main/kotlin/com/maxnetwork/backend/notification/infrastructure/InMemoryNotificationStore.kt")
cursor = read("backend/src/main/kotlin/com/maxnetwork/backend/notification/infrastructure/HmacNotificationCursorCodec.kt")
sql = read("backend/src/main/resources/db/migration/V008__notification_inbox.sql")
openapi = read("contracts/api/openapi.yaml")
network = read("android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt")
domain = read("android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/NotificationReadModel.kt")
data = read("android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/data/NetworkNotificationRepository.kt")
build = read("android/feature/notifications/build.gradle.kts")

expect("fun listNotifications(" in api and "accessToken: String" in api, "authenticated-list-endpoint")
expect("fun markRead(accessToken: String" in api, "authenticated-read-endpoint")
expect("auth.authenticate(accessToken)" in api, "server-session-authentication")
expect("StoreId(result.value.storeId)" in api, "tenant-derived-from-session")
expect("storeId:" not in api.split("fun listNotifications", 1)[1].split("private fun", 1)[0], "no-client-store-selector")
expect("sourceEventId" not in api and "sequence" not in api.split("data class NotificationResponse", 1)[1], "internal-fields-hidden")
expect("limit !in MIN_LIMIT..MAX_LIMIT" in service, "limit-validation")
expect("limit + 1" in service and "visible.last().sequence" in service, "stable-keyset-pagination")
expect("event.type.content()" in service, "server-owned-content")
expect("RequestNeedsReply" in service and "BalanceUpdated" in service, "six-server-content-types")
expect("byEvent" in store and "Replay" in store and "Conflict" in store, "idempotent-event-storage")
expect("synchronized(lock)" in store, "concurrency-protection")
expect("readAt" in store and "AlreadyRead" in store, "idempotent-read-state")
expect("HmacSHA256" in cursor and "MessageDigest.isEqual" in cursor, "signed-cursor")
expect("cursorStore == storeId.value" in cursor, "tenant-bound-cursor")
expect("MIN_SECRET_BYTES = 32" in cursor, "cursor-secret-strength")
expect("enable row level security" in sql.lower(), "sql-rls")
expect("current_setting('app.store_id'" in sql, "sql-tenant-context")
expect("unique (store_id, source_event_id)" in sql.lower(), "sql-event-idempotency")
expect("order by item.sequence_no desc" in sql.lower(), "sql-newest-first")
expect("notification content is immutable" in sql.lower(), "sql-content-immutable")
expect("notification rows cannot be deleted" in sql.lower(), "sql-delete-guard")
expect("read_at is not null" in sql.lower(), "sql-read-timestamp-once")
expect("revoke all on function" in sql.lower(), "sql-no-public-execute")
expect('@GET("v1/notifications")' in network, "android-list-client")
expect('@POST("v1/notifications/{notificationId}/read")' in network, "android-read-client")
expect("Unknown notification type" in network, "unknown-type-rejected")
expect("interface NotificationRepository" in read("android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/NotificationRepository.kt"), "domain-repository")
expect("class NetworkNotificationRepository" in data, "network-repository")
expect("NotificationType.BalanceUpdated -> NotificationKind.BalanceUpdated" in data, "all-type-mapping")
expect(not re.search(r'^import (android\.|androidx\.|retrofit2\.|okhttp3\.)', domain, re.M), "domain-platform-free")
expect('project(":feature:' not in build, "no-feature-dependency")
expect("/v1/notifications:" in openapi and "/v1/notifications/{notificationId}/read:" in openapi, "openapi-notification-routes")
notification_segment = openapi.split("  /v1/notifications:", 1)[1].split("  /v1/push/", 1)[0]
expect("put:" not in notification_segment and "patch:" not in notification_segment and "delete:" not in notification_segment, "no-notification-settings-or-delete")
expect("REQUEST_NEEDS_REPLY" in openapi and "BALANCE_UPDATED" in openapi, "six-openapi-types")
expect("notification settings" not in service.lower(), "no-complex-settings")

print(f"NotificationContractCheck: {checks}/{checks} checks passed")
