#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
coordinator = (root / "android/app/src/main/java/com/maxnetwork/android/session/SessionCoordinator.kt").read_text()
vm = (root / "android/app/src/main/java/com/maxnetwork/android/session/SessionViewModel.kt").read_text()
operations = (root / "android/app/src/main/java/com/maxnetwork/android/session/DefaultSessionOperations.kt").read_text()
profile = (root / "android/feature/profile/src/main/java/com/maxnetwork/feature/profile/presentation/ProfileScreen.kt").read_text()
auth_vm = (root / "android/feature/auth/src/main/java/com/maxnetwork/feature/auth/presentation/AuthViewModel.kt").read_text()
auth_repo = (root / "android/feature/auth/src/main/java/com/maxnetwork/feature/auth/data/DefaultAuthRepository.kt").read_text()
api = (root / "contracts/api/openapi.yaml").read_text()
checks = []

def require(value: bool, name: str) -> None:
    checks.append(name)
    if not value:
        raise SystemExit(f"FAIL: {name}")

require("sessionStore.clear(SignOutReason.UserRequested)" in auth_repo, "logout clears encrypted auth session before remote result")
require("clearTransientAuthenticationData" in coordinator and "clearProfileData" in coordinator, "logout clears all local sensitive feature state")
require("clearSensitiveUiState" in auth_vm, "in-memory credentials are cleared")
require("_loginUiState.value = LoginUiState()" in auth_vm, "login input is reset")
require("delete_account_first_dialog" in profile, "first deletion confirmation exists")
require("delete_account_final_dialog" in profile, "second deletion confirmation exists")
require("تبقى الحركات المالية" in profile, "financial retention is disclosed")
require("if (!state.deleting) onCancel()" in profile, "in-flight deletion cannot dismiss silently")
require("DeletionSubmission.Failed" in vm and "deletionError" in vm, "network failure remains visible")
require("requestId" in api and "requestAccountDeletion" in api, "deletion request is trackable by contract")
require("logout()" in coordinator and "is DeletionSubmission.Accepted" in coordinator, "accepted deletion clears session")
require("is DeletionSubmission.Failed -> submission" in coordinator, "failed deletion preserves signed-in state")
require("does not delete financial history" in api, "API protects financial history")
require("requestDeletion()" in operations, "deletion passes through domain use case")
require("clearRegistration()" in operations and "clearPasswordReset()" in operations, "temporary auth flows are cleared")

print(f"session-deletion-check: {len(checks)}/{len(checks)} passed")
