#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = 0


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def expect(condition: bool, name: str) -> None:
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {name}")
    checks += 1


models = read("backend/src/main/kotlin/com/maxnetwork/backend/balance/domain/FinancialLedgerModels.kt")
service = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/adjustment/application/VertoAdjustmentProjectionService.kt")
ports = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/adjustment/ports/AdjustmentProjectionPorts.kt")
store = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/infrastructure/InMemoryInvoiceProjectionStore.kt")
sync = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/application/VertoFinancialSynchronizer.kt")
module = read("backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/VertoInvoiceModule.kt")
sql = read("backend/src/main/resources/db/migration/V006__verto_corrections_returns_ledger.sql")
schema = read("contracts/verto/verto-events.schema.json")
openapi = read("contracts/api/openapi.yaml")

expect("Correction" in models and "Return" in models, "movement-types")
expect("signedDeltaMinorUnits: Long = defaultSignedDelta" in models, "explicit-adjustment-delta")
expect("signedDeltaMinorUnits == amountMinorUnits || signedDeltaMinorUnits == -amountMinorUnits" in models, "absolute-amount-invariant")
expect("event.causationEventId.isNullOrBlank()" in service, "cause-required")
expect("findMovementBySourceEventId(causationEventId)" in service, "cause-resolved-from-ledger")
expect("cause.storeId != storeId" in service, "same-store-cause")
expect("signed == Long.MIN_VALUE" in service, "minimum-long-rejected")
expect("FinancialMovementType.Correction" in service and "signedDelta = signed" in service, "signed-correction")
expect("FinancialMovementType.Return" in service and "cause.signedDeltaMinorUnits < 0" in service, "return-reverses-invoice")
expect("cause.type !in invoiceMovementTypes" in service, "return-invoice-only")
expect("findAdjustmentEventById" in service and "findAdjustmentEventByIdempotencyKey" in service, "adjustment-idempotency-precheck")
expect("payload.requestId.orEmpty()" in service, "fingerprint-covers-request-trace")
expect("commitAdjustment" in ports and "ReturnExceedsOriginal" in ports, "atomic-adjustment-port")
expect("@Synchronized\n    override fun commitAdjustment" in store, "atomic-in-memory-adjustment")
expect("returnedMinorUnitsByCause" in store and "Math.addExact" in store, "cumulative-return-limit")
expect("adjustmentEventsById.containsKey" in store and "settlementEventsById.containsKey" in store, "cross-type-conflicts")
expect("commitMovement(movement)" in store and "AdjustmentCommitResult.BalanceOverflow" in store, "atomic-balance-overflow")
expect("VertoEventType.ReturnRecorded" in sync and "AdjustmentApplied" in sync, "unified-sync-adjustments")
expect("appliedAdjustments" in sync and "cursorAdvanced = rejected == 0" in sync, "sync-report-and-cursor")
expect("VertoAdjustmentProjectionService" in module and "adjustmentProjector = adjustmentProjector" in module, "module-wiring")
expect("CORRECTION_RECORDED" in sql and "RETURN_RECORDED" in sql, "sql-event-types")
expect("verto_financial_event_causation_store_fk" in sql, "sql-same-store-cause-fk")
expect("amount_minor_units <> 0" in sql and "-9223372036854775808" in sql, "sql-correction-amount")
expect("cause_movement_type not in ('INCOMING_ORDER', 'OUTGOING_ORDER')" in sql, "sql-return-invoice-only")
expect("already_returned + absolute_amount_value > cause_amount" in sql, "sql-cumulative-return-limit")
expect("for update" in sql.lower(), "sql-store-row-lock")
expect("when 'CORRECTION_RECORDED' then new.amount_minor_units" in sql, "sql-signed-correction")
expect("when cause_signed_delta < 0 then new.amount_minor_units" in sql, "sql-return-direction")
expect("movement_type in ('CORRECTION', 'RETURN')" in sql, "sql-adjustment-sign-check")
expect('"causationEventId"' in schema and '"minimum": 1' in schema, "contract-adjustment-rules")
expect("CORRECTION, RETURN" in openapi, "openapi-movement-types")
expect("Android" not in service and "android" not in service, "backend-only-service")

print(f"VertoAdjustmentCheck: {checks}/{checks} checks passed")
