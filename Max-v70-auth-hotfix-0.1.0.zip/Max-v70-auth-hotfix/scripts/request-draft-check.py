#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
request = root / "android/feature/request/src/main"
domain_text = "\n".join(p.read_text() for p in (request / "java/com/maxnetwork/feature/request/domain").rglob("*.kt"))
all_text = "\n".join(p.read_text() for p in request.rglob("*.kt"))
checks = {
    "domain_has_request_draft": "data class RequestDraft(" in domain_text,
    "domain_has_request_content": "data class RequestContent(" in domain_text,
    "domain_has_request_status": "enum class RequestStatus" in domain_text,
    "domain_has_request_source": "enum class RequestSource" in domain_text,
    "text_supported": "text: String" in domain_text,
    "image_supported": "image: RequestAttachmentRef?" in domain_text,
    "audio_supported": "audio: RequestAttachmentRef?" in domain_text,
    "financial_false": "financialMovementCreated: Boolean = false" in domain_text,
    "room_database": "@Database(" in all_text,
    "room_entity": "@Entity(tableName = \"request_drafts\")" in all_text,
    "room_dao": "@Dao" in all_text,
    "domain_no_android_uri": "android.net.Uri" not in domain_text,
    "domain_no_android_context": "android.content.Context" not in domain_text,
    "domain_no_room": "androidx.room" not in domain_text,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} {name}")
if failed:
    raise SystemExit("Failed: " + ", ".join(failed))
print(f"RESULT {len(checks)}/{len(checks)}")
