#!/usr/bin/env python3
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
domain = "\n".join(p.read_text() for p in (ROOT/'android/feature/orders/src/main/java/com/maxnetwork/feature/orders/domain').rglob('*.kt'))
data = "\n".join(p.read_text() for p in (ROOT/'android/feature/orders/src/main/java/com/maxnetwork/feature/orders/data').rglob('*.kt'))
api = (ROOT/'contracts/api/openapi.yaml').read_text()
order_schema = api.split('    Order:\n', 1)[1].split('    OrderPage:\n', 1)[0]
network = (ROOT/'android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt').read_text()
checks = [
 ('read-model', 'data class OrderReadModel' in domain),
 ('directions', 'enum class OrderDirection { Incoming, Outgoing }' in domain),
 ('sources', 'enum class OrderSource { App, Verto, MaxTeam }' in domain),
 ('exact-statuses', 'enum class OrderVisualStatus { NeedsReply, Provided, Unavailable }' in domain),
 ('content', 'data class OrderContent' in domain),
 ('invoice-reference', 'InvoiceReference' in domain),
 ('unavailable-no-invoice', 'status != OrderVisualStatus.Unavailable || invoiceReference == null' in domain),
 ('cursor-pagination', all(x in domain for x in ['OrderCursor','OrderQuery','OrderPage','limit in 1..50'])),
 ('newest-first', 'compareByDescending<OrderReadModel> { it.occurredAt }' in domain),
 ('unified-repository', 'interface OrderReadRepository' in domain and 'getOrders(query: OrderQuery)' in domain),
 ('direction-filter', '.filter { it.direction == query.direction }' in domain),
 ('domain-platform-free', not re.search(r'^import (android\.|androidx\.|retrofit2\.|okhttp3\.)', domain, re.M)),
 ('network-adapter', 'class NetworkOrderReadRepository' in data),
 ('gateway-list-implemented', '@GET("v1/orders")' in network),
 ('gateway-detail-implemented', '@GET("v1/orders/{orderId}")' in network),
 ('api-source', 'OrderSource:' in api and 'enum: [APP, VERTO, MAX_TEAM]' in api),
 ('api-no-competitor', 'competitorName' not in api and 'competitorId' not in api),
 ('api-no-inventory', 'inventory' not in order_schema.lower() and 'stock' not in order_schema.lower()),
 ('api-no-money-in-order', not re.search(r'(amount|balanceAfter|movement|minorUnits)', order_schema, re.I)),
 ('no-feature-dependency', 'project(":feature:' not in (ROOT/'android/feature/orders/build.gradle.kts').read_text()),
]
failed=[name for name,ok in checks if not ok]
if failed:
 print('orders read contract checks failed:')
 for name in failed: print('-',name)
 raise SystemExit(1)
print(f'orders read contract checks passed: {len(checks)}/{len(checks)}')
for name,_ in checks: print('-',name)
