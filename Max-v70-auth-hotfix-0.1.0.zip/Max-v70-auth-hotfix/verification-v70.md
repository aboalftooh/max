# Max v70 — Verification Report

Date: 2026-08-29

## Release build

- Command: `./gradlew assembleRelease --offline --build-cache`
- Result: PASS (`BUILD_EXIT=0`)
- Gradle: 8.10.2, already available in the local wrapper cache
- Cache reuse: 208 tasks from cache during the successful build
- Dependency downloads: none
- Android SDK: existing local SDK at `/home/aboalftooh/Android/Sdk`
- Application ID: `com.maxnetwork.android`
- Version: `0.1.0` (versionCode `1`)
- APK: `Max-v70-auth-hotfix-0.1.0.apk`
- APK size: 11,250,641 bytes
- APK SHA-256: `7997dd1980c249a0327567fc947bfa4db6c35c084c51f51dfe069364eeb4803d`
- Signature verification: PASS

The server base URL was supplied from `secret.md` through a temporary Gradle environment property. It was not written to source, Git, or this report. The generated release configuration matched that supplied value.

## Server connectivity

- Production gateway probe: `POST /v1/auth/phone-challenges` with an empty JSON object
- Result: HTTP `400`, with no transport error; this confirms the deployed API route was reached and rejected invalid input as expected.
- `/health/live` returned HTTP `404`; that route is not exposed at the configured gateway path.
- No credentials, request bodies containing secrets, or response bodies were recorded.

## Quality verification

`./scripts/verify.sh` was run with Gradle offline enforcement. Result: FAIL overall (`17` passed, `8` failed, `2` skipped).

Passed security/authentication and architecture checks included Android auth, backend auth, auth UI, protected release paths, HTTP runtime, database boundary checks, and the debug build.

Existing blockers recorded by the script:

- Repository and Python checks: missing `scripts/secret-scan.py`; Python contract check also lacks the installed `jsonschema` module.
- Push delivery check: `publish-schedules-push` failed.
- Formatting: existing KtLint violations.
- Detekt: existing complexity/naming/line-length violations across feature modules.
- Unit tests: existing `BrandIdentityStaticChecksTest` failure.
- Android lint: 96 existing errors; first reported `ApplySharedPref` in `AndroidKeystoreTokenStorage.kt`.
- UI smoke test was skipped because no connected device/emulator was available.

No source or dependency versions were changed for this build. No `clean` operation was run, and existing build/cache directories were retained.
