# Max Backend/BFF

The backend contains the authentication core that implements the existing OpenAPI flow without coupling business logic to an HTTP framework or SMS provider.

## Structure

- `auth/domain`: entities, policy, failures, validation.
- `auth/application`: transactional authentication use cases.
- `auth/ports`: persistence, clock, hashing, token generation, and delivery boundaries.
- `auth/infrastructure`: JVM security and deterministic in-memory persistence.
- `auth/api`: transport-neutral handlers matching the OpenAPI authentication operations.
- `resources/db/migration`: PostgreSQL schema and tenant RLS.

## Verification

```bash
../scripts/compile-backend-auth.sh
```

Production deployment still requires an HTTP adapter, PostgreSQL repository adapter, runtime pepper, and an SMS delivery provider. None of those credentials belong in source control.

## Request acceptance — v21

- `request/domain`: request source, accepted request, upload ownership and failures.
- `request/application`: validates content and completed store-owned attachments.
- `request/api`: app-only `POST /v1/requests`, forcing source `APP`.
- `request/infrastructure`: deterministic concurrent in-memory adapters for direct tests.
- `V002__request_schema.sql`: production PostgreSQL target with tenant RLS, database idempotency, and internal notification outbox.

Run the direct endpoint suite with:

```bash
../scripts/compile-request-backend.sh
```

A production deployment still needs the HTTP framework adapter and PostgreSQL repository implementation.

## Verto invoice ledger — v27

- `integration/verto/invoice`: idempotent sale/purchase projection.
- `balance/domain`: immutable movements and balance snapshots.
- `V004__invoice_financial_ledger.sql`: append-only ledger, per-store sequencing, atomic balance update, v26 backfill, and tenant RLS.

Run the direct projection and ledger suite with:

```bash
../scripts/compile-verto-invoice-projection.sh
```

Payments, receipts, corrections, returns, and financial write endpoints are not implemented in v27.
## Verto payments and receipts — v28

- `integration/verto/settlement`: idempotent payment and receipt projection.
- `integration/verto/application/VertoFinancialSynchronizer`: one dispatcher for invoices, payments, and receipts.
- `V005__verto_payments_receipts_ledger.sql`: shared financial inbox, payment/receipt movements, RLS, row locking, and append-only protection.

Run the v27 regression and v28 settlement suite with:

```bash
../scripts/compile-verto-settlement-projection.sh
```

Payment reduces the balance, receipt increases it, and neither creates an order. Corrections and returns remain outside v28.


## Verto corrections and returns — v29

- `integration/verto/adjustment`: idempotent correction and invoice-return projection.
- `V006__verto_corrections_returns_ledger.sql`: same-store cause FK, signed corrections, capped partial returns, and atomic balance sequencing.
- `VertoFinancialSynchronizer`: one dispatcher for all six supported financial event types.

Run the v27–v29 financial suites with:

```bash
../scripts/compile-verto-adjustment-projection.sh
```

Corrections and returns append new movements and never rewrite orders or old ledger rows. Balance read APIs and Android balance UI remain deferred.


## Balance read API — v30

- `balance/application`: tenant-scoped snapshot and keyset movement queries.
- `balance/api`: authenticated transport-neutral GET handlers.
- `HmacBalanceCursorCodec`: opaque, store-bound pagination cursors.
- `V007__balance_read_api.sql`: security-invoker read functions scoped by `app.store_id`.

Run the direct backend read suite with:

```bash
../scripts/compile-balance-read-api.sh
```

Android Retrofit and the balance domain/data contract are implemented; the Compose screen remains deferred to v31. No financial write endpoint exists.

## Notification inbox — v32

- `notification/domain` owns the six V1 notification types and sanitized read views.
- `notification/application` owns server-authored content, idempotent publish, cursor pages, and mark-read behavior.
- `V008__notification_inbox.sql` provides tenant RLS, per-store sequencing, immutable content, and read-only client access apart from `read_at`.

Run the direct suite with:

```bash
../scripts/compile-notification-api.sh
```

Push delivery and device registration are intentionally deferred.

## Secure Android push delivery — v33

- `notification/application/PushServices.kt` owns authenticated registration, tenant fanout, retries, and invalid-token handling.
- `AesGcmPushTokenProtector` encrypts provider tokens and creates a purpose-separated HMAC digest.
- `FcmHttpV1PushGateway` sends OAuth-authenticated HTTPS data-only messages.
- `V009__push_device_delivery.sql` defines protected devices, immutable delivery outbox rows, tenant RLS, and no-delete guards.

Run the direct suites with:

```bash
../scripts/compile-push-delivery.sh
../scripts/compile-push-api.sh
../scripts/compile-fcm-push.sh
```

Production deployment must inject the token-protection secret, FCM project ID, OAuth access-token provider, HTTP adapter, and PostgreSQL adapters at runtime. No credential belongs in source control.

## Authenticated Android transport — v34

The encrypted Android auth store updates one process-local token bridge. Retrofit attaches the current token only to protected Max API paths. Authentication endpoints remain public and signed media uploads use an isolated client with no Max authorization interceptor.

Run the direct bridge suite with:

```bash
../scripts/compile-authenticated-transport.sh
```

## Profile and account deletion — v35

- `profile/application` derives identity from the authenticated session and returns the fixed V1 privacy/support contract.
- `AuthService.requestAccountDeletion` creates a tracking record, disables the user, and revokes active sessions.
- `V010__profile_account_deletion.sql` provides RLS, one-active-request uniqueness, immutable identity fields, and no-delete protection.
- The Android release gateway implements profile, privacy, support, and deletion endpoints.

Run the direct profile suite with:

```bash
../scripts/compile-profile-api.sh
```

## Order/media API parity — v36

`backend/request/read` and `backend/request/upload` implement the protected OpenAPI operations used by Release Android. Cursors are store/direction-bound and media URLs are short-lived HTTPS links.

Run:

```bash
../scripts/compile-order-read-upload-api.sh
```

## HTTP runtime — v37

`backend/http` provides strict JSON routing for every V1 path plus a bounded JDK HTTP server and fail-closed environment parsing.

Run:

```bash
../scripts/compile-backend-http-runtime.sh
```

Production deployment must still inject durable PostgreSQL/object-storage/SMS/FCM adapters. Development in-memory adapters are not a production persistence strategy.

## Durable authentication persistence — v38

`auth/infrastructure/postgres` now implements the complete `AuthStore` contract for stores, users, registration grants, phone challenges, password resets, sessions, and account deletion requests.

Required runtime variables:

```text
MAX_DB_URL=jdbc:postgresql://db.example/max?sslmode=verify-full
MAX_DB_USER=max_auth_service
MAX_DB_PASSWORD=<runtime-secret>
MAX_DB_DRIVER=org.postgresql.Driver   # optional default
```

The authentication role must own `max_auth` or have `BYPASSRLS`, because pre-login phone/token lookup is intentionally cross-tenant. The adapter executes `row_security = off`; PostgreSQL fails closed if the role cannot bypass policies. Apply `V001` through `V010` before readiness can pass.

Run:

```bash
../scripts/postgres-auth-check.py
../scripts/compile-postgres-auth.sh
```

Request, ledger, notification, push, and media persistence still require their durable production adapters.
