package com.maxnetwork.backend.notification.ports

import com.maxnetwork.backend.notification.domain.ProtectedPushToken
import com.maxnetwork.backend.notification.domain.PushEnvelope
import com.maxnetwork.backend.notification.domain.PushPrincipal
import com.maxnetwork.backend.notification.domain.PushProvider
import com.maxnetwork.backend.notification.domain.PushProviderResult
import com.maxnetwork.backend.notification.domain.StoredNotification
import com.maxnetwork.backend.notification.domain.StoredPushDelivery
import com.maxnetwork.backend.notification.domain.StoredPushDevice
import com.maxnetwork.backend.request.domain.StoreId
import java.time.Instant

fun interface PushDeviceIdGenerator {
    fun nextId(): String
}

fun interface PushDeliveryIdGenerator {
    fun nextId(): String
}

interface PushTokenProtector {
    fun protect(rawToken: String): ProtectedPushToken
    fun reveal(protectedToken: ProtectedPushToken): String
}

data class RegisterPushDeviceRecord(
    val deviceId: String,
    val principal: PushPrincipal,
    val installationId: String,
    val provider: PushProvider,
    val protectedToken: ProtectedPushToken,
    val appVersion: String,
    val now: Instant,
)

sealed interface PushDeviceRegistrationStoreResult {
    data class Applied(val value: StoredPushDevice, val created: Boolean, val rotated: Boolean) :
        PushDeviceRegistrationStoreResult
}

sealed interface PushDeviceUnregisterStoreResult {
    data object Disabled : PushDeviceUnregisterStoreResult
    data object AlreadyDisabled : PushDeviceUnregisterStoreResult
}

interface PushDeviceStore {
    fun register(record: RegisterPushDeviceRecord): PushDeviceRegistrationStoreResult
    fun unregister(principal: PushPrincipal, installationId: String, now: Instant): PushDeviceUnregisterStoreResult
    fun activeForStore(storeId: StoreId): List<StoredPushDevice>
    fun findActive(deviceId: String): StoredPushDevice?
    fun disable(deviceId: String, now: Instant)
}

data class EnqueuePushDeliveryCommand(
    val deliveryId: String,
    val storeId: StoreId,
    val notificationId: String,
    val deviceId: String,
    val envelope: PushEnvelope,
    val availableAt: Instant,
)

sealed interface PushDeliveryEnqueueResult {
    data class Enqueued(val value: StoredPushDelivery) : PushDeliveryEnqueueResult
    data class Replay(val value: StoredPushDelivery) : PushDeliveryEnqueueResult
}

interface PushDeliveryStore {
    fun enqueue(command: EnqueuePushDeliveryCommand): PushDeliveryEnqueueResult
    fun pending(now: Instant, limit: Int): List<StoredPushDelivery>
    fun markDelivered(deliveryId: String, deliveredAt: Instant)
    fun markInvalidToken(deliveryId: String)
    fun reschedule(deliveryId: String, availableAt: Instant)
}

fun interface PushProviderGateway {
    fun send(provider: PushProvider, token: String, envelope: PushEnvelope): PushProviderResult
}

fun interface NotificationPushSink {
    fun schedule(notification: StoredNotification)

    data object None : NotificationPushSink {
        override fun schedule(notification: StoredNotification) = Unit
    }
}
