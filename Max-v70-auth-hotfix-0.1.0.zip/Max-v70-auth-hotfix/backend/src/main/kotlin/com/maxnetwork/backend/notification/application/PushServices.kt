package com.maxnetwork.backend.notification.application

import com.maxnetwork.backend.notification.domain.PushDeliveryRun
import com.maxnetwork.backend.notification.domain.PushEnvelope
import com.maxnetwork.backend.notification.domain.PushPrincipal
import com.maxnetwork.backend.notification.domain.PushProviderResult
import com.maxnetwork.backend.notification.domain.PushRegistrationCommand
import com.maxnetwork.backend.notification.domain.PushRegistrationResult
import com.maxnetwork.backend.notification.domain.PushUnregisterResult
import com.maxnetwork.backend.notification.domain.StoredNotification
import com.maxnetwork.backend.notification.domain.pushTarget
import com.maxnetwork.backend.notification.ports.EnqueuePushDeliveryCommand
import com.maxnetwork.backend.notification.ports.NotificationPushSink
import com.maxnetwork.backend.notification.ports.PushDeliveryIdGenerator
import com.maxnetwork.backend.notification.ports.PushDeliveryStore
import com.maxnetwork.backend.notification.ports.PushDeviceIdGenerator
import com.maxnetwork.backend.notification.ports.PushDeviceRegistrationStoreResult
import com.maxnetwork.backend.notification.ports.PushDeviceStore
import com.maxnetwork.backend.notification.ports.PushDeviceUnregisterStoreResult
import com.maxnetwork.backend.notification.ports.PushProviderGateway
import com.maxnetwork.backend.notification.ports.PushTokenProtector
import com.maxnetwork.backend.notification.ports.RegisterPushDeviceRecord
import java.time.Clock
import java.time.Duration
import java.time.Instant

class PushRegistrationService(
    private val devices: PushDeviceStore,
    private val protector: PushTokenProtector,
    private val ids: PushDeviceIdGenerator,
    private val clock: Clock,
) {
    fun register(principal: PushPrincipal, command: PushRegistrationCommand): PushRegistrationResult {
        val protected = runCatching { protector.protect(command.token) }.getOrElse {
            return PushRegistrationResult.InvalidRequest
        }
        return when (
            val result = devices.register(
                RegisterPushDeviceRecord(
                    deviceId = ids.nextId(),
                    principal = principal,
                    installationId = command.installationId,
                    provider = command.provider,
                    protectedToken = protected,
                    appVersion = command.appVersion.trim(),
                    now = Instant.now(clock),
                ),
            )
        ) {
            is PushDeviceRegistrationStoreResult.Applied -> PushRegistrationResult.Success(
                created = result.created,
                rotated = result.rotated,
            )
        }
    }

    fun unregister(principal: PushPrincipal, installationId: String): PushUnregisterResult {
        if (!installationId.matches(INSTALLATION_ID_PATTERN)) return PushUnregisterResult.AlreadyDisabled
        return when (devices.unregister(principal, installationId, Instant.now(clock))) {
            PushDeviceUnregisterStoreResult.Disabled -> PushUnregisterResult.Disabled
            PushDeviceUnregisterStoreResult.AlreadyDisabled -> PushUnregisterResult.AlreadyDisabled
        }
    }

    private companion object {
        val INSTALLATION_ID_PATTERN = Regex("^[A-Za-z0-9_-]{16,128}$")
    }
}

class PushFanoutService(
    private val devices: PushDeviceStore,
    private val deliveries: PushDeliveryStore,
    private val ids: PushDeliveryIdGenerator,
) : NotificationPushSink {
    override fun schedule(notification: StoredNotification) {
        val envelope = PushEnvelope(
            notificationId = notification.notificationId,
            type = notification.type,
            target = notification.type.pushTarget(),
            title = notification.title,
            body = notification.body,
        )
        devices.activeForStore(notification.storeId).forEach { device ->
            deliveries.enqueue(
                EnqueuePushDeliveryCommand(
                    deliveryId = ids.nextId(),
                    storeId = notification.storeId,
                    notificationId = notification.notificationId,
                    deviceId = device.deviceId,
                    envelope = envelope,
                    availableAt = notification.occurredAt,
                ),
            )
        }
    }
}

class PushDeliveryWorker(
    private val devices: PushDeviceStore,
    private val deliveries: PushDeliveryStore,
    private val protector: PushTokenProtector,
    private val provider: PushProviderGateway,
    private val clock: Clock,
) {
    fun run(limit: Int = 100): PushDeliveryRun {
        require(limit in 1..500)
        val now = Instant.now(clock)
        var delivered = 0
        var invalid = 0
        var deferred = 0
        deliveries.pending(now, limit).forEach { delivery ->
            val device = devices.findActive(delivery.deviceId)
            if (device == null || device.principal.storeId != delivery.storeId) {
                deliveries.markInvalidToken(delivery.deliveryId)
                invalid += 1
                return@forEach
            }
            val token = runCatching { protector.reveal(device.protectedToken) }.getOrNull()
            if (token == null) {
                devices.disable(device.deviceId, now)
                deliveries.markInvalidToken(delivery.deliveryId)
                invalid += 1
                return@forEach
            }
            when (val result = provider.send(device.provider, token, delivery.envelope)) {
                PushProviderResult.Delivered -> {
                    deliveries.markDelivered(delivery.deliveryId, now)
                    delivered += 1
                }
                PushProviderResult.InvalidToken -> {
                    devices.disable(device.deviceId, now)
                    deliveries.markInvalidToken(delivery.deliveryId)
                    invalid += 1
                }
                is PushProviderResult.RetryableFailure -> {
                    val requested = result.retryAfterSeconds?.coerceIn(MIN_RETRY_SECONDS, MAX_RETRY_SECONDS)
                    val delay = requested ?: exponentialBackoff(delivery.attemptCount)
                    deliveries.reschedule(delivery.deliveryId, now.plusSeconds(delay))
                    deferred += 1
                }
            }
        }
        return PushDeliveryRun(delivered, invalid, deferred)
    }

    private fun exponentialBackoff(attemptCount: Int): Long =
        (MIN_RETRY_SECONDS shl attemptCount.coerceIn(0, 6)).coerceAtMost(MAX_RETRY_SECONDS)

    private companion object {
        const val MIN_RETRY_SECONDS = 30L
        val MAX_RETRY_SECONDS = Duration.ofHours(6).seconds
    }
}
