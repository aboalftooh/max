package com.maxnetwork.backend.notification

import com.maxnetwork.backend.auth.application.AuthService
import com.maxnetwork.backend.notification.api.NotificationApi
import com.maxnetwork.backend.notification.application.NotificationService
import com.maxnetwork.backend.notification.infrastructure.HmacNotificationCursorCodec
import com.maxnetwork.backend.notification.ports.NotificationIdGenerator
import com.maxnetwork.backend.notification.ports.NotificationPushSink
import com.maxnetwork.backend.notification.ports.NotificationStore
import java.time.Clock
import java.util.UUID

class NotificationModule private constructor(
    val api: NotificationApi,
    val service: NotificationService,
) {
    companion object {
        fun create(
            auth: AuthService,
            store: NotificationStore,
            cursorSecret: ByteArray,
            clock: Clock = Clock.systemUTC(),
            ids: NotificationIdGenerator = NotificationIdGenerator { UUID.randomUUID().toString() },
            push: NotificationPushSink = NotificationPushSink.None,
        ): NotificationModule {
            val service = NotificationService(
                store = store,
                cursors = HmacNotificationCursorCodec(cursorSecret),
                ids = ids,
                clock = clock,
                push = push,
            )
            return NotificationModule(
                api = NotificationApi(auth, service),
                service = service,
            )
        }
    }
}
