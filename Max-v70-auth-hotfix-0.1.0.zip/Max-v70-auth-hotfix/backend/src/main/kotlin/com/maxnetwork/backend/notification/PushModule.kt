package com.maxnetwork.backend.notification

import com.maxnetwork.backend.auth.application.AuthService
import com.maxnetwork.backend.notification.api.PushApi
import com.maxnetwork.backend.notification.application.PushDeliveryWorker
import com.maxnetwork.backend.notification.application.PushFanoutService
import com.maxnetwork.backend.notification.application.PushRegistrationService
import com.maxnetwork.backend.notification.ports.PushDeliveryIdGenerator
import com.maxnetwork.backend.notification.ports.PushDeliveryStore
import com.maxnetwork.backend.notification.ports.PushDeviceIdGenerator
import com.maxnetwork.backend.notification.ports.PushDeviceStore
import com.maxnetwork.backend.notification.ports.PushProviderGateway
import com.maxnetwork.backend.notification.ports.PushTokenProtector
import java.time.Clock
import java.util.UUID

class PushModule private constructor(
    val api: PushApi,
    val registration: PushRegistrationService,
    val fanout: PushFanoutService,
    val worker: PushDeliveryWorker,
) {
    companion object {
        fun create(
            auth: AuthService,
            devices: PushDeviceStore,
            deliveries: PushDeliveryStore,
            protector: PushTokenProtector,
            provider: PushProviderGateway,
            clock: Clock = Clock.systemUTC(),
            deviceIds: PushDeviceIdGenerator = PushDeviceIdGenerator { UUID.randomUUID().toString() },
            deliveryIds: PushDeliveryIdGenerator = PushDeliveryIdGenerator { UUID.randomUUID().toString() },
        ): PushModule {
            val registration = PushRegistrationService(devices, protector, deviceIds, clock)
            val fanout = PushFanoutService(devices, deliveries, deliveryIds)
            return PushModule(
                api = PushApi(auth, registration),
                registration = registration,
                fanout = fanout,
                worker = PushDeliveryWorker(devices, deliveries, protector, provider, clock),
            )
        }
    }
}
