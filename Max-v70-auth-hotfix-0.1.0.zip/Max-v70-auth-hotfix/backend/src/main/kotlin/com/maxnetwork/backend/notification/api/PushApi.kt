package com.maxnetwork.backend.notification.api

import com.maxnetwork.backend.auth.api.ApiErrorCode
import com.maxnetwork.backend.auth.api.ApiErrorResponse
import com.maxnetwork.backend.auth.api.ApiResponse
import com.maxnetwork.backend.auth.application.AuthService
import com.maxnetwork.backend.auth.domain.AuthResult
import com.maxnetwork.backend.notification.application.PushRegistrationService
import com.maxnetwork.backend.notification.domain.PushPrincipal
import com.maxnetwork.backend.notification.domain.PushProvider
import com.maxnetwork.backend.notification.domain.PushRegistrationCommand
import com.maxnetwork.backend.notification.domain.PushRegistrationResult
import com.maxnetwork.backend.request.domain.StoreId
import java.util.UUID

class PushApi(
    private val auth: AuthService,
    private val registration: PushRegistrationService,
    private val traceId: () -> String = { UUID.randomUUID().toString() },
) {
    fun register(
        accessToken: String,
        installationId: String,
        request: PushRegistrationRequest,
    ): ApiResponse<Unit> {
        val principal = authenticatedPrincipal(accessToken) ?: return unauthorized()
        val command = runCatching {
            PushRegistrationCommand(
                installationId = installationId,
                provider = request.provider.toProvider(),
                token = request.token,
                appVersion = request.appVersion,
            )
        }.getOrElse { return invalidRequest() }
        return when (registration.register(principal, command)) {
            is PushRegistrationResult.Success -> ApiResponse.Success(204, Unit)
            PushRegistrationResult.InvalidRequest -> invalidRequest()
        }
    }

    fun unregister(accessToken: String, installationId: String): ApiResponse<Unit> {
        val principal = authenticatedPrincipal(accessToken) ?: return unauthorized()
        registration.unregister(principal, installationId)
        return ApiResponse.Success(204, Unit)
    }

    private fun authenticatedPrincipal(accessToken: String): PushPrincipal? = when (val result = auth.authenticate(accessToken)) {
        is AuthResult.Failure -> null
        is AuthResult.Success -> runCatching {
            PushPrincipal(StoreId(result.value.storeId), result.value.userId)
        }.getOrNull()
    }

    private fun String.toProvider(): PushProvider = when (this) {
        "FCM" -> PushProvider.Fcm
        else -> error("Unsupported push provider")
    }

    private fun unauthorized() = failure(401, ApiErrorCode.Unauthorized, "الجلسة غير صالحة")
    private fun invalidRequest() = failure(400, ApiErrorCode.InvalidRequest, "بيانات الجهاز غير صالحة")

    private fun failure(status: Int, code: ApiErrorCode, message: String) = ApiResponse.Failure(
        status = status,
        error = ApiErrorResponse(code, message, traceId(), retryable = false),
    )
}

data class PushRegistrationRequest(
    val provider: String,
    val token: String,
    val appVersion: String,
)
