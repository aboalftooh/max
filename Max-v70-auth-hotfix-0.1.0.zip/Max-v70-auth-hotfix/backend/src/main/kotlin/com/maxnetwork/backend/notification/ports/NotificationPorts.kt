package com.maxnetwork.backend.notification.ports

import com.maxnetwork.backend.notification.domain.NotificationType
import com.maxnetwork.backend.notification.domain.StoredNotification
import com.maxnetwork.backend.request.domain.StoreId
import java.time.Instant

fun interface NotificationIdGenerator {
    fun nextId(): String
}

interface NotificationCursorCodec {
    fun encode(storeId: StoreId, beforeSequenceExclusive: Long): String
    fun decode(storeId: StoreId, rawCursor: String): Long?
}

data class NotificationAppendCommand(
    val notificationId: String,
    val storeId: StoreId,
    val type: NotificationType,
    val title: String,
    val body: String,
    val occurredAt: Instant,
    val sourceEventId: String,
)

sealed interface NotificationAppendResult {
    data class Applied(val value: StoredNotification) : NotificationAppendResult
    data class Replay(val value: StoredNotification) : NotificationAppendResult
    data object Conflict : NotificationAppendResult
}

sealed interface NotificationMarkReadResult {
    data class Marked(val value: StoredNotification) : NotificationMarkReadResult
    data class AlreadyRead(val value: StoredNotification) : NotificationMarkReadResult
    data object NotFound : NotificationMarkReadResult
}

interface NotificationStore {
    fun append(command: NotificationAppendCommand): NotificationAppendResult
    fun listBefore(storeId: StoreId, beforeSequenceExclusive: Long?, limit: Int): List<StoredNotification>
    fun markRead(storeId: StoreId, notificationId: String, readAt: Instant): NotificationMarkReadResult
}
