package com.maxnetwork.backend.notification.application

import com.maxnetwork.backend.notification.domain.NotificationEvent
import com.maxnetwork.backend.notification.domain.NotificationPageView
import com.maxnetwork.backend.notification.domain.NotificationPublishFailureKind
import com.maxnetwork.backend.notification.domain.NotificationPublishResult
import com.maxnetwork.backend.notification.domain.NotificationReadFailureKind
import com.maxnetwork.backend.notification.domain.NotificationReadResult
import com.maxnetwork.backend.notification.domain.NotificationType
import com.maxnetwork.backend.notification.domain.NotificationTarget
import com.maxnetwork.backend.notification.domain.NotificationView
import com.maxnetwork.backend.notification.domain.StoredNotification
import com.maxnetwork.backend.notification.ports.NotificationAppendCommand
import com.maxnetwork.backend.notification.ports.NotificationAppendResult
import com.maxnetwork.backend.notification.ports.NotificationCursorCodec
import com.maxnetwork.backend.notification.ports.NotificationIdGenerator
import com.maxnetwork.backend.notification.ports.NotificationMarkReadResult
import com.maxnetwork.backend.notification.ports.NotificationPushSink
import com.maxnetwork.backend.notification.ports.NotificationStore
import com.maxnetwork.backend.request.domain.StoreId
import java.time.Clock
import java.time.Instant

class NotificationService(
    private val store: NotificationStore,
    private val cursors: NotificationCursorCodec,
    private val ids: NotificationIdGenerator,
    private val clock: Clock,
    private val push: NotificationPushSink = NotificationPushSink.None,
) {
    fun publish(event: NotificationEvent): NotificationPublishResult {
        val content = event.type.content()
        return when (
            val result = store.append(
                NotificationAppendCommand(
                    notificationId = ids.nextId(),
                    storeId = event.storeId,
                    type = event.type,
                    title = content.title,
                    body = content.body,
                    occurredAt = event.occurredAt,
                    sourceEventId = event.eventId,
                ),
            )
        ) {
            is NotificationAppendResult.Applied -> {
                push.schedule(result.value.copy(target = event.resolvedTarget()))
                NotificationPublishResult.Success(result.value.notificationId, created = true)
            }
            is NotificationAppendResult.Replay -> {
                push.schedule(result.value.copy(target = event.resolvedTarget()))
                NotificationPublishResult.Success(result.value.notificationId, created = false)
            }
            NotificationAppendResult.Conflict -> NotificationPublishResult.Failure(NotificationPublishFailureKind.Conflict)
        }
    }

    fun list(
        storeId: StoreId,
        rawCursor: String?,
        limit: Int,
    ): NotificationReadResult<NotificationPageView> {
        if (limit !in MIN_LIMIT..MAX_LIMIT) {
            return NotificationReadResult.Failure(NotificationReadFailureKind.InvalidLimit)
        }
        val beforeSequence = when {
            rawCursor == null -> null
            rawCursor.isBlank() -> return NotificationReadResult.Failure(NotificationReadFailureKind.InvalidCursor)
            else -> cursors.decode(storeId, rawCursor)
                ?: return NotificationReadResult.Failure(NotificationReadFailureKind.InvalidCursor)
        }
        val fetched = store.listBefore(storeId, beforeSequence, limit + 1)
        val visible = fetched.take(limit)
        val nextCursor = if (fetched.size > limit) {
            cursors.encode(storeId, visible.last().sequence)
        } else {
            null
        }
        return NotificationReadResult.Success(
            NotificationPageView(
                items = visible.map { it.toView() },
                nextCursor = nextCursor,
            ),
        )
    }

    fun markRead(storeId: StoreId, notificationId: String): NotificationReadResult<Unit> {
        if (notificationId.isBlank()) {
            return NotificationReadResult.Failure(NotificationReadFailureKind.NotFound)
        }
        return when (store.markRead(storeId, notificationId, Instant.now(clock))) {
            is NotificationMarkReadResult.Marked,
            is NotificationMarkReadResult.AlreadyRead,
            -> NotificationReadResult.Success(Unit)
            NotificationMarkReadResult.NotFound -> NotificationReadResult.Failure(NotificationReadFailureKind.NotFound)
        }
    }

    private fun StoredNotification.toView() = NotificationView(
        notificationId = notificationId,
        type = type,
        title = title,
        body = body,
        occurredAt = occurredAt,
        readAt = readAt,
        target = if (target != NotificationTarget.None) target else defaultTarget(type, sourceEventId),
    )

    private fun com.maxnetwork.backend.notification.domain.NotificationEvent.resolvedTarget(): NotificationTarget =
        if (target != NotificationTarget.None) target else defaultTarget(type, eventId)

    private fun defaultTarget(type: NotificationType, sourceId: String): NotificationTarget = when (type) {
        NotificationType.BalanceMovement, NotificationType.BalanceUpdated -> NotificationTarget.Home
        NotificationType.RequestNeedsReply,
        NotificationType.OutgoingRequestUpdated,
        NotificationType.PartAvailable,
        NotificationType.PartUnavailable,
        -> NotificationTarget.conversation("conversation-$sourceId")
    }

    private data class NotificationContent(val title: String, val body: String)

    private fun NotificationType.content(): NotificationContent = when (this) {
        NotificationType.RequestNeedsReply -> NotificationContent(
            title = "طلب يحتاج ردك",
            body = "افتح الطلب الوارد للاطلاع والرد.",
        )
        NotificationType.OutgoingRequestUpdated -> NotificationContent(
            title = "تحديث طلب صادر",
            body = "تغيّرت حالة أحد طلباتك الصادرة.",
        )
        NotificationType.PartAvailable -> NotificationContent(
            title = "تم توفير القطعة",
            body = "تم تحديث طلبك: القطعة متوفرة.",
        )
        NotificationType.PartUnavailable -> NotificationContent(
            title = "القطعة غير متوفرة",
            body = "تم تحديث طلبك: القطعة غير متوفرة.",
        )
        NotificationType.BalanceMovement -> NotificationContent(
            title = "حركة رصيد جديدة",
            body = "أضيفت حركة جديدة إلى سجل رصيدك.",
        )
        NotificationType.BalanceUpdated -> NotificationContent(
            title = "تم تحديث الرصيد",
            body = "افتح شاشة الرصيد للاطلاع على آخر تحديث.",
        )
    }

    private companion object {
        const val MIN_LIMIT = 1
        const val MAX_LIMIT = 50
    }
}
