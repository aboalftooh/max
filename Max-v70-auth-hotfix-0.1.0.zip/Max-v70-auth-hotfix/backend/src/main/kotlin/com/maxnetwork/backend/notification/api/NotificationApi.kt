package com.maxnetwork.backend.notification.api

import com.maxnetwork.backend.auth.api.ApiErrorCode
import com.maxnetwork.backend.auth.api.ApiErrorResponse
import com.maxnetwork.backend.auth.api.ApiResponse
import com.maxnetwork.backend.auth.application.AuthService
import com.maxnetwork.backend.auth.domain.AuthResult
import com.maxnetwork.backend.notification.application.NotificationService
import com.maxnetwork.backend.notification.domain.NotificationPageView
import com.maxnetwork.backend.notification.domain.NotificationReadFailureKind
import com.maxnetwork.backend.notification.domain.NotificationReadResult
import com.maxnetwork.backend.notification.domain.NotificationType
import com.maxnetwork.backend.notification.domain.NotificationTarget
import com.maxnetwork.backend.notification.domain.NotificationTargetType
import com.maxnetwork.backend.notification.domain.NotificationView
import com.maxnetwork.backend.request.domain.StoreId
import java.time.Instant
import java.util.UUID

class NotificationApi(
    private val auth: AuthService,
    private val service: NotificationService,
    private val traceId: () -> String = { UUID.randomUUID().toString() },
) {
    fun listNotifications(
        accessToken: String,
        cursor: String?,
        limit: Int = 20,
    ): ApiResponse<NotificationPageResponse> {
        val storeId = authenticatedStore(accessToken) ?: return unauthorized()
        return when (val result = service.list(storeId, cursor, limit)) {
            is NotificationReadResult.Success -> ApiResponse.Success(200, result.value.toResponse())
            is NotificationReadResult.Failure -> invalidRequest()
        }
    }

    fun markRead(accessToken: String, notificationId: String): ApiResponse<Unit> {
        val storeId = authenticatedStore(accessToken) ?: return unauthorized()
        return when (val result = service.markRead(storeId, notificationId)) {
            is NotificationReadResult.Success -> ApiResponse.Success(204, Unit)
            is NotificationReadResult.Failure -> when (result.kind) {
                NotificationReadFailureKind.NotFound -> notFound()
                NotificationReadFailureKind.InvalidCursor,
                NotificationReadFailureKind.InvalidLimit,
                -> invalidRequest()
            }
        }
    }

    private fun authenticatedStore(accessToken: String): StoreId? = when (val result = auth.authenticate(accessToken)) {
        is AuthResult.Failure -> null
        is AuthResult.Success -> runCatching { StoreId(result.value.storeId) }.getOrNull()
    }

    private fun unauthorized(): ApiResponse.Failure = failure(
        status = 401,
        code = ApiErrorCode.Unauthorized,
        message = "الجلسة غير صالحة",
    )

    private fun invalidRequest(): ApiResponse.Failure = failure(
        status = 400,
        code = ApiErrorCode.InvalidRequest,
        message = "معاملات الصفحة غير صالحة",
    )

    private fun notFound(): ApiResponse.Failure = failure(
        status = 404,
        code = ApiErrorCode.NotFound,
        message = "الإشعار غير موجود",
    )

    private fun failure(status: Int, code: ApiErrorCode, message: String) = ApiResponse.Failure(
        status = status,
        error = ApiErrorResponse(
            code = code,
            message = message,
            traceId = traceId(),
            retryable = false,
        ),
    )
}

data class NotificationResponse(
    val id: String,
    val type: String,
    val title: String,
    val body: String,
    val occurredAt: Instant,
    val readAt: Instant?,
    val target: NotificationTargetResponse,
)

data class NotificationTargetResponse(val type: String, val id: String?)

data class NotificationPageResponse(
    val items: List<NotificationResponse>,
    val nextCursor: String?,
)

private fun NotificationPageView.toResponse() = NotificationPageResponse(
    items = items.map(NotificationView::toResponse),
    nextCursor = nextCursor,
)

private fun NotificationView.toResponse() = NotificationResponse(
    id = notificationId,
    type = type.toApiName(),
    title = title,
    body = body,
    occurredAt = occurredAt,
    readAt = readAt,
    target = target.toResponse(),
)

private fun NotificationTarget.toResponse() = NotificationTargetResponse(
    type = when (type) {
        NotificationTargetType.Conversation -> "CONVERSATION"
        NotificationTargetType.Home -> "HOME"
        NotificationTargetType.Invoice -> "INVOICE"
        NotificationTargetType.None -> "NONE"
    },
    id = id,
)

private fun NotificationType.toApiName(): String = when (this) {
    NotificationType.RequestNeedsReply -> "REQUEST_NEEDS_REPLY"
    NotificationType.OutgoingRequestUpdated -> "OUTGOING_REQUEST_UPDATED"
    NotificationType.PartAvailable -> "PART_AVAILABLE"
    NotificationType.PartUnavailable -> "PART_UNAVAILABLE"
    NotificationType.BalanceMovement -> "BALANCE_MOVEMENT"
    NotificationType.BalanceUpdated -> "BALANCE_UPDATED"
}
