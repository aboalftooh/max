# ADR-0017 — Typed central navigation owned by app

- **Status:** Accepted
- **Date:** 2026-07-28

## Decision

- `:app` يملك `MaxDestination` و`MaxBackStack` ويمثلان Graph مركزيًا typed دون تمرير بيانات حساسة في Routes.
- الميزات تعرض Screens وActions فقط ولا تعتمد على ميزات أخرى أو تملك الانتقال بينها.
- الدخول الناجح يستبدل الجذر بالرئيسية، والعودة من وجهات الرئيسية تعود إلى نسخة واحدة من الرئيسية.
- لا Bottom Bar في V1، والهيدر الكامل مملوك لشاشة الرئيسية فقط.

## Consequences

التنقل قابل للاختبار كمنطق Kotlin خالص، وتبقى حدود الميزات واضحة. إضافة وجهة جديدة تتطلب تسجيلها صراحة في `MaxNavigationGraph` واختبارها.
