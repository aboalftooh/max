# ADR-0028 — Short-lived private order media

- **Status:** Accepted
- **Session:** v25

## Decision

- Order text is rendered directly, while image and audio media are accessed only through authorization-scoped HTTPS links.
- The backend signs media links for five minutes and rejects configurations longer than ten minutes.
- The Android client treats links within 15 seconds of expiry as expired and refreshes the order through `getOrder` before access.
- Images are decoded into memory with caching disabled; they are not copied to public storage. Audio streams through `MediaPlayer` and is released when the panel leaves composition.
- No download, share, invoice-detail, source-identity, competitor-name, or inventory action is exposed.
- Loading, expiry, unsupported type, network interruption, and retry are explicit UI states.

## Consequences

Private media remains temporary and revocable. Expired links require network access to refresh, so offline users keep the order text and receive a clear retry state rather than a broken or permanently shared URL.
