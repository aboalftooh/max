# ADR-0001: Bootstrap Platform and Product Identity

- الحالة: Accepted
- التاريخ: 2026-07-28

## القرار

- تطبيق Android أصلي بـ Kotlin وJetpack Compose.
- Gradle Kotlin DSL وVersion Catalog.
- اسم التطبيق: ماكس.
- `applicationId`: `com.maxnetwork.android`.
- `minSdk 26`, `targetSdk 35`, `compileSdk 35`.
- JDK 17.
- واجهة عربية RTL وهوية أساسية بنفسجية.
- v01 يبدأ بوحدة `:app` فقط؛ التقسيم المعياري في v03.

## السبب

يوفر خطًا أساسًا صغيرًا قابلًا للتحقق، ويمنع إنشاء وحدات فارغة قبل وجود حدود فعلية.

## العواقب

أي تغيير في الهوية أو الحزمة أو المنصة أو القيم المثبتة يحتاج ADR جديدًا وطلبًا صريحًا.
