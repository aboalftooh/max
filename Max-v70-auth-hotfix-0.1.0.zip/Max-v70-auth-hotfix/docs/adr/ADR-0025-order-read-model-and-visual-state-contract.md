# ADR-0025 — Order read model and visual state contract

- **Status:** Accepted
- **Session:** v22

## Decision

- `:feature:orders` owns a platform-free `OrderReadModel`, one repository for both directions, cursor pagination, and deterministic newest-first normalization.
- The only business statuses in V1 are `NeedsReply`, `Provided`, and `Unavailable`.
- The source is explicit: `App`, `Verto`, or `MaxTeam`.
- The model contains request content and an optional internal invoice reference, but never competitor identity, inventory, money, balance, or a financial movement.
- An unavailable order cannot carry an invoice reference.
- Android reads through `MaxGateway`; the OpenAPI order schema is the contract boundary.

## Consequences

Incoming and outgoing screens share one domain contract and differ only by direction. Financial state remains exclusively in the balance feature and Verto-derived endpoints.
