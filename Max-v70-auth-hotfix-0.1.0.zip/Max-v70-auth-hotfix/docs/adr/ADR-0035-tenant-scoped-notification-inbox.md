# ADR-0035 — Tenant-scoped notification inbox and read state

- **Status:** Accepted
- **Date:** 2026-07-29

## Context

V1 requires immediate notifications for order and balance changes, but notifications are not a source of truth. The application must never select another store, expose Verto references, or create complex notification settings.

## Decision

- The backend owns notification content and stores one notification per unique source event within a store.
- Notifications receive a monotonic per-store sequence and are listed newest first with an opaque HMAC cursor bound to the authenticated store.
- The client can only list notifications and mark one as read. Marking read is idempotent and cannot rewrite the original content or timestamp.
- The response omits `storeId`, sequence numbers, source event IDs, invoice references, competitor names, and inventory details.
- PostgreSQL enforces tenant RLS, source-event uniqueness, immutable content, and no deletion.
- v32 creates the durable inbox and Android read contract only. OS push delivery, device-token registration, and deep-link handling are deferred to a later session.
- No notification settings screen is added in V1.

## Consequences

- Replays and concurrent delivery attempts cannot duplicate a notification.
- A notification may be delayed without corrupting order or balance truth; opening the destination reloads current data.
- Push providers remain replaceable because the domain does not depend on Firebase or Android APIs.
