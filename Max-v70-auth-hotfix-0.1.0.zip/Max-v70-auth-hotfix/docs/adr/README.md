# Architecture Decision Records

- ADR-0001: Bootstrap platform and identity.
- ADR-0002: Store users and roles.
- ADR-0003: Registration, OTP and reset-code lifetimes.
- ADR-0004: Account deletion and financial-history retention.
- ADR-0005: Private media storage and attachment limits.
- ADR-0006: Offline read, draft and request outbox.
- ADR-0007: Invoice details excluded from V1 UI.
- ADR-0008: Append-only corrections and returns.
- ADR-0009: Notification frequency and quiet hours.
- ADR-0010: Deferred commercial and operational automation decisions.

- ADR-0028: Short-lived private order media.
- ADR-0029: Verto invoice-to-order projection.
- ADR-0030: Invoice financial ledger.

- ADR-0031: Verto payments and receipts ledger.
- ADR-0032: Verto corrections and returns ledger.

- ADR-0033: Tenant-scoped balance read API.

- ADR-0034: Android balance read UI.

- ADR-0035: Tenant-scoped notification inbox and read state.

- ADR-0037: Authenticated protected Android transport.
- ADR-0038: Server-owned profile and account deletion.

- ADR-0041: Durable PostgreSQL request and media boundary.

- ADR-0045: Visible identity foundation — `max`, supplied launcher artwork, and Tajawal.
