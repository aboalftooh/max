# ADR-0024 — Server request acceptance before success UI

- **Status:** Accepted
- **Session:** v21

## Context

The local outbox from v20 can persist and retry a request, but local persistence is not proof that Max Server accepted it. Attachments are private and store-scoped, duplicate submissions must not create duplicate requests, and sending a request must not create any financial movement.

## Decision

1. `POST /v1/requests` is the only app endpoint that accepts a new part request.
2. The authenticated server principal supplies the store. The client cannot select another store.
3. The endpoint stores source `APP`. Trusted Verto/team adapters use separate ingestion boundaries.
4. Every referenced image/audio upload must belong to the authenticated store, match its declared kind, and be completed.
5. `Idempotency-Key` is the canonical client request identifier. A duplicate returns the original receipt without another notification.
6. A new accepted request emits one internal `RequestAcceptedNotification`.
7. Request acceptance never creates a financial movement.
8. Android shows the success screen only after the outbox receives a server receipt and transitions to `Accepted`.
9. Leaving the success screen acknowledges the accepted outbox record, clears the submitted draft, and rotates the next draft identifier.

## Consequences

- Offline or retrying submissions remain visible as pending and cannot display false success.
- Foreign, wrong-kind, and incomplete uploads are rejected.
- Concurrent duplicate requests converge to one server request and one internal notification.
- The success screen has no full header and routes only to outgoing requests or Home.
