# ADR-0011 — Android modular monolith and dependency boundaries

- **Status:** Accepted
- **Date:** 2026-07-28

## Decision
Android يستخدم Modular Monolith. `:app` هو Composition Root الوحيد. كل ميزة مستقلة ولا تعتمد على ميزة أخرى. `domain` بلا Android/Room/network، و`presentation` بلا DAO أو عميل شبكة. التكامل المشترك يمر عبر core محدود أو عقود تملكها الميزة.

## Consequences
يزداد عدد وحدات Gradle، لكن تصبح الحدود قابلة للاختبار ويقل خطر تحول `app` إلى مستودع لكل الكود. لا Microservices ولا API modules منفصلة دون مستهلك فعلي.
