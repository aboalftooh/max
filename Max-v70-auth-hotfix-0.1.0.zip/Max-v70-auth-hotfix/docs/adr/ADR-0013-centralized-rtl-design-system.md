# ADR-0013 — Centralized RTL design system and reduced motion

- **Status:** Accepted
- **Date:** 2026-07-28

## Decision
كل ألوان ومسافات وأحجام وحواف وطباعة ومكونات الواجهة تأتي من `:core:designsystem`. RTL مفروض من `MaxTheme`. الحد الأدنى للمس 48dp، والحالات لا تعتمد على اللون وحده. نبض المنتظر هادئ ويتوقف عندما يعطل النظام الحركة.

## Consequences
يحظر تكرار قيم التصميم داخل الميزات. تغيير الهوية يتم مركزيًا ويحتاج مراجعة contrast ولقطات المكونات.
