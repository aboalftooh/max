# ADR-0027 — Outgoing orders and separate synchronization state

- **Status:** Accepted
- **Session:** v24

## Decision

- Outgoing orders use the same business read model and visual statuses as incoming orders.
- A locally submitted request is represented by a separate `PendingOutgoingOrder` synchronization model owned by `:feature:orders`.
- `:app` maps the request feature's outbox state into that neutral synchronization model; neither feature depends on the other.
- A pending card never receives a business status. Once the server read model contains the accepted request ID, it replaces the pending card.
- Request success stores the accepted request ID and focuses that order when opening the outgoing screen.
- Submission and synchronization never create or display a balance movement.

## Consequences

Users can distinguish transport progress from operational status. Offline submissions remain visible without claiming that Max or Verto completed a business transaction.
