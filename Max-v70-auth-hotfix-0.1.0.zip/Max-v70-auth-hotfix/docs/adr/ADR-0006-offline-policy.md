# ADR-0006 — Offline read, draft and request outbox

- **Status:** Accepted
- **Date:** 2026-07-28

## Decision
- يعمل ماكس Offline في قراءة آخر بيانات متزامنة وحفظ مسودة طلب.
- الإرسال يستخدم Outbox محليًا مع `clientRequestId` ثابت وidempotency في الخادم.
- لا يوجد تعديل مالي Offline أو Online من ماكس.
- ترتيب العرض يعتمد توقيت الخادم بعد المزامنة، لا ساعة الجهاز.

## Consequences
Room مخزن قراءة ومسودات وطابور إرسال، وليس مصدر الحقيقة المالي. فشل الإرسال لا ينشئ حركة أو حالة نجاح وهمية.
