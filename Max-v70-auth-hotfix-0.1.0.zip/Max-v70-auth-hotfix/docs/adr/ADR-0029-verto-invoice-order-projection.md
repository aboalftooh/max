# ADR-0029 — Verto invoice-to-order projection

- **Status:** Accepted
- **Session:** v26

## Decision

- Max Backend consumes trusted Verto events; Android never reads Verto tables or accepts client-supplied financial state.
- `SALE_RECORDED` projects a provided outgoing order. `PURCHASE_RECORDED` projects a provided incoming order.
- When `requestId` is present, the invoice may link only to a request owned by the same store. The original request content, source, and request time are preserved.
- When no request is linked, the backend creates a Verto-sourced order with sanitized generic content and no competitor identity or inventory data.
- `eventId`, `idempotencyKey`, and the store-scoped invoice reference prevent duplicate projections. Reusing any identifier with changed payload is a conflict.
- Only successfully applied or safe duplicate invoice events are acknowledged to Verto. Payment, receipt, correction, and return events remain unacknowledged for v27.
- v26 creates no balance movement and performs no financial mutation. Invoice amounts remain only in the immutable integration inbox for later ledger work.

## Consequences

Sales and purchases become visible in the correct order list without duplication or cross-store linking. The integration remains resumable and safe under retries, while payment and ledger responsibilities stay outside this session.

- A rejected event blocks cursor advancement so later sessions or operators cannot lose it.
- Composite store-scoped foreign keys enforce request, media, and source-event ownership in PostgreSQL.
