# ADR-0044 — Dashboard, Conversations, Invoices, and Settings as the Target MAX Information Architecture

**Status:** Accepted for target v52  
**Date:** 2026-08-15  
**Decision owner:** MAX v44–v52 execution contract

## Context

The active v43 product navigation is centered on Home actions and older Incoming Orders, Outgoing Orders, Balance, and Profile flows. The v44–v52 product direction changes the information architecture while preserving MAX's core role: a small documentation-first companion around work that largely happens outside the app.

The target user needs the current financial position, recent movements, documentation conversations, and invoice lookup quickly. MAX must not become a general ERP, inventory system, payment product, or unrestricted chat application.

The execution contract requires product and architecture decisions to be frozen before production-code changes. Session 44 therefore records the target state without claiming it is already implemented.

## Decision

For target v52, MAX will use exactly four authenticated Bottom Navigation roots, in this order:

1. Home / **الرئيسية**
2. Conversations / **المحادثات**
3. Invoices / **الفواتير**
4. Settings / **الإعدادات**

Profile is nested inside Settings.

### Home

Home becomes a financial-first dashboard containing a compact header, notification icon/unread badge, semantic balance card, movement history, and New Request FAB. Charts, analytics, old order action cards, and a profile shortcut are excluded.

### Requests and conversations

A successfully accepted request creates/resolves exactly one documentation conversation and Android opens that conversation directly. The old Request Success interstitial is retired from the active flow.

Conversations are durable, sequenced, tenant-scoped documentation threads with unread cursors. They render request and MAX/system follow-up content but do not gain a general-purpose user chat composer or public generic send-message endpoint in this wave.

Offline outbox requests do not fabricate server conversation IDs before acceptance.

### Invoices

MAX backend owns a read-only invoice snapshot projected from Verto events. Android accesses invoices only through `MaxGateway`/MAX APIs. The invoice list supports tenant-scoped search by invoice number, item name, and part number. Invoice details open as a full in-app screen. PDF is not required.

No invoice action can mutate financial state, and existing ledger arithmetic remains unchanged.

### Notifications

Notifications use typed destinations (`CONVERSATION`, `HOME`, `INVOICE`, `NONE`). Arbitrary raw route strings from push payloads are rejected as a navigation contract.

### Settings and security

Settings contains only Profile, App Lock, Privacy, Support, About, and Logout. Language, theme/dark mode, and delete-account UI are excluded.

Password policy is 6–128 characters with no composition requirements. App lock uses Android system authentication (`BIOMETRIC_STRONG | DEVICE_CREDENTIAL`) and no custom MAX PIN.

## Architectural constraints

- `:app` remains the composition root and navigation owner.
- Feature modules do not depend on other feature modules.
- Android network access goes through `MaxGateway`; Android never reads Verto tables directly.
- MAX adds no financial write path.
- Tenant identity remains server-derived from authenticated session.
- Tokens/secrets do not enter UI/domain/logging.
- Existing HTTPS, tenant scoping, idempotency, RLS, append-only ledger, and session-security rules are preserved.
- No extra libraries are introduced except AndroidX Biometric in the session that explicitly permits it.

## Consequences

### Positive

- The primary information architecture matches the user's highest-frequency needs.
- Financial position and movements are visible immediately.
- Requests transition into durable documentation instead of an isolated success state.
- Invoice discovery supports the identifiers spare-parts users actually remember.
- Navigation targets are typed and safer than arbitrary push route strings.
- Product scope stays intentionally smaller than an ERP or chat app.

### Trade-offs

- Existing order-centric navigation remains in code temporarily but becomes inactive by v52.
- Conversations are intentionally read/documentation oriented; interactive chat is deferred.
- PDF generation is deferred until a stable invoice snapshot exists and is proven.
- v44 records only the target architecture; production behavior changes occur incrementally in sessions v45–v52.

## Superseded product decisions

For the v44–v52 target, this ADR and Product Source of Truth v2 supersede conflicting v1 decisions that stated:

- no Bottom Navigation;
- Home is the sole center for all feature entry;
- Incoming/Outgoing Orders and standalone Balance are primary navigation;
- Profile is a primary/root destination;
- Request Success is the accepted-request destination;
- conversations and invoice detail behavior follow the older v1 flow.

`max_product_source_of_truth_v1.md` remains preserved as historical documentation.

## Not decided here

This ADR does not authorize production implementation beyond each session's explicit allow-list. It does not add analytics, reports, payments, inventory, account deletion UI, dark mode, language switching, general-purpose chat, or invoice PDF.
