# ADR-0015 — Backend authentication security and tenant boundary

- **Status:** Accepted
- **Date:** 2026-07-28

## Context

V1 requires registration by a store-bound single-use code, phone verification, password reset, multiple users per store in the schema, and strict isolation between stores. Raw credentials or verification secrets must never become persistent data or log content.

## Decision

- The backend authentication core is a framework-independent Kotlin module behind the OpenAPI contract.
- PostgreSQL is the persistence target; `V001__auth_schema.sql` is the canonical initial schema.
- Passwords use PBKDF2-HMAC-SHA256 with a random salt and 210,000 iterations in the JVM adapter. The interface permits a future Argon2id adapter without changing application logic.
- Registration codes, OTP values, reset codes, access tokens, refresh tokens, and temporary grants are persisted only as purpose-separated HMAC-SHA256 digests.
- The HMAC pepper is injected from runtime secrets and is never committed.
- Registration validation grants last 15 minutes; phone-verification grants last 10 minutes.
- New OTP or reset challenges invalidate older active challenges for the same phone.
- Registration-code consumption, grant consumption, user creation, and session creation are one transaction.
- Sessions are opaque and resolve server-side to `userId`, `storeId`, and role. Clients cannot choose tenant claims.
- Tenant reads require `storeId` and are additionally protected by PostgreSQL RLS using `app.store_id`.
- Authentication errors are stable and generic; submitted codes, passwords, phones, digests, and internal identifiers are never returned.

## Consequences

- The in-memory adapter is for deterministic verification only; production deployment requires the PostgreSQL adapter and HTTP transport.
- SMS delivery is a port; no provider credential or OTP appears in the repository.
- Concurrent account creation with one registration code yields exactly one success.
