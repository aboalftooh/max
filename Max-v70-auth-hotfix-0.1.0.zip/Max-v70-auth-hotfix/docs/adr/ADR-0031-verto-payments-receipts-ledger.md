# ADR-0031 — Verto payments and receipts ledger

- **Status:** Accepted
- **Session:** v28

## Decision

- `PAYMENT_RECORDED` يضيف حركة `PAYMENT` سالبة.
- `RECEIPT_RECORDED` يضيف حركة `RECEIPT` موجبة.
- الدفع والاستلام يشتركان مع الفواتير في نفس دفتر المحل وتسلسله ورصيده.
- لا ينشئ الحدثان طلبًا ولا يرتبطان بـ`requestId`.
- صندوق أحداث مالي موحد يفرض تفرد `eventId` و`idempotencyKey` بين الفواتير والتسويات.
- الحدث والحركة وتحديث الرصيد تحفظ ذريًا وتبقى append-only.
- التصحيحات والمرتجعات تبقى مؤجلة ولا تُقر من مزامن v28.

## Consequences

يمكن إعادة تشغيل المزامنة بأمان، ولا تتضاعف الحركة أو يتغير ترتيب الدفتر. تطبيق Android يقرأ الرصيد فقط عبر Max API ولا يكتب ماليًا.
