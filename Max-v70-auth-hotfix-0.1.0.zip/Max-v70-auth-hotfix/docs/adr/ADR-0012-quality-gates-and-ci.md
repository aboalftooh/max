# ADR-0012 — Mandatory quality gates and reproducible CI

- **Status:** Accepted
- **Date:** 2026-07-28

## Decision
البناء والاختبارات وktlint وDetekt وAndroid Lint وفحص الأسرار والحدود بوابات مانعة. CI يستدعي نفس سكربت التحقق المحلي، ويصدر تقارير machine-readable. لا تُخزن الأسرار أو SDK أو Gradle cache داخل المشروع.

## Consequences
لا يمكن اعتبار مراجعة الكود بديلًا عن التنفيذ. غياب البيئة يُسجل فشلًا بيئيًا، بينما CI المجهز هو المرجع النهائي للبوابات Android.
