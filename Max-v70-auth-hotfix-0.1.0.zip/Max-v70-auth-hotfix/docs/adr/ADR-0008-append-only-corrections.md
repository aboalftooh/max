# ADR-0008 — Append-only corrections and returns

- **Status:** Accepted
- **Date:** 2026-07-28

## Decision
التعديل أو الإلغاء أو المرتجع في فيرتو يصل إلى ماكس كحدث تصحيح مستقل يحمل `eventId` و`idempotencyKey` ومرجع الحدث الأصلي. لا تُحذف الحركة السابقة ولا يعاد كتابتها.

## Consequences
يمكن إعادة بناء الرصيد والتحقق منه. Read Models تعرض النتيجة الحالية، بينما دفتر الأحداث يحتفظ بالتاريخ الكامل.
