# ADR-0041 — Durable PostgreSQL request and media boundary

- **Status:** Accepted
- **Session:** v39

## Decision

- App requests, upload ownership, request-acceptance outbox rows, and the order read model use PostgreSQL adapters in the production composition.
- `part_request` and `internal_notification_outbox` are inserted in one transaction. The application-level notification callback is disabled in this composition to avoid a non-atomic duplicate path.
- Every mutable user or upload dependency is revalidated under `FOR UPDATE` immediately before request insertion.
- All user-facing reads include an explicit store predicate. A separate trusted integration lookup returns only the owning store ID so Verto can distinguish missing requests from cross-store links without exposing request content.
- Upload object keys are store-namespaced. Upload identity and metadata are immutable; only `PENDING -> COMPLETED` or `PENDING -> REJECTED` is allowed.
- Accepted requests are immutable. Outbox content is immutable after insertion; only the first publication timestamp may be set.
- Composite foreign keys enforce request, creator, upload, and outbox ownership at the database layer.
- The durable runtime has no in-memory fallback and exposes a fail-closed schema readiness probe.

## Consequences

Request submission and read continuity survive process restarts and concurrent retries. Object bytes, upload-completion callbacks, durable financial projection, notifications, and Push remain separate deployment/session boundaries.
