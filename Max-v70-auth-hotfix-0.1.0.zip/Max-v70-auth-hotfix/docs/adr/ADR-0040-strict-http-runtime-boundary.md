# ADR-0040 — Strict HTTP runtime boundary

- **Status:** Accepted
- **Session:** v37

## Decision

- A framework-light JDK HTTP adapter exposes every OpenAPI V1 application route through the transport-neutral APIs.
- JSON parsing is strict: duplicate keys, unknown fields, non-integer numbers, malformed UTF-8 structures, oversized bodies, duplicate query parameters, and wrong content types are rejected.
- Bearer authentication is extracted once at the boundary; tenant identity never comes from path, query, or body fields.
- Responses use `no-store`, `nosniff`, frame denial, stable JSON errors, explicit 404/405 behavior, and no request-body logging.
- `/health/live` and `/health/ready` are operational routes; readiness fails closed.
- Runtime configuration requires purpose-separated base64 secrets. Production requires an HTTPS public base URL and fails fast on missing or weak values.
- The server uses a bounded worker pool and graceful shutdown. TLS may terminate at a trusted reverse proxy; the public production URL remains HTTPS.

## Consequences

The backend has an executable HTTP boundary without coupling domain/application code to a web framework. Production still must inject durable PostgreSQL/object-storage/SMS/FCM adapters and secrets at deployment time.
