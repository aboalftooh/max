# ADR-0037 — Authenticated protected Android transport

- **Status:** Accepted
- **Date:** 2026-07-29

## Context

The release Retrofit path implemented protected reads but did not attach the current access token. Debug worked through `FakeMaxGateway`, masking the production failure. Signed media uploads also must never inherit the Max bearer token.

## Decision

- A process-local, thread-safe bearer-token bridge is shared by the encrypted authentication store and the Retrofit API client.
- Restore, login, registration, refresh, password-reset completion, and logout update or clear the bridge through the auth-session boundary.
- Only allowlisted `/v1` protected paths receive `Authorization: Bearer ...`; authentication endpoints never inherit it.
- Pre-signed media uploads use a separate OkHttp client with no Max authorization interceptor.
- Tokens remain owned by authentication and are never logged or persisted by the network layer.

## Consequences

Protected release calls use the current rotated token without feature-to-feature dependencies. Logout clears the in-process token, and external upload hosts cannot receive it.
