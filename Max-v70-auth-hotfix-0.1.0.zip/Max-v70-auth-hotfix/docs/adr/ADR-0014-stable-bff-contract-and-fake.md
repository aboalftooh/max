# ADR-0014 — Stable Max BFF contract and replaceable Fake gateway

- **Status:** Accepted
- **Date:** 2026-07-28

## Decision
Android يتعامل فقط مع `MaxGateway` الموافق لعقد OpenAPI V1. نسخة Debug تُحقن بـ`FakeMaxGateway` وبيانات ثابتة، بينما Release غير مهيأ حتى إضافة عميل الشبكة الحقيقي. `VertoGateway` حد Backend-only، ولا يظهر في Android.

العقد يستخدم cursor pagination وRFC 3339 و`SDG` بوحدات صحيحة، وأخطاء موحدة وidempotency. لا توجد كتابة مالية، ولا أسماء منافسين أو مخزون في استجابات الطلبات.

## Consequences
يمكن تطوير الميزات واختبارها قبل Backend. استبدال Fake لا يغير domain أو presentation. تشغيل Release قبل إضافة المحول الحقيقي يفشل بوضوح بدل استخدام بيانات تجريبية.
