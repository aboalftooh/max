# ADR-0038 — Server-owned profile and trackable account deletion

- **Status:** Accepted
- **Date:** 2026-07-29

## Context

The Android profile UI existed, but release networking returned `Unavailable` and no backend profile/deletion module implemented the OpenAPI contract.

## Decision

- Profile identity is derived from the authenticated session; Android cannot submit `userId` or `storeId`.
- Support contact is deployment-owned and validated against approved WhatsApp HTTPS domains and E.164-like phone syntax.
- V1 privacy content is fixed by product policy and returned as a versioned server document.
- A confirmed deletion request creates an immutable, tenant-scoped tracking row, disables the user, revokes every active session, and returns server timestamps.
- The deletion schedule comes from backend policy. Financial history is neither changed nor deleted.
- PostgreSQL RLS, one-active-request uniqueness, no-delete, and immutable identity fields protect the audit row.

## Consequences

The release profile path no longer depends on fake data. Account deletion is explicit and trackable, while financial history remains append-only and inaccessible to the disabled identity.
