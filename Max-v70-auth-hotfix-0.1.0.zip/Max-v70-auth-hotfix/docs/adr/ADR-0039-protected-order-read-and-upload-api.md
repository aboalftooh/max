# ADR-0039 — Protected order read and media-upload API parity

- **Status:** Accepted
- **Session:** v36

## Decision

- The backend owns authenticated `POST /v1/media/upload-intents`, `GET /v1/orders`, and `GET /v1/orders/{orderId}` implementations matching the existing Android/OpenAPI contract.
- Store and user identity are derived from the opaque server session. No endpoint accepts a tenant selector.
- App requests are exposed as outgoing `NEEDS_REPLY`; Verto invoice projections are exposed through an adapter as incoming/outgoing `PROVIDED` orders.
- Lists are newest-first and use an HMAC cursor bound to both store and direction.
- Private image/audio links are reissued through the existing short-lived media authorization service. Missing or unauthorized media is never replaced by a public link.
- Upload intents validate the fixed V1 MIME/size policy and create pending, store-owned upload records with five-minute HTTPS slots.

## Consequences

Release Android no longer targets order/media operations that exist only in OpenAPI or fake data. Object-storage completion and PostgreSQL persistence remain infrastructure adapters, not Android responsibilities.
