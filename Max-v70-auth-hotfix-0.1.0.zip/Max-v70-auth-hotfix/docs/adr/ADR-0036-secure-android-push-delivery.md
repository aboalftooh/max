# ADR-0036 — Secure Android push registration and delivery

- **Status:** Accepted
- **Date:** 2026-07-29

## Context

v32 created a durable tenant-scoped notification inbox, but Android still needed device registration, provider delivery, runtime permission handling, and safe navigation. Provider tokens are credentials and must not become tenant selectors or durable plaintext.

## Decision

- The backend authenticates every register/unregister request and derives store/user identity from the opaque session.
- Installation IDs are random app-private identifiers. Provider tokens are encrypted with AES-GCM; a purpose-separated HMAC digest supports uniqueness without plaintext storage.
- One immutable outbox row exists per notification/device. Replays enqueue safely, retries are bounded, and terminal invalid tokens disable the device.
- FCM HTTP v1 uses OAuth over HTTPS and sends data-only payloads containing only schema, notification ID, approved type/target, title, and body.
- Android accepts only schema v1 and the six approved type-to-target mappings. It never accepts a URL or arbitrary route from Push.
- The OS notification opens an explicit immutable `PendingIntent` to one of Incoming Orders, Outgoing Orders, or Balance. The notification is marked read after authenticated consumption.
- `POST_NOTIFICATIONS` is requested once, only after authentication, on Android 13+.
- Firebase configuration comes from build properties. No provider secret or `google-services.json` is committed.
- Device unregistration runs before logout on a best-effort basis; local logout remains guaranteed.
- No notification settings screen is added in V1.

## Consequences

- A stolen database does not directly expose usable provider tokens without the runtime encryption secret.
- Tenant identity and navigation are not client-selectable through Push payloads.
- Provider delivery remains at-least-once; stable notification IDs collapse duplicate displays on Android.
- Production still requires the deployment HTTP/PostgreSQL adapters and a runtime OAuth access-token provider.
