# ADR-0026 — Incoming orders stateful list

- **Status:** Accepted
- **Session:** v23

## Decision

The incoming screen uses one immutable state with explicit loading, empty, error, offline, and pagination states. Cards use the shared semantic status component; attention animation respects the system motion setting. Pressing a card expands its request content inline. V1 does not open invoice dialogs or show competitor identity.

## Consequences

Long lists remain lazy and paginated. Business status changes are rendered from refreshed read models without adding financial or invoice-detail UI.
