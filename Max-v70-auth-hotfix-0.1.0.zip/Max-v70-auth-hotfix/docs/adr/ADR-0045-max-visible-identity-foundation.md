# ADR-0045: MAX Visible Identity Foundation

- الحالة: Accepted
- التاريخ: 2026-08-15

## السياق

ADR-0001 ثبّت هوية الإطلاق الأولى باسم مرئي «ماكس» وهوية بنفسجية. طلب المستخدم صراحةً اعتماد هوية جديدة قبل بناء Design System.

## القرار

- اسم التطبيق المرئي الرسمي يصبح `max` بحروف لاتينية صغيرة.
- يبقى `applicationId` والحزمة التقنية `com.maxnetwork.android` دون تغيير.
- Launcher icon يعتمد artwork الذي زوّده المستخدم في SESSION-53 للـlegacy والـadaptive resources.
- Tajawal هو الخط الرسمي الوحيد لواجهة Android وCompose.
- Cairo وAlyamama لا يدخلان production resources.
- أي ظهور مرئي لاسم المنتج القديم `ماكس` أو `MAX` يُستبدل بـ`max`؛ identifiers التقنية التي تتضمن Max/MAX لا تتغير لمجرد الهوية.
- هذه البنود تستبدل فقط قرارات الهوية المرئية المقابلة في ADR-0001؛ بقية ADR-0001 تبقى نافذة.

## العواقب

- SESSION-53 هو خط الأساس الإلزامي لهوية Design System اللاحقة.
- أي تغيير لاحق للاسم المرئي أو launcher أو عائلة الخط يحتاج طلبًا صريحًا وADR جديدًا.
