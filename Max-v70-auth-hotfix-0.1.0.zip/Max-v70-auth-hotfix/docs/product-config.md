# Product Configuration — Frozen in v01

| الإعداد | القيمة |
|---|---|
| اسم التطبيق | ماكس |
| applicationId | `com.maxnetwork.android` |
| namespace | `com.maxnetwork.android` |
| versionName | `0.1.0` |
| versionCode | `1` |
| minSdk | `26` |
| targetSdk | `35` |
| compileSdk | `35` |
| JDK toolchain | `17` |
| لغة الواجهة الأساسية | العربية |
| اتجاه الواجهة | RTL |
| اللون الأساسي | بنفسجي |

لا يتغير الاسم أو الحزمة أو الأيقونة أو القيم الجوهرية دون ADR وطلب صريح.
