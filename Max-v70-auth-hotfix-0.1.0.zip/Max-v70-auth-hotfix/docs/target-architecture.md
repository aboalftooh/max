# Target Architecture — Max V1

## الأسلوب

Modular Monolith لتطبيق Android، مع Max Backend/BFF واحد يفصل التطبيق عن فيرتو. لا Microservices في V1.

## الوحدات المستهدفة

```text
:app
:core:common
:core:model
:core:designsystem
:core:network
:core:database
:core:testing
:feature:auth
:feature:home
:feature:request
:feature:orders
:feature:balance
:feature:profile
:feature:notifications
```

## اتجاه الاعتماد

```text
presentation -> domain <- data
app -> feature + core
feature -> core
feature -X-> feature
Android -X-> Verto DB
```

## التكامل

```text
Android Max -> Max API/BFF -> stable Verto API/events
```

## البيانات

- دفتر الرصيد المالي append-only.
- أحداث فيرتو تستخدم `eventId` و`idempotencyKey`.
- Room قراءة محلية بعد المزامنة، وليس مصدر الحقيقة المالي.
- طلب التطبيق يدخل Outbox ولا ينشئ حركة مالية.
