# Continuous Integration

GitHub Actions يشغل نفس `scripts/verify.sh` المستخدم محليًا. يستخدم JDK 17 وAndroid SDK 35 وGradle cache الرسمي. صلاحيات workflow للقراءة فقط، ولا تُمرر أسرار إلى خطوات البناء.

أي فشل يمنع وصف التنفيذ بالنجاح. التقارير XML/SARIF/HTML وملخص JSON تُرفع كArtifact لمدة 14 يومًا.
