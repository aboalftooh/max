# Verto invoice order projection — v26

## Mapping

| Verto event | Max order direction | Visual status | Source |
|---|---|---|---|
| `SALE_RECORDED` | `OUTGOING` | `PROVIDED` | Original request source, otherwise `VERTO` |
| `PURCHASE_RECORDED` | `INCOMING` | `PROVIDED` | Original request source, otherwise `VERTO` |

## Linking rules

- `payload.requestId` is optional.
- A linked request must exist and belong to the event's `storeId`.
- Linking preserves request text/media references and the original request timestamp.
- An unlinked invoice creates a sanitized Verto order; no competitor name, stock, or invoice lines are exposed.
- One store cannot project the same invoice reference twice.

## Delivery semantics

- `eventId` and `idempotencyKey` are both unique.
- Exact replay returns the existing order and is safe to acknowledge.
- Reused identifiers with different payloads are rejected as conflicts.
- Event persistence and order projection must occur in one database transaction.
- Rejected events are not acknowledged, allowing later handling or investigation.

## Scope boundary

This session handles sale and purchase invoices only. Payments, receipts, corrections, returns, balance movements, and reconciliation start in v27–v31.

- A rejected event blocks cursor advancement so later sessions or operators cannot lose it.
- Composite store-scoped foreign keys enforce request, media, and source-event ownership in PostgreSQL.
