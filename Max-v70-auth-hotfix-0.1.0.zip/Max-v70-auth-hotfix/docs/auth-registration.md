# Android registration flow

## Ownership

- `RegistrationSessionStore` owns registration secrets in memory only.
- Routes carry destination names only; validation tokens, challenge identifiers, and phone numbers never become route arguments.
- `DefaultRegistrationRepository` enforces the order: valid registration code, then phone challenge.
- Leaving the flow clears the temporary registration session.

## النطاق المكتمل حتى v11

- Registration-code screen with one input and contact action.
- Server validation through `MaxGateway`.
- Phone-confirmation screen.
- Registration and phone challenge endpoints enabled in `RetrofitMaxGateway`.
- Invalid, expired, and used codes map to one safe UI error.


## OTP وإنشاء الحساب

- OTP قيمة منطقية واحدة بست خانات؛ الخانات المرئية ليست حقولًا مستقلة.
- اللصق وقارئ الشاشة وعدّاد إعادة الإرسال مدعومة.
- شاشة إنشاء الحساب لا تحتوي الهاتف بعد التحقق منه.
- نجاح الإنشاء يحفظ جلسة المصادقة ثم يمسح جلسة التسجيل المؤقتة.
- إعادة طلب إنشاء الحساب بعد النجاح لا تصل إلى الخادم.
