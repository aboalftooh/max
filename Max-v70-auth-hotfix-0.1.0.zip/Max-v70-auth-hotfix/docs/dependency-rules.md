# Dependency Rules — Enforced from v03

1. `:app` هو Composition Root ومسؤول عن نقطة الدخول والتنقل والحقن.
2. لا تعتمد ميزة على ميزة أخرى مباشرة.
3. `domain` لا يستورد Android أو Room أو Retrofit أو OkHttp.
4. `presentation` لا يعرف DAO أو Retrofit أو OkHttp أو VertoGateway.
5. `data` يطبق عقودًا مملوكة لـ domain ولا يكشف تفاصيل التخزين.
6. `:core:common` للقواعد التقنية العامة الثابتة فقط.
7. `:core:model` لأنواع مشتركة حقيقية مثل Money والمعرفات.
8. `:core:designsystem` للمظهر والمكونات فقط، بلا قواعد عمل.
9. `:core:database` لا يصبح مصدر حقيقة ماليًا.
10. Android لا يقرأ جداول فيرتو؛ التكامل عبر Max API/BFF.

تُفحص القواعد بواسطة `scripts/architecture-check.py` واختبارات `:core:testing`.
11. Backend auth application depends only on domain and ports; HTTP, PostgreSQL, SMS, and crypto implementations are adapters.
12. Tenant identity is resolved from an opaque server-side session; request bodies cannot choose `storeId`.
13. Authentication persistence stores hashes/digests only and never raw credentials or verification secrets.
14. `AuthRepository` هو الحد الوحيد الذي تستخدمه presentation للمصادقة؛ يمنع استيراد `.data.` داخل presentation.
15. `AuthSessionStore` لا يكشف access أو refresh token عبر حالة التطبيق.
16. لا يُسمح بـ`HttpLoggingInterceptor` أو `Log.*` داخل مسار المصادقة.
