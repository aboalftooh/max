# Build Environment

## Required

- Android Studio with Android SDK 35.
- JDK 17 or a compatible newer JDK capable of targeting 17.
- An Android 8.0+ emulator or device for the smoke test.
- Network access on the first build to fetch Gradle and Maven dependencies.

## Wrapper bootstrap

`android/gradlew` bootstraps Gradle 8.10.2 into the normal Gradle user cache on first use. Once Gradle is available, the project can regenerate the official wrapper artifacts with:

```bash
cd android
./gradlew wrapper --gradle-version 8.10.2 --distribution-type bin
```

## SDK path

Create `android/local.properties` locally; never commit it:

```properties
sdk.dir=/absolute/path/to/Android/Sdk
```

## Max API

- يضبط عنوان الإنتاج عبر Gradle property باسم `MAX_API_BASE_URL`.
- يجب أن يبدأ بـ`https://`؛ وإلا يبقى Release في حالة `unconfigured`.
- لا يُحفظ access token أو refresh token داخل ملفات Gradle أو المستودع.
