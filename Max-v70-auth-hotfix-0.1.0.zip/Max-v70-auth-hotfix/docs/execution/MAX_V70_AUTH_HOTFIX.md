# Max v70 authentication hotfix

- Server request path confirmed live through `max-api`.
- Production failure root cause: ambiguous PostgreSQL output-column references (`expires_at`, and related names) in Max auth RPCs.
- Production Supabase RPCs were repaired by qualifying target-table columns.
- OTP verification uses `max_auth_verify_phone_challenge_v2` so failed-attempt counters persist without transaction rollback.
- Android auth mapping now distinguishes a real transport failure (`traceId=network-unavailable`) from HTTP 5xx server failures, preventing misleading “check internet” errors.
- Gradle test execution was blocked locally because Gradle 8.10.2 was not cached and this environment has no internet access.
