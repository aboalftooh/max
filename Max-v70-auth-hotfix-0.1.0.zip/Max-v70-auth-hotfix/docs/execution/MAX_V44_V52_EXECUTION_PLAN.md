# MAX v44–v52 — Execution Plan and Locked Implementation Contract

**Baseline:** `max-v43.zip`  
**Final target:** `max-v52.zip`  
**Execution model:** sequential sessions; every output version is the only valid input for the next session.

---

## 1. Purpose

This plan implements the agreed MAX product direction without allowing the execution agent to redesign architecture, product behavior, flows, or contracts.

MAX remains a **documentation-first companion** to real-world work that mostly happens through WhatsApp, phone calls, and direct contact. The app must optimize for a busy user who wants a correct picture in seconds, not for rich in-app operations.

The final primary navigation is:

1. **الرئيسية**
2. **المحادثات**
3. **الفواتير**
4. **الإعدادات**

The profile is nested inside Settings.

---

## 2. Scientific/reference basis used for the design

The plan follows these sources already present in the project/library:

- `Software Architecture & Design of Modern Large Scale Systems.txt`
  - architecture is the output of design and input to implementation;
  - requirements and constraints must be fixed before coding;
  - incremental change is preferred over uncontrolled redesign.
- `android-architecture-componentsmvvm-with-dagger-retrofit.txt`
  - separation into Presentation / Domain / Data;
  - ViewModels act through use cases and repositories;
  - feature boundaries and testability are preserved.
- `Clean Architecture & SOLID Principles for Android in Kotlin.txt`
  - single responsibility, high cohesion, dependency inversion.
- `Master the fundamentals and advanced features of Kotlin development.txt`
  - keep UI responsive; long-running/network work stays off the UI thread.
- `kotlin-reference.pdf`
  - Kotlin language/reference baseline.
- Existing MAX internal truth:
  - `docs/active-architecture.md`
  - `docs/auth-security.md`
  - `docs/designsystem/max-design-system.md`
  - `docs/source-of-truth/max_product_source_of_truth_v1.md`

Where old MAX product truth conflicts with this plan, **this plan and the v44 Product Source of Truth v2 supersede it**.

---

# 3. Non-negotiable execution rules

## 3.1 Sequential Source of Truth

For every session `vNN`:

- Input MUST be exactly `max-v(NN-1).zip`.
- The agent MUST read:
  1. `docs/execution/MAX_V44_V52_EXECUTION_PLAN.md`
  2. `verification-v(NN-1).md`
  3. `docs/active-architecture.md`
- Output MUST be `max-vNN.zip`.
- Output MUST contain `verification-vNN.md`.
- Output MUST contain `modified-files-vNN.txt`.
- No later session may be executed on an older version.

If the required previous version is absent, stop with `INPUT_VERSION_MISMATCH`.

## 3.2 Agent role

The execution agent is an **implementer only**.

The agent MUST NOT:

- propose another architecture;
- rename features for taste;
- add extra screens or features;
- change the agreed flows;
- replace the custom navigation model with another framework;
- add analytics, reports, dark mode, language switching, account deletion UI, general-purpose chat, payments, or inventory;
- add libraries unless this plan explicitly permits them;
- modify a file outside the session allow-list;
- “fix nearby issues” outside scope.

If a required change needs a non-allowed file, stop with `SCOPE_BLOCKED` and identify that exact file. Do not workaround silently.

## 3.3 No internet / no live server as a gate

No session requires internet access, live Supabase/production access, Git, deployment, or downloading dependencies to be considered executed.

- SQL migrations may be written but MUST NOT be applied to a live server by the agent.
- Build/test commands may run only if the environment already supports them.
- Missing network or Gradle cache is `ENVIRONMENT_NOT_AVAILABLE`, not implementation failure.
- Static contract checks and code inspection remain mandatory.

## 3.4 Protected boundaries

Unless a session explicitly lists the file:

- no financial write path may be added to MAX;
- no direct Android access to Verto tables;
- no tokens/secrets in UI/domain/logs;
- no modification to existing ledger arithmetic;
- no competitor identity or competitor stock exposure;
- no weakening HTTPS, tenant scoping, idempotency, RLS, or append-only ledger rules.

---

# 4. Final product behavior — fixed design

## 4.1 Home / Dashboard

Top to bottom:

1. compact MAX header;
2. notification icon with unread badge;
3. large **الرصيد** card;
4. movement history immediately below;
5. FAB for **طلب جديد**;
6. bottom navigation.

### Balance semantics

- `balance > 0`: **دائن**, green.
- `balance < 0`: **مدين**, red.
- `balance == 0`: neutral.
- Amount is the visual priority.
- No charts or analytics.

### Movement semantics

- `delta < 0` → label **شال** + red.
- `delta > 0` → label **شلنا** + green.
- Each row: label, amount, date, time.
- No action buttons in movement rows.

## 4.2 New Request

One screen only:

- large free-text input;
- directly below it: **كاميرا | المعرض | تسجيل صوتي**;
- attachment preview/state;
- primary button **إرسال الطلب**.

Text/image/audio may be combined.

On successful server acceptance:

- no success interstitial;
- create/resolve the corresponding conversation;
- open that conversation immediately.

Offline rule: an outbox request is not represented as a server conversation until accepted. Do not fabricate a remote conversation ID.

## 4.3 Conversations

Conversation title:

- first nonblank line of original request text;
- trim spaces;
- maximum 80 displayed characters;
- if the request has no text: `طلب قطعة`.

Conversation list row:

- title;
- latest message date + time;
- unread visual marker;
- unread numeric count when > 0.

Ordering: latest message first.

Thread in this execution wave is **documentation/read oriented**:

- initial request message;
- MAX/system follow-up messages;
- text/image/audio rendering where available;
- no general-purpose user chat composer is introduced by this plan.

Unread rule:

- server owns message sequence;
- store has `lastReadSequence` per conversation;
- unread count = server messages after that sequence that are not authored by the store user;
- opening a thread marks read through the latest loaded sequence.

## 4.4 Invoices

Invoice list:

- search field at top;
- search by:
  - invoice number;
  - item name;
  - part number;
- newest first.

Invoice row:

- invoice number;
- date;
- total;
- financial/status label.

Tap opens a **full in-app details screen**, not a Dialog and not a PDF.

Invoice details:

- invoice number/date;
- line items;
- quantity;
- item name;
- part number when present;
- unit value / line total when supplied by Verto;
- invoice total;
- status.

PDF is not required for v44–v52. The internal detail screen is the required source view. PDF can be added later only from a stable invoice snapshot contract.

## 4.5 Notifications

Notification icon is on Home, not Bottom Navigation.

Supported destinations:

- request/message/update → target conversation;
- financial movement → Home;
- invoice notification → invoice details when an invoice target exists;
- otherwise → notifications inbox without guessing a destination.

Tap behavior:

1. mark notification read;
2. resolve typed destination;
3. navigate directly to target.

No raw arbitrary route string may be accepted from push payload.

## 4.6 Settings

Settings contains only:

- **الملف الشخصي**;
- **قفل التطبيق**;
- **الخصوصية**;
- **الدعم**;
- **حول التطبيق**;
- **تسجيل الخروج**.

Explicitly excluded:

- language selection;
- dark mode;
- delete account UI.

### Profile

Contains existing account/profile information plus **تغيير كلمة المرور**.

Password rule everywhere:

- minimum 6 characters;
- maximum 128 characters;
- any characters are allowed: letters, numbers, symbols, or any mixture;
- no forced uppercase/lowercase/digit/symbol composition rule.

### App lock

Use Android system authentication only:

- `BIOMETRIC_STRONG | DEVICE_CREDENTIAL`;
- no custom PIN stored by MAX;
- enabling lock requires successful system authentication first;
- if the device has no secure device credential, option is unavailable with explanatory text;
- lock applies only to authenticated/protected app content;
- cold start while authenticated requires unlock;
- returning after **120 seconds or more** in background requires unlock;
- cancellation keeps protected content hidden.

Privacy contains the privacy policy only.

---

# 5. Session plan

---

# SESSION 44 — Freeze Product Source of Truth v2

**Input:** `max-v43.zip` + this plan  
**Output:** `max-v44.zip`

## Goal

Install the new product/architecture contract inside the repository before any production-code change.

## Required implementation

1. Copy this plan verbatim into:
   - `docs/execution/MAX_V44_V52_EXECUTION_PLAN.md`
2. Create:
   - `docs/source-of-truth/max_product_source_of_truth_v2.md`
3. Create:
   - `docs/adr/ADR-0044-dashboard-conversations-invoices-settings.md`
4. Update `docs/active-architecture.md` with a clearly labeled **Target v52** section; do not claim unimplemented features are already active.
5. Mark v1 product source as historical by reference only; do not delete it.

## Allowed files only

- `docs/execution/MAX_V44_V52_EXECUTION_PLAN.md` **NEW**
- `docs/source-of-truth/max_product_source_of_truth_v2.md` **NEW**
- `docs/adr/ADR-0044-dashboard-conversations-invoices-settings.md` **NEW**
- `docs/active-architecture.md`
- `verification-v44.md` **NEW**
- `modified-files-v44.txt` **NEW**

## Acceptance

- Product v2 contains every behavior in section 4 of this plan.
- It explicitly supersedes conflicting v1 navigation/chat/invoice statements.
- Zero production source files changed.

---

# SESSION 45 — Password Policy 6–128 Everywhere

**Input:** `max-v44.zip`  
**Output:** `max-v45.zip`

## Goal

Replace the current 10-character password minimum with the agreed 6-character rule consistently across backend contract, Android domain validation, ViewModel validation, and UX text.

## Required implementation

- Registration: 6–128.
- Password reset: 6–128.
- Login does not add client composition rules.
- Allow letters, numbers, symbols, or any mixture.
- Preserve hashing/session security and reset-session revocation behavior.

## Allowed files only

- `contracts/api/openapi.yaml`
- `backend/src/main/kotlin/com/maxnetwork/backend/auth/domain/AuthModels.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/auth/domain/AuthValidation.kt`
- `backend/src/test/kotlin/com/maxnetwork/backend/auth/AuthSecurityTest.kt`
- `android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/usecase/RegistrationUseCases.kt`
- `android/feature/auth/src/main/java/com/maxnetwork/feature/auth/domain/usecase/PasswordResetUseCases.kt`
- `android/feature/auth/src/main/java/com/maxnetwork/feature/auth/presentation/AuthViewModel.kt`
- `android/feature/auth/src/main/res/values/strings.xml`
- `android/feature/auth/src/test/java/com/maxnetwork/feature/auth/domain/usecase/LoginUseCaseTest.kt`
- `android/feature/auth/src/test/java/com/maxnetwork/feature/auth/presentation/AuthViewModelTest.kt`
- `verification-v45.md` **NEW**
- `modified-files-v45.txt` **NEW**

## Acceptance

- No remaining user-facing text says 10 characters.
- 5 chars fails; 6 chars succeeds.
- examples such as `abcdef`, `123456`, `!!!!!!`, and `a1!b2@` satisfy the length policy.
- No password is logged or persisted raw.

---

# SESSION 46 — Invoice Snapshot Contract + Backend Read API

**Input:** `max-v45.zip`  
**Output:** `max-v46.zip`

## Goal

Create a read-only invoice snapshot owned by MAX backend, sourced only from Verto events, sufficient for list/search/details.

## Fixed contract

For `SALE_RECORDED` and `PURCHASE_RECORDED`, extend the Verto payload with:

- `invoiceNumber: String`
- `items: List<InvoiceItemSnapshot>`
- each item:
  - `name: String`
  - `partNumber: String?`
  - `quantity: Decimal/String-safe representation`
  - `unitAmountMinorUnits: Long?`
  - `lineTotalMinorUnits: Long?`

Existing `sourceReference`, amount, currency, request linkage, ledger logic remain unchanged.

Expose read-only endpoints:

- `GET /v1/invoices?q=&cursor=&limit=`
- `GET /v1/invoices/{invoiceId}`

Search normalization:

- trim;
- case-insensitive for names/part numbers;
- exact-or-prefix-friendly invoice number matching;
- tenant-scoped;
- server-side pagination.

## Allowed existing files

- `contracts/verto/verto-events.schema.json`
- `contracts/api/openapi.yaml`
- `backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/VertoGateway.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/domain/InvoiceProjectionModels.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/application/VertoInvoiceProjectionService.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/integration/verto/invoice/ports/InvoiceProjectionPorts.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/http/MaxHttpRouter.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/http/BackendHttpModule.kt`
- `backend/src/test/kotlin/com/maxnetwork/backend/integration/verto/invoice/VertoInvoiceProjectionTest.kt`

## Allowed new files

- `backend/src/main/kotlin/com/maxnetwork/backend/invoice/domain/InvoiceReadModels.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/invoice/ports/InvoiceReadPorts.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/invoice/application/InvoiceQueryService.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/invoice/api/InvoiceApi.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/invoice/infrastructure/postgres/PostgresInvoiceReadStore.kt`
- `backend/src/main/resources/db/migration/V012__invoice_read_snapshots.sql`
- `backend/src/test/kotlin/com/maxnetwork/backend/invoice/InvoiceReadApiTest.kt`
- `verification-v46.md`
- `modified-files-v46.txt`

## Acceptance

- Invoice APIs are read-only.
- Tenant is derived from authenticated server session.
- Invoice list cannot expose another store.
- Search finds invoice by number, item name, and part number.
- Ledger code and signed deltas are unchanged.
- No PDF endpoint is added.

---

# SESSION 47 — Android Invoices Feature

**Input:** `max-v46.zip`  
**Output:** `max-v47.zip`

## Goal

Implement invoices as an isolated Android feature with list/search/details, without exposing it in Bottom Navigation yet.

## Fixed architecture

`feature:invoices` uses:

- domain models + repository interface + use cases;
- data repository calling only `MaxGateway`;
- presentation ViewModel + Compose screens;
- no dependency on another feature module.

## Allowed existing files

- `android/settings.gradle.kts`
- `android/app/build.gradle.kts`
- `android/core/network/src/main/kotlin/com/maxnetwork/core/network/ApiModels.kt`
- `android/core/network/src/main/kotlin/com/maxnetwork/core/network/MaxGateway.kt`
- `android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt`
- `android/core/testing/src/main/kotlin/com/maxnetwork/core/testing/FakeMaxGateway.kt`
- `android/app/src/main/java/com/maxnetwork/android/di/MaxAppContainer.kt`
- `android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt`

## Allowed new files

- `android/feature/invoices/build.gradle.kts`
- `android/feature/invoices/src/main/AndroidManifest.xml`
- `android/feature/invoices/src/main/java/com/maxnetwork/feature/invoices/InvoicesFeatureFactory.kt`
- `android/feature/invoices/src/main/java/com/maxnetwork/feature/invoices/domain/InvoiceModels.kt`
- `android/feature/invoices/src/main/java/com/maxnetwork/feature/invoices/domain/InvoiceRepository.kt`
- `android/feature/invoices/src/main/java/com/maxnetwork/feature/invoices/domain/InvoiceUseCases.kt`
- `android/feature/invoices/src/main/java/com/maxnetwork/feature/invoices/data/NetworkInvoiceRepository.kt`
- `android/feature/invoices/src/main/java/com/maxnetwork/feature/invoices/presentation/InvoicesUiState.kt`
- `android/feature/invoices/src/main/java/com/maxnetwork/feature/invoices/presentation/InvoicesViewModel.kt`
- `android/feature/invoices/src/main/java/com/maxnetwork/feature/invoices/presentation/InvoicesScreen.kt`
- `android/feature/invoices/src/main/java/com/maxnetwork/feature/invoices/presentation/InvoiceDetailsScreen.kt`
- `android/feature/invoices/src/test/java/com/maxnetwork/feature/invoices/presentation/InvoicesViewModelTest.kt`
- `verification-v47.md`
- `modified-files-v47.txt`

## Acceptance

- Search debounces or submits without blocking UI.
- Empty/loading/error states exist.
- Details are a full screen, never Dialog/PDF.
- No financial mutation action exists.

---

# SESSION 48 — Conversation Backend + Unread Contract

**Input:** `max-v47.zip`  
**Output:** `max-v48.zip`

## Goal

Introduce durable documentation conversations. Every accepted app request owns one conversation and one initial message.

## Fixed backend model

Conversation:

- `conversationId`
- `storeId`
- `requestId`
- `title`
- `createdAt`
- `lastMessageAt`
- `latestSequence`
- store read cursor / `lastReadSequence`

Message:

- `messageId`
- `conversationId`
- `sequence`
- `authorType = STORE | MAX | SYSTEM`
- `text?`
- `imageMedia?`
- `audioMedia?`
- `createdAt`

One message must contain at least one content form.

Public Android API:

- `GET /v1/conversations`
- `GET /v1/conversations/{conversationId}/messages`
- `POST /v1/conversations/{conversationId}/read`

No public general-purpose send-message endpoint is added in this wave.

Request acceptance transaction must create the conversation idempotently and return `conversationId` in the request receipt.

## Notification target extension

Notification data may carry a typed target:

- `CONVERSATION + id`
- `HOME`
- `INVOICE + id`
- `NONE`

Raw route strings are forbidden.

## Allowed existing files

- `contracts/api/openapi.yaml`
- `backend/src/main/kotlin/com/maxnetwork/backend/request/api/RequestApi.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/request/application/RequestService.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/request/domain/RequestModels.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/request/ports/RequestPorts.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/http/MaxHttpRouter.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/http/BackendHttpModule.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/notification/domain/NotificationModels.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/notification/application/NotificationService.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/notification/api/NotificationApi.kt`
- `backend/src/test/kotlin/com/maxnetwork/backend/request/RequestEndpointTest.kt`
- `backend/src/test/kotlin/com/maxnetwork/backend/notification/NotificationApiTest.kt`

## Allowed new files

- `backend/src/main/kotlin/com/maxnetwork/backend/conversation/domain/ConversationModels.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/conversation/ports/ConversationPorts.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/conversation/application/ConversationService.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/conversation/api/ConversationApi.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/conversation/infrastructure/postgres/PostgresConversationStore.kt`
- `backend/src/main/resources/db/migration/V013__conversation_documentation.sql`
- `backend/src/test/kotlin/com/maxnetwork/backend/conversation/ConversationApiTest.kt`
- `verification-v48.md`
- `modified-files-v48.txt`

## Acceptance

- accepted request → exactly one conversation;
- replay does not duplicate conversation/message;
- title is first nonblank line, max 80 display chars; fallback `طلب قطعة`;
- unread count is server-derived and tenant-scoped;
- mark-read cannot advance beyond latest sequence;
- no generic chat-send endpoint exists.

---

# SESSION 49 — Android Conversations + Request → Conversation Handoff

**Input:** `max-v48.zip`  
**Output:** `max-v49.zip`

## Goal

Implement conversation list/thread and replace the success screen transition with direct conversation opening after accepted request.

## Request screen presentation

Required order:

1. free-text box;
2. camera button;
3. gallery button;
4. audio recording button;
5. attachment state/preview;
6. send button.

Reuse existing private-media, Photo Picker/SAF, camera, audio, outbox, upload, and retry infrastructure. Do not rewrite it.

## Allowed existing files

- `android/settings.gradle.kts`
- `android/app/build.gradle.kts`
- `android/core/network/src/main/kotlin/com/maxnetwork/core/network/ApiModels.kt`
- `android/core/network/src/main/kotlin/com/maxnetwork/core/network/MaxGateway.kt`
- `android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt`
- `android/core/testing/src/main/kotlin/com/maxnetwork/core/testing/FakeMaxGateway.kt`
- `android/app/src/main/java/com/maxnetwork/android/di/MaxAppContainer.kt`
- `android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt`
- `android/app/src/main/java/com/maxnetwork/android/MaxApp.kt`
- `android/feature/request/src/main/java/com/maxnetwork/feature/request/domain/RequestOutbox.kt`
- `android/feature/request/src/main/java/com/maxnetwork/feature/request/data/DefaultRequestOutboxRepository.kt`
- `android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestViewModel.kt`
- `android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestPartScreen.kt`
- `android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestImageAttachmentSection.kt`
- `android/feature/request/src/main/java/com/maxnetwork/feature/request/presentation/RequestAudioAttachmentSection.kt`
- `android/feature/request/src/test/java/com/maxnetwork/feature/request/domain/RequestDraftPolicyTest.kt`

## Allowed new files

- `android/feature/conversations/build.gradle.kts`
- `android/feature/conversations/src/main/AndroidManifest.xml`
- `android/feature/conversations/src/main/java/com/maxnetwork/feature/conversations/ConversationsFeatureFactory.kt`
- `android/feature/conversations/src/main/java/com/maxnetwork/feature/conversations/domain/ConversationModels.kt`
- `android/feature/conversations/src/main/java/com/maxnetwork/feature/conversations/domain/ConversationRepository.kt`
- `android/feature/conversations/src/main/java/com/maxnetwork/feature/conversations/domain/ConversationUseCases.kt`
- `android/feature/conversations/src/main/java/com/maxnetwork/feature/conversations/data/NetworkConversationRepository.kt`
- `android/feature/conversations/src/main/java/com/maxnetwork/feature/conversations/presentation/ConversationsUiState.kt`
- `android/feature/conversations/src/main/java/com/maxnetwork/feature/conversations/presentation/ConversationsViewModel.kt`
- `android/feature/conversations/src/main/java/com/maxnetwork/feature/conversations/presentation/ConversationsScreen.kt`
- `android/feature/conversations/src/main/java/com/maxnetwork/feature/conversations/presentation/ConversationThreadScreen.kt`
- `android/feature/conversations/src/test/java/com/maxnetwork/feature/conversations/presentation/ConversationsViewModelTest.kt`
- `verification-v49.md`
- `modified-files-v49.txt`

## Acceptance

- successful accepted request opens its conversation directly;
- `RequestSuccessScreen` is no longer used in the active flow;
- list shows title/date/time/unread marker/unread count;
- opening thread marks read through loaded latest sequence;
- no user message composer is added.

---

# SESSION 50 — Dashboard + Notifications Inbox and Direct Routing

**Input:** `max-v49.zip`  
**Output:** `max-v50.zip`

## Goal

Replace action-card Home with the financial-first dashboard and complete notification presentation/routing.

## Dashboard implementation

- large semantic balance card;
- `دائن` green / `مدين` red / zero neutral;
- movement list directly below;
- `شال` red for negative delta;
- `شلنا` green for positive delta;
- notification icon + unread badge in top area;
- FAB opens New Request;
- no analytics, charts, quick-action grid, incoming/outgoing cards, or profile shortcut.

## Notifications

Create an inbox screen using existing notification repository/use cases and typed target fields from v48.

Tap:

1. mark read;
2. route to Conversation/Home/Invoice when target is valid;
3. if target missing, remain in inbox.

## Allowed files only

- `android/feature/home/src/main/java/com/maxnetwork/feature/home/presentation/HomeScreen.kt`
- `android/feature/home/src/main/java/com/maxnetwork/feature/home/presentation/HomePresentationBoundary.kt`
- `android/feature/balance/src/main/java/com/maxnetwork/feature/balance/presentation/BalanceFormatting.kt`
- `android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/NotificationReadModel.kt`
- `android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/domain/PushModels.kt`
- `android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/presentation/NotificationsPresentationBoundary.kt`
- `android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/presentation/NotificationsScreen.kt` **NEW**
- `android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/presentation/NotificationsUiState.kt` **NEW**
- `android/feature/notifications/src/main/java/com/maxnetwork/feature/notifications/presentation/NotificationsViewModel.kt` **NEW**
- `android/app/src/main/java/com/maxnetwork/android/push/PushNavigation.kt`
- `android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt`
- `android/app/src/main/java/com/maxnetwork/android/MaxApp.kt`
- `android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/MaxIcons.kt`
- `android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/component/MaxStatusCard.kt`
- `verification-v50.md`
- `modified-files-v50.txt`

## Acceptance

- Home can be understood without scrolling through action cards.
- Color is not the only state signal; text/semantics accompany it.
- notification tap never accepts an arbitrary route string.
- FAB opens RequestPart.

---

# SESSION 51 — Settings + Profile Password Change + System App Lock

**Input:** `max-v50.zip`  
**Output:** `max-v51.zip`

## Goal

Create Settings, move Profile under it, add authenticated password change, and protect authenticated content using Android system authentication.

## Authenticated password-change API

Add:

- `POST /v1/profile/password`
- request: `currentPassword`, `newPassword`
- new password 6–128;
- successful change revokes other sessions but preserves/reissues the current session according to existing session contract;
- passwords never logged or returned.

## Settings structure

Rows only:

1. الملف الشخصي
2. قفل التطبيق
3. الخصوصية
4. الدعم
5. حول التطبيق
6. تسجيل الخروج

No language, theme, delete-account row.

## App-lock implementation

- AndroidX Biometric is the only new dependency permitted.
- `BIOMETRIC_STRONG | DEVICE_CREDENTIAL`.
- preference stores only enabled/disabled and last-background timing metadata; no PIN/credential.
- protected UI gate lives in `:app`, not inside a feature.
- 120-second background threshold.

## Allowed existing files

- `contracts/api/openapi.yaml`
- `backend/src/main/kotlin/com/maxnetwork/backend/auth/api/AuthApi.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/auth/application/AuthService.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/auth/domain/AuthModels.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/auth/ports/AuthPorts.kt`
- `backend/src/main/kotlin/com/maxnetwork/backend/auth/infrastructure/postgres/PostgresAuthStore.kt`
- `backend/src/test/kotlin/com/maxnetwork/backend/auth/AuthSecurityTest.kt`
- `android/gradle/libs.versions.toml`
- `android/settings.gradle.kts`
- `android/app/build.gradle.kts`
- `android/app/src/main/AndroidManifest.xml`
- `android/core/network/src/main/kotlin/com/maxnetwork/core/network/ApiModels.kt`
- `android/core/network/src/main/kotlin/com/maxnetwork/core/network/MaxGateway.kt`
- `android/core/network/src/main/kotlin/com/maxnetwork/core/network/RetrofitMaxGateway.kt`
- `android/app/src/main/java/com/maxnetwork/android/MaxApp.kt`
- `android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt`
- `android/app/src/main/java/com/maxnetwork/android/di/MaxAppContainer.kt`
- `android/feature/profile/src/main/java/com/maxnetwork/feature/profile/domain/ProfileRepository.kt`
- `android/feature/profile/src/main/java/com/maxnetwork/feature/profile/domain/usecase/ProfileUseCases.kt`
- `android/feature/profile/src/main/java/com/maxnetwork/feature/profile/data/DefaultProfileRepository.kt`
- `android/feature/profile/src/main/java/com/maxnetwork/feature/profile/presentation/ProfileScreen.kt`
- `android/feature/profile/src/main/java/com/maxnetwork/feature/profile/presentation/ProfileViewModel.kt`
- `android/feature/profile/src/main/java/com/maxnetwork/feature/profile/presentation/PrivacyScreen.kt`

## Allowed new files

- `android/feature/settings/build.gradle.kts`
- `android/feature/settings/src/main/AndroidManifest.xml`
- `android/feature/settings/src/main/java/com/maxnetwork/feature/settings/presentation/SettingsScreen.kt`
- `android/feature/settings/src/main/java/com/maxnetwork/feature/settings/presentation/SettingsUiState.kt`
- `android/app/src/main/java/com/maxnetwork/android/security/AppLockController.kt`
- `android/app/src/main/java/com/maxnetwork/android/security/AppLockStore.kt`
- `android/app/src/main/java/com/maxnetwork/android/security/AppLockGate.kt`
- `android/app/src/androidTest/java/com/maxnetwork/android/AppLockNavigationTest.kt`
- `verification-v51.md`
- `modified-files-v51.txt`

## Acceptance

- profile is reachable from Settings;
- change password is inside Profile;
- delete account is absent from UI;
- system credential/biometric is used, never custom PIN;
- canceling authentication cannot reveal protected content;
- unauthenticated login/registration screens are not blocked by app lock.

---

# SESSION 52 — Bottom Navigation Cutover + Final Integration Gate

**Input:** `max-v51.zip`  
**Output:** `max-v52.zip`

## Goal

Activate the final information architecture and remove old flows from active navigation without deleting still-valid historical/domain code.

## Final Bottom Navigation

Exactly four roots, in this order:

1. `Home` — الرئيسية
2. `Conversations` — المحادثات
3. `Invoices` — الفواتير
4. `Settings` — الإعدادات

Rules:

- bottom bar visible only on authenticated root/tab content;
- hidden on auth, request composer, conversation thread, invoice details, profile, password change, privacy, notifications, and app-lock gate;
- selecting a different tab opens that tab root;
- tapping the already-selected tab returns to that tab root;
- Android system Back pops nested content before leaving the current root.

## Old active routes to retire from UI

- Incoming Orders root entry
- Outgoing Orders root entry
- standalone Balance root entry
- Profile as a root/tab
- Request Success route

Their domain/data code is not deleted unless deletion is required by compilation. They simply cease to be active product navigation.

## Allowed files only

- `android/app/src/main/java/com/maxnetwork/android/MaxApp.kt`
- `android/app/src/main/java/com/maxnetwork/android/navigation/MaxDestination.kt`
- `android/app/src/main/java/com/maxnetwork/android/navigation/MaxBackStack.kt`
- `android/app/src/main/java/com/maxnetwork/android/navigation/MaxTab.kt` **NEW**
- `android/app/src/main/java/com/maxnetwork/android/navigation/MaxTabBackStacks.kt` **NEW**
- `android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/component/MaxBottomNavigation.kt` **NEW**
- `android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/MaxIcons.kt`
- `android/app/src/androidTest/java/com/maxnetwork/android/MaxAppNavigationTest.kt`
- `android/app/src/androidTest/java/com/maxnetwork/android/SessionNavigationTest.kt`
- `android/feature/home/src/main/java/com/maxnetwork/feature/home/presentation/HomeScreen.kt`
- `docs/active-architecture.md`
- `docs/source-of-truth/max_product_source_of_truth_v2.md`
- `verification-v52.md`
- `modified-files-v52.txt`

## Final acceptance gate

All must be true:

- `PASSWORD_MIN_LENGTH = 6`
- `HOME_BALANCE_CARD = YES`
- `HOME_MOVEMENT_HISTORY = YES`
- `HOME_NOTIFICATION_ICON = YES`
- `HOME_REQUEST_FAB = YES`
- `BOTTOM_NAV = HOME|CONVERSATIONS|INVOICES|SETTINGS`
- `PROFILE_NESTED_IN_SETTINGS = YES`
- `DELETE_ACCOUNT_UI = NO`
- `LANGUAGE_SETTING = NO`
- `DARK_MODE_SETTING = NO`
- `APP_LOCK_SYSTEM_CREDENTIAL = YES`
- `REQUEST_SUCCESS_INTERSTITIAL = NO`
- `REQUEST_OPENS_CONVERSATION = YES`
- `CONVERSATION_UNREAD_COUNT = YES`
- `INVOICE_SEARCH_NUMBER = YES`
- `INVOICE_SEARCH_ITEM_NAME = YES`
- `INVOICE_SEARCH_PART_NUMBER = YES`
- `INVOICE_DETAILS_SCREEN = YES`
- `INVOICE_DIALOG = NO`
- `PDF_REQUIRED = NO`
- `MAX_FINANCIAL_WRITES = NO`
- `ANDROID_DIRECT_VERTO_ACCESS = NO`

`SOURCE_OF_TRUTH_READY = YES` only if every line above passes.

---

# 6. Verification format required after every session

Every `verification-vNN.md` must contain:

1. input version;
2. session number;
3. scope executed;
4. exact modified files;
5. exact added files;
6. deleted files (normally none);
7. protected-boundary statement;
8. static verification results;
9. unit/UI/build results if runnable;
10. environment limitations;
11. unresolved blockers;
12. final flag:
   - `SOURCE_OF_TRUTH_READY = YES`, or
   - `SOURCE_OF_TRUTH_READY = NO`.

If `NO`, do not describe the output as a valid baseline for the next session.

---

# 7. Modification-boundary enforcement

For each session:

- generate `modified-files-vNN.txt` from actual changes;
- compare it to that session allow-list;
- any extra production path = FAIL;
- generated build output directories are excluded from the source package;
- do not include `.gradle`, `build/`, IDE caches, APKs, secrets, or local credentials in the source ZIP.

No agent is allowed to expand its own allow-list.

---

# 8. Expected final user experience

A busy user opens MAX and immediately sees the financial position and recent movement. If action is needed, New Request is one FAB away. Sending a request opens its documentation conversation. Conversations surface unread updates. Invoices are searchable by what a spare-parts user actually remembers: invoice number, item name, or part number. Settings contains only account/security/support essentials.

The result is intentionally smaller than a traditional ERP or chat app: MAX documents and exposes the truth quickly while real operational work can remain on WhatsApp, phone, and direct contact.
