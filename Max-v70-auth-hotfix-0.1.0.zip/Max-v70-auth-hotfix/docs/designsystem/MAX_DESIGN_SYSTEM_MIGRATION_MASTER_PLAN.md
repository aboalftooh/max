# MAX — Design System & UX Migration Master Plan

**Baseline code:** `max-v52(1).zip`  
**Inventory baseline:** `MAX_UI_SCREEN_INVENTORY(1).md`  
**Execution range:** SESSION-53 → SESSION-66  
**Platform:** Android / Kotlin / Jetpack Compose / RTL  
**Primary visual reference:** الشاشة الرئيسية المعتمدة من المستخدم (خلفية فاتحة، أسطح بيضاء، نص داكن، أخضر أساسي، بطاقة رصيد Gradient، Bottom Navigation بأربع وجهات وزر + مركزي)  
**Identity assets:** الأيقونة المرفقة + ملفات Tajawal المرفقة  

---

# 0. تصحيح Baseline قبل أي تنفيذ

جرد الشاشات مفيد وصالح كخريطة للتنقل والواجهات، لكن **قسم الهوية فيه لا يطابق كود v52 الفعلي**.

الفحص المباشر لـv52 أثبت الآتي:

- `android/app/src/main/res/values/strings.xml` ما زال يحتوي `app_name = "ماكس"`.
- `ProductIdentity.DISPLAY_NAME` ما زال `"ماكس"`.
- Android window themes ما زالت تستخدم `sans`.
- `Type.kt` ما زال يستخدم `FontFamily.SansSerif`.
- لا توجد ملفات Tajawal داخل `res/font` في v52.
- Launcher foreground الحالي Vector بنفسجي قديم، وليس الأيقونة المرفقة.
- توجد نصوص مرئية `MAX/ماكس` داخل Home وSettings وAppLock وConversation author وغيرها.

لذلك:

> **SESSION-53 هي جلسة تأسيس الهوية الإلزامية، ولا يجوز اعتبار الاسم/الأيقونة/Tajawal منفذة قبل نجاحها.**

كما أن تصنيفات `Current/Mixed/Legacy` في الجرد تصف النظام السابق فقط. بعد اعتماد التصميم الجديد، **كل شاشة Reachable يجب أن تمر Migration أو Verification صريح** حتى لو كانت مصنفة Current سابقًا.

---

# 1. الأساس العلمي/العملي الذي بُنيت عليه الخطة

## Kotlin / Compose

- الالتزام بـKotlin conventions وتنظيم المصدر والواجهات العامة الواضحة.
- Compose declarative UI مع **Unidirectional Data Flow**: state ينزل، events تصعد.
- State hoisting للمكونات القابلة لإعادة الاستخدام والاختبار.
- ViewModel يبقى مالك state المعقد؛ Design System لا يملك business state.
- المكونات العامة stateless قدر الإمكان وتستقبل data + callbacks.

## Architecture

- التصميم المعماري يسبق التنفيذ ويحدد الحدود والقيود قبل تعديل الكود.
- فصل Presentation/Design System عن Domain/Data.
- تقليل كلفة التغيير عبر مصدر حقيقة بصري واحد بدل styles محلية موزعة.
- لا يتم تغيير عقود الأعمال أو التخزين أو الشبكة من خلال مشروع تصميم.

## UX / Human-centric design

- Typography، iconography، navigation، notification، accessibility، compatibility، feedback حالات رئيسية وليست تحسينات اختيارية.
- الواجهة يجب أن تقلل الحمل الذهني وتظهر أهم المعلومات أولًا.
- الحالات Loading/Empty/Error/Offline/Success يجب أن تكون واضحة ومتسقة.
- التصميم يجب أن يعمل مع RTL، تكبير الخط، الشاشات الصغيرة، الوصول عبر TalkBack، ولوحة المفاتيح.

---

# 2. قانون مصدر الحقيقة بين الجلسات

لكل SESSION-N:

1. **Input code الوحيد:** `max-v(N-1).zip`.
2. **Output code الوحيد:** `max-vN.zip`.
3. ممنوع الدمج مع v52 أو أي نسخة أقدم بعد إنتاج نسخة أحدث.
4. ممنوع تنفيذ أي جزء من SESSION-(N+1) مقدمًا.
5. إذا ظهرت مشكلة خارج نطاق الجلسة: تسجل في `docs/designsystem/DESIGN-DEBT.md` ولا تُعالج إلا إن كانت تمنع بناء/اختبار الجلسة الحالية.

ترتيب مصادر الحقيقة داخل كل نسخة:

1. الكود الموجود في النسخة الحالية.
2. `docs/designsystem/CURRENT-DESIGN-STATE.md`.
3. `docs/designsystem/MIGRATION-LEDGER.md`.
4. أحدث `SESSION-HANDOFF-vNN.md`.
5. هذه الخطة `MAX_DESIGN_SYSTEM_MIGRATION_MASTER_PLAN.md`.
6. جرد الشاشات الأصلي كمرجع تعداد فقط.

إذا تعارض الجرد القديم مع الكود: **الكود الحالي يفوز**، ويُحدّث Ledger بدل اختراع تفسير.

---

# 3. مخرجات إلزامية بعد كل جلسة

يجب أن تنتج كل جلسة:

- `max-vN.zip`
- `verification-vN.md`
- `modified-files-vN.txt`
- `SESSION-HANDOFF-vN.md`
- تحديث `docs/designsystem/CURRENT-DESIGN-STATE.md`
- تحديث `docs/designsystem/MIGRATION-LEDGER.md`
- تحديث `docs/designsystem/DESIGN-DEBT.md` عند الحاجة

ويحتوي `SESSION-HANDOFF-vN.md` على:

- Input version.
- Output version.
- الملفات المعدلة.
- ما تم فعلاً.
- ما لم يتم.
- migrations التي أصبحت `MIGRATED`.
- أي عنصر أصبح `REMOVED`.
- نتائج الاختبارات والأوامر.
- أي blockers.
- violations المتبقية في Design Compliance.
- نقطة البداية الدقيقة للجلسة التالية.

---

# 4. حدود المشروع — ما يسمح وما يمنع

## مسموح

- `android/core/designsystem/**`
- Compose UI داخل `android/feature/**/presentation/**`
- App shell/navigation presentation داخل `android/app/**`
- Android resources المتعلقة بالاسم/الأيقونة/الخط/theme.
- presentation-only formatting/state mapping عند الحاجة.
- UI tests / screenshot harness / accessibility semantics.
- debug/androidTest fixtures والبيانات الوهمية الخاصة بالعرض والاختبار.
- حذف UI ميت موثق 0-call-sites في SESSION-65 فقط.

## ممنوع

- تغيير Domain rules.
- تغيير Database schema.
- تغيير API contracts.
- تغيير repository behavior.
- تغيير sync semantics.
- تغيير auth/business validation.
- تغيير server/backend.
- إضافة network dependencies لتسهيل التصميم.
- وضع بيانات وهمية hardcoded داخل Composables الإنتاجية.
- تغيير route semantics لمجرد التصميم.
- حذف ميزة Reachable.

أي UX يتطلب سلوك أعمال جديد يسجل في `DESIGN-DEBT.md` بدل تنفيذه خلسة.

---

# 5. الهوية النهائية الملزمة

## الاسم

- الاسم المرئي الرسمي: **`max`** بالحروف الصغيرة.
- تستبدل كل العلامات المرئية `ماكس` و`MAX` التي تعني اسم المنتج بـ`max`.
- لا تُغيّر identifiers التقنية مثل `MAX_FIREBASE_*` أو enum/class names أو registration-code formats.

## الخط

الخط الوحيد للواجهة: **Tajawal**.

الملفات المسموح باستخدامها من الحزمة المرفقة فقط:

- Tajawal-ExtraLight.ttf
- Tajawal-Light.ttf
- Tajawal-Regular.ttf
- Tajawal-Medium.ttf
- Tajawal-Bold.ttf
- Tajawal-ExtraBold.ttf
- Tajawal-Black.ttf

لا تُنسخ Cairo أو Alyamama إلى المشروع.

### Mapping الأوزان

- 200 → ExtraLight
- 300 → Light
- 400 → Regular
- 500 → Medium
- 700 → Bold
- 800 → ExtraBold
- 900 → Black

لا يوجد ملف SemiBold؛ **لا تستخدم synthetic SemiBold**. استخدم Medium أو Bold حسب role المحدد أدناه.

## الأيقونة

- Launcher icon = **الأيقونة المرفقة من المستخدم**.
- تُجهز legacy + adaptive icon resources من نفس الأصل.
- لا يبقى foreground البنفسجي القديم.
- `android:icon` و`android:roundIcon` يظلان يشيران إلى موارد launcher النهائية.
- `MaxBrandMark` يستخدم نفس الهوية عندما يعرض شعار المنتج داخل التطبيق.

---

# 6. Design Constitution — التصميم المستهدف

## 6.1 ألوان Semantic

هذه هي القيم المرجعية الملزمة ما لم تتطلب Accessibility adjustment موثقًا مع الحفاظ على نفس الهوية:

- `primary = #16A34A`
- `primaryStrong = #087C41`
- `primarySoft = #57C063`
- `onPrimary = #FFFFFF`
- `background = #F7F8FA`
- `surface = #FFFFFF`
- `surfaceSubtle = #F2F4F7`
- `onSurface = #202334`
- `onSurfaceVariant = #6B7280`
- `outline = #E5E7EB`
- `success = #159447`
- `successContainer = #EAF8EF`
- `error = #C62828`
- `errorContainer = #FDECEC`
- `warning = #C58A12`
- `warningContainer = #FFF7E2`

### Gradient

- Hero balance: `primaryStrong → primarySoft`.
- Central primary action may use the same family.
- ممنوع نشر Gradient في كل Card/Button؛ يستخدم فقط للعناصر ذات الأولوية البصرية العليا.

## 6.2 Typography roles — Tajawal فقط

- `displayAmount`: ExtraBold 52sp / 60sp
- `pageTitle`: Bold 28sp / 36sp
- `sectionTitle`: Bold 22sp / 30sp
- `title`: Bold 18sp / 26sp
- `bodyLarge`: Regular 16sp / 26sp
- `body`: Regular 14sp / 22sp
- `label`: Medium 14sp / 20sp
- `metadata`: Regular 12sp / 18sp
- `navLabel`: Medium 12sp / 18sp

Material3 Typography يجب أن تُربط بهذه الأدوار مركزيًا؛ لا `fontSize` محلي داخل Features.

## 6.3 Spacing scale

القيم الوحيدة العامة:

`4, 8, 12, 16, 20, 24, 32, 40, 48 dp`

- screen horizontal inset: 20dp هاتف، 24dp للشاشات الأوسع.
- section gap: 24dp.
- row vertical padding: 14–16dp عبر token، لا أرقام محلية.

## 6.4 Shapes

- small: 10dp
- medium: 16dp
- large: 22dp
- hero: 28dp
- pill: 50%

## 6.5 Elevation / surfaces

- background بدون elevation.
- list/container card: subtle 1–2dp.
- floating primary action: 6dp.
- dialog: Material elevation controlled centrally.
- ممنوع shadow قوي على كل عنصر.

## 6.6 Touch/accessibility

- minimum touch target = 48dp.
- نص عادي contrast >= 4.5:1.
- نص كبير >= 3:1.
- UI indicator/border المهم >= 3:1.
- لا يعتمد status على اللون وحده: لون + نص/أيقونة.
- كل IconButton له contentDescription مناسب.
- Decorative icons تستخدم semantics غير مزعجة.

---

# 7. مكتبة Design System المستهدفة

## Foundations

- `MaxColors`
- `MaxTypography`
- `MaxSpacing`
- `MaxShapes`
- `MaxElevation`
- `MaxSizes`
- `MaxMotion`
- `MaxTheme`
- `MaxStatusColors`

## Primitives

- `MaxText`
- `MaxIcon`
- `MaxDivider`
- `MaxBadge`
- `MaxStatusPill`
- `MaxIconContainer`

## Inputs / Actions

- `MaxPrimaryButton`
- `MaxSecondaryButton`
- `MaxTertiaryButton`
- `MaxDestructiveButton`
- `MaxIconButton`
- `MaxTextField`
- `MaxSearchField`
- `MaxOtpField`

## Structure

- `MaxScaffold`
- `MaxTopBar`
- `MaxBottomNavigation`
- `MaxSectionHeader`
- `MaxListContainer`
- `MaxListRow`
- `MaxBottomActionBar`

## Feedback

- `MaxLoadingState`
- `MaxEmptyState`
- `MaxErrorState`
- `MaxOfflineState`
- `MaxSuccessState`
- `MaxInlineBanner`

## Overlays

- `MaxDialog`
- `MaxConfirmationDialog`

Bottom Sheet لا يُنشأ فقط لأنه موجود في Design System؛ الجرد الحالي فيه 0 Bottom Sheets.

---

# 8. Screen Patterns

## Dashboard pattern

- header + primary metric hero + section list + global nav.
- Home هو reference implementation.

## Searchable List pattern

- TopBar → SearchField → list rows → states/pagination.
- Invoices / Conversations / Notifications حسب الحاجة.

## Details pattern

- TopBar → summary → grouped metadata/content → actions.

## Form pattern

- TopBar → scrollable form sections → attachment/action area → clear primary submit.

## Settings pattern

- section headers + list rows؛ لا Card منفصلة لكل setting.

## Chat pattern

- TopBar → messages/content → existing interaction surface only.
- لا يضاف business capability غير موجود في ViewModel/Domain.

---

# 9. بيانات وهمية آمنة أثناء التطوير

الهدف هو تمكين التصميم والاختبارات ببيانات ثابتة بدون تلويث production logic.

قواعد إلزامية:

- البيانات الوهمية في `src/debug` و/أو `src/androidTest` فقط.
- Screens الإنتاجية تستقبل UiState الحقيقي نفسه.
- لا `if (BuildConfig.DEBUG)` داخل Composable لتغيير business flow.
- لا hardcoded fake balances/invoices/messages داخل production UI.
- لكل شاشة Preview fixture يثبت الحالات الأساسية.
- بيانات الاختبار لا تحتوي أي PII حقيقي.

---

# 10. Migration Ledger

الحالات الوحيدة:

- `UNMIGRATED`
- `IN_PROGRESS`
- `MIGRATED`
- `REMOVED`
- `BLOCKED`

في بداية SESSION-54:

- كل 18 شاشة Reachable = `UNMIGRATED`.
- كل 4 شاشات Unreachable = `UNMIGRATED_DEAD` مؤقتًا حتى SESSION-65.
- Dialogs/overlays/components لها صفوف مستقلة.

شرط الإغلاق النهائي:

- 18/18 Reachable = `MIGRATED`.
- 4/4 dead screens = `REMOVED`.
- 0 `Mixed`.
- 0 `Legacy`.
- 0 design exceptions.

---

# 11. Design Compliance Guard

يُنشأ فحص static داخل المشروع بدون dependency خارجية جديدة.

الهدف: منع رجوع التصميم القديم بعد ترحيل كل ملف.

## مخالفات ممنوعة داخل Feature UI بعد Migration

- `Color(...)` أو hex colors.
- `FontFamily.*`.
- `fontSize = ...sp`.
- `RoundedCornerShape(...)` محلي.
- أرقام spacing/sizes المباشرة `.dp` إلا استثناء موثق مؤقت.
- Material `Button/OutlinedButton/TextButton` عندما يوجد Max equivalent.
- Material `OutlinedTextField/TextField` عندما يوجد Max equivalent.
- Material `Card` كإعادة تنفيذ لمكون موجود.
- `AlertDialog` خارج wrapper المعتمد بعد ترحيل feature.
- Cairo/Alyamama assets/references.
- user-visible `ماكس` أو `MAX` كاسم المنتج.

## Migration-mode

في SESSION-55 يبدأ scanner بallowlist يساوي الملفات غير المرحّلة.
بعد كل جلسة Feature:

- تُحذف ملفات feature المهاجرة من allowlist.
- أي violation جديد = FAIL.

في SESSION-66:

- allowlist يجب أن يصبح فارغًا.

---

# 12. خطة التنفيذ التفصيلية

---

## SESSION-53 — Identity Foundation

**Input:** `max-v52(1).zip` + أيقونة المستخدم + حزمة الخطوط  
**Output:** `max-v53.zip`

### الهدف

تنفيذ الهوية التي لم تُنفذ فعليًا: الاسم `max` + Launcher icon الجديد + Tajawal عالميًا.

### الملفات المسموح تعديلها

- `android/app/src/main/res/values/strings.xml`
- `android/app/src/main/res/values/themes.xml`
- `android/app/src/main/res/values-night/themes.xml`
- `android/app/src/main/res/mipmap*/**`
- `android/app/src/main/res/drawable*/**` المرتبط بالlauncher فقط
- `android/app/src/main/java/com/maxnetwork/android/security/AppLockController.kt`
- `android/app/src/main/java/com/maxnetwork/android/security/AppLockGate.kt`
- `android/core/common/src/main/kotlin/com/maxnetwork/core/common/ProductIdentity.kt`
- tests المرتبطة بـProductIdentity/branding فقط
- `android/core/designsystem/src/main/res/font/**`
- `android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/theme/Type.kt`
- `android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/component/MaxBrandMark.kt`
- `android/core/designsystem/src/main/java/com/maxnetwork/core/designsystem/gallery/MaxComponentGallery.kt`
- user-visible brand strings في أي شاشة Reachable بقدر استبدال اسم المنتج فقط، دون إعادة تصميم أو تغيير منطق؛ يشمل Auth وProfile عند الحاجة لتحقيق شرط 0 old-brand refs.
- `docs/designsystem/**`

### التنفيذ الإلزامي

1. استخراج Tajawal فقط من الحزمة المرفقة.
2. نسخ 7 أوزان Tajawal إلى `res/font` بأسماء Android resource صحيحة.
3. إنشاء `tajawal.xml` font-family mapping للأوزان.
4. إعادة بناء `MaxTypography` بحيث يستخدم Tajawal فقط، وإزالة `FontFamily.SansSerif`.
5. ربط Android window theme بـTajawal بدل `sans`.
6. تغيير `app_name` إلى `max`.
7. تغيير `ProductIdentity.DISPLAY_NAME` إلى `max`.
8. استبدال كل user-visible brand occurrence: `ماكس/MAX` → `max`، مع عدم لمس identifiers التقنية.
9. استبدال launcher artwork القديم بالأيقونة المرفقة وتوليد legacy/adaptive resources اللازمة.
10. تحديث `MaxBrandMark` ليستخدم نفس هوية الأيقونة.
11. تحديث اختبارات الهوية.
12. إنشاء static checks:
   - لا Cairo/Alyamama.
   - لا `FontFamily.SansSerif` في production UI.
   - لا user-visible old brand strings المعروفة.

### ممنوع

- أي إعادة تصميم شاشة.
- تغيير package/applicationId.
- تغيير registration codes أو BuildConfig constants.

### القبول

- Launcher يعرض الأيقونة الجديدة.
- اسم التطبيق تحت الأيقونة = `max`.
- Compose وAndroid theme كلاهما Tajawal.
- 0 Cairo/Alyamama.
- 0 user-visible product-name `ماكس/MAX`.
- tests/build الخاصة بالنطاق PASS أو blocker موثق.

### Handoff

SESSION-54 يبدأ حصريًا من `max-v53.zip`.

---

## SESSION-54 — Design Constitution + Foundations

**Input:** v53 فقط  
**Output:** v54

### الهدف

تحويل التصميم المرجعي إلى Tokens وعقد رسمي قبل لمس الشاشات.

### الملفات المسموح تعديلها

- `android/core/designsystem/**`
- `docs/designsystem/**`
- design-system unit/android tests فقط.

### التنفيذ

1. تثبيت semantic colors المحددة في القسم 6.
2. تثبيت typography roles وتوصيلها بـMaterial3 Typography.
3. تثبيت spacing/shape/elevation/size/motion tokens.
4. إضافة screen content insets وtouch-target token.
5. إنشاء `DESIGN-CONSTITUTION.md`.
6. إنشاء:
   - `CURRENT-DESIGN-STATE.md`
   - `MIGRATION-LEDGER.md`
   - `DESIGN-DEBT.md`
   - `DESIGN-COMPLIANCE-RULES.md`
7. إعادة تصنيف كل Reachable screen = UNMIGRATED مهما كان تصنيف الجرد السابق.
8. توثيق visual reference rules: light background, white surfaces, dark text, controlled green hierarchy, limited gradient.

### القبول

- Foundation values تأتي من مكان مركزي واحد.
- لا Feature modified.
- Tajawal محفوظ.
- docs كاملة وقابلة للاستخدام من الوكيل التالي دون اجتهاد.

---

## SESSION-55 — Core Components + Patterns + Compliance Scanner

**Input:** v54 فقط  
**Output:** v55

### الهدف

بناء الأدوات التي ستستخدمها كل Migration لاحقة، مع حارس يمنع التراجع.

### الملفات المسموح تعديلها

- `android/core/designsystem/**`
- `scripts/**` لفحص design compliance فقط
- `docs/designsystem/**`
- tests الخاصة بالنطاق.

### التنفيذ

إنشاء/توحيد APIs المكونات الواردة في القسم 7، مع:

- stateless API حيث يمكن.
- `state + callbacks` بدل business logic.
- preview لكل component في Light/Dark وRTL.
- states: enabled/disabled/loading/error/selected.
- central list-row/card patterns.
- `MaxOtpField` بدل القياسات المحلية في OTP لاحقًا.
- `MaxDialog` wrapper.
- تحديث component gallery.
- إنشاء `check_design_system_compliance` script/task.
- إنشاء migration allowlist من كل ملفات Feature UI الحالية؛ لا يفشل المشروع بسبب legacy السابق، لكنه يفشل على أي violation في ملف تمت هجرته.

### بيانات وهمية

إنشاء conventions فقط للـPreview fixtures؛ لا تضف fake business repository للإنتاج.

### القبول

- المكونات العامة لا تعتمد على Feature/ViewModel/Repository.
- previews/tests موجودة.
- compliance scanner يعمل وله baseline deterministic.

---

## SESSION-56 — App Shell + Bottom Navigation + Global Navigation UX

**Input:** v55 فقط  
**Output:** v56

### الهدف

تطبيق اللغة البصرية على الغلاف المحيط بكل الشاشات وإصلاح UX التنقل دون تغيير route contracts.

### الملفات المسموح تعديلها

- `android/app/src/main/java/com/maxnetwork/android/MaxApp.kt`
- `android/app/src/main/java/com/maxnetwork/android/navigation/**`
- `android/core/designsystem/**` فقط لإكمال مكون عام ظهر نقصه
- navigation/app-shell tests
- `docs/designsystem/**`

### التصميم

Bottom Navigation:

- 4 وجهات فقط: الرئيسية، المحادثات، الفواتير، الإعدادات.
- Selected = primary green.
- Unselected = onSurface/onSurfaceVariant.
- زر `+` مركزي 64dp، primary action، يفتح RequestPart عبر route الحالي.
- bottom bar سطح أبيض rounded-top/soft elevation وفق reference.
- sub-screens لا تعرض bottom nav.

### UX/navigation

- المحافظة على back stack الصحيح لكل tab إن كانت البنية الحالية تدعمه.
- لا زر Back صوري بلا فعل.
- safe insets وgesture navigation.
- RTL صحيح.
- لا duplicate top bar من shell + feature.

### القبول

- كل destinations الحالية تصل كما قبل.
- back behavior tests pass.
- shell لا يحتوي values/style محلية خارج DS.
- app-shell files تُزال من compliance allowlist.

---

## SESSION-57 — Auth Migration A: Welcome / Login / Forgot / Reset

**Input:** v56 فقط  
**Output:** v57

### النطاق

- `WelcomeScreen`
- `LoginScreen`
- `ForgotPasswordScreen`
- `ResetPasswordScreen`

### الملفات المسموح تعديلها

- ملفات UI لهذه الشاشات فقط داخل `feature/auth/presentation`.
- `core/designsystem` فقط لإصلاح component عام ناقص.
- auth UI tests/preview fixtures.
- docs ledger/state.

### التصميم

- خلفية فاتحة.
- brand mark أعلى الشاشة دون ازدحام.
- عنوان واضح ثم input(s).
- primary action full width.
- الروابط الثانوية tertiary style.
- layout scrollable/IME-aware.
- Error inline موحد.
- Loading داخل الزر بدل spinner منفصل متناقض.

### ممنوع

- تغيير AuthViewModel/repository/business validation إلا presentation-only adapter ضروري ومثبت.

### القبول

- 4/4 screens MIGRATED.
- لا Material Button/TextField مباشر.
- RTL + fontScale 2.0 بلا قص.

---

## SESSION-58 — Auth Migration B: Registration / OTP / Create Account

**Input:** v57 فقط  
**Output:** v58

### النطاق

- `RegistrationCodeScreen`
- `ConfirmPhoneScreen`
- `OtpScreen`
- `CreateAccountScreen`

### التنفيذ الخاص بـOTP

- إزالة 44dp/52dp/1dp المحلية.
- استخدام `MaxOtpField` + tokens.
- focus order واضح.
- paste/keyboard behavior الحالي لا يُكسر.
- error/resend/loading states موحدة.

### القبول

- كل Auth screens الثمانية الآن MIGRATED.
- 0 Mixed داخل Auth.
- all auth UI files خارج allowlist.

---

## SESSION-59 — Home Migration — Reference Screen

**Input:** v58 فقط  
**Output:** v59

### الهدف

جعل Home المرجع البصري النهائي الذي تقاس عليه بقية الشاشات.

### الملفات المسموح تعديلها

- `feature/home/presentation/HomeScreen.kt`
- presentation helpers الخاصة بـHome فقط
- preview/UI tests الخاصة بـHome
- `core/designsystem` لإصلاح generic component فقط
- docs.

### التصميم الملزم

1. Header RTL:
   - عنوان المستخدم/السياق يمين.
   - subtitle muted أسفله.
   - جرس يسار + unread badge.
2. Hero balance card:
   - gradient المحدد.
   - amount كبير أبيض Tajawal ExtraBold.
   - radius hero.
   - لا معلومات ثانوية تشتت داخل البطاقة إلا ما هو موجود أصلًا وضروري.
3. Section header `السجل`.
4. سجل الحركات داخل white list container:
   - الوصف يمين.
   - semantic pill يسار.
   - divider بين الصفوف.
   - status لا يعتمد على اللون فقط.
5. Bottom navigation يأتي من shell ولا يعاد بناؤه محليًا.
6. حالات الرصيد والحركات تستخدم DS feedback components.

### القبول

- Home MIGRATED.
- visual hierarchy مطابق لمرجع التصميم.
- 0 hardcoded style violations.
- screenshot/preview fixtures تغطي: normal/loading/error/empty.

---

## SESSION-60 — Request Part + Image/Audio Attachments

**Input:** v59 فقط  
**Output:** v60

### النطاق

- `RequestPartScreen`
- `RequestImageAttachmentSection`
- `RequestImageAttachmentPreview`
- `RequestAudioAttachmentSection`
- الحالات STA-018..029.

### الهدف

إزالة أقدم Legacy UI فعليًا بدل إخفائه.

### التصميم

- TopBar موحد.
- Form pattern واضح.
- `MaxTextField` بدل OutlinedTextField المباشر.
- attachment area موحد:
  - image action(s) كـDS buttons/icon buttons.
  - preview داخل surface مع delete action واضح.
  - audio states كـstatus row + action button.
- recording/playing/error states لا تعتمد على نص أحمر وحده.
- primary submit action واضح ويمكن الوصول إليه مع keyboard.

### ممنوع

- تغيير upload/recording permissions أو repository semantics.
- تغيير accepted route؛ النجاح الحالي يظل ينتقل إلى ConversationThread ما لم يكن هناك خلل وظيفي منفصل موثق.

### القبول

- RequestPart + image/audio components = MIGRATED.
- 0 Legacy attachment component.
- 0 direct Material Button/TextField.
- permissions denial UI usable.

---

## SESSION-61 — Conversations + Conversation Thread

**Input:** v60 فقط  
**Output:** v61

### النطاق

- `ConversationsScreen`
- `ConversationThreadScreen`
- rows/message cards/states التابعة لهما فقط.

### التصميم

Conversations list:

- Search لا يُضاف إن لم يكن له behavior حالي.
- white list container/rows.
- title/preview/date hierarchy.
- unread badge واضح.
- empty/loading/error موحدة.

Thread:

- TopBar + conversation identity.
- messages/content في hierarchy واضحة.
- الرسائل الواردة/الصادرة تفرق بالalignment/surface مع contrast مناسب.
- timestamp/metadata خافتة.
- أي attachment موجود في model يعرض بصريًا قدر ما تسمح به العقود الحالية فقط.

### قيد وظيفي مهم

إذا لا توجد API/UseCase لإرسال رسالة في الكود الحالي، **لا يخترع الوكيل composer وظيفيًا**. يسجل `MISSING_CHAT_COMPOSER_CAPABILITY` في DESIGN-DEBT بدل UI كاذبة.

### القبول

- الشاشتان MIGRATED.
- unread/read semantics واضحة.
- stale/error state لا يختفي بصريًا إذا كان model يقدمه.

---

## SESSION-62 — Invoices + Invoice Details

**Input:** v61 فقط  
**Output:** v62

### النطاق

- `InvoicesScreen`
- `InvoiceDetailsScreen`

### التصميم

Invoices:

- `MaxSearchField` full width؛ لا Button داخل Row بجانبه.
- list rows موحدة.
- number/date/amount/status hierarchy.
- loading/empty/error/inline error/loading-more عبر DS.

Details:

- summary header.
- grouped invoice facts.
- line items إن كانت موجودة أصلًا.
- totals hierarchy واضحة.
- لا Card لكل حقل منفرد.

### القبول

- الشاشتان MIGRATED.
- 0 local LoadingState/EmptyState duplicates.
- fontScale/RTL/search keyboard behavior pass.

---

## SESSION-63 — Notifications

**Input:** v62 فقط  
**Output:** v63

### النطاق

- `NotificationsScreen`
- notification rows + states فقط.

### التصميم

- title + list.
- unread state = surface/indicator + semantics، لا اللون وحده.
- timestamp metadata.
- notification type icon container.
- loading-more من DS.
- inline error banner من DS.
- `جارٍ الفتح…` state موحدة وغير مزاحمة.

### القبول

- Notifications MIGRATED.
- route resolution unchanged.
- 0 local Button/spinner/error surface duplicates.

---

## SESSION-64 — Settings + Profile + Privacy + AppLock + Dialogs

**Input:** v63 فقط  
**Output:** v64

### النطاق

- `SettingsScreen`
- `ProfileScreen`
- `PrivacyScreen`
- `PasswordChangeDialog`
- Settings About dialog
- `AppLockGate`

### التصميم

Settings:

- section headers + rows.
- profile/privacy/about/support/logout hierarchy.
- switches aligned RTL and minimum touch target.

Profile:

- values grouped logically.
- action rows from DS.
- password dialog uses MaxTextField/MaxDialog.

Privacy:

- readable scroll content، line-height مناسب، width bounded على الشاشات الكبيرة.

AppLock:

- full-screen surface من theme.
- brand name `max`.
- MaxPrimaryButton.
- authenticating/error states واضحة.

### القبول

- Settings/Profile/Privacy/AppLock/Dialog surfaces = MIGRATED.
- Settings scrollable على small screen/fontScale 2.0.
- 0 direct AlertDialog/TextField/Button بعد migration.

---

## SESSION-65 — Remove Dead UI + Eliminate Duplicates

**Input:** v64 فقط  
**Output:** v65

### الهدف

منع بقاء أي شاشة قديمة مختبئة في المشروع.

### العناصر المراد حذف UI الخاص بها بعد إعادة تحقق 0 production call-sites

- `BalanceScreen`
- `IncomingOrdersScreen`
- `OutgoingOrdersScreen`
- `RequestSuccessScreen`
- `OrderContentPanel` وfullscreen image UI إذا لم يبق لها caller إنتاجي.
- presentation-only helpers التي أصبحت orphan بعد الحذف.

### قاعدة صارمة

لا تحذف domain/data models أو route normalization التي تحفظ backward compatibility إلا إذا compile/navigation tests تثبت أنها غير مطلوبة وكانت إزالة ضمن Presentation فقط.

### كذلك

- حذف local loading/empty/error/button/textfield/card implementations التي لم يعد لها استعمال.
- تحديث tests/imports.
- تحديث inventory داخل docs: dead = REMOVED.
- تشغيل compliance scanner على **كل production UI**.

### القبول

- 4/4 dead screens = REMOVED.
- 0 unreachable production Composable من الجرد القديم.
- 0 Legacy.
- 0 Mixed.
- 0 orphan presentation file.

---

## SESSION-66 — Final UX / Accessibility / Responsive / Regression Certification

**Input:** v65 فقط  
**Output:** v66

### الهدف

عدم الاكتفاء بأن "الشاشات تبدو جديدة"؛ إثبات أن النظام كامل ولا يسمح بعودة القديم.

### لا إعادة تصميم جديدة في هذه الجلسة

مسموح فقط إصلاح violations التي تكشفها بوابات التحقق.

### مصفوفة الاختبار الإلزامية

#### Coverage

- 18/18 reachable screens.
- كل dialog/overlay reachable.
- كل Loading/Empty/Error/Success/Offline state القابل للتحفيز.

#### Layout

- widths: 320dp / 360dp / 412dp / 600dp إن أمكن.
- portrait + landscape للشاشات الحساسة.
- fontScale: 1.0 / 1.3 / 2.0.
- RTL Arabic.

#### Accessibility

- TalkBack semantics.
- touch target >=48dp.
- traversal/focus order.
- content descriptions.
- no color-only status.
- contrast checks.

#### Interaction

- keyboard/IME.
- Back behavior.
- tab switching.
- rotate/configuration change حيث relevant.
- no duplicate submit on repeated tap.
- loading disables actions appropriately.

#### Design Compliance

- allowlist = EMPTY.
- 0 hardcoded colors.
- 0 local font family/font size.
- 0 Cairo/Alyamama.
- 0 user-visible old product name.
- 0 direct deprecated Material primitives في Features.
- 0 Legacy/Mixed rows in ledger.

### أوامر التحقق

استخدم أوامر المشروع الموجودة أولًا. إذا البيئة تسمح:

- unit tests.
- lint.
- Compose/androidTest.
- assembleDebug.

لا تضف dependency من الإنترنت فقط لتجاوز غياب أداة اختبار. إذا تعذر device/instrumentation، الجلسة **لا تعلن FINAL PASS**؛ تسجل `BLOCKED_DEVICE_VERIFICATION` مع الأمر المطلوب تشغيله لاحقًا.

### معيار النجاح النهائي

`DESIGN_SYSTEM_MIGRATION = PASS` فقط إذا:

- 18/18 Reachable = MIGRATED.
- 4/4 Dead = REMOVED.
- 0 Legacy.
- 0 Mixed.
- 0 Compliance violations.
- identity = `max` + new icon + Tajawal.
- RTL/fontScale/accessibility gates pass.
- build/tests المطلوبة pass.

---

# 13. شاشة ↔ جلسة Migration Matrix

| Screen | Session |
|---|---:|
| Welcome | 57 |
| Login | 57 |
| Forgot Password | 57 |
| Reset Password | 57 |
| Registration Code | 58 |
| Confirm Phone | 58 |
| OTP | 58 |
| Create Account | 58 |
| Home | 59 |
| Request Part | 60 |
| Conversations | 61 |
| Conversation Thread | 61 |
| Invoices | 62 |
| Invoice Details | 62 |
| Notifications | 63 |
| Settings | 64 |
| Profile | 64 |
| Privacy | 64 |
| AppLock overlay | 64 |
| Balance dead UI | 65 REMOVE |
| Incoming Orders dead UI | 65 REMOVE |
| Outgoing Orders dead UI | 65 REMOVE |
| Request Success dead UI | 65 REMOVE |

---

# 14. Definition of Done لكل شاشة

لا تُكتب `MIGRATED` إلا إذا تحقق كله:

1. تستخدم Tajawal من theme فقط.
2. تستخدم DS colors/tokens فقط.
3. لا style literals محلية غير مستثناة.
4. primary task واضح.
5. Loading/Empty/Error states موحدة.
6. RTL صحيح.
7. fontScale 2.0 لا يكسر المهمة الأساسية.
8. scrolling/IME صحيح.
9. touch targets سليمة.
10. semantics سليمة.
11. navigation/back behavior لم يتراجع.
12. preview/test fixture موجود للحالة الرئيسية.
13. feature file خرج من compliance allowlist.
14. tests الخاصة بالنطاق pass.

---

# 15. Definition of Done للنظام كله

يُمنع إنهاء الخطة على أساس "أغلب الشاشات".

القبول النهائي عددي:

- `reachable_migrated = 18/18`
- `dead_removed = 4/4`
- `legacy_components = 0`
- `mixed_components = 0`
- `design_compliance_violations = 0`
- `identity_old_brand_refs = 0` (مع allowlist تقني فقط)
- `non_tajawal_ui_font_refs = 0`
- `cairo_assets = 0`
- `alyamama_assets = 0`
- `hardcoded_visual_tokens_in_features = 0`

أي قيمة غير صفرية = الخطة غير مكتملة.

---

# 16. أمر تشغيل ثابت للوكيل

استخدم النص التالي في كل مرة:

> افحص النسخة المرفقة أولًا. اقرأ `docs/designsystem/MAX_DESIGN_SYSTEM_MIGRATION_MASTER_PLAN.md` و`CURRENT-DESIGN-STATE.md` و`MIGRATION-LEDGER.md` وآخر `SESSION-HANDOFF`. نفّذ SESSION-XX فقط حرفيًا. لا تقترح حلولًا بديلة، ولا تنفذ جلسة لاحقة، ولا تغيّر ملفات خارج الحدود المحددة. بعد التنفيذ شغّل اختبارات الجلسة، حدّث ملفات مصدر الحقيقة، وأنشئ `max-vXX.zip` و`verification-vXX.md` و`modified-files-vXX.txt` و`SESSION-HANDOFF-vXX.md`. إذا تعذر شرط قبول، لا تعتبر الجلسة ناجحة؛ سجل BLOCKED والسبب والأمر المطلوب لإكمال التحقق.

---

# 17. قرار الخطة

هذه الخطة لا تعتمد على أن المطور "يتذكر" استخدام Design System.

الضمان مبني على خمسة حواجز متراكبة:

1. **Inventory كامل.**
2. **Migration Ledger عددي.**
3. **Design System واحد مركزي.**
4. **Compliance scanner يمنع style المحلي والرجوع للقديم.**
5. **Final gate لا يقبل أي Legacy/Mixed/Dead UI.**

وبذلك تكون المشكلة التي حدثت في المشروع السابق — بقاء شاشات قديمة بعد إنشاء Design System — **فشلًا قابلًا للكشف آليًا، لا مسألة مراجعة بصرية اختيارية**.
