# MAX — Design Compliance Rules

**Established:** SESSION-54 / v54  
**Scanner implementation:** `scripts/check_design_system_compliance` (SESSION-55)  
**Enforcement model:** migration allowlist shrinks after each feature session; empty in SESSION-66.

## 1. Scope

These rules apply to migrated production Compose UI under:

- `android/app/**`
- `android/feature/**`

`android/core/designsystem/**` is the authority that defines the tokens/components and is reviewed by dedicated Design System checks.

## 2. Forbidden in migrated Feature/App UI

- raw `Color(...)` or hexadecimal UI colors;
- `FontFamily.*` or custom feature font families;
- local `fontSize = ...sp`;
- local `RoundedCornerShape(...)`;
- direct spacing/size `.dp` literals unless a temporary exception is recorded;
- Material `Button`, `OutlinedButton`, `TextButton` when a MAX action equivalent exists;
- Material `OutlinedTextField` / `TextField` when a MAX field equivalent exists;
- Material `Card` used to recreate an existing MAX container pattern;
- `AlertDialog` outside the approved MAX wrapper after the relevant feature migration;
- Cairo or Alyamama assets/references;
- user-visible `ماكس` or `MAX` when it means the product name.

## 3. Required foundations

Migrated UI must derive visual decisions from:

- `MaxColors` / `MaterialTheme.colorScheme` supplied by `MaxTheme`;
- `MaxTypeRoles` / `MaxTypography`;
- `MaxSpacing` and `MaxScreenInsets`;
- `MaxShapes` / `MaxPillShape`;
- `MaxElevation`;
- `MaxSizes`;
- `MaxMotion`;
- `MaxStatusColors`.

## 4. Visual reference rules

- page background is light neutral;
- primary content surfaces are white;
- primary text is dark;
- green hierarchy is controlled and action/status-led;
- the approved green gradient is limited to hero/highest-priority use;
- repeated decorative gradients and heavy shadows fail review.

## 5. Accessibility rules

- touch target >= 48dp;
- normal text contrast >= 4.5:1;
- large text >= 3:1;
- important non-text indicators >= 3:1;
- status cannot rely on color alone;
- actionable icons require meaningful descriptions;
- reduced/disabled motion must be respected.

## 6. Migration-mode scanner contract

SESSION-55 implemented the static scanner without new external dependencies. The deterministic baseline is `DESIGN-COMPLIANCE-ALLOWLIST.txt`.

Initial allowlist = all files belonging to not-yet-migrated reachable/dead UI. After each migration session:

1. migrated feature files are removed from the allowlist;
2. any new violation outside the allowlist fails the session;
3. any file marked `MIGRATED` must have zero unapproved violations;
4. exceptions must be temporary, explicit, owned, and recorded in `DESIGN-DEBT.md`;
5. SESSION-66 requires an empty allowlist and zero design exceptions.

## 7. Session boundary

SESSION-54 defined the rules; SESSION-55 implemented the scanner and baseline. Feature/App migration still follows SESSION-56..65.
