# SESSION HANDOFF — v59

## Input / output

- Input: `max-v58.zip` only.
- Output: `max-v59.zip`.
- Executed: `SESSION-59 — Home Migration — Reference Screen`.
- Status: `PASS_WITH_ENVIRONMENT_BUILD_BLOCKER`.
- `SOURCE_OF_TRUTH_READY = YES`.

## Implemented

- Migrated `HomeScreen` to the shared MAX Design System and made it the reference dashboard screen.
- Replaced the local Material `Scaffold` with `MaxScaffold`.
- Removed Home's duplicate local request FAB; the existing centered Request action remains in the authenticated App shell.
- Rebuilt the compact RTL header as context/store title + muted subtitle on the right and notification action with unread badge on the left.
- Extended `MaxIconButton` generically with optional `badgeCount`, including `99+` capping and a stable badge test tag.
- Added generic `MaxHeroContainer` using the approved `primaryStrong → primarySoft` gradient, hero shape, DS padding, and white content color.
- Rebuilt the balance card as the hero with `MaxTypeRoles.displayAmount` and preserved balance status text/semantics.
- Renamed the Home movement section heading to `السجل`.
- Grouped movement history in `MaxListContainer`, added `MaxDivider` between rows, and rendered amount state with semantic `MaxStatusPill` tones.
- Replaced local loading/error/empty presentation with `MaxLoadingState`, `MaxErrorState`, and `MaxEmptyState`.
- Added Home debug preview fixtures for normal/loading/error/empty.
- Repaired and expanded Home instrumentation test source, including `fontScale = 2.0` coverage and shell-owned action verification.
- Added the Home module's missing Compose UI-test dependencies required by its existing `androidTest` source set.
- Removed `HomeScreen.kt` from `DESIGN-COMPLIANCE-ALLOWLIST.txt`.

## Behavior boundaries

- No `BalanceViewModel`, balance repository, data/domain model, formatter, API, backend, route, back-stack, shell navigation, or persistence behavior changed.
- The existing shell Request action continues to navigate to `MaxDestination.RequestPart`.
- No SESSION-60 Request screen or attachment UI was migrated.

## Verification summary

- SESSION-59 static acceptance: PASS (`26/26`).
- Design System: PASS (`44/44`).
- Compliance scanner: PASS (`production_ui=24`, `allowlisted_legacy=16`, `enforced=8`, `violations=0`).
- Architecture: PASS.
- Secret scan: PASS.
- Repository check: PASS.
- Targeted design-compliance tests: PASS (`3/3`).
- Home Android compile/lint/androidTest attempt: environment-blocked before compilation because Gradle `8.10.2` is not cached and DNS cannot resolve `services.gradle.org`.

## Known repository-wide note

The unrelated invoice contract fixture invariant (`invoiceNumber` / `items`) still fails the repository-wide contract suite and reproduces unchanged on pristine v58. SESSION-59 does not modify contracts or invoice fixtures.

## Next start point

SESSION-60 may start exclusively from `max-v59.zip` and migrate Request Part plus image/audio attachment UI.
