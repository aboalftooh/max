# MAX — Migration Ledger

**Initialized:** SESSION-54 / v54  
**Screen baseline:** 22 production screens = 18 reachable + 4 unreachable  
**Rule:** previous `Current/Mixed/Legacy` labels are historical only; every reachable production screen starts the new system as `UNMIGRATED`.

Temporary state `UNMIGRATED_DEAD` was authorized only for unreachable production UI pending mandatory removal in SESSION-65. SESSION-65 removed all such UI; `REMOVED` is now final for the four baseline dead screens.

## Reachable screens — 18/18 MIGRATED, 0/18 UNMIGRATED

| ID | Screen | Route | Source | Status | Target session |
|---|---|---|---|---|---|
| SCR-001 | WelcomeScreen | `welcome` | `feature/auth/.../WelcomeScreen.kt` | `REMOVED` | removed in 68; signed-out root is phone entry |
| SCR-002 | LoginScreen | `login` | `feature/auth/.../LoginScreen.kt` | `MIGRATED` | 57 |
| SCR-003 | RegistrationCodeScreen | `registration/code` | `feature/auth/.../RegistrationScreens.kt` | `MIGRATED` | 58 |
| SCR-004 | ConfirmPhoneScreen | `registration/phone` | `feature/auth/.../RegistrationScreens.kt` | `MIGRATED` | 58 |
| SCR-005 | OtpScreen | `registration/otp` | `feature/auth/.../OtpScreen.kt` | `MIGRATED` | 58 |
| SCR-006 | CreateAccountScreen | `registration/account` | `feature/auth/.../CreateAccountScreen.kt` | `MIGRATED` | 58 |
| SCR-007 | ForgotPasswordScreen | `password/forgot` | `feature/auth/.../PasswordResetScreens.kt` | `MIGRATED` | 57 |
| SCR-008 | ResetPasswordScreen | `password/reset` | `feature/auth/.../PasswordResetScreens.kt` | `MIGRATED` | 57 |
| SCR-009 | HomeScreen | `home` | `feature/home/.../HomeScreen.kt` | `MIGRATED` | 59 |
| SCR-010 | RequestPartScreen | `request` | `feature/request/.../RequestPartScreen.kt` | `MIGRATED` | 60 |
| SCR-011 | ConversationsScreen | `conversations` | `feature/conversations/.../ConversationsScreen.kt` | `MIGRATED` | 61 |
| SCR-012 | ConversationThreadScreen | `conversations/thread/{conversationId}` | `feature/conversations/.../ConversationThreadScreen.kt` | `MIGRATED` | 61 |
| SCR-013 | InvoicesScreen | `invoices` | `feature/invoices/.../InvoicesScreen.kt` | `MIGRATED` | 62 |
| SCR-014 | InvoiceDetailsScreen | `invoices/details/{invoiceId}` | `feature/invoices/.../InvoiceDetailsScreen.kt` | `MIGRATED` | 62 |
| SCR-015 | NotificationsScreen | `notifications` | `feature/notifications/.../NotificationsScreen.kt` | `MIGRATED` | 63 |
| SCR-016 | SettingsScreen | `settings` | `feature/settings/.../SettingsScreen.kt` | `MIGRATED` | 64 |
| SCR-017 | ProfileScreen | `profile` | `feature/profile/.../ProfileScreen.kt` | `MIGRATED` | 64 |
| SCR-018 | PrivacyScreen | `profile/privacy` | `feature/profile/.../PrivacyScreen.kt` | `MIGRATED` | 64 |

## Dead screens — 4/4 REMOVED

| ID | Screen | Legacy route | Source | Status | Required action |
|---|---|---|---|---|---|
| SCR-019 | BalanceScreen | `balance` | `feature/balance/.../BalanceScreen.kt` | `REMOVED` | removed in 65 after 0-call-site proof |
| SCR-020 | IncomingOrdersScreen | `orders/incoming` | `feature/orders/.../OrdersScreen.kt` | `REMOVED` | removed in 65 after 0-call-site proof |
| SCR-021 | OutgoingOrdersScreen | `orders/outgoing` | `feature/orders/.../OrdersScreen.kt` | `REMOVED` | removed in 65 after 0-call-site proof |
| SCR-022 | RequestSuccessScreen | `request/success` legacy | `feature/request/.../RequestSuccessScreen.kt` | `REMOVED` | removed in 65 after 0-call-site proof |

## Reachable dialogs / overlays / independent production components

| ID | Surface | Parent | Status | Target session |
|---|---|---|---|---|
| DIA-001 | About max dialog | Settings | `MIGRATED` | 64 |
| DIA-002 | PasswordChangeDialog | Profile | `MIGRATED` | 64 |
| OVR-001 | AppLockGate full-screen overlay | App/Security | `MIGRATED` | 64 |
| CMP-001 | RequestImageAttachmentSection | Request | `MIGRATED` | 60 |
| CMP-002 | RequestImageAttachmentPreview | Request | `MIGRATED` | 60 |
| CMP-003 | RequestAudioAttachmentSection | Request | `MIGRATED` | 60 |

## Removed dead overlay / independent production components

| ID | Surface | Parent | Status | Required action |
|---|---|---|---|---|
| OVR-002 | ZoomablePrivateImage full-screen Dialog | Orders | `REMOVED` | removed with dead Orders UI in 65 |
| CMP-004 | OrdersScreen shared body | Orders | `REMOVED` | removed with dead Orders UI in 65 |
| CMP-005 | OrderContentPanel | Orders | `REMOVED` | removed with dead Orders UI in 65 |

`CMP-006 MaxComponentGallery` is preview/androidTest tooling, not production UI, and is intentionally outside the production migration count.

## State handling

The 81 inventoried loading/empty/error/success/conditional states inherit the migration status of their owning production screen/component. A parent cannot become `MIGRATED` unless its reachable states satisfy the session acceptance checks.

## Closure gates

- reachable screens: `18/18 MIGRATED`;
- dead screens: `4/4 REMOVED`;
- dead production overlays/components: `REMOVED` in SESSION-65;
- `Mixed = 0`;
- `Legacy = 0`;
- design exceptions = 0;
- compliance allowlist = empty in SESSION-66.

## SESSION-66 final certification

- Static migration certification: `PASS`.
- Reachable: `18/18 MIGRATED`.
- Dead: `4/4 REMOVED`.
- Legacy: `0`; Mixed: `0`; compliance violations: `0`; allowlist: `EMPTY`.
- Connected-device UX/accessibility/responsive certification: `BLOCKED_DEVICE_VERIFICATION` in this environment.
- `DESIGN_SYSTEM_MIGRATION = PASS` is intentionally withheld until `FINAL-DEVICE-VERIFICATION.md` passes on a device/emulator.
