# MAX — Preview Fixture Convention

**Authority:** SESSION-55 / v55

- Preview fixtures are UI-only values; they never instantiate a Feature ViewModel, Repository, network client, database, or production fake.
- Reusable fixture objects belong in `src/debug` or `src/androidTest`; production Composables continue to receive their real `UiState` and callbacks.
- Component previews may use inline synthetic labels/numbers when no domain model is involved.
- No preview fixture contains real PII, credentials, tokens, phone numbers, invoice identifiers, or customer data.
- Preview fixtures cover enabled, disabled, loading, error, selected, empty/offline/success states when the component supports them.
- All shared component previews use `MaxComponentPreviews`: Light + Dark, Arabic locale, RTL through `MaxTheme`.
- No `BuildConfig.DEBUG` branch may alter production business flow to feed a preview.
