# MAX — Design Debt

## DESIGN-53-001 — Old visible product name outside original SESSION-53 file boundaries

**Status:** `RESOLVED`  
**Detected in:** SESSION-53  
**Resolved in:** SESSION-53 corrective pass

The original SESSION-53 candidate contained five reachable visible references to the old Arabic product name in Auth and Privacy.

The user explicitly authorized fixing SESSION-53. The identity-only replacement was applied to:

- `android/feature/auth/src/main/res/values/strings.xml` — 2 references.
- `android/feature/profile/src/main/java/com/maxnetwork/feature/profile/presentation/PrivacyScreen.kt` — 3 references.

No redesign or business behavior was changed. Reachable production UI now contains **0** user-visible `ماكس/MAX` product-name references.

## SESSION-54 review

**Status:** `NO_NEW_BLOCKING_DEBT`

All known reachable visual inconsistencies are intentionally represented by `UNMIGRATED` in `MIGRATION-LEDGER.md` and are assigned to SESSION-57..64; they are not silently treated as compliant debt exceptions. Dead UI is isolated as `UNMIGRATED_DEAD` for SESSION-65 removal. No Feature behavior or route was changed to resolve visual debt during SESSION-54.

## SESSION-55 review

**Status:** `NO_NEW_DESIGN_EXCEPTION`

SESSION-55 added the shared component/pattern library and migration-aware compliance guard without migrating Feature/App UI. The 24 current production Compose UI files are explicitly baselined in `DESIGN-COMPLIANCE-ALLOWLIST.txt`; this is migration state, not an approved design exception. The allowlist must shrink as SESSION-56..65 execute and must be empty in SESSION-66.

Build verification is environment-blocked because Gradle 8.10.2 is not cached and external network access is unavailable. This is recorded as an execution-environment blocker, not design debt.

## SESSION-56 review

**Status:** `NO_NEW_DESIGN_EXCEPTION`

SESSION-56 migrated only the App shell/global navigation and removed `MaxApp.kt` from the compliance allowlist. No Feature UI source was modified. `HomeScreen` still contains its pre-existing request FAB until its assigned SESSION-59 migration; this remains part of the screen's explicit `UNMIGRATED` state rather than a new design exception.

The repository-wide invoice contract invariant failure (`invoiceNumber` / `items`) reproduces unchanged on pristine v55 and is outside SESSION-56. Android Gradle verification remains environment-blocked because Gradle 8.10.2 is not cached and `services.gradle.org` cannot be resolved.

## SESSION-57 review

**Status:** `NO_NEW_DESIGN_EXCEPTION`

SESSION-57 migrated Welcome, Login, Forgot Password and Reset Password to the shared MAX Design System. The three owning production UI files were removed from the compliance allowlist and pass with zero violations. No Auth business/domain/data behavior changed.

Android Gradle verification remains environment-blocked because Gradle 8.10.2 is not cached and `services.gradle.org` cannot be resolved. Dedicated fontScale 2.0 instrumentation coverage was added but cannot execute in this environment for the same blocker.

## SESSION-58 review

**Status:** `NO_NEW_DESIGN_EXCEPTION`

SESSION-58 migrated Registration Code, Confirm Phone, OTP and Create Account to the shared MAX Design System and removed their three owning production UI files from the compliance allowlist. Auth is now fully migrated with zero Mixed files.

The required OTP migration removed the feature-local `BasicTextField`/44dp/52dp/1dp implementation and uses `MaxOtpField`. The generic component was extended only to preserve the prior IME Done contract and to remain usable at larger text scales; no Auth business logic changed.

The legacy `registration-otp-account-check.py` still contains an implementation-shape assertion requiring `BasicTextField` inside Auth presentation. That assertion conflicts with SESSION-58's explicit `MaxOtpField` requirement and is recorded as stale verification debt rather than reintroducing the legacy implementation. The main repository quality gate does not invoke this script.

Android Gradle verification remains environment-blocked because Gradle 8.10.2 is not cached and `services.gradle.org` cannot be resolved.

## SESSION-59 review

**Status:** `NO_NEW_DESIGN_EXCEPTION`

SESSION-59 migrated `HomeScreen` to the approved dashboard reference and removed it from the compliance allowlist. The old feature-local request FAB was removed because the authenticated App shell already owns the centered Request action; no route or navigation behavior was changed.

Two generic Design System extensions were required by the approved reference: `MaxHeroContainer` centralizes the fixed balance gradient/hero shape/content color, and `MaxIconButton` now accepts an optional unread badge. No Feature-local color, type, shape, spacing, size, or motion scale was introduced.

The repository-wide invoice contract fixture failure (`invoiceNumber` / `items`) reproduces unchanged on pristine `max-v58.zip` and remains outside SESSION-59. Android Gradle verification remains environment-blocked because Gradle 8.10.2 is not cached and `services.gradle.org` cannot be resolved.

## SESSION-61 review

**Status:** `OPEN_CAPABILITY_GAPS_NO_DESIGN_EXCEPTION`

SESSION-61 migrated Conversations and Conversation Thread without adding business/network behavior.

### MISSING_CHAT_COMPOSER_CAPABILITY

The current Conversations domain/repository exposes only list read, thread read, and mark-read operations. There is no send-message API, repository method, or UseCase. SESSION-61 therefore intentionally renders no composer or fake send action. A functional composer requires a separate product/backend capability change outside the Design System migration.

### MISSING_CONVERSATION_PREVIEW_CAPABILITY

The current `ConversationSummary` contract exposes title, timestamps, sequence/read counters, and unread count, but no last-message preview text/media summary. SESSION-61 therefore preserves title/date/read hierarchy without inventing preview data or issuing per-row thread reads. Adding a true list preview requires an explicit contract/backend capability change outside this session.

Neither item is a Design System exception. Both screens have zero compliance violations and remain eligible for `MIGRATED` status.

## SESSION-62 review

**Status:** `OPEN_CAPABILITY_GAP_NO_DESIGN_EXCEPTION`

SESSION-62 migrated Invoices and Invoice Details without changing financial or backend contracts.

### MISSING_INVOICE_STATUS_CAPABILITY

The current invoice domain exposes invoice number, kind (`Sale` / `Purchase`), amount and occurrence time, but no payment/status field. SESSION-62 therefore shows the existing invoice kind as a badge and does not invent paid/unpaid/overdue or other financial state. Adding a true invoice status requires an explicit Verto/backend contract change outside this Design System migration.

This is not a Design System exception. Both invoice screens are outside the compliance allowlist and pass the static compliance guard.

## SESSION-63 review

**Status:** `NO_NEW_DESIGN_EXCEPTION`

SESSION-63 migrated `NotificationsScreen` only at the presentation layer. The notification route, `NotificationTarget` resolution, ViewModel, repository, backend and domain contracts remain unchanged.

Unread treatment now combines a selected surface, explicit `غير مقروء` badge and accessibility state description. Loading, empty, error, incremental error, loading-more and routing feedback use shared Design System components; no feature-local spinner, Material button or error surface remains.

The repository-wide invoice contract fixture failure (`invoiceNumber` / `items`) reproduces unchanged on a pristine extraction of `max-v62.zip` and is outside SESSION-63. Android Gradle verification remains environment-blocked because Gradle 8.10.2 is not cached and `services.gradle.org` cannot be resolved.

## SESSION-64 review

**Status:** `NO_NEW_DESIGN_EXCEPTION`

SESSION-64 migrated Settings, Profile, Privacy, AppLockGate, the Settings About dialog and PasswordChangeDialog without changing navigation, ViewModels, domain, repository, network or backend contracts.

A shared `MaxSwitch` primitive was added so the Settings app-lock switch receives the Design System's centralized 48dp minimum touch target. Privacy uses the existing typography scale with a new centralized readable-content maximum width token; no feature-local size scale was introduced.

The four SESSION-64 production UI files are now outside the compliance allowlist and pass with zero violations. The remaining allowlist contains only dead/unreachable UI scheduled for SESSION-65 removal.

### Inherited stale profile UI checker

`scripts/profile-ui-check.py` still asserts the pre-v51 Profile layout (support/privacy/logout/delete rows) and old visible Arabic brand wording in Privacy. It fails unchanged on the pristine `max-v63.zip` input before SESSION-64. SESSION-64 does not reintroduce removed product behavior to satisfy this stale implementation-shape checker; the migration-specific source acceptance and compliance gates are authoritative for this session.

## SESSION-65 review

**Status:** `NO_NEW_DESIGN_EXCEPTION`

SESSION-65 removed all four baseline unreachable screens plus their dead Orders overlay/components after zero-production-call-site verification. The Orders presentation-only state/ViewModel layer and UI tests were removed because no reachable screen consumed them; Orders domain/data/network contracts remain intact.

Backward-compatible route normalization for `balance`, `orders/incoming`, `orders/outgoing`, and legacy `request/success` is intentionally retained. Balance presentation state/formatting remains because Home actively consumes it. The compliance allowlist is now empty and all 20 production Compose UI files pass with zero violations.

The inherited invoice fixture contract failure remains unchanged and outside this migration. Android Gradle execution remains environment-blocked if Gradle 8.10.2 is unavailable locally.

## SESSION-66 review

**Status:** `NO_DESIGN_EXCEPTION_BLOCKED_DEVICE_VERIFICATION`

Final static certification passes with an empty allowlist, 18/18 reachable screens migrated, 4/4 dead screens removed, and zero Legacy/Mixed rows. The inherited native Android theme accent was still the obsolete purple resource; SESSION-66 corrected it to the canonical MAX green and removed the unused legacy purple resource.

Final device certification is blocked in this environment because `adb` is unavailable and Gradle 8.10.2 is not cached. This is an execution-environment blocker, not an approved design exception. `DESIGN_SYSTEM_MIGRATION = PASS` must not be declared until the connected-device matrix in `FINAL-DEVICE-VERIFICATION.md` passes.
