# MAX — Final Device Verification / SESSION-66

Static certification is necessary but not sufficient. Final PASS requires a real Android device/emulator.

## Required matrix

- Reachable screens: 18/18 plus DIA-001, DIA-002 and OVR-001.
- States: every reachable Loading / Empty / Error / Success / Offline state that can be stimulated.
- Widths: 320dp, 360dp, 412dp, 600dp where supported by the emulator/device.
- Orientation: portrait and landscape for layout-sensitive screens.
- Font scale: 1.0, 1.3, 2.0.
- Locale/direction: Arabic RTL.
- Accessibility: TalkBack semantics, traversal/focus order, meaningful icon labels, >=48dp targets, no color-only state, contrast.
- Interaction: IME actions, Back, tab switching, rotation/configuration restoration, repeated-tap submit protection, loading disables actions.

## Required command

From `android/` with a connected device/emulator:

```bash
RUN_CONNECTED_TESTS=1 ../scripts/verify.sh
```

At minimum the connected gate must execute:

```bash
./gradlew :app:connectedDebugAndroidTest --stacktrace
```

Do not mark `DESIGN_SYSTEM_MIGRATION = PASS` until the connected run and the matrix above are recorded as passing.
