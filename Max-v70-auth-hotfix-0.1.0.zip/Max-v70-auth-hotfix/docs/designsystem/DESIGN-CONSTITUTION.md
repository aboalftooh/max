# MAX — Design Constitution

**Authority version:** v54 / SESSION-54  
**Applies to:** all production Android UI in `app` and `feature` modules  
**Visual direction:** light background, white surfaces, dark text, controlled green hierarchy, restrained gradients, RTL-first.

## 1. Non-negotiable principles

1. `core:designsystem` is the single visual source of truth.
2. Feature UI owns presentation state and events, not visual foundations.
3. Tajawal is the only production UI font family.
4. New local color, type, radius, spacing, elevation, size, or motion scales are prohibited.
5. Green communicates brand/action hierarchy; it must not flood ordinary surfaces.
6. Gradients are reserved for the highest visual priority: the balance hero and, when justified, the central primary action.
7. Loading, empty, error, offline, success, and disabled states must be explicit and consistent.
8. Status must never depend on color alone; pair color with text and/or iconography.
9. Every interactive control has at least a 48dp touch target.
10. RTL, font scaling, TalkBack semantics, small screens, and wide screens are acceptance requirements, not post-release polish.

## 2. Semantic colors

Canonical light tokens in `MaxColors`:

| Token | Value | Purpose |
|---|---|---|
| `primary` | `#16A34A` | brand accent/non-text emphasis |
| `primaryStrong` | `#087C41` | text-bearing primary actions / strong hierarchy |
| `primarySoft` | `#57C063` | gradient endpoint / soft brand emphasis |
| `onPrimary` | `#FFFFFF` | content over accessible strong-primary surfaces |
| `background` | `#F7F8FA` | app/page background |
| `surface` | `#FFFFFF` | cards, containers, sheets |
| `surfaceSubtle` | `#F2F4F7` | low-emphasis containers |
| `onSurface` | `#202334` | primary text |
| `onSurfaceVariant` | `#6B7280` | supporting/metadata text |
| `outline` | `#E5E7EB` | restrained borders/dividers |
| `success` | `#159447` | success indicator |
| `successContainer` | `#EAF8EF` | success surface |
| `error` | `#C62828` | error indicator/text |
| `errorContainer` | `#FDECEC` | error surface |
| `warning` | `#C58A12` | warning brand hue |
| `warningContainer` | `#FFF7E2` | warning surface |

### Accessibility aliases

`#16A34A` with white is below 4.5:1 for normal text, so text-bearing primary actions use `primaryStrong (#087C41)` while `primary` remains the approved accent. `warningAccessible (#825900)` is the text/icon foreground on `warningContainer`; the approved `warning` hue remains available for non-text decorative emphasis.

Dark values are centralized in `MaxDarkColors` and preserve the same green semantic family. No feature may define a separate dark palette.

## 3. Gradient rule

Approved hero gradient only:

`primaryStrong (#087C41) → primarySoft (#57C063)`

Allowed uses:

- balance hero;
- central primary action only when it is the dominant page action.

Forbidden: gradients on ordinary list cards, every button, every section header, or decorative backgrounds without hierarchy purpose.

## 4. Typography — Tajawal only

Canonical roles in `MaxTypeRoles`:

| Role | Weight | Size / line height |
|---|---|---|
| `displayAmount` | ExtraBold | `52sp / 60sp` |
| `pageTitle` | Bold | `28sp / 36sp` |
| `sectionTitle` | Bold | `22sp / 30sp` |
| `title` | Bold | `18sp / 26sp` |
| `bodyLarge` | Regular | `16sp / 26sp` |
| `body` | Regular | `14sp / 22sp` |
| `label` | Medium | `14sp / 20sp` |
| `metadata` | Regular | `12sp / 18sp` |
| `navLabel` | Medium | `12sp / 18sp` |

`MaxTypography` maps every Material3 Typography slot to one of these roles. Feature-local `fontSize`, custom `FontFamily`, or synthetic SemiBold are prohibited after migration.

## 5. Spacing and screen insets

Canonical general scale in `MaxSpacing`:

`4, 8, 12, 16, 20, 24, 32, 40, 48 dp`

Semantic spacing:

- section gap: `24dp`;
- row vertical padding: `16dp` token;
- compact/phone horizontal screen inset: `20dp`;
- wide-screen horizontal inset: `24dp`.

A screen chooses compact vs wide at its responsive layout boundary; it does not invent a third inset.

## 6. Shapes

- small: `10dp`
- medium: `16dp`
- large: `22dp`
- hero: `28dp`
- pill: `50%`

Material3 `MaxShapes` maps to this set; `MaxPillShape` is the only pill primitive.

## 7. Elevation

`MaxElevation`:

- background: `0dp`;
- subtle card: `1dp`;
- raised subtle card: `2dp`;
- floating primary action: `6dp`;
- dialog: `6dp`.

Strong repeated shadows are prohibited.

## 8. Size and touch targets

`MaxSizes.minimumTouchTarget = 48dp` is mandatory. Shared fixed dimensions such as input height and canonical icon/state sizes must come from `MaxSizes`, not screen literals.

## 9. Motion

`MaxMotion` centralizes duration families:

- fast: `150ms`;
- standard: `250ms`;
- emphasized: `400ms`;
- status pulse: `1200ms`.

Motion must respect `LocalMaxMotionEnabled`; disabling system animations must not block state changes or navigation.

## 10. Surface hierarchy

Default visual stack:

1. `background` for the page;
2. `surface` for interactive/content containers;
3. `surfaceSubtle` for secondary grouping;
4. `onSurface` for primary text;
5. `onSurfaceVariant` for supporting text;
6. `outline` for restrained separation;
7. green only for actions, status, hero, and selected emphasis.

Do not use a colored card when hierarchy can be communicated with typography, spacing, or a subtle border.

## 11. Accessibility minimums

- normal text contrast: `>= 4.5:1`;
- large text: `>= 3:1`;
- important indicators/borders: `>= 3:1`;
- every `IconButton` has meaningful `contentDescription`;
- decorative icons do not create noisy accessibility nodes;
- status = color + text/icon, never color alone;
- touch targets `>= 48dp`.

Any needed accessibility adjustment must be centralized, documented here, and preserve the approved visual family.

## 12. Migration law

A screen is not considered compliant because it previously looked “Current”. As of v54 all 18 reachable screens are `UNMIGRATED`. They become `MIGRATED` only in their assigned migration session after design-compliance checks pass. The four unreachable production screens remain `UNMIGRATED_DEAD` until SESSION-65 removes them.
