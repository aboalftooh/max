# SESSION HANDOFF — v65

## Input / output

- Input: `max-v64.zip` only.
- Output: `max-v65.zip`.
- Executed: `SESSION-65 — Remove Dead UI + Eliminate Duplicates`.
- Status: `PASS_WITH_ENVIRONMENT_BUILD_BLOCKER`.

## Implemented

- Removed `BalanceScreen` after confirming no production caller; retained Balance ViewModel/formatting/domain because Home consumes them.
- Removed `IncomingOrdersScreen`, `OutgoingOrdersScreen`, shared `OrdersScreen`, `OrderContentPanel`, and full-screen private-image UI.
- Removed orphan Orders presentation-only `OrdersUiState` / `OrdersViewModel` wiring and their UI/state tests.
- Removed `RequestSuccessScreen`; accepted-request behavior remains conversation-thread navigation.
- Reduced the Orders module from Compose UI to domain/data/network responsibilities.
- Emptied `DESIGN-COMPLIANCE-ALLOWLIST.txt`.
- Added a permanent dead-UI regression guard and updated historical Balance/Orders/Request acceptance scripts to the v65 architecture.
- Marked SCR-019..022 and dead Orders components `REMOVED` in the migration ledger.

## Preserved boundaries

- Balance domain/data/network and Home balance projection are unchanged.
- Orders domain/data/network and push target contracts are retained.
- Legacy `balance`, `orders/incoming`, `orders/outgoing`, and `request/success` route normalization remains for backward compatibility.
- No backend/API/business contract was removed.

## Verification summary

See `verification-v65.md` and the v65 log artifacts in the repository root.

## Next start point

SESSION-66 may start exclusively from `max-v65.zip` for final UX/accessibility/responsive/regression certification.
