# Max Design System — v05

## الهوية

- Primary: `#6D28D9`؛ بنفسجي ثابت عالي التباين.
- Positive: أخضر لتم توفيره والوارد.
- Attention: أحمر للطلب المنتظر والأثر السلبي.
- Unavailable: رمادي لغير الموجود.
- الواجهة عربية RTL دائمًا.

## القواعد

- الحد الأدنى للمس 48dp.
- المقاسات والمسافات والحواف من Tokens فقط.
- النص العربي يستخدم Sans Serif النظام دون تضمين ملفات خطوط.
- النبض هادئ 1200ms ويُلغى عندما تكون حركة النظام معطلة.
- اللون ليس الإشارة الوحيدة؛ كل حالة لها وصف semantics وأيقونة.

## المكونات

`MaxPrimaryButton`، `MaxTextField`، `MaxStatusCard`، `MaxTopBar`، `MaxStateScreen`، `MaxErrorMessage`، `MaxBrandMark`.

## المعرض

`MaxComponentGallery` يعرض الحالات الطبيعية وLoading وDisabled وError وحالات الطلب الثلاث. لقطة SVG المرجعية توضح الترتيب، لكن لقطة runtime النهائية تحتاج Android SDK/Emulator.
