# Authentication security — v07

## Implemented flow

1. An operator provisions a store and a 72-hour registration code.
2. `/v1/auth/registration-codes/validate` returns a 15-minute opaque validation grant without consuming the code.
3. `/v1/auth/phone-challenges` creates a six-digit OTP challenge lasting five minutes, with five attempts and a 60-second resend delay.
4. Verification returns a 10-minute opaque phone-verification grant.
5. Account creation atomically consumes the registration code and both grants, creates the user, and issues opaque session tokens.
6. Login verifies the password hash. Logout revokes the session.
7. Password-reset requests return the same response shape for known and unknown phones. A successful reset revokes all existing sessions.

## Persistence rules

- Store only `password_hash`, `secret_digest`, `otp_digest`, `code_digest`, and token digests.
- Never persist raw registration codes, OTPs, reset codes, passwords, access tokens, or refresh tokens.
- Set the request transaction variable `app.store_id` from the authenticated server-side principal before tenant queries.
- Pre-authentication queries run through a restricted backend service role; Android never accesses these tables.

## Concurrency rule

Production account creation must lock the registration code and both grants, conditionally mark the code used, require one affected row, and commit user/session creation in the same transaction.

## Logging rule

Do not log request bodies or credential fields on authentication routes. Logs may contain only route, status, trace ID, duration, and coarse failure category.
