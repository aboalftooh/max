# Active Architecture — v39

## Android

- `:app` هو Composition Root ونقطة تشغيل التطبيق، ويملك التنقل بين وجهات الميزات دون اعتماد ميزة على أخرى.
- `:feature:auth/domain` يملك `AuthRepository`، حالات المصادقة، والـuse cases؛ بلا Android أو Retrofit.
- `:feature:auth/data` يطبق المستودع و`AuthSessionStore` وتخزين Android Keystore، ويصل للشبكة فقط عبر `MaxGateway`.
- `:feature:auth/presentation` يملك شاشة الترحيب، شاشة تسجيل الدخول، `LoginUiState` و`AuthViewModel`.
- `AuthRepository.authState` هو حالة المصادقة الوحيدة المعروضة للتطبيق، ولا تحتوي أي token.
- استعادة الجلسة تبدأ من `AuthViewModel` عند دخول Composition Root للمصادقة.
- `:core:network` يملك `RetrofitMaxGateway`؛ Debug يستخدم `FakeMaxGateway` وRelease يستخدم Max API. عنوان المصادقة الإنتاجي الافتراضي هو Supabase Edge Function `max-api` ويمكن تجاوزه عبر `MAX_API_BASE_URL`.
- عميل المصادقة يقبل HTTPS فقط، وcleartext معطل في Manifest.

## Navigation and home

- `:app` owns a typed `MaxDestination` graph and immutable `MaxBackStack`; feature modules expose screens/actions only.
- Authentication changes replace the graph root instead of stacking duplicate home destinations.
- `:feature:home` owns the RTL home screen and its five one-tap actions; optional store/activity content is absent until real data exists.
- The complete brand header exists only on Home. No bottom navigation is implemented.

## Profile and privacy

- `:feature:profile/domain` owns `ProfileRepository`, profile/support models, and use cases.
- `:feature:profile/data` is the only profile layer allowed to call `MaxGateway`; it keeps only an in-memory cache.
- `:feature:profile/presentation` owns profile/privacy screens and sanitized support-channel events.
- `:app` opens the declared external channel after the domain validates it; profile screens never construct Android intents.

## Session and account lifecycle

- `:app/session` owns cross-feature orchestration through `SessionCoordinator`; features remain independent.
- Logout clears encrypted credentials, temporary authentication inputs, profile cache, and protected navigation state.
- Remote revocation failure never prevents local cleanup.
- Account deletion requires two explicit confirmations and a server-issued tracking ID.
- A failed deletion request keeps the session intact and exposes an actionable error.
- Financial history remains owned by Verto and cannot be deleted or changed by Max; account access is disabled while ledger integrity is preserved.

## Authentication UI flow

1. الترحيب هو نقطة دخول المستخدم غير المسجل.
2. الدخول ينتقل إلى نموذج الهاتف وكلمة المرور.
3. ViewModel يحول نتائج domain إلى حالات UI دون معرفة Retrofit أو التخزين.
4. نجاح المستودع يحدث `AuthState.Authenticated`؛ التطبيق ينقل إلى الرئيسية.
5. الأخطاء تبقى داخل شاشة الدخول مع الاحتفاظ بالإدخال.

## Session lifecycle

1. قراءة الكتلة المشفرة من التخزين.
2. استخدام access token إذا بقي أكثر من 30 ثانية.
3. تنفيذ refresh واحد فقط عند التزامن.
4. تدوير الرمزين وحفظهما ذريًا عند النجاح.
5. الاحتفاظ بالجلسة المشفرة عند فشل الشبكة القابل للمحاولة.
6. مسح الجلسة عند رفض refresh أو خروج المستخدم.

## Backend authentication

- Framework-independent Kotlin modular core: `domain`, `application`, `ports`, `api`, and `infrastructure`.
- PostgreSQL authentication schema with store-scoped RLS is defined by `V001__auth_schema.sql`.
- Passwords are salted PBKDF2-HMAC-SHA256 hashes; all codes, grants, and session tokens are purpose-separated HMAC digests.
- Tenant identity comes from the opaque server session, never from client-selected `storeId`.

## Fixed boundaries

No financial writes from Max, no competitor names, no competitor inventory, no Android access to Verto tables, and no authentication secret in logs.


## v16 — Request draft
`feature:request` now owns pure request domain models and a Room database for the active draft and private attachment references. No financial writes are exposed.


## v17 — Private image media
`feature:request` owns Photo Picker/SAF and external-camera acquisition through FileProvider. Images are re-encoded into the app-private directory before becoming draft references.


## v18 — Private audio media
`feature:request` owns lifecycle-safe AAC/M4A recording and local playback. Runtime microphone permission and audio-focus interruption remain presentation/infrastructure concerns; domain keeps only attachment metadata.

## Request outbox — v20

طلبات التطبيق تُكتب إلى Room Outbox قبل الشبكة. المرفقات تُرفع مستقلًا وتُستأنف بمعرفات رفع محفوظة، ثم يُنشأ الطلب بمفتاح idempotency. WorkManager هو مشغل إعادة المحاولة المقيد بالشبكة.

## Server request acceptance — v21

`backend/request` owns request validation, store-scoped attachment ownership, idempotent persistence, and one internal acceptance notification. The Android outbox remains pending until `POST /v1/requests` returns a receipt; only then may the app open the success screen. Request acceptance has no financial side effect.

## Order content and private media — v25

- `:feature:orders/domain` owns media expiry and content-type policy without Android dependencies.
- `:feature:orders/presentation` renders text, in-memory private images, and streamed audio; it never exposes download or share actions.
- Expired media refreshes through `LoadOrderUseCase`; presentation never calls `MaxGateway` directly.
- `backend/request/media` authorizes the order before issuing a five-minute HMAC-signed HTTPS link.
- Signed URLs are never persisted as durable domain data, and no competitor identity, inventory, or invoice details are rendered.
## Verto invoice-to-order projection — v26

- `backend/integration/verto/invoice` owns sale/purchase projection, idempotency, and acknowledgement policy.
- `SALE_RECORDED` becomes a provided outgoing order; `PURCHASE_RECORDED` becomes a provided incoming order.
- A linked request must belong to the same store; its content, source, and accepted time are preserved.
- Unlinked invoices create sanitized Verto-sourced orders without competitor identity, inventory, or invoice-line details.
- Event inbox and order projection are committed atomically with tenant RLS and unique event, idempotency, and invoice-reference constraints.
- Payment, receipt, correction, return, ledger, and reconciliation paths remain outside v26.


- A rejected event blocks cursor advancement so later sessions or operators cannot lose it.
- Composite store-scoped foreign keys enforce request, media, and source-event ownership in PostgreSQL.
## Invoice financial ledger — v27

- `backend/balance/domain` owns immutable financial movement and store-balance models.
- Sale invoices append `OUTGOING_ORDER` movements with a negative delta; purchase invoices append `INCOMING_ORDER` movements with a positive delta.
- Event inbox, order projection, movement append, and balance update form one atomic unit of work.
- Every store has an independent monotonic ledger sequence and tenant-isolated balance snapshot.
- Exact replay returns the existing movement; concurrent retries cannot double-apply the balance.
- PostgreSQL backfills v26 invoice events, locks the store balance row, enforces one movement per source event, and rejects UPDATE/DELETE on ledger rows.
- Payment, receipt, correction, return, read API implementation, and Android balance UI remain outside v27.
## Verto payments and receipts ledger — v28

- `backend/integration/verto/settlement` owns payment/receipt validation and idempotent projection.
- `PAYMENT_RECORDED` appends a negative `PAYMENT` movement; `RECEIPT_RECORDED` appends a positive `RECEIPT` movement.
- Invoices, payments, and receipts share one store-scoped append-only ledger, balance snapshot, and monotonic sequence.
- Payment and receipt events never create orders and reject any `requestId`.
- The unified synchronizer acknowledges only applied or safe duplicate events; corrections and returns block cursor advancement.
- PostgreSQL uses one financial inbox, a locked balance row, tenant RLS, composite source ownership, and append-only guards.
- Corrections, returns, read API implementation, and Android balance UI remain outside v28.

## Verto corrections and returns ledger — v29

- `backend/integration/verto/adjustment` owns validation and idempotent projection of corrections and returns.
- `CORRECTION_RECORDED` appends a signed `CORRECTION` movement; zero and `Long.MIN_VALUE` are rejected.
- `RETURN_RECORDED` appends a `RETURN` movement that reverses an original sale or purchase direction.
- `causationEventId` must resolve to a same-store, same-currency movement; returns cannot target settlements or adjustments.
- Partial returns share a cause-scoped cumulative limit and cannot exceed the original invoice under concurrency.
- Invoices, settlements, corrections, and returns share one inbox, ledger, store sequence, and balance snapshot.
- Exact replays are safe duplicates; cross-type event IDs, idempotency keys, and source references conflict.
- Corrections and returns never create or rewrite orders; Android and Max API remain financially read-only.
- Balance read API implementation and Android balance UI remain outside v29.


## Tenant-scoped balance read API — v30

- `backend/balance/application` reads the immutable ledger only; it exposes no financial command.
- `BalanceApi` authenticates the opaque access token and derives `storeId` from the server session.
- Movement pages use descending ledger sequence and an HMAC-signed cursor bound to the store.
- Responses omit source event IDs, source references, store IDs, invoice details, and ledger sequence.
- Empty stores return SDG 0 with a null `asOf` and an empty movement page.
- Android `MaxGateway`, fake data, and `feature:balance` domain/data implement the read contract; Compose UI remains outside v30.

## Android balance UI — v31

- `:feature:balance/domain` owns the read-only balance and movement models and use cases.
- `:feature:balance/data` is the only balance layer allowed to call `MaxGateway`.
- `:feature:balance/presentation` owns the screen, state reducer, formatting, and pagination trigger; it has no financial command.
- The signed balance is large and green/positive, red/negative, or neutral/zero without ownership wording.
- Movements preserve server order, deduplicate page overlap by movement ID, and expose no Verto references.
- `:app` constructs `BalanceViewModel`, refreshes on screen entry, and cancels/clears tenant data on logout.

## Tenant-scoped notification inbox — v32

- `backend/notification` owns server-authored notification content, per-store sequencing, idempotent event projection, read pagination, and mark-read state.
- `NotificationApi` derives `storeId` from the authenticated server session and never accepts a tenant selector.
- Notification cursors are HMAC-signed and bound to the store; API responses omit source events, Verto references, sequence numbers, competitor identity, and inventory.
- PostgreSQL `V008__notification_inbox.sql` enforces RLS, source-event uniqueness, immutable content, no deletion, and a write-once read timestamp.
- `:feature:notifications/domain` and `data` implement the read contract without Android UI, Firebase, or feature-to-feature dependencies.
- OS push delivery, device registration, deep links, and runtime permission handling remain outside v32.

## Secure Android push delivery — v33

- `backend/notification` owns authenticated device registration, protected provider tokens, tenant fanout, durable delivery outbox, retry policy, and provider abstraction.
- `PushApi` derives store/user identity from the server session; Android cannot select a tenant.
- FCM tokens are AES-GCM encrypted and identified by a purpose-separated HMAC digest; raw tokens are absent from PostgreSQL.
- `V009__push_device_delivery.sql` enforces tenant RLS, active-token uniqueness, immutable delivery payloads, no deletes, and one delivery per notification/device.
- FCM HTTP v1 is data-only, OAuth-authenticated, HTTPS-only, and omits store IDs, source events, Verto references, competitor identity, and inventory.
- `:feature:notifications/domain` validates schema v1 and the six fixed type-to-target mappings without Android/Firebase dependencies.
- `:app/push` owns Firebase lifecycle integration, Android 13 permission, explicit immutable notifications, token rotation, and typed internal navigation.
- Push can open only Incoming Orders, Outgoing Orders, or Balance. The destination reloads current server truth and the notification is marked read after authenticated consumption.
- Logout attempts remote device unregistration before clearing the local session; failure never blocks local cleanup.
- No notification settings screen or financial command is introduced.

## Protected Android transport — v34

- `:core:network` owns a process-local `BearerTokenStore`; it never persists or logs tokens.
- `:feature:auth` updates the bridge through the session-store boundary on restore, rotation, save, and clear.
- The Retrofit API client adds bearer authorization only to allowlisted protected `/v1` paths.
- Signed media uploads use a separate unauthenticated OkHttp client, preventing credential leakage to storage hosts.

## Profile backend and deletion — v35

- `backend/profile` owns the transport-neutral profile, privacy, support, and deletion API.
- Profile identity and deletion targets come only from `AuthService.authenticate`; Android supplies no user/store selector.
- Account deletion is tracked in `max_auth.account_deletion_request`, immediately disables the user, and revokes sessions.
- Deletion rows are tenant-scoped, immutable in identity, and non-deletable; financial ledger tables are untouched.
- Release Retrofit now implements all profile endpoints instead of delegating to `UnavailableMaxGateway`.


## Protected order and upload backend — v36

- `backend/request/upload` owns authenticated upload-intent validation, store ownership, short-lived HTTPS slot issuance, and no public media URL.
- `backend/request/read` owns tenant-scoped incoming/outgoing reads, deterministic newest-first pagination, store/direction-bound HMAC cursors, and short-lived private media projection.
- Accepted app requests are outgoing `NEEDS_REPLY`; the Verto adapter maps immutable invoice orders to `PROVIDED` without competitor identity, inventory, or money.

## HTTP runtime boundary — v37

- `backend/http` is the sole HTTP transport adapter for the V1 APIs; application modules remain framework-neutral.
- Strict JSON rejects duplicate/unknown fields and oversized bodies. Authorization is derived from a bearer header only.
- JDK `HttpServer` provides a bounded runtime, graceful stop, liveness/readiness, stable errors, and security/no-cache headers.
- Production configuration fails closed on weak/missing secrets or a non-HTTPS public base URL.
- Durable PostgreSQL, object-storage completion, SMS, and FCM credentials remain deployment adapters and are never embedded in the repository.

## Durable PostgreSQL authentication — v38

- `backend/auth/infrastructure/postgres` implements the complete `AuthStore` contract through JDBC without leaking SQL into application services.
- Store provisioning, registration grants, OTP, password reset, sessions, account identity, and deletion requests share one database transaction boundary.
- Mutable authentication reads use `FOR UPDATE`; writes require exactly one affected row.
- The adapter executes with `row_security = off` and therefore requires a dedicated schema-owner/BYPASSRLS service role; an under-privileged role fails closed instead of returning partial cross-tenant authentication data.
- Production JDBC configuration requires PostgreSQL server-certificate verification and redacts credentials from diagnostics.
- `PostgresAuthSchemaProbe` feeds runtime readiness; migrations remain deployment-controlled.
- Request, ledger, notification, push, and media stores remain in-memory until their own durable adapters are installed.


## Durable PostgreSQL requests and media — v39

- `backend/request/infrastructure/postgres` implements durable app-request and upload ownership ports through JDBC.
- Request acceptance re-locks the authenticated user and every referenced upload, then inserts the request and acceptance outbox atomically.
- `PostgresOrderReadStore` merges durable app requests with the Verto-owned order read model while preserving tenant-scoped reads.
- Private media catalog and authorization are database-backed; only completed, linked media can receive a short-lived link.
- Composite foreign keys enforce creator, attachment, request, and outbox tenant ownership. Accepted requests and terminal upload identity are immutable.
- `PostgresRequestRuntime` has no in-memory fallback and exposes a request-schema readiness probe.
- Object bytes, storage callbacks, financial projection, notifications, and push persistence remain separate deployment boundaries.

---

# v52 Active Architecture — Session 52

> Session 52 activates this architecture. Where earlier sections describe superseded navigation or product entry points, this v52 section is authoritative.

## Active product navigation

The authenticated app exposes exactly four Bottom Navigation roots, in order:

1. Home / `الرئيسية`
2. Conversations / `المحادثات`
3. Invoices / `الفواتير`
4. Settings / `الإعدادات`

`:app` remains the composition root and navigation owner. Profile is nested under Settings. Incoming Orders, Outgoing Orders, standalone Balance, Profile-root navigation, and Request Success are not active roots/flows in v52 without requiring deletion of still-valid historical/domain code.

## Active Home

Home is financial-first: compact MAX header, notification icon with unread badge, semantic balance card, movement history, and New Request FAB. It contains no charts, analytics, quick-action grid, incoming/outgoing order cards, or profile shortcut.

Balance and movement semantics are fixed by `docs/source-of-truth/max_product_source_of_truth_v2.md`.

## Active request and conversation boundary

Request capture continues to reuse the existing private media, outbox, upload, retry, and idempotency infrastructure. After server acceptance, exactly one tenant-scoped documentation conversation is created/resolved idempotently and the receipt exposes its `conversationId`; Android opens it directly.

An offline/pending outbox request is not a server conversation and cannot fabricate a remote conversation ID.

`backend/conversation` owns durable conversation/message/read-cursor models and tenant-scoped read APIs. Android `:feature:conversations` owns domain/data/presentation layers and call MAX only through `MaxGateway`. No generic public send-message endpoint or general-purpose chat composer is part of this target.

## Active invoice boundary

`backend/invoice` owns a tenant-scoped, read-only invoice snapshot projected from Verto invoice events. Search supports invoice number, item name, and part number with pagination. Android `:feature:invoices` uses domain/repository/use-case/presentation separation and access only `MaxGateway`.

Invoice details are a full in-app screen; PDF is not required. Existing ledger arithmetic is unchanged and MAX gains no financial write capability.

## Active notification navigation

Notifications route through typed destinations only: Conversation, Home, Invoice, or None. Arbitrary raw route strings from push payloads are not accepted. The notification icon belongs on Home rather than Bottom Navigation.

## Active Settings and app security

Settings contains only Profile, App Lock, Privacy, Support, About, and Logout. Language selection, dark mode, and delete-account UI are excluded.

Password creation/reset/change policy is 6–128 characters with no composition requirement. App lock is owned at the `:app` protected-content gate and uses Android system authentication (`BIOMETRIC_STRONG | DEVICE_CREDENTIAL`) only; MAX stores no custom PIN.

## Active protected boundaries

The v52 implementation preserves all fixed safety/architecture boundaries:

- no financial writes from MAX;
- no Android direct access to Verto tables;
- no tokens/secrets in UI, domain, or logs;
- no changes to existing ledger arithmetic;
- no competitor identity or competitor stock exposure;
- no weakening of HTTPS, tenant scoping, idempotency, RLS, or append-only ledger rules;
- feature modules remain isolated and do not depend on other feature modules.

The authoritative product contract is `docs/source-of-truth/max_product_source_of_truth_v2.md`; the sequential implementation contract is `docs/execution/MAX_V44_V52_EXECUTION_PLAN.md`.
