# Max authentication production cutover — v69

- Production endpoint: `https://madkfvggyolmdberzmtb.supabase.co/functions/v1/max-api/`
- Edge Function: `max-api` version 2, active.
- Database migrations applied: `max_auth_edge_api_v1`, `max_auth_verify_attempt_persistence_v2`.
- Supported flow: phone → OTP → resolve verified phone → existing user Dashboard / new user join code → account creation.
- Session refresh and logout are implemented.
- OTP delivery uses the existing BRQSMS runtime secrets; secrets are not stored in the Android source.
- Expired unused Verto join codes no longer keep competitors hidden permanently from the Max candidate list.
- Android Release now has a safe production base URL fallback, so builds no longer silently produce an unconfigured authentication gateway.
- Protected-path token detection accepts nested gateway prefixes such as `/functions/v1/max-api/v1/...`.

Verification:
- `scripts/android-auth-check.py`: 18/18 PASS
- `scripts/registration-flow-check.py`: 13/13 PASS
- `scripts/registration-otp-account-check.py`: 15/15 PASS
- Full Gradle test execution was blocked locally because Gradle 8.10.2 is not cached and external downloads are unavailable in the execution environment.
