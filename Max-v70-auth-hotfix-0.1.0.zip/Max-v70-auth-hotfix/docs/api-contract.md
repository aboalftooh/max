# API Contract Summary — V1

- النسخة: `/v1` و`x-max-contract-version: 2026-07-28`.
- الأخطاء: `ApiError(code, message, traceId, retryable, fieldErrors)`.
- pagination: cursor، حد افتراضي 20 وأقصى 50.
- الوقت: RFC 3339 UTC.
- المال: `minorUnits` عدد صحيح و`currency = SDG`.
- الطلب: `Idempotency-Key` ولا ينشئ حركة مالية.
- الوسائط: upload intent خاص وروابط قصيرة العمر.
- الأوامر المالية: غير موجودة في العقد.

## Authentication transport

- `POST /v1/auth/sessions`: الهاتف وكلمة المرور؛ يعيد access token وrefresh token ووقت الانتهاء.
- `POST /v1/auth/sessions/refresh`: refresh token؛ يدور الزوج ويبطل الجلسة السابقة.
- `DELETE /v1/auth/sessions/current`: يبطل الجلسة الحالية باستخدام Bearer access token.
- إنتاج Android يرفض base URL غير HTTPS.
- لا تُسجل request/response bodies أو Authorization headers.

## Request acceptance (v21)

- `POST /v1/requests` requires `Idempotency-Key`.
- `201` creates a request; `200` returns the already accepted request for the same key.
- The authenticated store owns every referenced completed upload.
- The app endpoint fixes source to `APP`; trusted Verto/team ingestion is separate.
- Acceptance emits one internal notification and never writes a financial movement.
## Verto invoice projection (v26)

- Trusted Verto `SALE_RECORDED` events project `OUTGOING/PROVIDED` orders.
- Trusted Verto `PURCHASE_RECORDED` events project `INCOMING/PROVIDED` orders.
- `requestId` links only to a same-store request; otherwise a sanitized Verto order is created.
- `eventId`, `idempotencyKey`, and store-scoped invoice reference prevent duplicate projection.
- v27 appends invoice-derived balance movements internally; payments, receipts, corrections, and returns remain excluded.

## Invoice ledger (v27)

- Successful sale and purchase events append one immutable movement and update the store balance atomically.
- Balance endpoints remain read-only; no POST/PUT/PATCH/DELETE financial operation is exposed.
- `amount` is absolute, while movement type determines the signed balance effect.
## Verto payments and receipts (v28)

- Trusted `PAYMENT_RECORDED` events append negative `PAYMENT` movements.
- Trusted `RECEIPT_RECORDED` events append positive `RECEIPT` movements.
- These events never create orders and must not carry `requestId`.
- They share the same per-store sequence and balance with invoice movements.
- Android and Max API remain read-only for all financial state.
- Corrections and returns remain unsupported and unacknowledged.


## Verto corrections and returns (v29)

- Trusted `CORRECTION_RECORDED` events append signed `CORRECTION` movements and require `causationEventId`.
- Trusted `RETURN_RECORDED` events append `RETURN` movements against original sale or purchase invoices only.
- Partial returns cannot cumulatively exceed the original invoice amount.
- Corrections and returns never create or modify an order and expose no financial write endpoint to Android.


## Balance reads (v30)

- `GET /v1/balance` returns the authenticated store balance; the client cannot supply a store ID.
- `GET /v1/balance/movements` returns newest-first keyset pages with a maximum limit of 50.
- The cursor is opaque, HMAC-signed, and bound to the authenticated store.
- `amount` is always positive; `delta` carries the signed effect; `balanceAfter` is the resulting balance.
- `asOf` is null only when the store has no movements.
- Source event IDs, Verto references, store IDs, invoice lines, and competitor data are not exposed.
- No financial POST, PUT, PATCH, or DELETE endpoint exists.
