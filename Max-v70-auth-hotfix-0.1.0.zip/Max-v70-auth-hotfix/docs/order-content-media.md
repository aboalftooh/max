# Order content and private media

## Scope

The order panel displays only the request text, private image, and private audio. It does not display competitor identity, inventory, or invoice details.

## Access flow

1. `GET /v1/orders/{orderId}` authorizes the current store.
2. The backend returns newly signed HTTPS media links with absolute expiry.
3. Android refreshes the order when a link is expired or within 15 seconds of expiry.
4. Image bytes remain in memory and HTTP caching is disabled.
5. Audio streams for the current composition and the player is released on exit.

## Failure behavior

- Expired link: show **تحديث الوسائط**.
- Network interruption: retain text and show retryable error.
- Unsupported content type: do not attempt rendering.
- Failed audio/image load: show a local error without logging or exposing the URL.
