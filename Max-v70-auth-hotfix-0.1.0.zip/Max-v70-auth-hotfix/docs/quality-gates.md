# Quality Gates — v04

لا تعتبر الجلسة أو Pull Request ناجحة إلا عند نجاح جميع البوابات المنطبقة.

## البوابات

1. بنية المستودع والملفات الإلزامية.
2. فحص أسرار وملفات اعتماد.
3. Architecture boundaries مع self-test يكشف انتهاكًا محقونًا.
4. ktlint.
5. Detekt بصفر مشاكل.
6. Unit tests لكل وحدات JVM وAndroid.
7. Android Lint بتحويل التحذيرات إلى أخطاء.
8. Debug build.
9. UI smoke على جهاز/محاكي عند تغير نقطة الدخول.

## التشغيل

```bash
./scripts/verify.sh
```

الناتج الآلي في `verification-artifacts/summary.json` و`gates.ndjson`. لا تُحفظ أسرار أو cache داخل التسليم.
