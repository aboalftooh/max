# MAX Product Source of Truth v2

**Status:** Active product Source of Truth at v52  
**Installed by:** Session 44  
**Baseline:** `max-v43.zip`  
**Active baseline:** `max-v52.zip`

## 1. Authority and supersession

This document is the product Source of Truth for the v44–v52 execution wave.

It supersedes conflicting product statements in `docs/source-of-truth/max_product_source_of_truth_v1.md`, specifically old statements about:

- no Bottom Navigation;
- Home as the entry point to every feature;
- Incoming Orders and Outgoing Orders as primary product roots;
- Balance as a standalone primary destination;
- Profile as a primary/root destination;
- the Request Success interstitial;
- the absence of documentation conversations;
- old invoice/list behavior that conflicts with the in-app invoice snapshot/details contract below.

The v1 document remains historical context and MUST NOT be deleted. Statements in v1 that do not conflict with this document remain historical/product background only; implementation decisions for v44–v52 are governed by this v2 document and `docs/execution/MAX_V44_V52_EXECUTION_PLAN.md`.

MAX remains a **documentation-first companion** to real-world work that mostly occurs through WhatsApp, phone calls, and direct contact. It is intentionally smaller than a traditional ERP or general-purpose chat application.

## 2. Fixed primary navigation

The final authenticated Bottom Navigation contains exactly four roots, in this order:

1. **الرئيسية** — Home
2. **المحادثات** — Conversations
3. **الفواتير** — Invoices
4. **الإعدادات** — Settings

Profile is nested inside Settings.

Bottom Navigation is visible only on authenticated root/tab content. It is hidden on authentication screens, the request composer, conversation thread, invoice details, profile, password change, privacy, notifications, and the app-lock gate.

Selecting another tab opens that tab root. Selecting the already-selected tab returns to that tab root. Android system Back pops nested content before leaving the current root.

The following old roots cease to be active product navigation by v52:

- Incoming Orders;
- Outgoing Orders;
- standalone Balance;
- Profile as a root/tab;
- Request Success.

Their still-valid historical/domain code is not required to be deleted.

## 3. Home / Dashboard

The Home screen is financial-first and is ordered as follows:

1. compact MAX header;
2. notification icon with unread badge;
3. large **الرصيد** card;
4. movement history immediately below;
5. FAB for **طلب جديد**;
6. Bottom Navigation.

### 3.1 Balance semantics

- `balance > 0`: **دائن**, green.
- `balance < 0`: **مدين**, red.
- `balance == 0`: neutral.
- The amount is the visual priority.
- No charts or analytics are shown.
- Color is not the only state signal; text/semantics accompany it.

### 3.2 Movement semantics

- `delta < 0` → label **شال** + red.
- `delta > 0` → label **شلنا** + green.
- Each movement row contains label, amount, date, and time.
- Movement rows contain no action buttons.

Home does not contain analytics, charts, a quick-action grid, incoming/outgoing order cards, or a profile shortcut.

## 4. New Request

New Request is a single screen containing, in order:

1. large free-text input;
2. **كاميرا**;
3. **المعرض**;
4. **تسجيل صوتي**;
5. attachment preview/state;
6. primary button **إرسال الطلب**.

Text, image, and audio may be combined.

Existing private-media, Photo Picker/SAF, camera, audio, outbox, upload, retry, and idempotency infrastructure is reused; it is not redesigned in this execution wave.

### 4.1 Accepted request handoff

On successful server acceptance:

- no success interstitial is shown;
- the server creates or resolves the corresponding documentation conversation idempotently;
- the accepted request receipt contains the `conversationId`;
- Android opens that conversation immediately.

### 4.2 Offline rule

An outbox request that has not yet been accepted by the server is **not** represented as a server conversation. MAX MUST NOT fabricate a remote conversation ID while offline or before acceptance.

## 5. Conversations

Conversations are durable documentation threads, not a general-purpose chat system.

### 5.1 Conversation title

The title is derived from the original request:

- use the first nonblank line of request text;
- trim spaces;
- display at most 80 characters;
- if the request has no text, use `طلب قطعة`.

### 5.2 Conversation list

Each row shows:

- title;
- latest message date and time;
- unread visual marker;
- unread numeric count when greater than zero.

Ordering is latest message first.

### 5.3 Conversation thread

The thread is documentation/read oriented and may render:

- the initial request message;
- MAX/system follow-up messages;
- text;
- image media where available;
- audio media where available.

This execution wave MUST NOT introduce a general-purpose store-user message composer or public generic send-message endpoint.

### 5.4 Durable backend model

A Conversation contains:

- `conversationId`;
- `storeId`;
- `requestId`;
- `title`;
- `createdAt`;
- `lastMessageAt`;
- `latestSequence`;
- store read cursor / `lastReadSequence`.

A Message contains:

- `messageId`;
- `conversationId`;
- `sequence`;
- `authorType = STORE | MAX | SYSTEM`;
- `text?`;
- `imageMedia?`;
- `audioMedia?`;
- `createdAt`.

Every message contains at least one content form.

Public Android-facing APIs are:

- `GET /v1/conversations`;
- `GET /v1/conversations/{conversationId}/messages`;
- `POST /v1/conversations/{conversationId}/read`.

### 5.5 Unread rule

The server owns message sequence.

- MAX stores `lastReadSequence` per conversation for the store.
- Unread count equals server messages after `lastReadSequence` that are not authored by the store user.
- Opening a thread marks read through the latest loaded sequence.
- Mark-read cannot advance beyond `latestSequence`.
- Unread calculations and reads are tenant-scoped.

## 6. Invoices

Invoices are a read-only MAX view built from Verto-sourced invoice snapshots. MAX does not perform financial mutation.

### 6.1 Invoice snapshot contract

For `SALE_RECORDED` and `PURCHASE_RECORDED`, the Verto payload includes:

- `invoiceNumber: String`;
- `items: List<InvoiceItemSnapshot>`.

Each invoice item contains:

- `name: String`;
- `partNumber: String?`;
- `quantity: Decimal/String-safe representation`;
- `unitAmountMinorUnits: Long?`;
- `lineTotalMinorUnits: Long?`.

Existing `sourceReference`, amount, currency, request linkage, and ledger logic remain unchanged.

MAX backend exposes read-only endpoints:

- `GET /v1/invoices?q=&cursor=&limit=`;
- `GET /v1/invoices/{invoiceId}`.

Search is tenant-scoped and server-paginated. Search normalization trims input, is case-insensitive for item names/part numbers, and is exact-or-prefix-friendly for invoice numbers.

### 6.2 Invoice list

The list contains a search field at the top and searches by:

- invoice number;
- item name;
- part number.

Results are newest first.

Each row shows:

- invoice number;
- date;
- total;
- financial/status label.

### 6.3 Invoice details

Tapping an invoice opens a **full in-app details screen**, never a Dialog and never a required PDF.

The detail screen shows:

- invoice number/date;
- line items;
- quantity;
- item name;
- part number when present;
- unit value and/or line total when supplied by Verto;
- invoice total;
- status.

PDF is not required for v44–v52. A later PDF feature may only be built from a stable invoice snapshot contract.

## 7. Notifications

The notification icon lives on Home, not in Bottom Navigation.

Notification data uses typed destinations only:

- `CONVERSATION + id`;
- `HOME`;
- `INVOICE + id`;
- `NONE`.

Raw arbitrary route strings from push payloads are forbidden.

Supported behavior:

- request/message/update notification → target conversation;
- financial movement → Home;
- invoice notification → invoice details when an invoice target exists;
- missing/unknown target → notifications inbox without guessing.

On tap:

1. mark notification read;
2. resolve the typed destination;
3. navigate directly to the valid target;
4. when the target is missing, remain in the inbox.

## 8. Settings

Settings contains only:

1. **الملف الشخصي**;
2. **قفل التطبيق**;
3. **الخصوصية**;
4. **الدعم**;
5. **حول التطبيق**;
6. **تسجيل الخروج**.

Explicitly excluded from Settings:

- language selection;
- dark mode;
- delete-account UI.

### 8.1 Profile

Profile contains existing account/profile information plus **تغيير كلمة المرور**.

Authenticated password change uses `POST /v1/profile/password` with `currentPassword` and `newPassword`. Passwords are never logged or returned. Successful change revokes other sessions while preserving/reissuing the current session according to the existing session contract.

### 8.2 Password policy

Every password creation/reset/change policy uses:

- minimum length: 6 characters;
- maximum length: 128 characters;
- any characters are allowed;
- no mandatory uppercase/lowercase/digit/symbol composition rule.

Login MUST NOT add client-side composition rules.

### 8.3 App lock

App lock uses Android system authentication only:

- `BIOMETRIC_STRONG | DEVICE_CREDENTIAL`;
- no custom PIN is stored by MAX;
- enabling lock requires successful system authentication first;
- if the device has no secure device credential, the option is unavailable with explanatory text;
- lock protects only authenticated/protected app content;
- cold start while authenticated requires unlock;
- returning after **120 seconds or more** in background requires unlock;
- cancellation keeps protected content hidden;
- unauthenticated login/registration content is not blocked by app lock.

Only enabled/disabled state and last-background timing metadata may be stored; no device credential is stored by MAX.

### 8.4 Privacy

Privacy contains the privacy policy only.

## 9. Protected boundaries

The following remain non-negotiable:

- no financial write path is added to MAX;
- no direct Android access to Verto tables;
- no tokens or secrets in UI, domain models, or logs;
- no modification to existing ledger arithmetic;
- no competitor identity exposure;
- no competitor stock exposure;
- HTTPS, tenant scoping, idempotency, RLS, and append-only ledger rules are not weakened.

## 10. Explicitly excluded from v44–v52

The execution wave does not add:

- analytics;
- reports;
- dark mode;
- language switching;
- account deletion UI;
- general-purpose chat;
- payments;
- inventory;
- required invoice PDF;
- arbitrary push-route navigation.

## 11. Final v52 product gate

The active v52 baseline is valid only when all of the following are true:

- `PASSWORD_MIN_LENGTH = 6`
- `HOME_BALANCE_CARD = YES`
- `HOME_MOVEMENT_HISTORY = YES`
- `HOME_NOTIFICATION_ICON = YES`
- `HOME_REQUEST_FAB = YES`
- `BOTTOM_NAV = HOME|CONVERSATIONS|INVOICES|SETTINGS`
- `PROFILE_NESTED_IN_SETTINGS = YES`
- `DELETE_ACCOUNT_UI = NO`
- `LANGUAGE_SETTING = NO`
- `DARK_MODE_SETTING = NO`
- `APP_LOCK_SYSTEM_CREDENTIAL = YES`
- `REQUEST_SUCCESS_INTERSTITIAL = NO`
- `REQUEST_OPENS_CONVERSATION = YES`
- `CONVERSATION_UNREAD_COUNT = YES`
- `INVOICE_SEARCH_NUMBER = YES`
- `INVOICE_SEARCH_ITEM_NAME = YES`
- `INVOICE_SEARCH_PART_NUMBER = YES`
- `INVOICE_DETAILS_SCREEN = YES`
- `INVOICE_DIALOG = NO`
- `PDF_REQUIRED = NO`
- `MAX_FINANCIAL_WRITES = NO`
- `ANDROID_DIRECT_VERTO_ACCESS = NO`

`SOURCE_OF_TRUTH_READY = YES` at v52 only if every gate above passes.
